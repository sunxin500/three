create PACKAGE BODY     df_stage_das_pkg IS
  /*==================================================
  Procedure Name :
      df_stage_instance_log
  Description:
      记录das平台接口日志
  Argument:
     p_uuid：             本次请求uuid
     p_service：          服务名称
     p_key：              关键字
     p_request_date:      请求时间
     p_request_content:   请求内容
     p_response_date:     响应时间
     p_response_content:  响应内容
     p_result:            接口调用接口（SUCCESS/FAILURE)
     p_error_log:         p_result='FAILURE'的错误日志
     p_instance_log:      标记是否记录日志
     p_request_log:       标记是否记录请求日志
     p_response_log:      标记是否记录响应日志
     x_msg:               调用结果
  History:
      1.00  2016-11-16  jianfeng.zheng  Creation
      1.00  2018-01-23  Echo.Zeng  update by
  ==================================================*/
  PROCEDURE df_stage_instance_log(p_uuid             IN VARCHAR2,
                                  p_service          IN VARCHAR2,
                                  p_key              IN VARCHAR2,
                                  p_request_date     IN DATE,
                                  p_request_content  IN CLOB,
                                  p_response_date    IN DATE,
                                  p_response_content IN CLOB,
                                  p_result           IN VARCHAR2,
                                  p_error_log        IN CLOB,
                                  p_instance_log     IN VARCHAR2,
                                  p_request_log      IN VARCHAR2,
                                  p_response_log     IN VARCHAR2,
                                  p_token            IN VARCHAR2,
                                  x_msg              OUT VARCHAR2) IS
  BEGIN
    IF p_instance_log = 'N' THEN
      RETURN;
    END IF;
    INSERT INTO df_stage_instance_log
      (id,
       uuid,
       service,
       key,
       request_date,
       request_content,
       response_date,
       response_content,
       RESULT,
       error_log,
       token)
    VALUES
      (df_stage_instance_log_s.nextval,
       p_uuid,
       p_service,
       p_key,
       p_request_date,
       p_request_content,
       p_response_date,
       p_response_content,
       p_result,
       p_error_log,
       p_token);
    x_msg := 'SUCCESS';
  END df_stage_instance_log;

  PROCEDURE df_stage_api_auth(p_token IN VARCHAR2,
                              x_code  OUT VARCHAR2,
                              x_msg   OUT VARCHAR2) IS
     l_user_msg VARCHAR2(300);
    l_count    NUMBER;
    l_username VARCHAR2(50);
  BEGIN
    x_code := 'SUCCESS';
    x_msg  := '{"code":"SUCCESS","user":"';
    BEGIN
      SELECT username
        INTO l_username
        FROM df_stage_token t
       WHERE t.token = p_token;
     -- fusion_app_ctx.set_env('DAS_USER', l_username);
      x_msg := x_msg || l_username || '"}';
    EXCEPTION
      WHEN OTHERS THEN
        x_code := 'FAILED';
        x_msg  := '{"code":"FAILED","devMsg":"TOKEN_TIME_OUT","userMsg":"登录过期请重新登录"}';
    END;
  END;
  PROCEDURE df_stage_login_success(p_uid      IN VARCHAR2,
                                   p_platform IN VARCHAR2,
                                   x_token    OUT VARCHAR2,
                                   x_json     OUT VARCHAR2) IS
    l_json pl_json := pl_json;
    l_role VARCHAR2(2000);
  BEGIN
    --1.生成32位token
    x_token := dbms_random.string('A', 32);
    --2.保存token
    INSERT INTO df_stage_token
      (id,
       token,
       username,
       platform,
       last_invoke_date,
       creation_date,
       is_expired)
    VALUES
      (df_stage_token_s.nextval,
       x_token,
       p_uid,
       p_platform,
       SYSDATE,
       SYSDATE,
       'N');
    l_json.set_value('token', x_token);
    l_json.set_value('userId', p_uid);
    l_json.set_value('userRole', l_role);
    x_json := to_char(l_json.to_json);
  EXCEPTION
    WHEN OTHERS THEN
      l_json.fail('未知操作,请联系管理员');
      x_json := to_char(l_json.to_json);
  END df_stage_login_success;
  /*PROCEDURE df_stage_login_success(p_uid      IN VARCHAR2,
                                   p_platform IN VARCHAR2,
                                   x_token    OUT VARCHAR2,
                                   x_json     OUT VARCHAR2) IS
    l_json pl_json := pl_json;
    l_role VARCHAR2(2000);
    v_role_lv  number;
    v_system_code varchar2(300);
  BEGIN
    --1.随机生成32位token
    x_token := dbms_random.string('A', 32);
    --2.记录token
    INSERT INTO df_stage_token
      (id,
       token,
       username,
       platform,
       last_invoke_date,
       creation_date,
       is_expired)
    VALUES
      (df_stage_token_s.nextval,
       x_token,
       p_uid,
       p_platform,
       SYSDATE,
       SYSDATE,
       'N');
    l_json.set_value('token', x_token);
    l_json.set_value('userId', p_uid);
    --update by Echo.Zeng 2018-01-23
    --查询当前人员对应的角色的等级
 select to_number(v.seq)
   into v_role_lv
   from dbpm_role_member_params t,
        dbpm_role_params        drp,
        dbpm_role_members       drm,
        dbpm_roles              dr,
        dcld_data_value_v       v
  where t.param_id = drp.param_id
    and t.member_id = drm.member_id
    and drp.role_id = dr.role_id
    and drm.role_id = dr.role_id
    and drp.data_source_code = v.data_source_code
    and drp.data_source_code = 'admin_type'
    and t.param_value = v.value_code
    and lower(drm.member_code) = lower(p_uid)
    and v.ds_status = 'Y'
    and v.dsv_status = 'Y';
    --update by Echo.Zeng  2018-02-06
    --查询当前人员对应的系统编号
 select max(t.param_value)
  into v_system_code
  from dbpm_role_member_params t,
       dbpm_role_params        drp,
       dbpm_role_members       drm,
       dbpm_roles              dr,
       dcld_data_value_v       v
 where t.param_id = drp.param_id
   and t.member_id = drm.member_id
   and drp.role_id = dr.role_id
   and drm.role_id = dr.role_id
   and drp.data_source_code = v.data_source_code
   and drp.data_source_code = 'DbpmSysCode'
   and t.param_value = v.value_code
   and lower(drm.member_code) = lower(p_uid)
   and v.ds_status = 'Y'
   and v.dsv_status = 'Y';

    l_json.set_value('roleLevel', v_role_lv); --update by Echo.Zeng 2018-01-23
    l_json.set_value('systemCode', v_system_code); --update by Echo.Zeng 2018-02-06
    l_json.set_value('userRole', l_role);
    x_json := to_char(l_json.to_json);
  EXCEPTION
    WHEN OTHERS THEN
      l_json.fail('系统错误,请稍后再试');
      x_json := to_char(l_json.to_json);
  END df_stage_login_success;*/

  /*FUNCTION CURRENT_USER RETURN VARCHAR2 IS
  BEGIN
    RETURN sys_context('dstagecontext', 'USER');
  END;*/

  PROCEDURE df_stage_get_user(p_token IN VARCHAR2,
                              x_code  OUT VARCHAR2,
                              x_msg   OUT VARCHAR2) IS
  BEGIN
    x_code := 'SUCCESS';
    SELECT t.username
      INTO x_msg
      FROM df_stage_token t
     WHERE t.token = p_token;
  EXCEPTION
    WHEN OTHERS THEN
      x_code := 'FAIL';
      x_msg  := '{"code":"FAILED","userMsg":"会话过期请重新登录"}';
  END;

  /*==================================================
  Procedure Name :
      df_stage_execute
  Description:
      动态执行存储过程或者函数
  Argument:
     p_token：            token
     p_proc_type:         PROCEDURE/FUNCTION
     p_pkg:               pkg名称
     p_proc_name:         存储过程或者函数名
     p_service:           服务名称
     x_code:              SUCCESS/FAIL
     x_msg:               错误信息
  History:
      1.00  2016-12-10  jianfeng.zheng  Creation
  ==================================================*/
  PROCEDURE df_stage_execute(p_token     IN VARCHAR2,
                             p_proc_type IN VARCHAR2,
                             p_pkg       IN VARCHAR2,
                             p_proc_name IN VARCHAR2,
                             p_service   IN VARCHAR2,
                             p_request   IN CLOB,
                             x_response  OUT CLOB) IS
    v_code VARCHAR2(100);
    v_msg  VARCHAR2(500);
  BEGIN
    --1.设置上下文环境
    df_stage_api_auth(p_token => p_token, x_code => v_code, x_msg => v_msg);
    IF v_code <> 'SUCCESS' THEN
      x_response := v_msg;
      GOTO finish;
    END IF;
    --2.动态调用存储过程或者函数
    IF 'FUNCTION' = p_proc_type THEN
      EXECUTE IMMEDIATE 'begin :1 := ' || p_pkg || '.' || p_proc_name ||
                        '(:2); end;'
        USING OUT x_response, IN p_request;
    ELSIF 'PROCEDURE' = p_proc_type THEN
      EXECUTE IMMEDIATE 'begin ' || p_pkg || '.' || p_proc_name ||
                        '(:1,:2); end;'
        USING IN p_request, OUT x_response;
    END IF;
    <<finish>>
    NULL;
  END;
END df_stage_das_pkg;
/

