create package     dbpm_event_pkg is

  -- Author  : YAOSHALLWE
  -- Created : 2019/3/4 18:11:54
  -- Purpose : 基于流程中心的事件响应

  /*==================================================
  Procedure/Function Name :
      proc_get_event_flag
  Description:
      This function perform:
      判断是否需要响应事件
  Argument:
     p_business_param： 流程业务参数
     p_process_param 流程基本参数
  History:
      1.00  2019-03-04 xiaowei.yao  Creation
  ==================================================*/

  procedure proc_get_event_flag(p_document_id  VARCHAR2,
                                p_process_code VARCHAR2,
                                p_instanceid   VARCHAR2,
                                p_event_type   VARCHAR2,
                                p_attr         VARCHAR2,
                                x_flag         OUT VARCHAR2,
                                x_error_msg    OUT VARCHAR2,
                                x_attr1        OUT VARCHAR2,
                                x_attr2        OUT VARCHAR2);

  /*==================================================
  Procedure/Function Name :
      proc_is_auto_approval
  Description:
      This function perform:
      从审批历史中查询是否应该自动审批
      1、申请人与申请人后第一个人工节点是同一个人，不自动审批
      2、在申请人之后如果存在与分配人相同的审批人，自动审批
  Argument:
     p_instance_id： instance_id
     p_assignee： 待办分配人
  History:
      1.00  2019-03-04 xiaowei.yao  Creation
  ==================================================*/
  PROCEDURE proc_is_auto_approval(p_instance_id VARCHAR2,
                                  p_assignee    VARCHAR2,
                                  x_result_flag OUT VARCHAR2,
                                  x_error_msg   OUT VARCHAR2);
  /*==================================================
  Procedure/Function Name :
      proc_get_email_ext
  Description:
      This function perform:
      使用扩展方式生成邮件的主题和body
  History:
       1.00  2019-03-01  xiaower.yao  Creation
  ==================================================*/
  PROCEDURE proc_get_email_ext(p_taskid         VARCHAR2,
                               P_locale         VARCHAR2,
                               p_process_param  dbpm_process_param_rec,
                               p_business_param dbpm_business_param_tbl,
                               x_email_title    OUT VARCHAR2,
                               x_email_body     OUT VARCHAR2,
                               x_result_flag    OUT VARCHAR2,
                               x_error_msg      OUT VARCHAR2);

  /*==================================================
  Procedure/Function Name :
      proc_get_sevice_ext
  Description:
      This function perform:
      获得服务
  History:
       1.00  2019-03-22  xiaower.yao  Creation
  ==================================================*/
  PROCEDURE proc_get_sevice_ext(p_invoke_stage   VARCHAR2,
                                p_service_type   VARCHAR2,
                                p_task_id        VARCHAR2,
                                p_instance_id    VARCHAR2,
                                p_syscode        VARCHAR2,
                                p_process_param  dbpm_process_param_rec,
                                p_business_param dbpm_business_param_tbl,
                                x_services       OUT dbpm_service_tbl,
                                x_result_flag    OUT VARCHAR2,
                                x_error_msg      OUT VARCHAR2);
  /*
  * 获取动态参数值
  */
  FUNCTION func_get_process_param_value(p_business_param     dbpm_business_param_tbl,
                                        p_process_param_code VARCHAR2)
    RETURN VARCHAR2;

end dbpm_event_pkg;

/

