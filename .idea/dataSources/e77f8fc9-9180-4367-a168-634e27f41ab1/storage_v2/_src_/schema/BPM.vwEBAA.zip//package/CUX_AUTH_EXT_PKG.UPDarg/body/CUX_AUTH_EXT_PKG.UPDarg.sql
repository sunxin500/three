create package body     CUX_AUTH_EXT_PKG is

  /*==================================================
  Procedure/Function Name :
      proc_get_approvers_hooms_ext
  Description:
      This function perform:
      使用扩展方式来获取权限流程审批人
  Argument:
     p_node_id： 节点编码

  History:
      1.00  2019-01-04  xiaowei.yao  Creation
  ==================================================*/
  PROCEDURE proc_get_approvers_auth_ext(p_node_id        NUMBER,
                                        p_document_id    VARCHAR2,
                                        p_process_param  dbpm_process_param_rec,
                                        p_business_param dbpm_business_param_tbl,
                                        x_approvers      OUT VARCHAR2,
                                        x_result_flag    OUT VARCHAR2,
                                        x_error_msg      OUT VARCHAR2) IS
    v_role_code    VARCHAR2(100);
    v_org_code     VARCHAR2(2000);
    v_param_key    VARCHAR2(100);
    v_param_value  VARCHAR2(2000);
    v_org_array    type_split;
    v_tmpApprover  varchar2(100);
    v_tmp_org_code varchar2(100);
    v_appliercode  varchar2(100);
  begin
    -- 获取角色编码
    SELECT dnr.business_role
      INTO v_role_code
      FROM BPM.dbpm_node_roles dnr
     WHERE dnr.node_id = p_node_id
       AND dnr.node_from_type = 'ChainNode';
    --1.3 获取参数值
    BEGIN
      FOR i IN 1 .. p_business_param.count LOOP
        v_param_key   := p_business_param(i).paramkey;
        v_param_value := p_business_param(i).paramvalue;
        IF 'MODULAR' = v_param_key THEN
          v_org_code := v_param_value;
        END IF;
        IF 'APPLYER' = v_param_key THEN
          v_appliercode := v_param_value;
        END IF;
      END LOOP;
    EXCEPTION
      WHEN no_data_found THEN
        x_result_flag := 'N';
        x_error_msg   := '查找参数异常，审批节点node_id=' || p_node_id;
        raise_application_error(-20001,
                                '根据经营体' || v_org_code || '和角色' ||
                                v_role_code || '查询审批人为空！');
        RETURN;
    END;
    --拆分小微编码
    v_org_array   := func_string_split(v_org_code, ',');
    v_tmpApprover := '';
    FOR i IN 1 .. v_org_array.count LOOP
      v_tmp_org_code := v_org_array(i);
      --根据角色编码和经营体查出审批人
      select listagg(v.member_code, ',') within group(order by v.member_code)
        into v_tmpApprover
        from (select distinct rm.member_code
                from dbpm_roles              r,
                     dbpm_role_members       rm,
                     dbpm_role_params        rp,
                     dbpm_role_member_params rmp
               where r.role_id = rm.role_id
                 and r.role_id = rp.role_id
                 and rp.param_id = rmp.param_id
                 and rp.role_id = r.role_id
                 and rmp.member_id = rm.member_id
                 and rmp.param_value = v_tmp_org_code
                 and r.role_code = v_role_code) v;

      if v_tmpApprover is not null and
         func_is_exist(x_approvers, v_tmpApprover) <> 'Y' then
        x_approvers := x_approvers || v_tmpApprover || ',';
      end if;
    end loop;

    if v_tmpApprover is not null and
       func_is_exist(x_approvers, v_tmpApprover) <> 'Y' then
      x_approvers := x_approvers || v_tmpApprover || ',';
    end if;
    IF x_approvers IS NULL THEN
      raise_application_error(-20001,
                              '根据经营体' || v_org_code || '和角色' || v_role_code ||
                              '查询审批人为空！');
    else
      x_result_flag := 'Y';
      x_approvers   := substr(x_approvers, 0, length(x_approvers) - 1);
    END IF;

  end proc_get_approvers_auth_ext;
  /*==================================================
  Procedure/Function Name :
      func_is_exist
  Description:
      This function perform:
      判断字符串数组中是否包含另一字符串
      如：1234,234,321是否包含321
  Argument:
     p_value_array： 字符串数组
     p_param：  判断字符串
  History:
      1.00  2017-07-05  yong.xu  Creation
  ==================================================*/
  FUNCTION func_is_exist(p_value_array VARCHAR2, p_param VARCHAR2)
    RETURN VARCHAR2 is
    v_result      VARCHAR2(20) := 'N';
    v_value_array type_split;
    v_param_array type_split;
    v_value       VARCHAR2(200);
    v_bool        BOOLEAN := true;
  BEGIN
    v_param_array := func_string_split(p_param, ',');
    IF p_value_array IS NOT NULL THEN
      v_value_array := func_string_split(p_value_array, ',');
      FOR i IN 1 .. v_param_array.count LOOP
        v_value := v_param_array(i);
        IF v_value_array IS NOT NULL THEN
          FOR j IN 1 .. v_value_array.count LOOP
            IF v_value = v_value_array(j) THEN
              v_result := 'Y';
              EXIT;
            ELSE
              v_result := 'N';
              CONTINUE;
            END IF;
          END LOOP;
        ELSE
          v_result := 'N';
        END IF;
        IF v_result = 'N' THEN
          EXIT;
        END IF;
      END LOOP;
    ELSE
      v_result := 'N';
    END IF;
    RETURN v_result;
  EXCEPTION
    WHEN OTHERS THEN
      v_result := 'N';
      RETURN v_result;
  END func_is_exist;
  /*==================================================
  Procedure/Function Name :
      proc_get_email_ext
  Description:
      This function perform:
      使用扩展方式生成邮件的主题和body
  History:
      1.00  2019-03-01  xiaower.yao  Creation
  ==================================================*/
  PROCEDURE proc_get_email_ext(p_taskid         VARCHAR2,
                               P_locale         VARCHAR2,
                               p_process_param  dbpm_process_param_rec,
                               p_business_param dbpm_business_param_tbl,
                               x_email_title    OUT VARCHAR2,
                               x_email_body     OUT VARCHAR2,
                               x_result_flag    OUT VARCHAR2,
                               x_error_msg      OUT VARCHAR2) is
    v_task_url        varchar2(2000) := 'https://ssosci.haier.net:444/authority/login-dd.jsp';
    v_process_name    varchar2(2000);
    v_task_count      number;
    v_taskid          varchar2(2000);
    v_assigne_user    varchar2(2000);
    cursor sub_task_cur(v_par_taskid varchar2) is
      select t.taskid from wftask t where t.taskgroupid = v_par_taskid;
  begin
    x_result_flag := 'Y';
    begin
      select count(*)
        into v_task_count
        from wftask wf
       where wf.taskid = p_taskid
         and wf.hassubtask = 'T';
      if v_task_count > 0 then
        for sub_task in sub_task_cur(p_taskid) loop
          v_taskid := sub_task.taskid;
          select v.ASSIGNEE
            into v_assigne_user
            from dbpm_wf_task_v v
           where v.TASKID = v_taskid;
          if v_assigne_user is not null then
            x_error_msg := x_error_msg || v_assigne_user || ',';
          end if;
        end loop;
      end if;
      --去掉最后一个逗号
      if x_error_msg is not null and instr(x_error_msg, ',') > 0 then
        x_error_msg := substr(x_error_msg, 0, length(x_error_msg) - 1);
      end if;
    end;
    select dp.process_name
      into v_process_name
      from dbpm_process dp
     where dp.process_code = p_process_param.processCode;
    x_email_title := p_process_param.processTitle;
    x_email_body  := ' <h4>您好：</br></br>  您有一条' || v_process_name ||
                     '的待办，请及时前往
      <a href="' || v_task_url || '">' ||
                     v_process_name ||
                     '</a>点击待办，进行批阅。</br>此为系统邮件，请勿回复！</h4>';

  EXCEPTION
    WHEN OTHERS THEN
      x_email_title := '';
      x_email_body  := '';
      x_result_flag := 'N';
      x_error_msg   := '获取权限流程模板异常';

  end proc_get_email_ext;

end CUX_AUTH_EXT_PKG;

/

