create package body     DBPM_RULE_API_PKG is

  /*==================================================
  Procedure/Function Name :
      func_parse_rule
  Description:
      This function perform:
       转换规则为字符串
  Argument:
     p_rule_list： 请求参数
  History:
      1.00  2018-05-31  wlj  Creation
  ==================================================*/
  FUNCTION func_parse_rule(p_rule_list json_list) return varchar2 as
    v_request         json := json;
    v_rule_list       json_list;
    v_rule_item       json;
    v_rule_str        varchar2(32767 byte);
    v_rule_op         varchar2(32767 byte);
    v_rule_static_str varchar2(100) := ' :1 = 1 ';
  begin

    for i in 1 .. p_rule_list.count loop
      v_rule_item       := json(p_rule_list.get(i));
      v_rule_static_str := ' :' || v_rule_item.get_string('ruleUuid') ||
                           ' = 1 ';
      if v_rule_item.get_string('type') = 'group' then

        --获取json_list递归
        if i = 1 then
          if v_rule_item.exist('group') then
            v_rule_op := func_parse_rule(json_list(v_rule_item.get('group')));
          else
            v_rule_op := ' 1 = 1 ';
          end if;
          continue;
        end if;
        if not v_rule_item.exist('group') then
          continue;
        end if;
        v_rule_op := v_rule_op || v_rule_item.get_string('op') ||
                     func_parse_rule(json_list(v_rule_item.get('group')));
      else
        if i = 1 then
          v_rule_op := v_rule_static_str;
          continue;
        end if;
        v_rule_op := v_rule_op || v_rule_item.get_string('op') ||
                     v_rule_static_str;
      end if;

    end loop;
    v_rule_str := ' ( ' || v_rule_op || ' ) ';
    return v_rule_str;
  end;

  /*==================================================
  Procedure/Function Name :
      proc_upgrade_old_chain_rule
  Description:
      This function perform:
       将老版本中没有规则树的审批连升级
  Argument:
     p_rule_list： 请求参数
  History:
      1.00  2018-07-18  wlj  Creation
  ==================================================*/
  PROCEDURE proc_upgrade_old_chain_rule as
    v_group_pljson pl_json := pl_json;
    v_list_pljson  pl_json := pl_json;
    v_rule_pljson  pl_json := pl_json;
    v_temp_list    pl_json := pl_json;
    v_clob         clob;
    v_count        number;
    cursor v_rules_cursor(p_chain_id number) is
      select rule_id, rule_uuid
        from dbpm_chain_rules r
       where r.chain_id = p_chain_id; --10274;
    cursor v_chain_cursor is
      select tree.chain_id
        from dbpm_chain_rules_tree tree
       where exists (select rule_id
                from dbpm_chain_rules r
               where r.chain_id = tree.chain_id);
  begin

    --初始化  dbpm_chain_rules_tree 表
    --当dbpm_chain_rules_tree表中没有数据时执行
    select count(1) into v_count from dbpm_chain_rules_tree tree;

    if v_count > 0 then
      return;
    end if;

    --将dbpm_approval_chain的数据拷贝至dbpm_chain_rules_tree
    insert into dbpm_chain_rules_tree
      (chain_id,
       chain_name,
       chain_type,
       process_id,
       organization_id,
       version,
       space_id,
       is_deleted,
       from_chain_id,
       status,
       object_version_number,
       creation_date,
       created_by,
       last_updated_by,
       last_update_date)
      select t.chain_id,
             t.chain_name,
             t.chain_type,
             t.process_id,
             t.organization_id,
             t.version,
             t.space_id,
             t.is_deleted,
             t.from_chain_id,
             t.status,
             t.object_version_number,
             t.creation_date,
             t.created_by,
             t.last_updated_by,
             t.last_update_date
        from dbpm_approval_chain t;

    --更新规则树
    for v_chain_cur in v_chain_cursor loop
      v_group_pljson := pl_json;
      v_list_pljson  := pl_json;
      v_rule_pljson  := pl_json;
      v_temp_list    := pl_json;
      v_list_pljson.set_data_type('ARRAY');
      v_temp_list.set_data_type('ARRAY');
      v_count := 0;
      for v_cur in v_rules_cursor(v_chain_cur.chain_id) loop
        v_count       := v_count + 1;
        v_rule_pljson := pl_json;
        v_rule_pljson.set_value('ruleUuid',
                                to_char(nvl(v_cur.rule_uuid, v_cur.rule_id)));
        v_rule_pljson.set_value('type', 'single');
        v_rule_pljson.set_value('op', 'and');
        v_temp_list.add_list_item(v_rule_pljson);
      end loop;
      v_group_pljson.set_value('type', 'group');
      v_group_pljson.set_value('op', 'and');
      v_group_pljson.set_value('group', v_temp_list);
      v_list_pljson.add_list_item(v_group_pljson);
      v_clob := v_list_pljson.to_data_json();

      if v_count > 0 then
        update dbpm_chain_rules_tree t
           set t.chain_rule_tree = v_clob
         where t.chain_id = v_chain_cur.chain_id;
      end if;
    end loop;

  end;

end DBPM_RULE_API_PKG;

/

