create PACKAGE BODY     "PL_JSON_PKG" IS

  PROCEDURE append_text(io_clob   IN OUT NOCOPY CLOB,
                        io_buffer IN OUT NOCOPY VARCHAR2,
                        i_text    IN VARCHAR2) IS
  BEGIN
    io_buffer := io_buffer || i_text;
  EXCEPTION
    WHEN value_error THEN
      dbms_lob.writeappend(io_clob, length(io_buffer), io_buffer);
      io_buffer := i_text;
  END append_text;

  PROCEDURE append_clob(io_clob   IN OUT NOCOPY CLOB,
                        io_buffer IN OUT NOCOPY VARCHAR2,
                        i_clob    IN CLOB) IS
  BEGIN
    io_clob   := io_clob || io_buffer;
    io_clob   := io_clob || i_clob;
    io_buffer := '';
  END append_clob;

  PROCEDURE write_append(io_clob   IN OUT NOCOPY CLOB,
                         io_buffer IN OUT NOCOPY VARCHAR2) IS
  BEGIN
    io_clob := io_clob || io_buffer;
  END write_append;
END pl_json_pkg;

/

