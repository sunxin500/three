create PACKAGE BODY dbpm_comm_pkg IS

  /*
  * 根据流程ID获取表单ID
  */
  FUNCTION func_get_process_form(p_process_id NUMBER) RETURN NUMBER IS
    v_form_id NUMBER;
  BEGIN
    SELECT df.form_id
      INTO v_form_id
      FROM dbpm_form df
     WHERE df.process_id = p_process_id
       AND df.status = 'Published'; --migrate by xiaowei.yao 20180412
    RETURN v_form_id;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END func_get_process_form;

  /*
  * 根据表单ID获取流程ID
  */
  FUNCTION func_get_form_process(p_form_id NUMBER) RETURN NUMBER IS
    v_process_id NUMBER;
  BEGIN
    SELECT df.process_id
      INTO v_process_id
      FROM dbpm_form df
     WHERE df.form_id = p_form_id;
    RETURN v_process_id;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END func_get_form_process;

  /*
  * 判断组件类型是否是否是数字类型组件
  */
  FUNCTION is_number_component(p_type varchar2) return varchar2 is
  begin
    if p_type = 'number-input' or p_type = 'N1+N2' OR P_TYPE = 'N1-N2' OR
       P_TYPE = 'N1*N2' OR P_TYPE = 'N1/N2' OR
       P_TYPE = 'calculator-readonly' THEN
      RETURN 'Y';
    ELSE
      RETURN 'N';
    END IF;
  end is_number_component;

  /*
  * 判断是否映射到标准字段的组件
  */
  function is_standard_component(p_type varchar2) return varchar2 is

  begin
    if p_type = 'document-number-readonly' or p_type = 'usercode-readonly' OR
       P_TYPE = 'applicant-readonly' OR P_TYPE = 'apply-date-readonly' OR
       P_TYPE = 'department-readonly' THEN
      RETURN 'Y';
    ELSE
      RETURN 'N';
    END IF;
  end is_standard_component;
  /*
  * 判断是否映射文本域的组件-migrate by xiaowei.yao 20180411
  */
  FUNCTION is_textarea_component(p_type VARCHAR2) RETURN VARCHAR2 IS

  BEGIN
    IF p_type = 'textarea-input' OR p_type = 'textarea-input' THEN
      RETURN 'Y';
    ELSE
      RETURN 'N';
    END IF;
  END is_textarea_component;

  /*
  * 获取数据字典值名称
  */
  FUNCTION get_datasource_value_name(p_datasource_code VARCHAR2,
                                     p_value_code      VARCHAR2)
    RETURN VARCHAR2 IS
    v_value_name VARCHAR2(4000);
  BEGIN
    SELECT ddsv.value_name
      INTO v_value_name
      FROM dbpm_data_source_values ddsv
     WHERE ddsv.data_source_code = p_datasource_code
       AND ddsv.value_code = p_value_code;
    RETURN v_value_name;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN '';
  END get_datasource_value_name;

  /*
  * 获取当前语言
  */
  FUNCTION get_current_locale RETURN VARCHAR2 IS

  BEGIN
    RETURN 'zh_CN';
  END get_current_locale;
  /*
  * 根据当前节点ID获取下级节点ID--migrate by xiaowei.yao 20180411
  */
  FUNCTION get_next_node_id(p_node_id NUMBER) RETURN NUMBER IS
    v_chain_id     NUMBER;
    v_order_num    NUMBER;
    v_next_node_id NUMBER;
    v_version      number;
  BEGIN
    SELECT dcn.chain_id, order_num, dcn.version
      INTO v_chain_id, v_order_num, v_version
      FROM dbpm_chain_nodes dcn
     WHERE dcn.node_id = p_node_id;
    SELECT node_id
      INTO v_next_node_id
      FROM (SELECT *
              FROM dbpm_chain_nodes dcn
             WHERE dcn.chain_id = v_chain_id
               and dcn.version = v_version
               AND dcn.order_num > v_order_num
             ORDER BY dcn.order_num)
     WHERE rownum = 1;
    RETURN v_next_node_id;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END get_next_node_id;
  /*
  * 更新文本域组件更新clob字段
  */
  procedure update_clob_component(code out varchar2) is
    v_sql            clob;
    v_value_sql      clob;
    v_value          clob;
    v_column_name    varchar2(500);
    v_TEXTAREA_count number;
    cursor clob_cur is
      select t.form_id,
             t.id,
             REGEXP_REPLACE(t.ATTR_NAME,
                            'TEXT_ATTRIBUTE',
                            'CLOB_ATTRIBUTE',
                            1,
                            1) attr_name
        from DBPM_FORM_FIELD_MAPPING t, DBPM_FORM_FIELD dff
       where t.id = dff.id
         and t.form_id = dff.form_id
         and dff.type = 'textarea-input';
    cursor textaerea_cur is
      select tt.document_id, dm.attr_name, TT.FORM_ID, TT.ID
        from (select t.document_id, dff.id, t.form_id
                from DBPM_DOCUMENTS t, DBPM_FORM_FIELD dff
               where t.form_id = dff.form_id
                 and dff.type = 'textarea-input') tt,
             DBPM_FORM_FIELD_MAPPING dm
       where dm.id = tt.id
         and dm.form_id = tt.form_id;
  begin
    for c_textaerea_cur in textaerea_cur loop
      v_value_sql := 'SELECT ' || c_textaerea_cur.attr_name ||
                     ' FROM dbpm_documents WHERE document_id = ' ||
                     c_textaerea_cur.document_id;

      EXECUTE IMMEDIATE v_value_sql
        INTO v_value;
      select count(1)
        into v_TEXTAREA_count
        from DBPM_DOCUMENT_TEXTAREA ddt
       where ddt.document_id = c_textaerea_cur.document_id;
      if v_TEXTAREA_count = 0 then
        v_sql := 'insert into DBPM_DOCUMENT_TEXTAREA(TEXTAREA_ID,DOCUMENT_ID,CLOB_ATTRIBUTE1)values(DBPM_DOCUMENT_TEXTAREA_s.Nextval,' ||
                 c_textaerea_cur.document_id || ',:1) ';
        Update DBPM_FORM_FIELD_MAPPING t
           set t.attr_name = 'CLOB_ATTRIBUTE1'
         where t.form_id = c_textaerea_cur.form_id
           and t.id = c_textaerea_cur.id;
      else
        v_sql := 'update DBPM_DOCUMENT_TEXTAREA set CLOB_ATTRIBUTE2 = :1 where DOCUMENT_ID =' ||
                 c_textaerea_cur.document_id;
        Update DBPM_FORM_FIELD_MAPPING t
           set t.attr_name = 'CLOB_ATTRIBUTE2'
         where t.form_id = c_textaerea_cur.form_id
           and t.id = c_textaerea_cur.id;
      end if;
      EXECUTE IMMEDIATE v_sql
        using v_value;
      v_sql       := null;
      v_value_sql := null;
    end loop;

    /* for c_clob_cur in clob_cur loop
      update DBPM_FORM_FIELD_MAPPING t
         set t.attr_name = c_clob_cur.attr_name
       where t.form_id = c_clob_cur.form_id
         and t.id = c_clob_cur.id;
    end loop;*/
    commit;
  exception
    when others then
      code := v_sql;
  end;

  /*==================================================
  Procedure/Function Name :
      func_get_task_url
  Description:
      This function perform:
      获取表单连接
  Argument:

  History:
      1.00  2018-06-07  wlj  Creation
  ==================================================*/
  function func_get_task_url(p_domain_url  varchar2,
                             p_instance_id varchar2,
                             p_form_key    varchar2,
                             p_task_id     varchar2,
                             p_params      varchar2,
                             p_sys_code    varchar2) return varchar2 as
    v_url        varchar2(4000);
    v_formKey    varchar2(400);
    v_params     varchar2(4000);
    v_actCode    varchar2(400);
    v_node_id    number;
    v_domain_url varchar2(400);

  begin
    begin
      select wf.protectedtextattribute9, wf.protectednumberattribute1
        into v_actCode, v_node_id
        from wftask wf
       where wf.taskid = p_task_id;
    exception
      when others then
        v_actCode := '';
    end;
    /* if p_domain_url is null then
      return null;
    end if;*/
    v_formKey := p_form_key;
    v_params  := p_params;
    if p_instance_id is null and p_task_id is null and p_form_key is null and
       p_params is null then
      return p_domain_url;
    end if;
    if p_sys_code = 'HOOMS' then
      --出国流程自开发
      if v_node_id is null then
        begin
          select t.acitivity_formurl,
                 wf.protectedtextattribute7,
                 wf.protectedtextattribute6
            into v_url, v_formKey, v_params
            from cux_hooms_process_node t, wftask wf
           where t.activity_code = wf.protectedtextattribute9
             and wf.taskid = p_task_id;
        exception
          when others then
            v_url := '';
        end;
      else
        --出国流程配置
        begin
          select cn.acitivity_formurl,
                 wf.protectedtextattribute7,
                 wf.protectedtextattribute6
            into v_url, v_formKey, v_params
            from dbpm_chain_nodes       dn,
                 dbpm_approval_chain    dc,
                 dbpm_process           dp,
                 CUX_HOOMS_PROCESS_NODE cn， wftask wf
           where dc.chain_id = dn.chain_id
             and dp.process_id = dc.process_id
             and dp.process_code = cn.process_code
                --  and dn.node_name = cn.activity_name
             and dn.node_id = wf.protectednumberattribute1
             and wf.taskid = p_task_id
             and cn.order_num = dn.order_num;
        exception
          when others then
            v_url := '';
        end;
      end if;
    else --通用方式找url
      v_url := p_domain_url;
    end if;
    if instr(v_url, '?') <= 0 then
      v_url := v_url || '?';
    else
      v_url := v_url || '&';
    end if;
    v_url := v_url || 'BPM=BPM&';
    select v_url || nvl2(p_instance_id, 'instanceId=' || p_instance_id, '') ||
           nvl2(p_task_id, '&' || 'taskId=' || p_task_id, '') ||
           nvl2(v_formKey, '&' || 'formKey=' || v_formKey, '') ||
           nvl2(v_params, '&' || v_params, '')
      into v_url
      from dual;
    return v_url;
  end;

  /*==================================================
  Procedure/Function Name :
      func_instance_live_day
  Description:
      This function perform:
      获取流程执行的天数
  Argument:

  History:
      1.00  2018-06-25  wlj  Creation
  ==================================================*/
  function func_instance_live_day(p_instance_id varchar2) return number as
    v_instance_create_date date;
    v_instance_modify_date date;
    v_state                NUMBER;
    v_instance_live_day    NUMBER;
  begin
    select t.creation_date + 0, t.modify_date + 0, t.state
      into v_instance_create_date, v_instance_modify_date, v_state
      from CUBE_INSTANCE t
     where t.cikey = to_number(p_instance_id);

    if v_state = 1 then
      v_instance_live_day := round(sysdate - v_instance_create_date);
    else
      v_instance_live_day := round(v_instance_modify_date -
                                   v_instance_create_date);
    end if;

    if v_instance_live_day = 0 then
      v_instance_live_day := 0.5;
    end if;
    return v_instance_live_day;
  exception
    when others then
      return null;
  end;

  /*==================================================
  Procedure/Function Name :
      func_string_split
  Description:
      This function perform:
      按照特殊分隔符拆分字符串为数组
      如：1234,234,321 --> [1234,234,321]
  Argument:
     p_list： 要拆分的字符串
     p_sep：  分隔符
  History:
      1.00  2018-08-31  xiaowei.yao  Creation
  ==================================================*/
  FUNCTION func_string_split(p_list VARCHAR2, p_sep VARCHAR2)
    RETURN type_split AS
    l_idx         PLS_INTEGER;
    v_list        VARCHAR2(4000) := p_list; --长度多给点
    v_spilt_array type_split;
  BEGIN
    v_spilt_array := type_split();
    --循环递归
    LOOP
      l_idx := instr(v_list, p_sep); --获取位置
      v_spilt_array.extend;
      IF l_idx > 0 THEN
        v_spilt_array(v_spilt_array.count) := substr(v_list, 1, l_idx - 1);
        v_list := substr(v_list, l_idx + length(p_sep)); --递归
      ELSE
        v_spilt_array(v_spilt_array.count) := v_list;
        EXIT;
      END IF;
    END LOOP;
    RETURN v_spilt_array;
  END func_string_split;
  /*==================================================
  Procedure/Function Name :
      proc_get_email_address
  Description:
      This function perform:
     根据工号查询邮件地址
  Argument:
       p_userCode   2018-10-13 12.00
     x_email_address 邮件地址


  History:
      1.00  2018-10-13 12.00  xiaowei.yao  Creation
  ==================================================*/
  procedure proc_get_email_address(p_userCode      in varchar,
                                   x_email_address out varchar,
                                   x_outadd        out varchar) is
  begin
   /* select max(nvl(de.email, 'NULL'))
      into x_email_address
      from dfnd_employees de
     where upper(de.employee_code) = upper(p_userCode);
    if x_email_address = 'NULL' then
      select max(nvl(bu.usermail, ','))
        into x_email_address
        from bpm_t_idm.t_idm_user bu
       where upper(bu.usercode) = upper(p_userCode);
    end if;
    --update by xuy 20190905
    if x_email_address is null and instr(p_userCode,'@') >0 then
      x_email_address := p_userCode;
    end if;
    /* if x_email_address is null then
      raise_application_error(-20001,
                              '工号' || p_userCode || '查询邮箱地址为空');
    end if;*/
    
    null;

  end proc_get_email_address;

END dbpm_comm_pkg;

/

