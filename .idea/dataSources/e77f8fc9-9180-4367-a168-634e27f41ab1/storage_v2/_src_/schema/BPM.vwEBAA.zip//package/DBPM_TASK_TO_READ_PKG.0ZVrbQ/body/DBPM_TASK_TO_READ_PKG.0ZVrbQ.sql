create PACKAGE BODY     dbpm_task_to_read_pkg IS
  /*

  创建待阅记录

  */
  PROCEDURE create_task_read(p_document_id IN NUMBER) IS
  BEGIN
    INSERT INTO dbpm_document_read
      (read_id, document_id)
    VALUES
      (dbpm_document_read_s.nextval, p_document_id);
  END;

  /*

  查询待阅记录
  Author  : XJL
  Created : 2017/11/29
  */
  PROCEDURE get_task_read(p_request IN CLOB, x_response OUT CLOB) IS
    v_request        json;
    v_response       pl_json := pl_json;
    v_line           pl_json;
    v_current_user   varchar2(100);
    v_search_content VARCHAR2(4000);
    v_page           NUMBER;
    v_size           NUMBER;
    v_total          NUMBER := 0;
    --排序参数
    v_sort_col varchar2(100);
    v_sort     json;
    CURSOR v_task_todo_v_cur IS
      SELECT *
        FROM (SELECT v.*, rownum cnt
                FROM (SELECT count(1) over(partition by 1) total,
                             v1.document_id,
                             v1.form_id,
                             v1.process_id,
                             v1.doc_number,
                             v1.task_number,
                             v1.title,
                             v1.status,
                             dbpm_comm_pkg.get_datasource_value_name('DbpmProcessStatus',
                                                                     v1.status) status_meaning,
                             v1.process_name,
                             v1.process_code,
                             dpt.type_name process_type,
                             dpt.display_color process_type_color,
                             v1.creation_date,
                             v1.created_user_name,
                             v1.created_user_code,
                             ddr.is_read,
                             ddr.read_id
                        FROM DBPM_TASK_READ_QUERY_V v1,
                             dbpm_document_read     ddr,
                             dbpm_process_types     dpt
                       WHERE dpt.type_code(+) = v1.process_type
                         and ddr.document_id = v1.document_id
                         and ddr.is_read = 'N'
                         and upper(v1.created_user_code) =
                             upper(v_current_user)
                         AND (nvl(v1.task_number, 'NL') LIKE
                              '%' || v_search_content || '%' OR
                              nvl(v1.title, 'NL') LIKE
                              '%' || v_search_content || '%' OR
                              nvl(v1.process_name, 'NL') LIKE
                              '%' || v_search_content || '%' OR
                              nvl(dpt.Type_Name, 'NL') =
                              nvl(v_search_content, nvl(dpt.Type_Name, 'NL')) OR
                              INSTR(NVL(v1.created_user_name, 'NL'),
                                    NVL(v_search_content,
                                        nvl(v1.created_user_name, 'NL'))) > 0)

                       ORDER BY decode(v_sort_col,
                                       'task_number_desc',
                                       v1.task_number,
                                       'title_desc',
                                       v1.title,
                                       'process_type_desc',
                                       dpt.type_name,
                                       'created_user_name_desc',
                                       v1.created_user_name,
                                       v1.creation_date) DESC) v
               WHERE rownum <= v_page * v_size)
       WHERE cnt > (v_page - 1) * v_size;
  BEGIN
    v_request        := json(p_request, 'OBJECT');
    v_current_user   := v_request.username;
    v_page           := nvl(v_request.get('page').get_number, 1);
    v_size           := nvl(v_request.get('size').get_number, 20);
    v_search_content := dcld_comm_pkg.get_filter_value('all', v_request);
    if v_request.exist('sort') then
      v_sort     := json(v_request.get('sort'));
      v_sort_col := v_sort.get_string('value');
      v_sort_col := v_sort_col || '_' || v_sort.get_string('order');
    end if;

    for v_task_todo_row in v_task_todo_v_cur loop
      v_line  := pl_json;
      v_total := v_task_todo_row.total;
      v_line.set_value('documentId', v_task_todo_row.document_id);
      v_line.set_value('formId', v_task_todo_row.form_id);
      v_line.set_value('processId', v_task_todo_row.process_id);
      v_line.set_value('task_number', v_task_todo_row.task_number);
      v_line.set_value('title', v_task_todo_row.title);
      v_line.set_value('status', v_task_todo_row.status);
      v_line.set_value('status_meaning', v_task_todo_row.status_meaning);
      v_line.set_value('isRead', v_task_todo_row.is_read);
      v_line.set_value('process_name', v_task_todo_row.process_name);
      v_line.set_value('process_code', v_task_todo_row.process_code);
      v_line.set_value('process_type', v_task_todo_row.process_type);
      --待阅ID
      v_line.set_value('readId', v_task_todo_row.read_id);
      v_line.set_value('process_type_color',
                       v_task_todo_row.process_type_color);
      v_line.set_value('creation_date',
                       to_char(v_task_todo_row.creation_date,
                               'YYYY-MM-DD HH24:MI'));

      v_line.set_value('created_user_name',
                       v_task_todo_row.created_user_name);
      v_line.set_value('created_user_code',
                       v_task_todo_row.created_user_code);

      v_response.add_list_item('list', v_line);
    end loop;
    v_response.set_value('total', v_total);
    x_response := v_response.to_json;
  END;

  /*
  更新已读状态
  Author  : XJL
  Created : 2017/11/29
  */
  PROCEDURE update_task_read(p_read_id IN NUMBER) IS
  BEGIN
    if p_read_id is not null then
      update dbpm_document_read ddr
         set ddr.is_read = 'Y'
       where ddr.read_id = p_read_id
         and ddr.is_read = 'N';
      commit;
    end if;
  exception
    when others then
      return;
  END;
END dbpm_task_to_read_pkg;

/

