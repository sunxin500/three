create PACKAGE BODY     dfnd_address_list_pkg IS

  /*==================================================
  Procedure/Function Name :
      proc_query_address_list
  Description:
      This function perform:
      查询通讯录接口
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-03-13  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_query_address_list(p_request CLOB, x_response OUT CLOB) IS
    v_request      json;
    v_query_model  VARCHAR2(10);
    v_current_user VARCHAR2(50); --获取当前用户

  BEGIN
    -- 判断本次查询通讯录的方式（暂时只实现全部联系人查找）
    --解析字段
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;
    --v_request      := json(p_request);
    --v_current_user := '008';
    

    v_query_model := nvl(v_request.get('contactType').get_string, 'ALL');

    IF v_query_model = 'ALL' THEN
      -- 1. 查询全部联系人
      proc_get_all_address_list(p_request  => p_request,
                                x_response => x_response);
    ELSIF v_query_model = 'FRIEND' THEN
      -- 2. 查询我的好友
      NULL;
    END IF;
  END proc_query_address_list;

  /*==================================================
  Procedure/Function Name :
      get_all_address_list
  Description:
      This function perform:
      查询全部人员的通讯录接口
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-03-13  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_get_all_address_list(p_request CLOB, x_response OUT CLOB) IS
    v_request       json;
    v_response      pl_json := pl_json;
    v_current_user  VARCHAR2(50); --获取当前用户
    v_line          pl_json;
    v_total         NUMBER := 0;
    v_page          NUMBER;
    v_size          NUMBER;
    v_seach_content varchar2(1000); -- update by Echo.Zeng 2018-02-26
    CURSOR v_emp_cur IS
      SELECT *
        FROM (SELECT fe.*,
                     (CASE
                       WHEN fri.friend_user_code IS NULL THEN
                        'N'
                       ELSE
                        'Y'
                     END) is_friend,
                     (CASE
                       WHEN SYSDATE - nvl(fri.creation_date, SYSDATE - 100) > 7 THEN
                        'N'
                       ELSE
                        'Y'
                     END) is_new_friend,
                     rownum cnt
                FROM dfnd_employees fe,
                     (SELECT dmf.creation_date, dmf.friend_user_code
                        FROM dcld_my_frineds dmf
                       WHERE dmf.my_user_code = v_current_user) fri
               WHERE fe.employee_code = fri.friend_user_code(+)
                 AND (INSTR(NVL(UPPER(FE.EMPLOYEE_CODE), 1),
                            NVL(v_seach_content,
                                NVL(UPPER(FE.EMPLOYEE_CODE), 1))) > 0 OR
                     INSTR(NVL(FE.EMAIL, 1),
                            NVL(v_seach_content, NVL(FE.EMAIL, 1))) > 0 OR
                     INSTR(NVL(FE.EMPLOYEE_NAME, 1),
                            NVL(v_seach_content, NVL(FE.EMPLOYEE_NAME, 1))) > 0)
                 AND rownum <= v_page * v_size)
       WHERE cnt > (v_page - 1) * v_size
       ORDER BY employee_code;
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;
    --v_request      := json(p_request);
    --v_current_user := '008';

    v_page          := v_request.get_number('page'); -- update by Echo.Zeng 2018-02-26
    v_size          := v_request.get_number('size'); -- update by Echo.Zeng 2018-02-26
    v_seach_content := upper(v_request.get_string('searchValue')); -- update by Echo.Zeng 2018-02-26
    --updated by echo.zeng 2018-02-26 begin
    select count(1)
      into v_total
      from dfnd_employees fe,
           (SELECT dmf.creation_date, dmf.friend_user_code
              FROM dcld_my_frineds dmf
             WHERE dmf.my_user_code = v_current_user) fri
     WHERE fe.employee_code = fri.friend_user_code(+)
       AND (INSTR(NVL(UPPER(FE.EMPLOYEE_CODE), 1),
                  NVL(v_seach_content, NVL(UPPER(FE.EMPLOYEE_CODE), 1))) > 0 OR
           INSTR(NVL(FE.EMAIL, 1), NVL(v_seach_content, NVL(FE.EMAIL, 1))) > 0 OR
           INSTR(NVL(FE.EMPLOYEE_NAME, 1),
                  NVL(v_seach_content, NVL(FE.EMPLOYEE_NAME, 1))) > 0);
    --updated by echo.zeng 2018-02-26 end;
    FOR v_emp IN v_emp_cur LOOP
      v_line := pl_json;
      v_line.set_value('userCode', v_emp.employee_code);
      v_line.set_value('userName', v_emp.employee_name);
      v_line.set_value('userPhone', v_emp.phone);
      v_line.set_value('userEmail', v_emp.email);
      v_line.set_value('userPosition', ''); -- TODO
      v_line.set_value('thumbPic', ' '); -- TODO
      --v_line.set_value('companyName', '上海得帆信息技术有限公司'); -- TODO
      v_line.set_value('isFriend', v_emp.is_friend);
      v_line.set_value('isNewFriend', v_emp.is_new_friend);
      v_response.add_list_item('userList', v_line);
    END LOOP;

    v_response.set_value('total', v_total);
    x_response := v_response.to_json;
  END proc_get_all_address_list;

  /*==================================================
  Procedure/Function Name :
      proc_add_friend
  Description:
      This function perform:
      加好友，如果已经是好友，不加
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-03-14  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_add_friend(p_request CLOB, x_response OUT CLOB) IS
    v_request      json;
    v_response     pl_json := pl_json;
    v_current_user VARCHAR2(50); --获取当前用户
    v_friend_user  VARCHAR2(100);
    v_count        NUMBER;
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;

    v_friend_user := v_request.get('friendUserCode').get_string;
    SELECT COUNT(1)
      INTO v_count
      FROM dcld_my_frineds dmf
     WHERE dmf.my_user_code = v_current_user
       AND dmf.friend_user_code = v_friend_user;
    -- 如果已经是好友，这里不加好友
    IF v_count = 0 THEN
      INSERT INTO dcld_my_frineds
        (frined_id,
         my_user_code,
         friend_user_code,
         created_by,
         last_updated_by)
      VALUES
        (dcld_my_frineds_s.nextval,
         v_current_user,
         v_friend_user,
         v_current_user,
         v_current_user);
    END IF;
    x_response := v_response.to_json;
  END proc_add_friend;
END dfnd_address_list_pkg;
/

