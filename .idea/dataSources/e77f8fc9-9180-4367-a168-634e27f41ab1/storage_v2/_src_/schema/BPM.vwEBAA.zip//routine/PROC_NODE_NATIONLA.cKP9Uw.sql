create procedure     proc_node_nationla(p_processCode varchar2) is

  cursor v_nodeid_cur is --获得流程的所有节点
    select dpn.node_id
      from dbpm_process_nodes dpn, dbpm_process dp
     where dpn.process_id = dp.process_id
       and dp.process_code = p_processCode;
  v_node         dbpm_process_nodes_tl%rowtype;
  v_locale_count number;
  v_nation_value varchar2(64);
begin
  for v_nodeid_row in v_nodeid_cur loop
    --遍历每个节点的国际化值

    begin
      --获得每个节点的国际化值的数量
      SELECT count(1)
        into v_locale_count
        FROM dbpm_process_nodes dpn, dbpm_process_nodes_tl dpnt
       WHERE dpn.node_id = dpnt.node_id
         and dpn.node_id = v_nodeid_row.node_id;
    end;
    if v_locale_count <> 2 then
      --判断节点缺少国际化值
      begin
        SELECT dpnt.*
          into v_node
          FROM dbpm_process_nodes dpn, dbpm_process_nodes_tl dpnt
         WHERE dpn.node_id = dpnt.node_id
           and dpn.node_id = v_nodeid_row.node_id;
      end;
      begin
        select distinct cnt.nation_value --查出国际化值
          into v_nation_value
          from CUX_language_NATION_TEMP cnt
         where cnt.node_name = v_node.node_name
           and 'en_US' = cnt.locale;
      end;
      v_node.node_name := v_nation_value;
      v_node.locale    := 'en_US';
      insert into dbpm_process_nodes_tl values v_node; --插入到节点国际化表
    end if;
  end loop;
end proc_node_nationla;

/

