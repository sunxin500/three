create package body dbpm_subprocess_pkg is

  /*==================================================
  procedure/function name :
      proc_get_sub_processid
  description:
      this function perform:
       查询子流程
  argument:
     p_request： 请求参数
     x_response： 响应结果
  history:
      1.00  2019-06-14  xiaowei.yao  creation
  ==================================================*/

  procedure proc_get_sub_processid(p_instanceid in varchar2,
                                  x_chainuuids out TYPE_ARRAY) is
    v_request_content clob;
    v_re              json;
    v_subchainparams  json_list;
    v_subchainparam   json;
    v_processids      TYPE_ARRAY:=TYPE_ARRAY();

  begin
    select param.request_content
      into v_request_content
      from dbpm_process_start_param param
     where param.instanceid = p_instanceid;
     v_re := json(v_request_content);
   if v_re.path('subChainParams') is not null then
      v_subchainparams := json_list(v_re.get('subChainParams'));
     for i in 1 .. v_subchainparams.count loop
      v_subchainparam := json(v_subchainparams.get(i));
      if v_subchainparam.path('subChainId') is not null then
        v_processids.extend();
        v_processids(i) := v_subchainparam.get_string('subChainId');
      end if;
    end loop;
    x_chainuuids := v_processids;
    return;
   end if;



    EXCEPTION
    WHEN OTHERS THEN

      raise_application_error(-20001,
                              '查找子流程标志符报错 ' || p_instanceid);

  end proc_get_sub_processid;
  /*==================================================
  procedure/function name :
      proc_get_subchain_nodes
  description:
      this function perform:
       查询子审批链详情
  argument:
     p_processid： 子流程id
     x_nodeids： 审批节点数组
  history:
      1.00  2019-06-14  xiaowei.yao  creation
  ==================================================*/

  procedure proc_get_subchain_nodes(p_chainuuid  in varchar2,
                                   p_instanceid in varchar2,
                                   p_nodeid     in number,
                                   x_nodeids    out DBPM_SUB_CHAINNODE_TBL) is
    v_business_param  dbpm_business_param_tbl := dbpm_business_param_tbl();
    v_p_process_param dbpm_process_param_rec := dbpm_process_param_rec(null,
                                                                       null,
                                                                       null,
                                                                       null,
                                                                       null,
                                                                       null,
                                                                       null);

    v_subchainparams  json_list;
    v_subchainparam   json;
    v_subparams       json_list;
    v_subparam        json;
    v_re              json;
    v_recontent       clob;
    v_chain_id        number;
    v_result_flag     varchar2(100);
    v_result_msg      varchar2(100);
    v_index           number := 1;
    v_nodes         DBPM_SUB_CHAINNODE_TBL:=DBPM_SUB_CHAINNODE_TBL();
    v_node  DBPM_SUB_CHAINNODE_rec:=DBPM_SUB_CHAINNODE_rec(null,null);
    cursor v_chainnodes_cur(p_chainid number) is
      select * from dbpm_chain_nodes dn where dn.chain_id = p_chainid
      and dn.is_deleted='N';
  begin
    select dsp.request_content
      into v_recontent
      from dbpm_process_start_param dsp
     where dsp.instanceid = p_instanceid;

    v_re := json(v_recontent);

    if v_re.path('subChainParams') is not null then
      v_subchainparams := json_list(v_re.get('subChainParams'));
    end if;
    for i in 1 .. v_subchainparams.count loop
      v_subchainparam := json(v_subchainparams.get(i));
      if v_subchainparam.get_string('subChainId') = p_chainuuid and
         v_subchainparam.path('subParam') is not null then
        v_subparams := json_list(v_subchainparam.get('subParam'));
        for j in 1 .. v_subparams.count loop
          v_subparam := json(v_subparams.get(j));
          v_business_param.extend();
          dbms_output.put_line(v_subparam.get_string('key'));
           dbms_output.put_line(v_subparam.get_string('value'));
          v_business_param(j) := dbpm_business_param_rec(v_subparam.get_string('key'),
                                                         v_subparam.get_string('value'));
        end loop;
      end if;
    end loop;
    proc_get_chain_id(p_node_id        => p_nodeid,
                      p_document_id    => '',
                      p_process_param  => v_p_process_param,
                      p_business_param => v_business_param,
                      x_chain_id       => v_chain_id,
                      x_result_flag    => v_result_flag,
                      x_error_msg      => v_result_msg);
    if v_result_flag = 'N' then
      --查找审批链失败
      raise_application_error(-20001, v_result_msg);
    else
      --查找子审批链成功
      for v_nod in v_chainnodes_cur(v_chain_id) loop
        v_node.node_id:=v_nod.node_id;
        v_node.chain_uuid:=p_chainuuid;
        v_nodes.extend();
        v_nodes(v_index) := v_node;
        v_index := v_index + 1;
      end loop;
      x_nodeids := v_nodes;
    end if;
  end proc_get_subchain_nodes;
  /*==================================================
  procedure/function name :
      proc_get_node_detail
  description:
      this function perform:
       查询节点详情
  argument:
     p_nodeid： 审批节点id
     x_nodeids： 审批节点数组
  history:
      1.00  2019-06-14  xiaowei.yao  creation
  ==================================================*/

  procedure proc_get_node_detail(p_nodeid          in number,
                                p_instanceid      in varchar2,
                                p_chainuuid       in varchar2,
                                x_node_id         out number,
                                x_node_type       out varchar2,
                                x_nodename        out varchar2,
                                x_node_formurl    out varchar2,
                                x_approvers       out varchar2,
                                x_proxy_rule      out varchar2,
                                x_proxy_approvers out varchar2,
                                x_process_param   out dbpm_process_param_rec,
                                x_business_param  out dbpm_business_param_tbl) is

    v_process_param  dbpm_process_param_rec := dbpm_process_param_rec(null,
                                                                      null,
                                                                      null,
                                                                      null,
                                                                      null,
                                                                      null,
                                                                      null);
    v_business_param dbpm_business_param_tbl := dbpm_business_param_tbl();
    v_subchainparams json_list;
    v_subchainparam  json;
    v_subparams      json_list;
    v_subparam       json;
    v_re             json;
    v_proc_param     json;
    v_recontent      clob;
    v_result_flag    varchar2(1000);
    v_msg            varchar2(1000);
  begin

    begin
      select dn.node_formurl, dcn.node_id, dcn.node_type
        into x_node_formurl, x_node_id, x_node_type
        from dbpm_process_nodes dn, dbpm_chain_nodes dcn
       where dcn.node_id = p_nodeid
         and dn.node_id = dcn.parent_id;
    exception
      when others then
        x_nodename     := '';
        x_node_formurl := 'www.nopagefound.com';
        --  x_result_flag := 'N';
      --  x_error_msg   := '获取节点信息有误';
    end;
    begin
      --获取流程参数
      select dsp.request_content
        into v_recontent
        from dbpm_process_start_param dsp
       where dsp.instanceid = p_instanceid;
      v_re := json(v_recontent);
      if v_re.path('subChainParams') is not null then
        v_subchainparams := json_list(v_re.get('subChainParams'));
      end if;
      if v_re.path('processParam') is not null then
        v_proc_param                    := json(v_re.get('processParam'));
        v_process_param.processformno   := v_proc_param.get_string('processFormNo');
        v_process_param.processapplier  := v_proc_param.get_string('processApplier');
        v_process_param.processcode     := v_proc_param.get_string('processCode');
        v_process_param.businesssyscode := v_proc_param.get_string('businessSysCode');
      -- v_process_param.
      end if;
      for i in 1 .. v_subchainparams.count loop
        v_subchainparam := json(v_subchainparams.get(i));
        if v_subchainparam.get_string('subChainId') = p_chainuuid and
           v_subchainparam.path('subParam') is not null then
          v_subparams                    := json_list(v_subchainparam.get('subParam'));
          v_process_param.processParam := v_subchainparam.get_string('subProcessParam');
          v_process_param.processtitle   := v_subchainparam.get_string('subProcessTitle');
          for j in 1 .. v_subparams.count loop
            v_subparam := json(v_subparams.get(j));
            v_business_param.extend();
            v_business_param(j) := dbpm_business_param_rec(v_subparam.get_string('key'),
                                                           v_subparam.get_string('value'));
          end loop;
        end if;
      end loop;
    end;
    ---获取审批人
    dbpm_core_pkg.proc_get_approvers(p_node_id        => p_nodeid,
                                     p_document_id    => '',
                                     p_process_param  => v_process_param,
                                     p_business_param => v_business_param,
                                     x_approvers      => x_approvers,
                                     x_result_flag    => v_result_flag,
                                     x_error_msg      => v_msg);
    --获取代理规则
    dbpm_core_pkg.proc_get_proxy_rules(p_approvers       => x_approvers,
                                       p_node_id         => p_nodeid,
                                       p_document_id     => '',
                                       p_process_param   => v_process_param,
                                       p_business_param  => v_business_param,
                                       x_proxy_approvers => x_proxy_approvers,
                                       x_proxy_rules     => x_proxy_rule,
                                       x_result_flag     => v_result_flag,
                                       x_error_msg       => v_msg);
    x_process_param  := v_process_param;
    x_business_param := v_business_param;

  end proc_get_node_detail;
  /*
  * 获取审批链id
  */
  procedure proc_get_chain_id(p_node_id        number,
                              p_document_id    number,
                              p_process_param  dbpm_process_param_rec,
                              p_business_param dbpm_business_param_tbl,
                              x_chain_id       out number,
                              x_result_flag    out varchar2,
                              x_error_msg      out varchar2) is
    v_compare_result  varchar2(10);



    -- 有规则的审批链
    cursor v_chain_cur is
      select *
        from dbpm_node_chains dac
       where dac.node_id = p_node_id
         and (select count(1)
                from dbpm_chain_rules dcr
               where dcr.chain_id = dac.chain_id) > 0;
  begin
    for v_chain in v_chain_cur loop
      dbpm_core_pkg.proc_get_chain_rule_result(p_chain_id       => v_chain.chain_id,
                                               p_document_id    => p_document_id,
                                               p_process_param  => p_process_param,
                                               p_business_param => p_business_param,
                                               x_result         => v_compare_result,
                                               x_result_flag    => x_result_flag,
                                               x_error_msg      => x_error_msg);

      if v_compare_result = 'Y' then
        x_chain_id := v_chain.chain_id;
        return;
      end if;
    end loop;
    /*
    * 当没有存在有规则的审批链或者所有的规则审批链都不满足
    * 查找默认审批链
    */
    begin
      select dac.chain_id
        into x_chain_id
       from dbpm_node_chains dac
       where dac.node_id = p_node_id
         and (select count(1)
                from dbpm_chain_rules dcr
               where dcr.chain_id = dac.chain_id) = 0;
      x_result_flag := 'Y';
      x_error_msg   := '';
    exception
      when others then
        x_result_flag := 'N';
        x_error_msg   := '未找到符合条件的审批链';
    end;
  end proc_get_chain_id;

  /*
   *测试方法
   */
     procedure test_lsg(p_processid in String, x_chain out String) is

    v_chain type_array;
    v_str   Varchar2(200);
  begin
     dbpm_subprocess_pkg.proc_get_sub_processid(p_processid, v_chain);
    For i In 1 .. v_chain.count
    Loop
      v_str := v_str || i || v_chain(i);

      x_chain := v_str;
    End Loop;

    null;
  end test_lsg;

end dbpm_subprocess_pkg;

/

