create view DBPM_GEMS_TASK_APPROVE_LOG_V as
SELECT wt.instanceid instance_id,
       wt.taskid task_id,
       wt.protectedtextattribute3 dcno,
       wt.updatedby update_by,
       to_char(wt.createddate, 'yyyy-mm-dd hh24:mi:ss') created_date,
       to_char(wt.updateddate, 'yyyy-mm-dd hh24:mi:ss') updated_date,
       SUBSTR(cl.log_info, instr(cl.log_info, '(')) during_time
  FROM wftask wt, cux_log cl
 WHERE SUBSTR(cl.log_info, 0, instr(cl.log_info, '(') - 1) = wt.taskid
   AND cl.log_type = 'updateTaskOutcome-taskId'
   AND cl.log_level = 'INFO'
 ORDER BY cl.log_date DESC
/

