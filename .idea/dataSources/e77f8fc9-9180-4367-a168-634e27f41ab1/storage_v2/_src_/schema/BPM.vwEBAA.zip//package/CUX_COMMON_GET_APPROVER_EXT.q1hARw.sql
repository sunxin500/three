create package cux_common_get_approver_ext is

  -- Author  : xiaowei.yao
  -- Created : 2019/3/1 18:49:39
  -- Purpose : 海尔共用的找人方法

  -- Public type declarations
  /*==================================================
  Procedure/Function Name :
      proc_get_manager_ext
  Description:
      This function perform:
      通过申请人查找IDM直线经理
  Argument:
     p_business_param： 流程业务参数
  History:
      1.00  2019-3-01  xiaower.yao  Creation
  ==================================================*/
  PROCEDURE proc_get_manager_ext(p_node_id        NUMBER,
                                       p_document_id    VARCHAR2,
                                       p_process_param  dbpm_process_param_rec,
                                       p_business_param dbpm_business_param_tbl,
                                       x_approvers      OUT VARCHAR2,
                                       x_result_flag    OUT VARCHAR2,
                                       x_error_msg      OUT VARCHAR2);
 /*==================================================
  Procedure/Function Name :
      proc_get_sec_manager_ext
  Description:
      This function perform:
      通过申请人查找IDM二线经理
  Argument:
     p_business_param： 流程业务参数
  History:
      1.00  2019-3-01  xiaower.yao  Creation
  ==================================================*/
  PROCEDURE proc_get_sec_manager_ext(  p_node_id        NUMBER,
                                       p_document_id    VARCHAR2,
                                       p_process_param  dbpm_process_param_rec,
                                       p_business_param dbpm_business_param_tbl,
                                       x_approvers      OUT VARCHAR2,
                                       x_result_flag    OUT VARCHAR2,
                                       x_error_msg      OUT VARCHAR2);
/*==================================================
  Procedure/Function Name :
      proc_get_xwmaster_ext
  Description:
      This function perform:
      通过申请人查找小微自注册小微主(来源于EDW)
  Argument:
     p_business_param： 流程业务参数
  History:
      1.00  2019-3-01  xiaower.yao  Creation
  ==================================================*/
  PROCEDURE proc_get_xwmaster_ext(  p_node_id        NUMBER,
                                       p_document_id    VARCHAR2,
                                       p_process_param  dbpm_process_param_rec,
                                       p_business_param dbpm_business_param_tbl,
                                       x_approvers      OUT VARCHAR2,
                                       x_result_flag    OUT VARCHAR2,
                                       x_error_msg      OUT VARCHAR2);
 /*==================================================
  Procedure/Function Name :
      proc_get_ptmaster_ext
  Description:
      This function perform:
      通过申请人查找小微自注册平台主(来源于EDW)
  Argument:
     p_business_param： 流程业务参数
  History:
      1.00  2019-3-01  xiaower.yao  Creation
  ==================================================*/
  PROCEDURE proc_get_ptmaster_ext(  p_node_id        NUMBER,
                                       p_document_id    VARCHAR2,
                                       p_process_param  dbpm_process_param_rec,
                                       p_business_param dbpm_business_param_tbl,
                                       x_approvers      OUT VARCHAR2,
                                       x_result_flag    OUT VARCHAR2,
                                       x_error_msg      OUT VARCHAR2);

end cux_common_get_approver_ext;

/

