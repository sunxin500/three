create package     CUX_AUTH_EXT_PKG is

  -- Author  : YAOSHALLWE
  -- Created : 2019/1/4 18:27:55
  -- Purpose : 权限流程开发包

  /*==================================================
  Procedure/Function Name :
      proc_get_approvers_hooms_ext
  Description:
      This function perform:
      使用扩展方式来获取出国流程审批人
  Argument:
     p_node_id： 节点编码

  History:
      1.00  2019-01-04  xiaowei.yao  Creation
  ==================================================*/
  PROCEDURE proc_get_approvers_auth_ext( p_node_id        NUMBER,
                                         p_document_id    VARCHAR2,
                                         p_process_param  dbpm_process_param_rec,
                                         p_business_param dbpm_business_param_tbl,
                                         x_approvers      OUT VARCHAR2,
                                         x_result_flag    OUT VARCHAR2,
                                         x_error_msg      OUT VARCHAR2);
 /*==================================================
  Procedure/Function Name :
      func_is_exist
  Description:
      This function perform:
      判断字符串数组中是否包含另一字符串
      如：1234,234,321是否包含321
  Argument:
     p_value_array： 字符串数组
     p_param：  判断字符串
  History:
      1.00  2017-07-05  yong.xu  Creation
  ==================================================*/
  FUNCTION func_is_exist(p_value_array VARCHAR2, p_param VARCHAR2)
    RETURN VARCHAR2;
 /*==================================================
  Procedure/Function Name :
      proc_get_email_ext
  Description:
      This function perform:
     生成邮件的主题和内容
  History:
      1.00  2019-03-01  xiaower.yao  Creation
  ==================================================*/
  PROCEDURE proc_get_email_ext(p_taskid         VARCHAR2,
                               P_locale         VARCHAR2,
                               p_process_param  dbpm_process_param_rec,
                               p_business_param dbpm_business_param_tbl,
                               x_email_title    OUT VARCHAR2,
                               x_email_body     OUT VARCHAR2,
                               x_result_flag    OUT VARCHAR2,
                               x_error_msg      OUT VARCHAR2);
end CUX_AUTH_EXT_PKG;

/

