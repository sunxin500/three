create PACKAGE BODY dbpm_form_api_pkg IS

  /*==================================================
  整包覆盖迁移，migrate by xiaowei.yao 20180416
  ==================================================*/
  /*==================================================
  Procedure/Function Name :
      proc_query_all_process_form
  Description:
      This function perform:
      查询所有流程表单
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-01  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_query_all_process_form(p_request  CLOB,
                                        x_response OUT CLOB) IS
    v_request           json;
    v_response          pl_json := pl_json;
    v_line              pl_json;
    v_filter            json;
    v_total             NUMBER := 0;
    v_size              NUMBER := 200;
    v_page              NUMBER := 1;
    v_current_user      varchar2(30);
    v_space_id          varchar2(100);
    v_super_admin_count number;
    v_form_name         varchar2(1000);
    v_is_lov            varchar2(10);
    v_search_content    varchar2(4000);
    v_is_templates      varchar2(10); --判断是否是模版管理
    CURSOR v_form_cur IS
      SELECT *
        FROM (SELECT v.*, rownum cnt
                FROM (SELECT COUNT(1) over(PARTITION BY 1) total,
                             df.*,
                             df.form_id || '' form_id_str
                        FROM dbpm_form df
                       WHERE df.status = 'Published'
                         AND NVL(DF.SPACE_ID, 'NL') =
                             NVL(v_space_id, NVL(DF.SPACE_ID, 'NL'))
                         AND INSTR(NVL(DF.FORM_NAME, 'NL'),
                                   NVL(v_form_name, NVL(DF.FORM_NAME, 'NL'))) > 0
                       ORDER BY df.form_id DESC) v
               WHERE rownum <= v_page * v_size)
       WHERE cnt > (v_page - 1) * v_size;
    --lov
    CURSOR v_form_lov_cur IS
      SELECT *
        FROM (SELECT v.*, rownum cnt
                FROM (SELECT COUNT(1) over(PARTITION BY 1) total,
                             df.form_id,
                             df.form_name,
                             df.form_icon,
                             df.form_id || '' form_id_str
                        FROM dbpm_form df
                       WHERE df.status = 'Published'
                         AND (df.process_id is null or df.process_id = 1000)
                         AND NVL(DF.SPACE_ID, 'NL') =
                             NVL(v_space_id, NVL(DF.SPACE_ID, 'NL'))
                         AND INSTR(NVL(DF.FORM_NAME || TO_CHAR(DF.FORM_ID),
                                       'NL'),
                                   NVL(v_search_content,
                                       NVL(DF.FORM_NAME || TO_CHAR(DF.FORM_ID),
                                           'NL'))) > 0
                      union all
                      select null as total,
                             null as form_id,
                             null as form_name,
                             null as form_icon,
                             null as form_id_str
                        from dual
                       ORDER BY form_id DESC) v
               WHERE rownum <= v_page * v_size)
       WHERE cnt > (v_page - 1) * v_size;
    --模板管理lov
    CURSOR v_templates_form_cur IS
      SELECT *
        FROM (SELECT v.*, rownum cnt
                FROM (SELECT COUNT(1) over(PARTITION BY 1) total,
                             df.*,
                             df.form_id || '' form_id_str
                        FROM dbpm_form df
                       WHERE df.status = 'Published'
                         and df.form_id not in
                             (select nvl(t.form_id, -1)
                                from templates t
                               where t.space_id = v_space_id
                                 and t.deleted = 0)
                         AND NVL(DF.SPACE_ID, 'NL') =
                             NVL(v_space_id, NVL(DF.SPACE_ID, 'NL'))
                         AND INSTR(NVL(DF.FORM_NAME, 'NL'),
                                   NVL(v_form_name, NVL(DF.FORM_NAME, 'NL'))) > 0
                       ORDER BY df.form_id DESC) v
               WHERE rownum <= v_page * v_size)
       WHERE cnt > (v_page - 1) * v_size;
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;
    v_space_id     := v_request.get_string('spaceId');
    v_is_templates := v_request.get_string('isTemplates');
    v_is_lov       := v_request.get_string('isFormLov');
    if v_space_id is null then
      v_space_id := DFND_ADMIN_PKG.func_get_space_id(v_current_user);
    end if;
    v_form_name := dcld_comm_pkg.get_filter_value('formName', v_request);
    --如果未找到company_id,设置company_id为-1
    --如果是超级管理员,设置company_id为null
    select count(1)
      into v_super_admin_count
      from dbpm_administrators t
     where t.user_code = v_current_user
       and t.admin_type = 'SuperAdmin';
    if v_space_id is null then
      v_space_id := '-';
    end if;
    /*    if v_super_admin_count > 0 then
      v_space_id := null;
    end if;*/

    IF v_request.exist('page') THEN
      v_page := v_request.get_number('page');
    END IF;
    IF v_request.exist('size') THEN
      v_size := v_request.get_number('size');
    END IF;
    v_search_content := dcld_comm_pkg.get_filter_value('all', v_request);
    IF v_is_templates = 'Y' THEN
      FOR v_form IN v_templates_form_cur LOOP
        v_total := v_form.total;
        v_line  := pl_json;
        v_line.set_value('formId', v_form.form_id);
        v_line.set_value('formIdStr', v_form.form_id_str);
        v_line.set_value('formName', v_form.form_name);
        v_line.set_value('thumbPicCode', v_form.form_icon);
        v_response.add_list_item('formList', v_line);
      END LOOP;
    elsif v_is_lov = 'Y' then
      FOR v_form IN v_form_lov_cur LOOP
        v_total := v_form.total;
        v_line  := pl_json;
        v_line.set_value('formId', v_form.form_id);
        v_line.set_value('formIdStr', v_form.form_id_str);
        v_line.set_value('formName', v_form.form_name);
        v_line.set_value('thumbPicCode', v_form.form_icon);
        v_response.add_list_item('formList', v_line);
      END LOOP;

    ELSE
      FOR v_form IN v_form_cur LOOP
        v_total := v_form.total;
        v_line  := pl_json;
        v_line.set_value('formId', v_form.form_id);
        v_line.set_value('formIdStr', v_form.form_id_str);
        v_line.set_value('formName', v_form.form_name);
        v_line.set_value('thumbPicCode', v_form.form_icon);
        v_response.add_list_item('formList', v_line);
      END LOOP;
    END IF;

    v_response.set_value('total', v_total);
    x_response := v_response.to_json;
  END proc_query_all_process_form;

  /*==================================================
  Procedure/Function Name :
      proc_save_process_form
  Description:
      This function perform:
      保存流程表单
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-01  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_save_process_form(p_request CLOB, x_response OUT CLOB) IS
    v_request          json;
    v_response         pl_json := pl_json;
    v_current_user     VARCHAR2(50); --获取当前用户
    v_count            NUMBER := 0;
    v_form_id          NUMBER;
    v_process_id       NUMBER := 1000;
    v_form_name        VARCHAR2(200);
    v_config_html      CLOB := ' ';
    v_process_html     CLOB := ' ';
    v_is_required      VARCHAR2(10);
    v_is_title         VARCHAR2(10);
    v_is_preview       VARCHAR2(10);
    v_is_print         VARCHAR2(10);
    v_is_visiable      VARCHAR2(10);
    v_is_keyword       VARCHAR2(10);
    v_IS_FOLD          varchar2(10);
    v_TEXT_ALIGN       varchar2(50);
    v_config_list      json_list;
    v_field            json;
    v_table_config     json;
    v_tbl_cfg_list     json_list;
    v_column           json;
    v_text_index       NUMBER := 0;
    v_number_index     NUMBER := 0;
    v_textarea_index   number := 0;
    v_tbl_text_index   NUMBER := 0;
    v_tbl_number_index NUMBER := 0;
    v_attr_name        VARCHAR2(100);
    v_status           VARCHAR2(10);
    v_form_code        VARCHAR2(100);
    v_rows             NUMBER;
    v_maxColumns       number;
    v_order_seq        NUMBER; --排序字段
    v_is_mobileShow    varchar2(100); --移动端是否显示字段
    v_space_id         varchar2(100);
    v_is_change        number;
    v_count_change     number;
    v_table_name       varchar2(500); --存数据映射表名
    v_cascade_config   json;
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;
    v_space_id     := v_request.get_string('spaceId');
    if v_space_id is null then
      v_space_id := DFND_ADMIN_PKG.func_get_space_id(v_current_user);
    end if;
    IF v_request.get('formId') IS NOT NULL THEN
      v_form_id := v_request.get('formId').get_number;
    ELSE
      v_form_id := dbpm_form_s.nextval;
    END IF;

    SELECT COUNT(1)
      INTO v_count
      FROM dbpm_form df
     WHERE df.form_id = v_form_id;

    v_form_name := v_request.get('formName').get_string;
    IF v_request.get('formName').get_string IS NULL THEN
      --v_response.fail('表单名称不能为空，请确认！');
      v_response.fail(DCLD_COMM_PKG.func_get_err_msg('DCLD-00006',
                                                     v_request.locale));
      x_response := v_response.to_json;
      RETURN;
    END IF;
    IF v_request.exist('configHtml') AND
       v_request.get_string('configHtml') IS NOT NULL THEN
      v_request.get('configHtml').get_string(v_config_html);
    END IF;
    IF v_request.exist('processHtml') AND
       v_request.get_string('processHtml') IS NOT NULL THEN
      v_request.get('processHtml').get_string(v_process_html);
    END IF;
    --v_config_html  := v_request.get('configHtml').get_string;
    --v_process_html := v_request.get('processHtml').get_string;
    v_status      := v_request.get('status').get_string;
    v_maxColumns  := v_request.get_number('maxColumns');
    v_config_list := json_list(v_request.path('configList'));

    IF v_count > 0 THEN
      DELETE FROM dbpm_form_field dff WHERE dff.form_id = v_form_id;
      -- 如果是发布操作，修改其它版本的状态
      IF v_status = 'Published' THEN
        SELECT df.form_code
          INTO v_form_code
          FROM dbpm_form df
         WHERE df.form_id = v_form_id;
        /*SELECT df.form_id
            INTO v_is_change
            FROM dbpm_form df
           WHERE df.form_code = v_form_code
             and df.status = 'Published';
        */
        UPDATE dbpm_form df
           SET df.status = 'Migrated'
         WHERE df.form_code = v_form_code
           AND df.status = 'Published'
           AND df.form_id <> v_form_id;
        --修改模板状态
        /*       select count(*)
          into v_count_change
          from templates t
         where t.form_id = v_is_change;
        if v_count_change <> 0 then
          update templates t
             set t.form_id = v_form_id
           where t.form_id = v_is_change;
        end if;*/
      END IF;
      UPDATE dbpm_form df
         SET df.form_name             = v_form_name,
             df.config_html           = v_config_html,
             df.process_html          = v_process_html,
             df.status                = v_status,
             df.object_version_number = df.object_version_number + 1,
             df.last_update_date      = SYSDATE,
             df.last_updated_by       = v_current_user,
             df.form_max_column       = v_maxColumns
       WHERE df.form_id = v_form_id;
    ELSE
      INSERT INTO dbpm_form
        (form_id,
         form_code,
         process_id,
         form_name,
         form_icon,
         config_html,
         process_html,
         version,
         status,
         created_by,
         last_updated_by,
         space_id)
      VALUES
        (v_form_id,
         v_form_id,
         v_process_id,
         v_form_name,
         NULL,
         v_config_html,
         v_process_html,
         1,
         v_status,
         v_current_user,
         v_current_user,
         v_space_id);
    END IF;

    DELETE FROM dbpm_form_field_mapping dfam
     WHERE dfam.form_id = v_form_id;

    FOR i IN 1 .. v_config_list.count LOOP
      v_field := json(v_config_list.get(i));
      -- 插入dbpm_form_field
      IF v_field.get('isRequired').get_bool THEN
        v_is_required := 'Y';
      ELSE
        v_is_required := 'N';
      END IF;

      IF v_field.get('isTitle').get_bool THEN
        v_is_title := 'Y';
      ELSE
        v_is_title := 'N';
      END IF;
      IF v_field.get('isPreview').get_bool THEN
        v_is_preview := 'Y';
      ELSE
        v_is_preview := 'N';
      END IF;
      IF v_field.get('isPrint').get_bool THEN
        v_is_print := 'Y';
      ELSE
        v_is_print := 'N';
      END IF;
      IF v_field.get('isVisiable') IS NULL THEN
        v_is_visiable := 'Y';
      ELSIF v_field.get('isVisiable').get_bool THEN
        v_is_visiable := 'Y';
      ELSE
        v_is_visiable := 'N';
      END IF;
      IF v_field.get('isFold') IS NULL THEN
        v_IS_FOLD := 'Y';
      ELSIF v_field.get('isFold').get_bool THEN
        v_IS_FOLD := 'Y';
      ELSE
        v_IS_FOLD := 'N';
      END IF;
      IF v_field.get('isMobileShow') IS NULL THEN
        v_is_MobileShow := 'Y';
      ELSIF v_field.get('isMobileShow').get_bool THEN
        v_is_MobileShow := 'Y';
      ELSE
        v_is_MobileShow := 'N';
      END IF;
      IF v_field.get('isKeyword') IS NOT NULL AND v_field.get('isKeyword')
        .get_bool THEN
        v_is_keyword := 'Y';
      ELSE
        v_is_keyword := '';
      END IF;
      IF v_field.get('rows') IS NOT NULL THEN
        v_rows := v_field.get('rows').get_number;
      END IF;

      INSERT INTO dbpm_form_field
        (field_id,
         form_id,
         id,
         TYPE,
         label,
         attr_code,
         tip,
         is_title,
         is_required,
         is_preview,
         is_print,
         is_keyword,
         display_width,
         display_rows,
         default_value,
         suffix,
         data_source_text,
         data_source_code,
         data_format,
         arrange,
         default_date_value,
         default_time_value,
         number_range,
         is_visiable,
         cal_formula,
         cal_table_id,
         cal_column_id,
         created_by,
         last_updated_by,
         order_seq,
         IS_MOBILESHOW,
         is_fold,
         text_align,
         url,
         operation)
      VALUES
        (dbpm_form_field_s.nextval,
         v_form_id,
         v_field.get('id').get_string,
         v_field.get('type').get_string,
         v_field.get('title').get_string,
         v_field.get('attrCode').get_string,
         v_field.get('controlTip').get_string,
         v_is_title,
         v_is_required,
         v_is_preview,
         v_is_print,
         v_is_keyword,
         v_field.get('width').get_number,
         v_rows,
         v_field.get('defaultValue').get_string,
         v_field.get('suffix').get_string,
         v_field.get('source').get_string,
         v_field.get('sourceDataCode').get_string,
         v_field.get('validateData').get_string,
         v_field.get('sourceArrange').get_string,
         v_field.get('defaultDate').get_string,
         v_field.get('defaultTime').get_string,
         v_field.get('numberRange').get_string,
         v_is_visiable,
         v_field.get('calFormula').get_string,
         v_field.get('calTableId').get_string,
         v_field.get('calColumnId').get_string,
         v_current_user,
         v_current_user,
         v_field.get_number('orderSeq'),
         --移动端是否显示字段--xjl
         v_is_MobileShow,
         v_IS_FOLD,
         v_field.get_string('textAlign'),
         v_field.get_string('url'),
         v_field.get_string('fnOperation'));

      IF v_field.get('type').get_string = 'table-input' THEN
        v_tbl_text_index   := 0;
        v_tbl_number_index := 0;
        -- 表格处理
        v_table_config := json(v_field.path('tableConfig'));
        v_tbl_cfg_list := json_list(v_table_config.path('columnConfigs'));
        FOR j IN 1 .. v_tbl_cfg_list.count LOOP
          v_column := json(v_tbl_cfg_list.get(j));
          IF dbpm_comm_pkg.is_number_component(v_column.get('type')
                                               .get_string) = 'Y' THEN
            v_tbl_number_index := v_tbl_number_index + 1;
            v_attr_name        := 'NUMBER_ATTRIBUTE' || v_tbl_number_index;
          ELSE
            v_tbl_text_index := v_tbl_text_index + 1;
            v_attr_name      := 'TEXT_ATTRIBUTE' || v_tbl_text_index;
          END IF;
          INSERT INTO dbpm_form_field_mapping
            (form_id,
             id,
             table_name,
             attr_name,
             created_by,
             last_updated_by)
          VALUES
            (v_form_id,
             v_column.get('id').get_string,
             'BPM.DBPM_DOCUMENT_LINES',
             v_attr_name,
             v_current_user,
             v_current_user);
          IF v_column.get('isRequired').get_bool THEN
            v_is_required := 'Y';
          ELSE
            v_is_required := 'N';
          END IF;
          IF v_column.get('isKeyword') IS NOT NULL AND v_column.get('isKeyword')
            .get_bool THEN
            v_is_keyword := 'Y';
          ELSE
            v_is_keyword := '';
          END IF;

          IF v_column.get('isMobileShow') IS NULL THEN
            v_is_MobileShow := 'Y';
          ELSIF v_column.get('isMobileShow').get_bool THEN
            v_is_MobileShow := 'Y';
          ELSE
            v_is_MobileShow := 'N';
          END IF;
          INSERT INTO dbpm_form_field
            (field_id,
             form_id,
             id,
             parent_id,
             TYPE,
             label,
             attr_code,
             is_required,
             is_keyword,
             default_value,
             data_source_text,
             data_source_code,
             n1_id,
             n2_id,
             created_by,
             last_updated_by,
             order_seq,
             is_mobileshow,
             url,
             operation,
             cal_table_id)
          VALUES
            (dbpm_form_field_s.nextval,
             v_form_id,
             v_column.get('id').get_string,
             v_field.get('id').get_string,
             v_column.get('type').get_string,
             v_column.get('title').get_string,
             v_column.get('attrCode').get_string,
             v_is_required,
             v_is_keyword,
             v_column.get('defaultValue').get_string,
             v_column.get('source').get_string,
             v_column.get('sourceDataCode').get_string,
             v_column.get('n1Id').get_string,
             v_column.get('n2Id').get_string,
             v_current_user,
             v_current_user,
             v_column.get('orderSeq').get_number,
             v_is_MobileShow,
             v_column.get_string('url'),
             v_column.get_string('fnOperation'),
             v_column.get_string('calTableId'));
        END LOOP;
      ELSIF v_field.get('type').get_string = 'select-cascade' THEN
        -- 级联组件处理
        v_cascade_config := json(v_field.path('cascadeConfig'));
        v_tbl_cfg_list   := json_list(v_cascade_config.path('columnConfigs'));
        FOR j IN 1 .. v_tbl_cfg_list.count LOOP
          v_column := json(v_tbl_cfg_list.get(j));
          IF dbpm_comm_pkg.is_number_component(v_column.get('type')
                                               .get_string) = 'Y' THEN
            v_tbl_number_index := v_tbl_number_index + 1;
            v_attr_name        := 'NUMBER_ATTRIBUTE' || v_tbl_number_index;
          ELSE
            v_tbl_text_index := v_tbl_text_index + 1;
            v_attr_name      := 'TEXT_ATTRIBUTE' || v_tbl_text_index;
          END IF;
          INSERT INTO dbpm_form_field_mapping
            (form_id,
             id,
             table_name,
             attr_name,
             created_by,
             last_updated_by)
          VALUES
            (v_form_id,
             v_column.get('id').get_string,
             'BPM.DBPM_DOCUMENT_LINES',
             v_attr_name,
             v_current_user,
             v_current_user);
          IF v_column.get('isRequired').get_bool THEN
            v_is_required := 'Y';
          ELSE
            v_is_required := 'N';
          END IF;
          IF v_column.get('isKeyword') IS NOT NULL AND v_column.get('isKeyword')
            .get_bool THEN
            v_is_keyword := 'Y';
          ELSE
            v_is_keyword := '';
          END IF;

          IF v_column.get('isMobileShow') IS NULL THEN
            v_is_MobileShow := 'Y';
          ELSIF v_column.get('isMobileShow').get_bool THEN
            v_is_MobileShow := 'Y';
          ELSE
            v_is_MobileShow := 'N';
          END IF;
          INSERT INTO dbpm_form_field
            (field_id,
             form_id,
             id,
             parent_id,
             TYPE,
             label,
             attr_code,
             is_required,
             is_keyword,
             default_value,
             data_source_text,
             data_source_code,
             n1_id,
             n2_id,
             created_by,
             last_updated_by,
             order_seq,
             is_mobileshow,
             url,
             operation)
          VALUES
            (dbpm_form_field_s.nextval,
             v_form_id,
             v_column.get('id').get_string,
             v_field.get('id').get_string,
             v_column.get('type').get_string,
             v_column.get('title').get_string,
             v_column.get('attrCode').get_string,
             v_is_required,
             v_is_keyword,
             v_column.get('defaultValue').get_string,
             v_column.get('source').get_string,
             v_column.get('sourceDataCode').get_string,
             v_column.get('n1Id').get_string,
             v_column.get('n2Id').get_string,
             v_current_user,
             v_current_user,
             v_column.get('orderSeq').get_number,
             v_is_MobileShow,
             v_column.get_string('url'),
             v_column.get_string('fnOperation'));
        END LOOP;
      ELSE
        -- 标题字段存储在title字段中，不存在在弹性域字段中
        IF v_is_title = 'N' AND
           dbpm_comm_pkg.is_standard_component(v_field.get('type')
                                               .get_string) = 'N' THEN
          IF dbpm_comm_pkg.is_number_component(v_field.get('type')
                                               .get_string) = 'Y' THEN
            v_number_index := v_number_index + 1;
            v_attr_name    := 'NUMBER_ATTRIBUTE' || v_number_index;
            v_table_name   := 'BPM.DBPM_DOCUMENTS';
          elsif dbpm_comm_pkg.is_textarea_component(v_field.get('type')
                                                    .get_string) = 'Y' then
            v_textarea_index := v_textarea_index + 1;
            v_attr_name      := 'CLOB_ATTRIBUTE' || v_textarea_index;
            v_table_name     := 'BPM.DBPM_DOCUMENT_TEXTAREA';
          ELSE
            v_text_index := v_text_index + 1;
            v_attr_name  := 'TEXT_ATTRIBUTE' || v_text_index;
            v_table_name := 'BPM.DBPM_DOCUMENTS';
          END IF;
          INSERT INTO dbpm_form_field_mapping
            (form_id,
             id,
             table_name,
             attr_name,
             created_by,
             last_updated_by)
          VALUES
            (v_form_id,
             v_field.get('id').get_string,
             v_table_name,
             v_attr_name,
             v_current_user,
             v_current_user);
        END IF;
      END IF;
    END LOOP;

    v_response.set_value('formId', v_form_id);
    x_response := v_response.to_json;
  END proc_save_process_form;

  /*==================================================
  Procedure/Function Name :
      proc_get_form_config_html
  Description:
      This function perform:
      获取流程表单配置模版
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-01  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_get_form_config_html(p_request CLOB, x_response OUT CLOB) IS
    --v_request json;
    v_form_id NUMBER := to_char(p_request);
  BEGIN
    SELECT df.config_html
      INTO x_response
      FROM dbpm_form df
     WHERE df.form_id = v_form_id;
    /*  EXCEPTION
    WHEN OTHERS THEN
      x_response := '获取表单配置模版HTML出错';*/
  END proc_get_form_config_html;

  /*==================================================
  Procedure/Function Name :
      proc_get_form_process_html
  Description:
      This function perform:
      获取流程表单数据模块
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-01  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_get_form_process_html(p_request CLOB, x_response OUT CLOB) IS
    v_form_id NUMBER := to_char(p_request);
  BEGIN
    SELECT df.process_html
      INTO x_response
      FROM dbpm_form df
     WHERE df.form_id = v_form_id;
    /* EXCEPTION
    WHEN OTHERS THEN
      x_response := '获取表单数据模版HTML出错';*/
  END proc_get_form_process_html;

  /*==================================================
  Procedure/Function Name :
      proc_delete_process_form
  Description:
      This function perform:
      删除流程表单配置
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-05  chenming  Creation
  ==================================================*/
  PROCEDURE proc_delete_process_form(p_request CLOB, x_response OUT CLOB) IS
    v_api      VARCHAR2(100) := 'proc_delete_process_form';
    v_request  json;
    v_response pl_json := pl_json;
    v_form_id  NUMBER;
  BEGIN
    v_request := json(p_request, 'OBJECT');
    v_form_id := v_request.get('formId').get_number;
    DELETE FROM dbpm_form df WHERE df.form_id = v_form_id;
    DELETE FROM dbpm_form_field dff WHERE dff.form_id = v_form_id;
    DELETE FROM dbpm_form_field_mapping dffm
     WHERE dffm.form_id = v_form_id;
    x_response := v_response.to_json;
    /*  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_delete_process_form;

  /*==================================================
  Procedure/Function Name :
      proc_get_process_form
  Description:
      This function perform:
      获取流程表单配置
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-05  chenming  Creation
  ==================================================*/
  PROCEDURE proc_get_process_form(p_request CLOB, x_response OUT CLOB) IS
    v_api               VARCHAR2(100) := 'proc_get_process_form';
    v_request           json;
    v_response          pl_json := pl_json;
    v_current_user      VARCHAR2(50);
    v_form_id           NUMBER;
    v_creator_name      VARCHAR2(100);
    v_organization_id   VARCHAR2(100);
    v_organization_name VARCHAR2(500);
    v_line              pl_json := pl_json;
    v_configlist        pl_json := pl_json;
    v_table_config      pl_json := pl_json;
    v_table_column      pl_json;
    v_maxColumns        number;
    v_form_name         VARCHAR2(200);
    v_column_count      NUMBER := 0;
    v_access_code       VARCHAR2(100);
    v_process_id        number;
    v_is_shared         varchar2(50);
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;

    v_form_id := v_request.get('formId').get_number;
    SELECT df.form_name, df.form_max_column, df.process_id
      INTO v_form_name, v_maxColumns, v_process_id
      FROM dbpm_form df
     WHERE df.form_id = v_form_id;
    if v_process_id is not null then
      begin
        select dp.is_shared
          into v_is_shared
          from dbpm_process dp
         where dp.process_id = v_process_id;
      exception
        when others then
          v_is_shared := 'N';
      end;
    end if;
    v_response.set_value('isShared', v_is_shared);
    v_response.set_value('formId', v_form_id);
    v_response.set_value('formName', v_form_name);
    v_response.set_value('maxColumns', v_maxColumns);
    v_response.set_value('docNumber', 'Post-save generation');
    v_response.set_value('creatorCode', v_current_user);
    BEGIN
      SELECT nvl(fe.employee_name,fe.full_name)
        INTO v_creator_name
        FROM dfnd_employees fe
       WHERE upper(fe.employee_code) = upper(v_current_user);
      v_response.set_value('creatorName', v_creator_name);
    END;

    v_response.set_value('createTime',
                         to_char(SYSDATE, 'YYYY-MM-DD HH24:MI'));
    dcld_comm_pkg.get_user_master_organization(p_user_code         => v_current_user,
                                               x_organization_id   => v_organization_id,
                                               x_organization_name => v_organization_name);

    v_response.set_value('organizationId', v_organization_id);
    v_response.set_value('organizationName', v_organization_name);
    -- 生成configlist
    v_response := dbpm_form_api_pkg.func_get_form_config(p_request,
                                                         v_response);
    x_response := v_response.to_json;
    /*  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_get_process_form;

  /*
  * 生成configlist
  */
  FUNCTION func_get_form_config(p_request CLOB, p_response pl_json)
    RETURN pl_json IS
    v_request      json;
    v_response     pl_json := p_response;
    v_form_id      NUMBER;
    v_configlist   pl_json := pl_json;
    v_document_id  number;
    v_line         pl_json := pl_json;
    v_table_config pl_json := pl_json;
    v_table_column pl_json;
    v_form_name    VARCHAR2(200);
    v_column_count NUMBER := 0;
    v_access_code  VARCHAR2(100);
    v_status       varchar2(50);
    v_locale       varchar2(10);
    CURSOR v_filed_cur IS
      SELECT dff.*,
             t1.component_name,
             NVL2(T2.COMPONENT_NAME, T1.component_name, DFF.LABEL) LOCALE_NAME
        FROM dbpm_form_field dff,
             (select t.component_name, t.component_code
                from dcld_component_tl t
               where instr(T.LOCALE, v_locale) > 0) t1,
             dcld_component_tl t2
       WHERE dff.form_id = v_form_id
         AND DFF.TYPE = t1.COMPONENT_CODE(+)
         AND DFF.TYPE = T2.COMPONENT_CODE(+)
         AND DFF.LABEL = T2.COMPONENT_NAME(+)
         AND dff.parent_id IS NULL
       ORDER BY dff.order_seq /*(CASE
                                                                                                                                                                        WHEN dff.type = 'calculator-readonly' THEN
                                                                                                                                                                         9999999999999
                                                                                                                                                                        ELSE
                                                                                                                                                                         dff.order_seq
                                                                                                                                                                      END)*/
      ;
  BEGIN
    v_request := json(p_request, 'OBJECT');
    v_locale  := v_request.locale;
    v_form_id := v_request.get('formId').get_number;

    FOR v_filed IN v_filed_cur LOOP
      v_configlist := pl_json;
      v_configlist.set_value('id', v_filed.id);
      v_configlist.set_value('type', v_filed.type);
      v_configlist.set_value('title', v_filed.locale_name);
      v_configlist.set_value('attrCode', v_filed.attr_code);
      v_configlist.set_value('controlTip', v_filed.tip);
      IF v_filed.is_required = 'Y' THEN
        v_configlist.set_value('isRequired', TRUE);
      ELSE
        v_configlist.set_value('isRequired', FALSE);
      END IF;
      --当有taskId传入时，判断附件组件在完成流程完成状态可以编辑
      if v_filed.type = 'attachment-input' then
        if v_request.exist('documentId') then
          begin
            v_document_id := v_request.get_number('documentId');
            if v_document_id is not null then
              SELECT dd.status
                INTO v_status
                FROM dbpm_documents dd
               WHERE dd.document_id = v_document_id;
              if v_status = 'PROCESSING' then
                v_configlist.set_value('canOperation', false);
              else
                v_configlist.set_value('canOperation', TRUE);
              end if;
            end if;
          exception
            when others then
              v_configlist.set_value('canOperation', false);
          end;
        else
          v_configlist.set_value('canOperation', true);
        end if;
      end if;

      IF v_filed.is_title = 'Y' THEN
        v_configlist.set_value('isTitle', TRUE);
      ELSE
        v_configlist.set_value('isTitle', FALSE);
      END IF;
      IF v_filed.is_preview = 'Y' THEN
        v_configlist.set_value('isPreview', TRUE);
      ELSE
        v_configlist.set_value('isPreview', FALSE);
      END IF;
      IF v_filed.is_fold = 'Y' THEN
        v_configlist.set_value('isFold', TRUE);
      ELSE
        v_configlist.set_value('isFold', FALSE);
      END IF;
      /*IF v_filed.is_visiable = 'Y' THEN
        v_configlist.set_value('isVisiable', TRUE);
      ELSE
        v_configlist.set_value('isVisiable', FALSE);
      END IF;*/
      IF v_filed.is_keyword = 'Y' THEN
        v_configlist.set_value('isKeyword', TRUE);
      ELSE
        v_configlist.set_value('isKeyword', FALSE);
      END IF;
      v_configlist.set_value('width', v_filed.display_width);
      v_configlist.set_value('rows', v_filed.display_rows);
      IF v_filed.is_print = 'Y' THEN
        v_configlist.set_value('isPrint', TRUE);
      ELSE
        v_configlist.set_value('isPrint', FALSE);
      END IF;

      IF v_filed.is_mobileshow = 'Y' THEN
        --移动端是否显示字段
        v_configlist.set_value('isMobileShow', TRUE);
      ELSE
        v_configlist.set_value('isMobileShow', FALSE);
      END IF;
      v_configlist.set_value('defaultValue', v_filed.default_value);
      v_configlist.set_value('suffix', v_filed.suffix);
      v_configlist.set_value('validateData', v_filed.data_format);
      v_configlist.set_value('source', v_filed.data_source_text);
      v_configlist.set_value('sourceDataCode', v_filed.data_source_code);
      v_configlist.set_value('sourceArrange', v_filed.arrange);
      v_configlist.set_value('defaultDate', v_filed.default_date_value);
      v_configlist.set_value('defaultTime', v_filed.default_time_value);
      v_configlist.set_value('numberRange', v_filed.number_range);
      v_configlist.set_value('calFormula', v_filed.cal_formula);
      v_configlist.set_value('calTableId', v_filed.cal_table_id);
      v_configlist.set_value('calColumnId', v_filed.cal_column_id);
      v_configlist.set_value('textAlign', v_filed.text_align);
      v_configlist.set_value('url', v_filed.url);
      v_configlist.set_value('fnOperation', v_filed.operation);
      v_configlist.set_value('orderSeq', v_filed.order_seq); --add by chenzhibin
      -- 设置控制是否只读
      IF v_request.get('nodeId') IS NOT NULL THEN
        -- 如果是待办，需要根据审批节点动态获取只读属性

        IF v_request.get('nodeId').get_number = -1 THEN
          v_configlist.set_value('disabled', FALSE);
          v_configlist.set_value('isVisiable', TRUE);
        ELSE
          BEGIN
            SELECT dnff.access_code
              INTO v_access_code
              FROM dbpm_node_form_fields dnff
             WHERE dnff.node_id = v_request.get('nodeId').get_number
               AND dnff.id = v_filed.id;
            IF v_access_code = 'Updatable' THEN
              v_configlist.set_value('disabled', FALSE);
            ELSE
              v_configlist.set_value('disabled', TRUE);
            END IF;
            IF v_access_code = 'Invisible' THEN
              v_configlist.set_value('isVisiable', FALSE);
            ELSE
              v_configlist.set_value('isVisiable', TRUE);
            END IF;

          EXCEPTION
            WHEN OTHERS THEN
              v_configlist.set_value('disabled', TRUE);
              v_configlist.set_value('isVisiable', TRUE);
          END;
        END IF;
      ELSE
        -- 根据传递进来的访问类型，来控制字段是否只读
        IF v_request.get('readOnly') IS NOT NULL AND v_request.get('readOnly')
          .get_bool THEN
          v_configlist.set_value('disabled', TRUE);
        ELSE
          v_configlist.set_value('disabled', FALSE);
        END IF;
        v_configlist.set_value('isVisiable', TRUE);
      END IF;

      IF v_filed.type = 'table-input' THEN
        v_table_config := pl_json;
        v_column_count := 0;
        FOR v_column IN (SELECT dff.*, rownum order_num
                           FROM dbpm_form_field dff
                          WHERE dff.form_id = v_form_id
                            AND dff.parent_id = v_filed.id
                          ORDER BY dff.order_seq) LOOP
          v_column_count := v_column_count + 1;
          v_table_column := pl_json;
          v_table_column.set_value('title', v_column.label);
          v_table_column.set_value('attrCode', v_column.attr_code);
          v_table_column.set_value('id', v_column.id);
          IF v_column.is_required = 'Y' THEN
            v_table_column.set_value('isRequired', TRUE);
          ELSE
            v_table_column.set_value('isRequired', FALSE);
          END IF;
          IF v_column.is_keyword = 'Y' THEN
            v_table_column.set_value('isKeyword', TRUE);
          ELSE
            v_table_column.set_value('isKeyword', FALSE);
          END IF;
          v_table_column.set_value('defaultValue', v_column.default_value);
          v_table_column.set_value('source', v_column.data_source_text);
          v_table_column.set_value('sourceDataCode',
                                   v_column.data_source_code);
          IF v_column.is_mobileshow = 'Y' THEN
            --移动端是否显示字段
            v_table_column.set_value('isMobileShow', TRUE);
          ELSE
            v_table_column.set_value('isMobileShow', FALSE);
          END IF;
          v_table_column.set_value('type', v_column.type);
          v_table_column.set_value('n1Id', v_column.n1_id);
          v_table_column.set_value('n2Id', v_column.n2_id);
          --v_table_column.set_value('order', v_column.order_num);
          v_table_column.set_value('order', v_column.order_seq);
          v_table_column.set_value('orderSeq', v_column.order_seq); -- add by chenzhibin
          v_table_column.set_value('url', v_column.url);
          v_table_column.set_value('fnOperation', v_column.operation);
          v_table_column.set_value('calTableId', v_column.cal_table_id);
          v_table_config.add_list_item('columnConfigs', v_table_column);
        END LOOP;
        v_table_config.set_value('columnNumber', v_column_count);
        v_configlist.set_value('tableConfig', v_table_config);
      ELSE
        v_configlist.set_value('tableConfig', 'null');
      END IF;

      IF v_filed.type = 'select-cascade' THEN
        v_table_config := pl_json;
        v_column_count := 0;
        FOR v_column IN (SELECT dff.*, rownum order_num
                           FROM dbpm_form_field dff
                          WHERE dff.form_id = v_form_id
                            AND dff.parent_id = v_filed.id
                          ORDER BY dff.order_seq) LOOP
          v_column_count := v_column_count + 1;
          v_table_column := pl_json;
          v_table_column.set_value('title', v_column.label);
          v_table_column.set_value('attrCode', v_column.attr_code);
          v_table_column.set_value('id', v_column.id);
          IF v_column.is_required = 'Y' THEN
            v_table_column.set_value('isRequired', TRUE);
          ELSE
            v_table_column.set_value('isRequired', FALSE);
          END IF;
          IF v_column.is_keyword = 'Y' THEN
            v_table_column.set_value('isKeyword', TRUE);
          ELSE
            v_table_column.set_value('isKeyword', FALSE);
          END IF;
          v_table_column.set_value('defaultValue', v_column.default_value);
          v_table_column.set_value('source', v_column.data_source_text);
          v_table_column.set_value('sourceDataCode',
                                   v_column.data_source_code);
          IF v_column.is_mobileshow = 'Y' THEN
            --移动端是否显示字段
            v_table_column.set_value('isMobileShow', TRUE);
          ELSE
            v_table_column.set_value('isMobileShow', FALSE);
          END IF;
          v_table_column.set_value('type', v_column.type);
          v_table_column.set_value('n1Id', v_column.n1_id);
          v_table_column.set_value('n2Id', v_column.n2_id);
          v_table_column.set_value('order', v_column.order_num);
          v_table_column.set_value('url', v_column.url);
          v_table_column.set_value('fnOperation', v_column.operation);
          v_table_column.set_value('orderSeq', v_column.order_seq); -- add by chenzhibin
          v_table_config.add_list_item('columnConfigs', v_table_column);
        END LOOP;
        v_table_config.set_value('columnNumber', v_column_count);
        v_configlist.set_value('cascadeConfig', v_table_config);
      ELSE
        v_configlist.set_value('cascadeConfig', 'null');
      END IF;

      v_response.add_list_item('configList', v_configlist);
    END LOOP;
    RETURN v_response;
  END func_get_form_config;

  /*==================================================
  Procedure/Function Name :
      proc_save_document_data
  Description:
      This function perform:
      保存表单数据，需要判断是新建还更新
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-07  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_save_document_data(p_request CLOB, x_response OUT CLOB) IS
    v_request             json;
    v_response            pl_json := pl_json;
    v_api                 VARCHAR2(1000) := 'proc_save_document_data';
    v_current_user        VARCHAR2(50);
    v_form_values         json_list;
    v_form_value          json;
    v_table_value         json_list;
    v_cascade_value       json_list; --add by wlj
    v_column_list         json_list;
    v_column_json         json;
    v_document_id         NUMBER;
    v_document_number     VARCHAR2(100);
    v_form_id             NUMBER;
    v_organization_id     VARCHAR2(100);
    v_company_id          VARCHAR2(100);
    v_organization_name   VARCHAR2(500);
    v_process_id          NUMBER;
    v_process_code        VARCHAR2(100);
    v_process_name        VARCHAR2(500);
    v_title               VARCHAR2(4000);
    v_count               NUMBER := 0;
    v_user_name           VARCHAR2(100);
    v_doc_creator         VARCHAR2(100);
    v_sql                 clob;
    v_sql_clob            clob;
    v_line_sql            VARCHAR2(4000);
    v_column_name         VARCHAR2(100);
    v_status              VARCHAR2(100) := 'NEW';
    v_line_id             NUMBER;
    v_attr_name           VARCHAR2(4000);
    v_error_msg           VARCHAR2(4000);
    v_column_name_meaning VARCHAR2(100); --表单中列的中文名称
    v_is_required         VARCHAR2(10);
    v_temp_form_value     VARCHAR2(4000);
    v_form_value_clob     clob;
    v_TEXTAREA_count      number;

    --附件
    v_temp_attachment_array json_list;
    v_attach                json;
    v_temp_attachid         NUMBER;
    v_fun_id                NUMBER;
    v_fun_name              VARCHAR2(100);
    v_temp_attachname       VARCHAR2(4000);
    v_temp_attachdocid      VARCHAR2(4000);
    v_temp_attachdocurl     VARCHAR2(4000);
    v_temp_attachdoctype    VARCHAR2(4000);
    v_temp_upload_date      date;
    v_temp_upload_user      varchar2(100);

    --扩展外部表单功能begin
    --描述：
    --1.根据流程种类和表单种类来确定是否是外部表单
    --2.formKey为外部表的ID，这里需要在dbpm_documents表中建立外部表单，得云流程，组织的关系
    v_process_class varchar2(100); --流程种类
    v_doc_sys_code  varchar2(100); --表单种类
    --扩展外部表单功能end
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;

    IF v_request.get('documentId') IS NULL THEN
      v_document_id := dbpm_documents_s.nextval;
    ELSE
      v_document_id := v_request.get('documentId').get_number;
      IF v_request.get('status')
       .get_string IS NULL OR v_request.get('status').get_string = 'null' THEN
        SELECT dd.status
          INTO v_status
          FROM dbpm_documents dd
         WHERE dd.document_id = v_document_id;
      ELSE
        v_status := v_request.get('status').get_string;
      END IF;
    END IF;

    -- 获取组织ID
    IF v_request.get('organizationId') IS NULL THEN
      dcld_comm_pkg.get_user_master_organization(p_user_code         => v_current_user,
                                                 x_organization_id   => v_organization_id,
                                                 x_organization_name => v_organization_name);
    ELSE
      v_organization_id := v_request.get('organizationId').get_string;
    END IF;

    IF v_organization_id IS NULL THEN
      v_response.fail(DCLD_COMM_PKG.func_get_err_msg('DCLD-00024',
                                                       v_request.locale));
        x_response := v_response.to_json;
        RETURN;
    END IF;

    --扩展外部表单功能begin
    v_process_class := v_request.get_string('processClass');
    v_doc_sys_code  := v_request.get_string('docSysCode');
    if v_doc_sys_code = 'BPM' or v_doc_sys_code is null THEN
      NULL;
    ELSE
      proc_save_document_data_ext(p_request, x_response);
      return;
    END IF;
    --扩展外部表单功能end

  v_form_id := v_request.get_number('formId');



    BEGIN
      SELECT do.company_id
        INTO v_company_id
        FROM dfnd_organizations do
       WHERE do.organization_id = v_organization_id;
    EXCEPTION
      WHEN OTHERS THEN
        v_company_id := '';
    END;

    BEGIN
      SELECT df.process_id
        INTO v_process_id
        FROM dbpm_form df
       WHERE df.form_id = v_form_id;
      SELECT dpt.process_name, dp.process_code
        INTO v_process_name, v_process_code
        FROM dbpm_process dp, dbpm_process_tl dpt
       WHERE dpt.process_id = dp.process_id
         AND dpt.locale = 'en_US'
         AND dp.process_id = v_process_id;

    EXCEPTION
      WHEN OTHERS THEN
        --v_response.fail('保存表单数据出错，该表单没有找到对应的流程信息');
        v_response.fail(DCLD_COMM_PKG.func_get_err_msg('DCLD-00007',
                                                       v_request.locale));
        x_response := v_response.to_json;
        RETURN;
    END;
    SELECT COUNT(1)
      INTO v_count
      FROM dbpm_documents dd
     WHERE dd.document_id = v_document_id;

    SELECT NVL(de.full_name,de.employee_name), de.employee_name
      INTO v_user_name, v_doc_creator
      FROM dfnd_employees de
     WHERE upper(de.employee_code) = upper(v_current_user);
    v_title := v_user_name || '发起的' || v_process_name;

    v_sql := 'update dbpm_documents set  status = ''' || v_status || ''' ';

    -- 删除表单行数据
    DELETE FROM dbpm_document_lines ddl
     WHERE ddl.document_id = v_document_id;
    --删除表单文本域数据
    DELETE FROM DBPM_DOCUMENT_TEXTAREA DDT
     WHERE DDT.DOCUMENT_ID = v_document_id;
    v_form_values := json_list(v_request.path('formValueList'));

    FOR i IN 1 .. v_form_values.count LOOP
      v_form_value := json(v_form_values.get(i));
      IF v_form_value.get('type').get_string = 'table-input' THEN
        IF v_form_value.get('tableValue') IS NULL THEN
          continue;
        END IF;
        v_table_value := json_list(v_form_value.path('tableValue'));
        FOR j IN 1 .. v_table_value.count LOOP
          v_column_list := json_list(json(v_table_value.get(j))
                                     .path('columnList'));

          v_line_id := dbpm_document_lines_s.nextval;
          -- 插入行表
          INSERT INTO dbpm_document_lines
            (line_id, document_id, table_id, created_by, last_updated_by)
          VALUES
            (v_line_id,
             v_document_id,
             v_form_value.get('id').get_string,
             v_current_user,
             v_current_user);
          -- 更新行表其他字段
          v_line_sql := 'update dbpm_document_lines set last_updated_by = ''' ||
                        v_current_user || '''';
          FOR k IN 1 .. v_column_list.count LOOP
            v_column_json := json(v_column_list.get(k));
            BEGIN
              SELECT dfam.attr_name
                INTO v_column_name
                FROM dbpm_form_field_mapping dfam
               WHERE dfam.form_id = v_form_id
                 AND dfam.id = v_column_json.get('id').get_string;
              SELECT dff.label, dff.is_required
                INTO v_column_name_meaning, v_is_required
                FROM dbpm_form_field dff
               WHERE dff.id = v_column_json.get('id').get_string
                 AND dff.form_id = v_form_id;
              IF dbpm_comm_pkg.is_number_component(v_column_json.get('type')
                                                   .get_string) = 'Y' THEN
                -- 如果是数字类型
                IF v_column_json.get('value').get_number IS NOT NULL THEN
                  v_line_sql := v_line_sql || ', ' || v_column_name ||
                                '=''' || v_column_json.get('value')
                               .get_number || '''';
                ELSE
                  --判断数字类型是否必输
                  IF v_is_required = 'Y' THEN
                    --v_response.fail(v_column_name_meaning || '不能为空，请确认！');
                    v_response.fail(DCLD_COMM_PKG.func_get_err_msg('DCLD-00008',
                                                                   v_request.locale,
                                                                   v_column_name_meaning));
                    x_response := v_response.to_json;
                    ROLLBACK;
                    RETURN;
                  END IF;
                END IF;
              ELSE
                -- 其他认为是字符串类型
                IF v_column_json.get('value').get_string IS NOT NULL THEN
                  v_line_sql := v_line_sql || ', ' || v_column_name ||
                                '=''' || v_column_json.get('value')
                               .get_string || '''';
                ELSE
                  --判断字符类型是否必输
                  IF v_is_required = 'Y' THEN
                    --v_response.fail(v_column_name_meaning || '不能为空，请确认！');
                    v_response.fail(DCLD_COMM_PKG.func_get_err_msg('DCLD-00008',
                                                                   v_request.locale,
                                                                   v_column_name_meaning));
                    x_response := v_response.to_json;
                    ROLLBACK;
                    RETURN;
                  END IF;
                END IF;
              END IF;

            EXCEPTION
              WHEN OTHERS THEN
                -- 没找到mapping，不处理
                NULL;
            END;
          END LOOP;
          v_line_sql := v_line_sql || ' where line_id = ' || v_line_id;
          EXECUTE IMMEDIATE v_line_sql;
        END LOOP;
      ELSIF v_form_value.get('type').get_string = 'select-cascade' THEN

        IF v_form_value.get('cascadeValue') IS NULL THEN
          continue;
        END IF;
        v_cascade_value := json_list(v_form_value.path('cascadeValue'));
        FOR cascade_item IN 1 .. v_cascade_value.count LOOP
          v_column_list := json_list(json(v_cascade_value.get(cascade_item))
                                     .path('columnList'));

          v_line_id := dbpm_document_lines_s.nextval;
          -- 插入行表
          INSERT INTO dbpm_document_lines
            (line_id, document_id, table_id, created_by, last_updated_by)
          VALUES
            (v_line_id,
             v_document_id,
             v_form_value.get('id').get_string,
             v_current_user,
             v_current_user);
          -- 更新行表其他字段
          v_line_sql := 'update dbpm_document_lines set last_updated_by = ''' ||
                        v_current_user || '''';
          FOR cascade_k IN 1 .. v_column_list.count LOOP
            v_column_json := json(v_column_list.get(cascade_k));
            BEGIN
              SELECT dfam.attr_name
                INTO v_column_name
                FROM dbpm_form_field_mapping dfam
               WHERE dfam.form_id = v_form_id
                 AND dfam.id = v_column_json.get('id').get_string;
              SELECT dff.label, dff.is_required
                INTO v_column_name_meaning, v_is_required
                FROM dbpm_form_field dff
               WHERE dff.id = v_column_json.get('id').get_string
                 AND dff.form_id = v_form_id;
              IF dbpm_comm_pkg.is_number_component(v_column_json.get('type')
                                                   .get_string) = 'Y' THEN
                -- 如果是数字类型
                IF v_column_json.get('value').get_number IS NOT NULL THEN
                  v_line_sql := v_line_sql || ', ' || v_column_name ||
                                '=''' || v_column_json.get('value')
                               .get_number || '''';
                ELSE
                  --判断数字类型是否必输
                  IF v_is_required = 'Y' THEN
                    --v_response.fail(v_column_name_meaning || '不能为空，请确认！');
                    v_response.fail(DCLD_COMM_PKG.func_get_err_msg('DCLD-00008',
                                                                   v_request.locale,
                                                                   v_column_name_meaning));
                    x_response := v_response.to_json;
                    ROLLBACK;
                    RETURN;
                  END IF;
                END IF;
              ELSE
                -- 其他认为是字符串类型
                IF v_column_json.get('value').get_string IS NOT NULL THEN
                  v_line_sql := v_line_sql || ', ' || v_column_name ||
                                '=''' || v_column_json.get('value')
                               .get_string || '''';
                ELSE
                  --判断字符类型是否必输
                  IF v_is_required = 'Y' THEN
                    --v_response.fail(v_column_name_meaning || '不能为空，请确认！');
                    v_response.fail(DCLD_COMM_PKG.func_get_err_msg('DCLD-00008',
                                                                   v_request.locale,
                                                                   v_column_name_meaning));
                    x_response := v_response.to_json;
                    ROLLBACK;
                    RETURN;
                  END IF;
                END IF;
              END IF;

            EXCEPTION
              WHEN OTHERS THEN
                -- 没找到mapping，不处理
                NULL;
            END;
          END LOOP;
          v_line_sql := v_line_sql || ' where line_id = ' || v_line_id;
          EXECUTE IMMEDIATE v_line_sql;
        END LOOP;
      ELSE
        -- 如果是弹性域字段对应的组件
        IF dbpm_comm_pkg.is_standard_component(v_form_value.get('type')
                                               .get_string) = 'N' THEN
          -- 判断是否必输
          IF v_form_value.get('isRequired').get_bool = TRUE THEN
            IF dbpm_comm_pkg.is_number_component(v_form_value.get('type')
                                                 .get_string) = 'Y' THEN
              -- 数字类型
              IF v_form_value.get('value').get_number IS NULL THEN
                SELECT dff.label
                  INTO v_attr_name
                  FROM dbpm_form_field dff, dbpm_form df
                 WHERE dff.id = v_form_value.get('id').get_string
                   and df.form_id = dff.form_id
                   and df.status = 'Published';
                --v_response.fail(v_attr_name || '不能为空，请确认！');
                v_response.fail(DCLD_COMM_PKG.func_get_err_msg('DCLD-00008',
                                                               v_request.locale,
                                                               v_attr_name));
                x_response := v_response.to_json;
                ROLLBACK;
                RETURN;
              END IF;
            ELSE
              -- 字符类型
              IF v_form_value.get('value').get_string IS NULL THEN
                SELECT dff.label
                  INTO v_attr_name
                  FROM dbpm_form_field dff, dbpm_form df
                 WHERE dff.id = v_form_value.get('id').get_string
                   and df.form_id = dff.form_id
                   and df.status = 'Published';
                --v_response.fail(v_attr_name || '不能为空，请确认！');
                v_response.fail(DCLD_COMM_PKG.func_get_err_msg('DCLD-00008',
                                                               v_request.locale,
                                                               v_attr_name));
                x_response := v_response.to_json;
                ROLLBACK;
                RETURN;
              END IF;
            END IF;
          END IF;
          -- 判断是否是标题字段
          IF v_form_value.get('isTitle').get_bool = TRUE THEN
            IF dbpm_comm_pkg.is_number_component(v_form_value.get('type')
                                                 .get_string) = 'Y' THEN
              v_title := to_char(v_form_value.get('value').get_number);
            ELSE
              v_title := v_form_value.get('value').get_string;
            END IF;
            v_sql := v_sql || ',title=''' || v_form_value.get('value')
                    .get_string || '''';
          ELSE
            SELECT dfam.attr_name
              INTO v_column_name
              FROM dbpm_form_field_mapping dfam
             WHERE dfam.form_id = v_form_id
               AND dfam.id = v_form_value.get('id').get_string;
            -- 需要区分数字类型还是字符串类型
            IF dbpm_comm_pkg.is_number_component(v_form_value.get('type')
                                                 .get_string) = 'Y' THEN

              v_temp_form_value := '';
              IF v_form_value.exist('value') THEN
                v_temp_form_value := to_char(v_form_value.get('value')
                                             .get_number);
              END IF;
              --add by wlj
              if v_temp_form_value is not null then
                v_sql := v_sql || ',' || v_column_name || '=' ||
                         v_temp_form_value;
              end if;
              --新增clob类型的列值
            elsif dbpm_comm_pkg.is_textarea_component(v_form_value.get('type')
                                                      .get_string) = 'Y' THEN
              begin
                if v_form_value.get('value') is not null then
                  /*v_form_value_clob := ' ';*/
                  dbms_lob.createtemporary(v_form_value_clob, true);
                  v_form_value.get('value').get_string(v_form_value_clob);
                end if;
              exception
                when others then
                  v_form_value_clob := null;
              end;

              select count(1)
                into v_TEXTAREA_count
                from DBPM_DOCUMENT_TEXTAREA ddt
               where ddt.document_id = v_document_id;
              if v_TEXTAREA_count = 0 then
                v_sql_clob := 'INSERT into DBPM_DOCUMENT_TEXTAREA (TEXTAREA_ID,DOCUMENT_ID ,' ||
                              v_column_name || ')VALUES(' ||
                              DBPM_DOCUMENT_TEXTAREA_S.NEXTVAL || ' ,' ||
                              v_document_id || ',:1)';
              else
                v_sql_clob := 'update DBPM_DOCUMENT_TEXTAREA set ' ||
                              v_column_name || '= :1 where DOCUMENT_ID =' ||
                              v_document_id;
              end if;
              /*   v_response.fail(v_sql_clob);
              x_response := v_response.to_json;
              return;*/

              EXECUTE IMMEDIATE v_sql_clob
                using v_form_value_clob;
              v_sql_clob := null;

            ELSE

              v_temp_form_value := '';
              IF v_form_value.exist('value') THEN
                v_temp_form_value := v_form_value.get('value').get_string;
              END IF;
              v_sql := v_sql || ',' || v_column_name || '=''' ||
                       v_temp_form_value || '''';

            END IF;
          END IF;
        END IF;
      END IF;
    END LOOP;

    IF v_count > 0 THEN
      SELECT dd.doc_number
        INTO v_document_number
        FROM dbpm_documents dd
       WHERE dd.document_id = v_document_id;
      v_sql := v_sql || ', doc_number = ''' || v_document_number ||
               ''' where document_id = ' || v_document_id;
      EXECUTE IMMEDIATE v_sql;
    ELSE
      dbpm_document_sequences_pkg.proc_get_doc_number(p_document_type   => v_process_code,
                                                      x_document_number => v_document_number,
                                                      x_return_message  => v_error_msg);
      IF v_error_msg IS NOT NULL AND v_document_number IS NULL THEN
        v_document_number := '';
      END IF;
      v_sql := v_sql || ', doc_number = ''' || v_document_number ||
               ''' where document_id = ' || v_document_id;
      INSERT INTO dbpm_documents
        (document_id,
         doc_number,
         title,
         doc_creator,
         doc_creator_name,
         doc_create_time,
         organization_id,
         company_id,
         process_id,
         process_code,
         form_id,
         created_by,
         last_updated_by)
      VALUES
        (v_document_id,
         v_document_number,
         v_title,
         v_current_user,
         v_doc_creator,
         SYSDATE,
         v_organization_id,
         v_company_id,
         v_process_id,
         v_process_code,
         v_form_id,
         v_current_user,
         v_current_user);
      EXECUTE IMMEDIATE v_sql;
    END IF;

    --先删除相关附件信息,再添加.
    BEGIN
      SELECT dd.source_document_id, dd.process_code
        INTO v_fun_id, v_fun_name
        FROM dbpm_documents dd
       WHERE dd.document_id = v_document_id;
    EXCEPTION
      WHEN no_data_found THEN
        v_fun_id   := NULL;
        v_fun_name := NULL;
    END;
    DELETE FROM dfnd_attachments dat WHERE dat.document_id = v_document_id;
    IF v_request.exist('attachments') THEN
      v_temp_attachment_array := json_list(v_request.get('attachments'));
      FOR i IN 1 .. v_temp_attachment_array.count LOOP
        v_attach := json(v_temp_attachment_array.get(i));
        --v_temp_attachid      := v_attach.get_number('attachmentId');
        v_temp_attachname    := v_attach.get_string('attachmentName');
        v_temp_attachdoctype := v_attach.get_string('fileSuffix');
        v_temp_attachdocurl  := v_attach.get_string('downloadUrl');
        v_temp_upload_user   := v_attach.get_string('creatorName');
        v_temp_upload_date   := v_attach.get_date('createTime');
        --v_temp_attachdocid   := v_attach.get_number('docId');
        INSERT INTO dfnd_attachments
          (attachment_id,
           attachment_name,
           document_id,
           download_url,
           fun_id,
           fun_name,
           suffix,
           created_by,
           last_updated_by,
           creation_date)
        VALUES
          (dfnd_attachments_s.nextval,
           v_temp_attachname,
           v_document_id,
           v_temp_attachdocurl,
           v_fun_id,
           v_fun_name,
           v_temp_attachdoctype,
           nvl(v_temp_upload_user, 'weblogic'),
           nvl(v_temp_upload_user, 'weblogic'),
           nvl(v_temp_upload_date, sysdate));
      END LOOP;
    END IF;
    v_response.set_value('docNumber', v_document_number);
    v_response.set_value('documentId', v_document_id);
    x_response := v_response.to_json;

    /*EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_save_document_data;

  /*==================================================
  Procedure/Function Name :
      proc_get_document_data
  Description:
      This function perform:
      获取表单数据
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-08  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_get_document_data(p_request CLOB, x_response OUT CLOB) IS
    v_api                VARCHAR2(1000) := 'proc_get_document_data';
    v_request            json;
    v_response           pl_json := pl_json;
    v_current_user       VARCHAR2(50);
    v_form_value         pl_json;
    v_table_value        pl_json;
    v_cascade_value      pl_json; --add by wlj
    v_column_json        pl_json;
    v_document_id        NUMBER;
    v_document_number    VARCHAR2(100);
    v_form_id            NUMBER;
    v_form_name          VARCHAR2(400);
    v_status             VARCHAR2(100);
    v_title              VARCHAR2(4000);
    v_creator_code       VARCHAR2(100);
    v_creator_name       VARCHAR2(100);
    v_create_time        VARCHAR2(100);
    v_organization_id    VARCHAR2(100);
    v_organization_name  VARCHAR2(500);
    v_value              VARCHAR2(4000);
    v_clob_value         clob;
    v_attr_value         VARCHAR2(4000);
    v_display_value      VARCHAR2(4000);
    v_attr_display_value VARCHAR2(4000);
    v_sql                VARCHAR2(4000);
    v_item_name          VARCHAR2(500);
    v_temp_code          VARCHAR2(100);
    v_maxColumns         number;
    --待阅ID
    v_read_id     NUMBER;
    v_attachments pl_json := pl_json;
    v_attach_item pl_json;
    v_usercode varchar2(100);
    --多选组件截取数据
    cursor v_mutli_select_cur is
      SELECT REGEXP_SUBSTR(v_value, '[^,]+', 1, LEVEL) as attr_value
        FROM DUAL
      CONNECT BY REGEXP_SUBSTR(v_value, '[^,]+', 1, LEVEL) IS NOT NULL;
    CURSOR v_attr_mapping_cur IS
      SELECT dff.id,
             dfam.attr_name,
             dff.type,
             dff.is_title,
             dff.is_required,
             dff.cal_formula,
             dff.cal_table_id,
             dff.cal_column_id,
             dff.data_source_code,
             dfam.table_name
        FROM dbpm_form_field_mapping dfam, dbpm_form_field dff
       WHERE dfam.form_id(+) = dff.form_id
         AND dfam.id(+) = dff.id
         AND dff.parent_id IS NULL
         AND dff.form_id = v_form_id;
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;
    v_read_id      := v_request.get_number('readId');
    /* update dbpm_document_read ddr
      set ddr.is_read = 'Y'
    where ddr.read_id = v_read_id;*/
    --如果有待阅 更新已读状态
    dbpm_task_to_read_pkg.update_task_read(v_read_id);
    v_document_id := v_request.get('documentId').get_number;
    SELECT dd.form_id,
           dd.doc_number,
           dd.title,
           dd.status,
           dd.doc_creator,
           dd.doc_creator_name,
           to_char(dd.doc_create_time, 'YYYY-MM-DD HH24:MI'),
           dd.organization_id,
           (SELECT do.organization_name
              FROM dfnd_organizations do
             WHERE do.organization_id = dd.organization_id
             and rownum = 1)
      INTO v_form_id,
           v_document_number,
           v_title,
           v_status,
           v_creator_code,
           v_creator_name,
           v_create_time,
           v_organization_id,
           v_organization_name
      FROM dbpm_documents dd
     WHERE dd.document_id = v_document_id;

    SELECT df.form_name
      INTO v_form_name
      FROM dbpm_form df
     WHERE df.form_id = v_form_id;
    -- add by chenzhibin begin
    BEGIN
      SELECT template_code
        INTO v_temp_code
        FROM (SELECT tmp.template_code
                FROM templates tmp, dbpm_documents dd
               WHERE tmp.form_id = dd.form_id
                 AND dd.document_id = v_document_id
                 AND tmp.deleted = 0
               ORDER BY tmp.id DESC) v
       WHERE rownum = 1;
    EXCEPTION
      WHEN no_data_found THEN
        NULL;
    END;
    -- add by chenzhibin end

    v_response.set_value('documentId', v_document_id);
    v_response.set_value('docNumber', v_document_number);
    v_response.set_value('formId', v_form_id);
    v_response.set_value('status', v_status);
    v_response.set_value('creatorCode', v_creator_code);
    v_response.set_value('creatorName', v_creator_name);
    v_response.set_value('createTime', v_create_time);
    v_response.set_value('organizationId', v_organization_id);
    v_response.set_value('organizationName', v_organization_name);
    v_response.set_value('formName', v_form_name);
    --移动段需要的字段
    v_response.set_value('mobileFormName', '单据详情');

    -- add by chenzhibin begin
    IF v_temp_code IS NOT NULL THEN
      v_response.set_value('templateCode', v_temp_code);
    END IF;
    -- add by chenzhibin end

    FOR v_attr_mapping IN v_attr_mapping_cur LOOP
      v_value      := null;
      v_form_value := pl_json;
      v_form_value.set_value('id', v_attr_mapping.id);
      v_form_value.set_value('type', v_attr_mapping.type);
      v_form_value.set_value('calFormula', v_attr_mapping.cal_formula);
      v_form_value.set_value('calTableId', v_attr_mapping.cal_table_id);
      v_form_value.set_value('calColumnId', v_attr_mapping.cal_column_id);

      IF v_attr_mapping.type = 'table-input' THEN
        v_form_value.set_value('value', 'null');
        v_form_value.set_value('isTitle', FALSE);
        v_form_value.set_value('isRequired', FALSE);
        FOR v_doc_line IN (SELECT *
                             FROM dbpm_document_lines
                            WHERE document_id = v_document_id
                              AND table_id = v_attr_mapping.id) LOOP
          v_table_value := pl_json;
          FOR v_line_col_map IN (SELECT dfam.*,
                                        dff.type,
                                        dff.data_source_code,
                                        dff.n1_id,
                                        dff.n2_id,
                                        rownum order_num
                                   FROM dbpm_form_field_mapping dfam,
                                        dbpm_form_field         dff
                                  WHERE dfam.form_id = dff.form_id
                                    AND dfam.id = dff.id
                                    AND dff.form_id = v_form_id
                                    AND dff.parent_id = v_attr_mapping.id
                                  ORDER BY dff.field_id) LOOP
            v_sql := 'SELECT ' || v_line_col_map.attr_name ||
                     ' FROM dbpm_document_lines WHERE document_id = ' ||
                     v_document_id || ' and line_id = ' ||
                     v_doc_line.line_id;
            /*   IF dbpm_comm_pkg.is_textarea_component(v_line_col_map.type) = 'Y' THEN
              EXECUTE IMMEDIATE v_sql
                INTO v_clob_value;
            else*/
            EXECUTE IMMEDIATE v_sql
              INTO v_value;
            /*   end if;*/
            v_column_json := pl_json;
            v_column_json.set_value('id', v_line_col_map.id);
            v_column_json.set_value('type', v_line_col_map.type);
            IF dbpm_comm_pkg.is_number_component(v_line_col_map.type) = 'Y' THEN
              -- 如果是数字类型
              v_column_json.set_value('value', to_number(v_value));
              v_column_json.set_value('displayValue', to_number(v_value));
            ELSE
              -- 否则是字符串类型
              v_column_json.set_value('value', v_value);
              -- 如果是下拉框，且datasource不为空，需要获取对应meaning
              IF (v_line_col_map.type = 'select-input' OR
                 v_line_col_map.type = 'radio-input' or
                 v_line_col_map.type = 'lov-input') AND
                 v_line_col_map.data_source_code IS NOT NULL THEN
                v_display_value := dbpm_data_source_api_pkg.get_data_value_name(p_data_source_code => v_line_col_map.data_source_code,
                                                                                p_data_value_code  => v_value);
                v_column_json.set_value('displayValue', v_display_value);
              ELSIF v_line_col_map.type = 'checkbox-input' AND
                    v_line_col_map.data_source_code IS NOT NULL THEN
                v_display_value := func_get_checkbox_disvalue(p_data_source_code => v_line_col_map.data_source_code,
                                                              p_value            => v_value);
                v_column_json.set_value('displayValue', v_display_value);
                -- 八局特有逻辑增加项目LOV显示
                -- 八局特有逻辑增加多选LOV显示 add by xjl
                 ELSIF v_attr_mapping.type = 'multi-select' THEN
                  v_display_value := null;
                  for c_mutli_select_cur in v_mutli_select_cur loop
                    v_attr_display_value := func_get_checkbox_disvalue(p_data_source_code => v_attr_mapping.data_source_code,
                                                                       p_value            => c_mutli_select_cur.attr_value);
                    if v_display_value is null then
                      v_display_value := v_attr_display_value;
                    else
                      v_display_value := v_display_value || ',' ||
                                         v_attr_display_value;
                    end if;
                  end loop;
                  v_form_value.set_value('displayValue', v_display_value);
                /*elsif v_attr_mapping.type = 'lov-project' and
                      v_value is not null then
                  select csp.project_name
                    into v_display_value
                    from cux_stm_projects_t csp
                   where csp.project_no = v_value;
                  v_column_json.set_value('displayValue', v_display_value);*/
              elsif v_attr_mapping.type = 'lov-org' and v_value is not null then
                select do.organization_name
                  into v_display_value
                  from dfnd_organizations do
                 where do.organization_id = v_value;
                v_column_json.set_value('displayValue', v_display_value);

              ELSE
                v_column_json.set_value('displayValue', v_value);
              END IF;
            END IF;
            v_column_json.set_value('n1Id', v_line_col_map.n1_id);
            v_column_json.set_value('n2Id', v_line_col_map.n2_id);
            v_column_json.set_value('order', v_line_col_map.order_num);
            v_table_value.add_list_item('columnList', v_column_json);
          END LOOP;
          v_form_value.add_list_item('tableValue', v_table_value);
        END LOOP;
      ELSIF v_attr_mapping.type = 'select-cascade' THEN
        v_form_value.set_value('value', 'null');
        v_form_value.set_value('isTitle', FALSE);
        v_form_value.set_value('isRequired', FALSE);
        FOR v_doc_line IN (SELECT *
                             FROM dbpm_document_lines
                            WHERE document_id = v_document_id
                              AND table_id = v_attr_mapping.id) LOOP
          v_cascade_value := pl_json;
          FOR v_line_col_map IN (SELECT dfam.*,
                                        dff.type,
                                        dff.data_source_code,
                                        dff.n1_id,
                                        dff.n2_id,
                                        rownum order_num
                                   FROM dbpm_form_field_mapping dfam,
                                        dbpm_form_field         dff
                                  WHERE dfam.form_id = dff.form_id
                                    AND dfam.id = dff.id
                                    AND dff.form_id = v_form_id
                                    AND dff.parent_id = v_attr_mapping.id
                                  ORDER BY dff.field_id) LOOP
            v_sql := 'SELECT ' || v_line_col_map.attr_name ||
                     ' FROM dbpm_document_lines WHERE document_id = ' ||
                     v_document_id || ' and line_id = ' ||
                     v_doc_line.line_id;
            /*   IF dbpm_comm_pkg.is_textarea_component(v_line_col_map.type) = 'Y' THEN
              EXECUTE IMMEDIATE v_sql
                INTO v_clob_value;
            else*/
            EXECUTE IMMEDIATE v_sql
              INTO v_value;
            /*   end if;*/
            v_column_json := pl_json;
            v_column_json.set_value('id', v_line_col_map.id);
            v_column_json.set_value('type', v_line_col_map.type);
            IF dbpm_comm_pkg.is_number_component(v_line_col_map.type) = 'Y' THEN
              -- 如果是数字类型
              v_column_json.set_value('value', to_number(v_value));
              v_column_json.set_value('displayValue', to_number(v_value));
            ELSE
              -- 否则是字符串类型
              v_column_json.set_value('value', v_value);
              -- 如果是下拉框，且datasource不为空，需要获取对应meaning
              IF (v_line_col_map.type = 'select-input' OR
                 v_line_col_map.type = 'radio-input' or
                 v_line_col_map.type = 'lov-input') AND
                 v_line_col_map.data_source_code IS NOT NULL THEN
                v_display_value := dbpm_data_source_api_pkg.get_data_value_name(p_data_source_code => v_line_col_map.data_source_code,
                                                                                p_data_value_code  => v_value);
                v_column_json.set_value('displayValue', v_display_value);
              ELSIF v_line_col_map.type = 'checkbox-input' AND
                    v_line_col_map.data_source_code IS NOT NULL THEN
                v_display_value := func_get_checkbox_disvalue(p_data_source_code => v_line_col_map.data_source_code,
                                                              p_value            => v_value);
                v_column_json.set_value('displayValue', v_display_value);
                -- 八局特有逻辑增加项目LOV显示
                -- 八局特有逻辑增加多选LOV显示 add by xjl
                ELSIF v_attr_mapping.type = 'multi-select' THEN
                  v_display_value := null;
                  for c_mutli_select_cur in v_mutli_select_cur loop
                    v_attr_display_value := func_get_checkbox_disvalue(p_data_source_code => v_attr_mapping.data_source_code,
                                                                       p_value            => c_mutli_select_cur.attr_value);
                    if v_display_value is null then
                      v_display_value := v_attr_display_value;
                    else
                      v_display_value := v_display_value || ',' ||
                                         v_attr_display_value;
                    end if;
                  end loop;
                  v_form_value.set_value('displayValue', v_display_value);
                /*elsif v_attr_mapping.type = 'lov-project' and
                      v_value is not null then
                  select csp.project_name
                    into v_display_value
                    from cux_stm_projects_t csp
                   where csp.project_no = v_value;
                  v_column_json.set_value('displayValue', v_display_value);*/
              elsif v_attr_mapping.type = 'lov-org' and v_value is not null then
                select do.organization_name
                  into v_display_value
                  from dfnd_organizations do
                 where do.organization_id = v_value;
                v_column_json.set_value('displayValue', v_display_value);

              ELSE
                v_column_json.set_value('displayValue', v_value);
              END IF;
            END IF;
            v_column_json.set_value('n1Id', v_line_col_map.n1_id);
            v_column_json.set_value('n2Id', v_line_col_map.n2_id);
            v_column_json.set_value('order', v_line_col_map.order_num);
            v_cascade_value.add_list_item('columnList', v_column_json);
          END LOOP;
          v_form_value.add_list_item('cascadeValue', v_cascade_value);
        END LOOP;
      ELSE
        -- 使用弹性域字段的组件
        IF dbpm_comm_pkg.is_standard_component(v_attr_mapping.type) = 'N' THEN
          IF v_attr_mapping.is_title = 'Y' THEN
            v_form_value.set_value('isTitle', TRUE);
            SELECT dd.title
              INTO v_value
              FROM dbpm_documents dd
             WHERE dd.document_id = v_document_id;
          ELSE
            v_form_value.set_value('isTitle', FALSE);
            v_sql := 'SELECT ' || v_attr_mapping.attr_name || ' FROM ' ||
                     v_attr_mapping.table_name || ' WHERE document_id = ' ||
                     v_document_id;
            --判断是否文本域组件字段数据
            IF dbpm_comm_pkg.is_textarea_component(v_attr_mapping.type) = 'Y' THEN
              BEGIN
                EXECUTE IMMEDIATE v_sql
                  INTO v_clob_value;
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  v_clob_value := null;
              END;
            else
              EXECUTE IMMEDIATE v_sql
                INTO v_value;
            end if;
          END IF;
          IF v_attr_mapping.is_required = 'Y' THEN
            v_form_value.set_value('isRequired', TRUE);
          ELSE
            v_form_value.set_value('isRequired', FALSE);
          END IF;

          IF dbpm_comm_pkg.is_number_component(v_attr_mapping.type) = 'Y' THEN
            -- 如果是数字类型
            v_form_value.set_value('value', to_number(v_value));
            -- 如果是下拉框或单选框，且datasource不为空，需要获取对应meaning
            IF (v_attr_mapping.type = 'select-input' OR
               v_attr_mapping.type = 'radio-input' OR
               v_attr_mapping.type = 'lov-input') AND
               v_attr_mapping.data_source_code IS NOT NULL THEN
              v_display_value := dbpm_data_source_api_pkg.get_data_value_name(p_data_source_code => v_attr_mapping.data_source_code,
                                                                              p_data_value_code  => v_value);
              v_form_value.set_value('displayValue', v_display_value);
            ELSIF v_attr_mapping.type = 'checkbox-input' AND
                  v_attr_mapping.data_source_code IS NOT NULL THEN
              v_display_value := func_get_checkbox_disvalue(p_data_source_code => v_attr_mapping.data_source_code,
                                                            p_value            => v_value);
              v_form_value.set_value('displayValue', v_display_value);
              -- 八局特有逻辑增加项目LOV显示
              /*  elsif v_attr_mapping.type = 'lov-project' and
                  v_value is not null then
              select csp.project_name
                into v_display_value
                from cux_stm_projects_t csp
               where csp.project_no = v_value;
              v_form_value.set_value('displayValue', v_display_value);*/
            elsif v_attr_mapping.type = 'lov-org' and v_value is not null then
              select do.organization_name
                into v_display_value
                from dfnd_organizations do
               where do.organization_id = v_value;
              v_form_value.set_value('displayValue', v_display_value);
            ELSE
              v_form_value.set_value('displayValue', v_value);
            END IF;
          ELSE
            -- 否则是字符串类型
            v_form_value.set_value('value', v_value);
            -- 如果是下拉框，且datasource不为空，需要获取对应meaning
            IF (v_attr_mapping.type = 'select-input' OR
               v_attr_mapping.type = 'radio-input' or
               v_attr_mapping.type = 'lov-input') AND
               v_attr_mapping.data_source_code IS NOT NULL THEN
              v_display_value := dbpm_data_source_api_pkg.get_data_value_name(p_data_source_code => v_attr_mapping.data_source_code,
                                                                              p_data_value_code  => v_value);
              v_form_value.set_value('displayValue', v_display_value);
            ELSIF v_attr_mapping.type = 'checkbox-input' AND
                  v_attr_mapping.data_source_code IS NOT NULL THEN
              v_display_value := func_get_checkbox_disvalue(p_data_source_code => v_attr_mapping.data_source_code,
                                                            p_value            => v_value);
              v_form_value.set_value('displayValue', v_display_value);
              -- 八局特有逻辑增加项目LOV显示
              -- 八局特有逻辑增加多选LOV显示 add by xjl
               ELSIF v_attr_mapping.type = 'multi-select' THEN
              v_display_value := null;
              for c_mutli_select_cur in v_mutli_select_cur loop
                v_attr_display_value := func_get_checkbox_disvalue(p_data_source_code => v_attr_mapping.data_source_code,
                                                                   p_value            => c_mutli_select_cur.attr_value);
                if v_display_value is null then
                  v_display_value := v_attr_display_value;
                else
                  v_display_value := v_display_value || ',' ||
                                     v_attr_display_value;
                end if;
              end loop;
              v_form_value.set_value('displayValue', v_display_value);
              /* elsif v_attr_mapping.type = 'lov-project' and
                  v_value is not null then
              select csp.project_name
                into v_display_value
                from cux_stm_projects_t csp
               where csp.project_no = v_value;
              v_form_value.set_value('displayValue', v_display_value);*/
            elsif v_attr_mapping.type = 'lov-org' and v_value is not null then
              select do.organization_name
                into v_display_value
                from dfnd_organizations do
               where do.organization_id = v_value;
              v_form_value.set_value('displayValue', v_display_value);
            elsif v_attr_mapping.type = 'lov-people' and
                  v_value is not null then
              select nvl(fe.employee_name,fe.english_name),fe.employee_code
                into v_display_value,v_usercode
                from dfnd_employees fe
               where upper(fe.employee_code) = upper(v_value);
              v_form_value.set_value('displayValue', v_display_value||'-'||v_usercode);
            elsif v_attr_mapping.type = 'textarea-input' and
                  v_clob_value is not null then
              v_form_value.set_value('value', v_clob_value);
            ELSE
              v_form_value.set_value('displayValue', v_value);
            END IF;
          END IF;
        ELSE
          IF v_attr_mapping.type = 'document-number-readonly' THEN
            v_form_value.set_value('value', v_document_number);
            v_form_value.set_value('displayValue', v_document_number);
          ELSIF v_attr_mapping.type = 'apply-date-readonly' THEN
            v_form_value.set_value('value', v_create_time);
            v_form_value.set_value('displayValue', v_create_time);
          ELSIF v_attr_mapping.type = 'applicant-readonly' THEN
            v_form_value.set_value('value', v_creator_name);
            v_form_value.set_value('displayValue', v_creator_name);
          ELSIF v_attr_mapping.type = 'usercode-readonly' THEN
            v_form_value.set_value('value', v_creator_code);
            v_form_value.set_value('displayValue', v_creator_code);
          ELSIF v_attr_mapping.type = 'department-readonly' THEN
            v_form_value.set_value('value', v_organization_id);
            v_form_value.set_value('displayValue', v_organization_name);
          END IF;
        END IF;
      END IF;

      v_response.add_list_item('formValueList', v_form_value);
    END LOOP;
    /*-- 获取附件
    v_attachments.set_data_type('ARRAY');
    FOR attach_item IN (SELECT *
                          FROM DFND_ATTACHMENTS AT
                         WHERE AT.DOCUMENT_ID = v_document_id) LOOP
      v_attach_item := pl_json;
      v_attach_item.set_value('attachmentName',
                              attach_item.attachment_name);
      v_attach_item.set_value('downloadUrl', attach_item.download_url);
      v_attach_item.set_value('docType', attach_item.suffix);
      v_attach_item.set_value('createBy', attach_item.created_by);
      v_attach_item.set_value('createDate', attach_item.creation_date);
      v_attachments.add_list_item(v_attach_item);
    END LOOP;
    v_response.set_value('attachments',v_attachments);*/
    -- 生成configlist
    v_response := dbpm_form_api_pkg.func_get_form_config(p_request,
                                                         v_response);

    x_response := v_response.to_json;

  END proc_get_document_data;

  /*==================================================
  Procedure/Function Name :
      proc_query_form_fields
  Description:
      This function perform:
      查询某个表单的所有字段
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-11  chenming  Creation
  ==================================================*/
  PROCEDURE proc_query_form_fields(p_request CLOB, x_response OUT CLOB) IS
    v_api      VARCHAR2(100) := 'proc_query_form_fields';
    v_request  json;
    v_form_id  NUMBER;
    v_line     pl_json;
    v_total    NUMBER := 0;
    v_response pl_json := pl_json;
    --v_fieldlist pl_json := pl_json;
    CURSOR v_field_cur IS
      SELECT dff.id, dff.label
        FROM dbpm_form_field dff
       WHERE dff.form_id = v_form_id;
  BEGIN
    v_request := json(p_request, 'OBJECT');
    v_form_id := v_request.get('formId').get_number;
    FOR v_field IN v_field_cur LOOP
      v_line := pl_json;
      v_line.set_value('id', v_field.id);
      v_line.set_value('label', v_field.label);
      v_response.add_list_item('fieldList', v_line);
      v_total := v_total + 1;
    END LOOP;
    v_response.set_value('total', v_total);
    --v_response.add_list_item(v_fieldlist);
    x_response := v_response.to_json;
    /*  EXCEPTION
    WHEN OTHERS THEN
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_query_form_fields;

  /*==================================================
  Procedure/Function Name :
      proc_relate_process_form
  Description:
      This function perform:
      关联流程与表单
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-11  chenming  Creation
  ==================================================*/
  PROCEDURE proc_relate_process_form(p_request CLOB, x_response OUT CLOB) IS
    v_api        VARCHAR2(100) := 'proc_relate_process_form';
    v_request    json;
    v_response   pl_json := pl_json;
    v_form_id    NUMBER;
    v_process_id NUMBER;
  BEGIN
    v_request    := json(p_request, 'OBJECT');
    v_form_id    := v_request.get('formId').get_number;
    v_process_id := v_request.get('processId').get_number;

    UPDATE dbpm_form df
       SET df.process_id = v_process_id
     WHERE df.form_id = v_form_id;

    x_response := v_response.to_json;
    /*  EXCEPTION
    WHEN OTHERS THEN
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_relate_process_form;

  /*
  * 获取复选框显示值
  */
  FUNCTION func_get_checkbox_disvalue(p_data_source_code VARCHAR2,
                                      p_value            VARCHAR2)
    RETURN VARCHAR2 IS
    v_display_value VARCHAR2(4000);
    v_item_name     VARCHAR2(500);
  BEGIN
    v_display_value := p_value;
    FOR v_item IN (WITH a AS
                      (SELECT p_value || ',' items FROM dual)
                     SELECT regexp_substr(items, '[^,]+', 1, rownum) item
                       FROM a
                     CONNECT BY rownum <=
                                length(regexp_replace(items, '[^,]+'))) LOOP
      v_item_name     := dbpm_data_source_api_pkg.get_data_value_name(p_data_source_code => p_data_source_code,
                                                                      p_data_value_code  => v_item.item);
      v_display_value := REPLACE(v_display_value, v_item.item, v_item_name);
    END LOOP;
    RETURN v_display_value;
  END func_get_checkbox_disvalue;

  /*==================================================
  Procedure/Function Name :
      proc_edit_process_form
  Description:
      This function perform:
      编辑流程表单（升级）
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-10-06  zhoujian.wang  Creation
  ==================================================*/
  PROCEDURE proc_edit_process_form(p_request CLOB, x_response OUT CLOB) IS
    v_api          VARCHAR2(100) := 'proc_edit_process_form';
    v_request      json;
    v_response     pl_json := pl_json;
    v_current_user VARCHAR2(100);
    v_form_id      NUMBER;
    v_new_form_id  NUMBER;
    v_status       VARCHAR2(100);
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_form_id      := v_request.get('formId').get_number;
    v_current_user := v_request.username;
    SELECT df.status
      INTO v_status
      FROM dbpm_form df
     WHERE df.form_id = v_form_id;
    IF v_status = 'Saved' THEN
      v_response.set_value('formId', v_form_id);
    ELSE
      dbpm_core_pkg.proc_upgrade_form_version(p_form_id      => v_form_id,
                                              p_current_user => v_current_user,
                                              x_form_id      => v_new_form_id);

      v_response.set_value('formId', v_new_form_id);
    END IF;

    x_response := v_response.to_json;
    /*  EXCEPTION
    WHEN OTHERS THEN
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_edit_process_form;

  /*==================================================
  Procedure/Function Name :
      proc_query_process_form
  Description:
      This function perform:
      查询所有的表单
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-10-06  zhiheng.wei  Creation
  ==================================================*/
  PROCEDURE proc_query_process_form(p_request CLOB, x_response OUT CLOB) IS
    v_request           json;
    v_response          pl_json := pl_json;
    v_forms             pl_json;
    v_index             NUMBER := 0;
    v_space_id          varchar2(100);
    v_current_user      varchar2(30);
    v_super_admin_count number;
    v_total             NUMBER := 0;
    v_size              NUMBER := 10;
    v_page              NUMBER := 1;
    v_form_name         varchar2(4000);
    CURSOR v_form_cur IS
      SELECT *
        FROM (SELECT v.*, rownum cnt
                FROM (SELECT COUNT(1) over(PARTITION BY 1) total,
                             df.form_name,
                             df.version,
                             df.status,
                             df.form_code,
                             df.form_id
                        FROM dbpm_form df
                       WHERE df.status <> 'Published'
                         AND NVL(DF.SPACE_ID, 'NL') =
                             NVL(v_space_id, NVL(DF.SPACE_ID, 'NL'))
                         AND INSTR(NVL(DF.FORM_NAME, 'NL'),
                                   NVL(v_form_name, NVL(DF.FORM_NAME, 'NL'))) > 0
                       ORDER BY df.creation_date desc, df.version) v
               WHERE rownum <= v_page * v_size)
       WHERE cnt > (v_page - 1) * v_size;
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;
    v_space_id     := v_request.get_string('spaceId');
    if v_space_id is null then
      v_space_id := DFND_ADMIN_PKG.func_get_space_id(v_current_user);
    end if;
    v_form_name := dcld_comm_pkg.get_filter_value('formName', v_request);
    IF v_request.exist('page') THEN
      v_page := v_request.get_number('page');
    END IF;
    IF v_request.exist('size') THEN
      v_size := v_request.get_number('size');
    END IF;
    --如果未找到company_id,设置company_id为-1
    --如果是超级管理员,设置company_id为null
    select count(1)
      into v_super_admin_count
      from dbpm_administrators t
     where t.user_code = v_current_user
       and t.admin_type = 'SuperAdmin';
    if v_space_id is null then
      v_space_id := '-';
    end if;
    /*    if v_super_admin_count > 0 then
      v_space_id := null;
    end if;*/

    --v_request := json(p_request);
    FOR v_form IN v_form_cur LOOP
      v_forms := pl_json;
      v_total := v_form.total;
      v_forms.set_value('formName', v_form.form_name);
      v_forms.set_value('version', 'v_' || v_form.version || '.0');
      v_forms.set_value('status', v_form.status);
      v_forms.set_value('statusMeaning',
                        dcld_comm_pkg.get_lookup_meaning('FORM_STATUS',v_form.status,v_request.locale));
      v_forms.set_value('formCode', v_form.form_code);
      v_forms.set_value('formId', v_form.form_id);
      v_response.add_list_item('formList', v_forms);
    END LOOP;
    v_response.set_value('total', v_total);
    x_response := v_response.to_json;
  END proc_query_process_form;

  /*==================================================
  Procedure/Function Name :
      proc_query_comm_process_form
  Description:
      This function perform:
      查询通用表单
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-11-30  liangjun.wu  Creation
  ==================================================*/
  PROCEDURE proc_query_comm_process_form(p_request  CLOB,
                                         x_response OUT CLOB) AS
    v_request   json;
    v_response  pl_json := pl_json;
    v_line      pl_json;
    v_total     NUMBER := 0;
    v_size      NUMBER := 200;
    v_page      NUMBER := 1;
    v_form_name varchar2(4000);
    CURSOR v_form_cur IS
      SELECT *
        FROM (SELECT v.*, rownum cnt
                FROM (SELECT COUNT(1) over(PARTITION BY 1) total,
                             df.*,
                             df.form_id || '' form_id_str
                        FROM dbpm_form df, dbpm_process dp
                       WHERE df.process_id(+) = dp.process_id
                         AND dp.is_shared = 'Y'
                         AND dp.space_id = '1'
                         AND df.status = 'Published'
                         AND INSTR(NVL(DF.FORM_NAME, 'NL'),
                                   NVL(v_form_name, NVL(DF.FORM_NAME, 'NL'))) > 0
                       ORDER BY df.form_id DESC) v
               WHERE rownum <= v_page * v_size)
       WHERE cnt > (v_page - 1) * v_size;
  BEGIN
    v_request   := json(p_request, 'OBJECT');
    v_form_name := dcld_comm_pkg.get_filter_value('formName', v_request);
    IF v_request.exist('page') THEN
      v_page := v_request.get_number('page');
    END IF;
    IF v_request.exist('size') THEN
      v_size := v_request.get_number('size');
    END IF;

    FOR v_form IN v_form_cur LOOP
      v_total := v_form.total;
      v_line  := pl_json;
      v_line.set_value('formId', v_form.form_id);
      v_line.set_value('formIdStr', v_form.form_id_str);
      v_line.set_value('formName', v_form.form_name);
      v_line.set_value('thumbPicCode', v_form.form_icon);
      v_response.add_list_item('formList', v_line);
    END LOOP;

    v_response.set_value('total', v_total);
    x_response := v_response.to_json;
  END proc_query_comm_process_form;
  /*==================================================
  Procedure/Function Name :
      proc_delete_process_form
  Description:
      This function perform:
      删除表单
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-01-31  jinglun.xu  Creation
  ==================================================*/
  PROCEDURE proc_delete_process(p_request CLOB, x_response OUT CLOB) AS
    v_request            json;
    v_response           pl_json := pl_json;
    v_process_id         number;
    V_role_code          VARCHAR2(200);
    V_ERRO               VARCHAR2(500);
    v_process_count      number;
    v_process_task_count number;
    cursor v_process_nodes is
      select * from dbpm_process_nodes t where t.process_id = v_process_id;
    cursor v_process_params is
      select *
        from dbpm_process_params t
       where t.process_id = v_process_id;
    cursor v_process_tl is
      select * from dbpm_process_tl t where t.process_id = v_process_id;
    cursor v_node_roles(p_node_id number) is
      select * from dbpm_node_roles t where t.node_id = p_node_id;

    cursor v_approval_chain is
      select *
        from dbpm_approval_chain t
       where t.process_id = v_process_id;
    cursor v_chain_rules(p_chain_id number) is
      select * from dbpm_chain_rules t where t.chain_id = p_chain_id;
    cursor v_chain_nodes(p_chain_id number) is
      select * from dbpm_chain_nodes t where t.chain_id = p_chain_id;
    cursor v_chain_nodes_tl(p_node_id number) is
      select * from dbpm_chain_nodes_tl t where t.node_id = p_node_id;
    cursor v_DYNAMIC_APPROVERS(p_node_id number) is
      select * from DBPM_DYNAMIC_APPROVERS t where t.node_id = p_node_id;
  begin
    v_request := json(p_request, 'OBJECT');
    --v_request    :=json('{"processId":10167}');
    v_process_id := v_request.get_number('processId');
    if v_process_id is not null then
      select count(*)
        into v_process_count
        from dbpm_form df
       where df.process_id = v_process_id;
      if v_process_count <> 0 then
        --v_response.fail('该流程已关联表单，无法删除！');
        v_response.fail(DCLD_COMM_PKG.func_get_err_msg('DCLD-00009',
                                                       v_request.locale));
        x_response := v_response.to_json;
        return;
      end if;
      select count(*)
        into v_process_task_count
        from DBPM_DOCUMENTS t
       where t.process_id = v_process_id;
      if v_process_task_count <> 0 then
        --v_response.fail('该流程已被发起过，无法删除！');
        v_response.fail(DCLD_COMM_PKG.func_get_err_msg('DCLD-00010',
                                                       v_request.locale));
        x_response := v_response.to_json;
        return;
      end if;
      --dbpm_process;
      for c_process_nodes in v_process_nodes loop
        --dbpm_process_nodes;
        for c_node_roles in v_node_roles(c_process_nodes.node_id) loop
          --dbpm_node_roles;
          BEGIN
            select dr.role_id
              INTO V_role_code
              from dbpm_roles dr
             where dr.role_id = c_node_roles.business_role;
            /*            delete from DBPM_ROLE_PARAMS t where t.role_id = V_role_code;
            */ --DBPM_ROLE_PARAMS;
            delete from dbpm_node_role_param_value t
             where t.node_role_id = V_role_code;
            --dbpm_node_role_param_value;
          EXCEPTION
            WHEN OTHERS THEN
              V_ERRO := SQLERRM;
          END;
        end loop;
        delete from dbpm_node_roles t
         where t.node_id = c_process_nodes.node_id;

        delete from dbpm_selected_approvers t
         where t.node_id = c_process_nodes.node_id;
        --dbpm_selected_approvers;
      end loop;
      delete from dbpm_process_nodes t where t.process_id = v_process_id;

      delete from dbpm_process_params t where t.process_id = v_process_id;
      --dbpm_process_params;
      delete from dbpm_process_tl t where t.process_id = v_process_id;
      --dbpm_process_tl;

      for c_approval_chain in v_approval_chain loop
        --dbpm_approval_chain;
        delete from dbpm_chain_rules t
         where t.chain_id = c_approval_chain.chain_id;
        --dbpm_chain_rules;
        for c_chain_nodes in v_chain_nodes(c_approval_chain.chain_id) loop
          --dbpm_chain_nodes;
          delete from dbpm_chain_nodes_tl t
           where t.node_id = c_chain_nodes.node_id;
          --dbpm_chain_nodes_tl;
          for c_node_roles in v_node_roles(c_chain_nodes.node_id) loop
            BEGIN
              select dr.role_id
                INTO V_role_code
                from dbpm_roles dr
               where dr.role_id = c_node_roles.business_role;
              delete from DBPM_ROLE_PARAMS t where t.role_id = V_role_code;
              --DBPM_ROLE_PARAMS;
              delete from dbpm_node_role_param_value t
               where t.node_role_id = V_role_code;
              --dbpm_node_role_param_value;
            EXCEPTION
              WHEN OTHERS THEN
                V_ERRO := SQLERRM;
            END;
          end loop;
          --DBPM_DYNAMIC_APPROVERS;
          delete from DBPM_DYNAMIC_APPROVERS t
           where t.node_id = c_chain_nodes.node_id;
          --dbpm_selected_approvers;
          delete from dbpm_selected_approvers t
           where t.node_id = c_chain_nodes.node_id;
          delete from dbpm_node_roles t
           where t.node_id = c_chain_nodes.node_id;
        end loop;
        delete from dbpm_chain_nodes t
         where t.chain_id = c_approval_chain.chain_id;
      end loop;
      delete from dbpm_approval_chain t where t.process_id = v_process_id;
      delete from dbpm_process t where t.process_id = v_process_id;
    end if;

    x_response := v_response.to_json;
  end proc_delete_process;

  /*==================================================
  Procedure/Function Name :
      proc_save_document_data_ext
  Description:
      This function perform:
      扩展外部表单
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-05-16  wlj  Creation
  ==================================================*/
  PROCEDURE proc_save_document_data_ext(p_request  CLOB,
                                        x_response OUT CLOB) AS
    v_request           json;
    v_response          pl_json := pl_json;
    v_current_user      VARCHAR2(50);
    v_form_values       json_list;
    v_form_value        json;
    v_table_value       json_list;
    v_column_list       json_list;
    v_column_json       json;
    v_document_id       NUMBER;
    v_document_number   VARCHAR2(100);
    v_form_id           NUMBER;
    v_organization_id   VARCHAR2(100);
    v_company_id        VARCHAR2(100);
    v_organization_name VARCHAR2(500);
    v_process_id        NUMBER;
    v_process_code      VARCHAR2(100);
    v_process_name      VARCHAR2(500);
    v_title             VARCHAR2(4000);
    v_count             NUMBER := 0;
    v_user_name         VARCHAR2(100);
    v_status            VARCHAR2(100) := 'NEW';
    v_doc_creator       VARCHAR2(100);
    v_sql               VARCHAR2(4000);
    v_error_msg         VARCHAR2(4000);
    --扩展外部表单功能begin
    --描述：
    --1.根据流程种类和表单种类来确定是否是外部表单
    --2.formKey为外部表的ID，这里需要在dbpm_documents表中建立外部表单，得云流程，组织的关系
    v_process_class   varchar2(100); --流程种类
    v_doc_sys_code    varchar2(100); --表单种类
    v_form_key        varchar2(100); --外部表单ID
    v_form_url        varchar2(4000); --表单链接
    v_temp            varchar2(4000); --缓存
    v_bpm_instance_id varchar2(100);
    --扩展外部表单功能end
  begin
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;

    v_process_class   := v_request.get_string('processClass');
    v_doc_sys_code    := v_request.get_string('docSysCode');
    v_form_key        := v_request.get_string('formKey');
    v_process_id      := v_request.get_number('processId');
    v_bpm_instance_id := v_request.get_string('instanceId');

    IF v_request.get('documentId') IS NULL THEN
      v_document_id := dbpm_documents_s.nextval;
      v_status      := nvl(v_request.get('status').get_string, v_status);
    ELSE
      v_document_id := v_request.get('documentId').get_number;
      IF v_request.get('status')
       .get_string IS NULL OR v_request.get('status').get_string = 'null' THEN
        SELECT dd.status
          INTO v_status
          FROM dbpm_documents dd
         WHERE dd.document_id = v_document_id;
      ELSE
        v_status := v_request.get('status').get_string;
      END IF;
    END IF;

    SELECT COUNT(1)
      INTO v_count
      FROM dbpm_documents dd
     WHERE dd.document_id = v_document_id;

    -- 获取组织ID
    IF v_request.get('organizationId') IS NULL THEN
      dcld_comm_pkg.get_user_master_organization(p_user_code         => v_current_user,
                                                 x_organization_id   => v_organization_id,
                                                 x_organization_name => v_organization_name);
    ELSE
      v_organization_id := v_request.get('organizationId').get_string;
    END IF;

    -- title
    SELECT dp.process_name, dp.process_code
      INTO v_process_name, v_process_code
      FROM dbpm_process dp
     WHERE dp.process_id = v_process_id;

    SELECT de.full_name, de.employee_name
      INTO v_user_name, v_doc_creator
      FROM dfnd_employees de
     WHERE upper(de.employee_code) = upper(v_current_user);
    v_title := v_user_name || '发起的' || v_process_name;
    v_sql   := 'update dbpm_documents set  status = ''' || v_status ||
               ''' ';

    IF v_count > 0 THEN
      SELECT dd.doc_number
        INTO v_document_number
        FROM dbpm_documents dd
       WHERE dd.document_id = v_document_id;
      v_sql := v_sql || ', doc_number = ''' || v_document_number ||
               ''' where document_id = ' || v_document_id;
    ELSE
      dbpm_document_sequences_pkg.proc_get_doc_number(p_document_type   => v_process_code,
                                                      x_document_number => v_document_number,
                                                      x_return_message  => v_error_msg);
      IF v_error_msg IS NOT NULL AND v_document_number IS NULL THEN
        v_document_number := '';
      END IF;
      v_sql := v_sql || ', doc_number = ''' || v_document_number ||
               ''' where document_id = ' || v_document_id;

      INSERT INTO dbpm_documents
        (document_id,
         doc_number,
         title,
         doc_creator,
         doc_creator_name,
         doc_create_time,
         organization_id,
         company_id,
         process_id,
         process_code,
         form_id,
         created_by,
         last_updated_by,
         doc_sys_code,
         doc_form_id,
         bpm_instance_id)
      VALUES
        (v_document_id,
         v_document_number,
         v_title,
         v_current_user,
         v_doc_creator,
         SYSDATE,
         v_organization_id,
         v_company_id,
         v_process_id,
         v_process_code,
         '-1',
         v_current_user,
         v_current_user,
         v_doc_sys_code,
         v_form_key,
         v_bpm_instance_id);
    END IF;
    EXECUTE IMMEDIATE v_sql;

    dbpm_core_pkg.proc_get_form_url(v_document_id,
                                    v_form_url,
                                    v_temp,
                                    v_temp);
    update dbpm_documents d
       set d.doc_url = v_form_url
     where d.document_id = v_document_id;

    v_response.set_value('docNumber', v_document_number);
    v_response.set_value('documentId', v_document_id);
    x_response := v_response.to_json;
  end;

END dbpm_form_api_pkg;

/

