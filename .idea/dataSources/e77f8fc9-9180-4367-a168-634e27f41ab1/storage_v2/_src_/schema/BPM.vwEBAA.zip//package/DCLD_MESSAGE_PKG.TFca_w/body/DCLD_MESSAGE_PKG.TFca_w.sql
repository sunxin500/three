create PACKAGE BODY     dcld_message_pkg IS
  /*==================================================
  Procedure/Function Name :
      proc_query_sys_meg_list
  Description:
      This function perform:
      查询系统消息列表
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-03-17  chenming  Creation
  ==================================================*/
  PROCEDURE proc_query_sys_msg_list(p_request CLOB, x_response OUT CLOB) IS
    v_api          VARCHAR2(100) := 'proc_query_sys_meg_list';
    v_request      json;
    v_response     pl_json := pl_json;
    v_line         pl_json;
    v_current_user VARCHAR2(50); --获取当前用户
    CURSOR v_msg_cur IS --声明游标
      SELECT dsm.*, dsmr.is_read
        FROM dcld_sys_msg dsm, dcld_sys_msg_readers dsmr
       WHERE dsm.msg_id = dsmr.msg_id
         AND dsmr.user_code = v_current_user;

  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;

    FOR v_msg IN v_msg_cur LOOP
      v_line := pl_json;
      v_line.set_value('content', v_msg.content);
      v_line.set_value('category', v_msg.category);
      v_line.set_value('function_name', v_msg.function_name);
      v_line.set_value('creation_date', v_msg.creation_date);
      v_line.set_value('isread', v_msg.is_read);
      v_response.add_list_item('line', v_line);
    END LOOP;
    x_response := v_response.to_json;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;

  END proc_query_sys_msg_list;

  /*==================================================
  Procedure/Function Name :
      proc_add_sys_msg
  Description:
      This function perform:
      新增系统消息
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-03-17  chenming  Creation
  ==================================================*/
  PROCEDURE proc_add_sys_msg(p_request CLOB, x_response OUT CLOB) IS
    v_request      json;
    v_response     pl_json := pl_json;
    v_current_user VARCHAR2(50); --获取当前用户
    v_reader_list  json_list;
    v_reader       json;
    v_msg_id       NUMBER;
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;

    v_msg_id := dcld_sys_msg_s.nextval;
    -- 插入系统消息
    INSERT INTO dcld_sys_msg
      (msg_id,
       content,
       category,
       function_name,
       created_by,
       last_updated_by)
    VALUES
      (v_msg_id,
       v_request.get ('content' ).get_string,
       v_request.get ('category' ).get_string,
       v_request.get ('functionName' ).get_string,
       v_current_user,
       v_current_user);
    -- 插入系统消息阅读人
    v_reader_list := json_list(v_request.path('readers'));
    FOR i IN 1 .. v_reader_list.count LOOP
      v_reader := json(v_reader_list.get(i));
      INSERT INTO dcld_sys_msg_readers
        (msg_id, user_code, is_read, created_by, last_updated_by)
      VALUES
        (v_msg_id,
         v_reader.get('reader').get_string,
         'N',
         v_current_user,
         v_current_user);
    END LOOP;

    x_response := v_response.to_json;
  END proc_add_sys_msg;

  /*==================================================
  Procedure/Function Name :
      proc_read_sys_msg
  Description:
      This function perform:
      阅读系统消息
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-03-17  chenming  Creation
  ==================================================*/
  PROCEDURE proc_read_sys_msg(p_request CLOB, x_response OUT CLOB) IS
    v_request      json;
    v_response     pl_json := pl_json;
    v_msg_id       NUMBER;
    v_current_user VARCHAR2(50); --获取当前用户
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;

    v_msg_id := v_request.get('msgId').get_string;

    UPDATE dcld_sys_msg_readers smr
       SET smr.is_read = 'Y'
     WHERE smr.user_code = v_current_user
       AND smr.msg_id = v_msg_id;

    x_response := v_response.to_json;
  END proc_read_sys_msg;

  PROCEDURE proc_add_service_log(p_UUID             in varchar2,
                                 p_INSTANCE_ID      in varchar2,
                                 p_NODE_ID          in NUMBER,
                                 p_SERVICE_ID       in number,
                                 p_SERVICE_URL      in varchar2,
                                 p_CONTENT_TYPE     in varchar2,
                                 p_REQUEST_CONTENT  in varchar2,
                                 p_REQUEST_DATE     in varchar2,
                                 p_RESPONSE_CONTENT in varchar2,
                                 p_RESPONSE_DATE    in varchar2,
                                 p_ERROR_LOG        in varchar2,
                                 p_response_code    in number,
                                 p_ATTRIBUTE1       in varchar2,
                                 p_ATTRIBUTE2       in varchar2,
                                 p_ATTRIBUTE3       in varchar2,
                                 p_ATTRIBUTE4       in varchar2,
                                 p_ATTRIBUTE5       in varchar2,
                                 p_result           out varchar2) IS
    v_log_id NUMBER;
  BEGIN
    p_result := 'success';
    v_log_id := dbpm_service_log_s.nextval;
    -- 插入日志消息
    INSERT INTO dbpm_service_log
      (message_id,
       uuid,
       instance_id,
       node_id,
       service_id,
       service_url,
       content_type,
       request_content,
       request_date,
       response_content,
       response_date,
       error_log,
       attribute1,
       attribute2,
       attribute3,
       attribute4,
       attribute5,
       response_code)
    VALUES
      (v_log_id,
       p_uuid,
       p_instance_id,
       p_node_id,
       p_service_id,
       p_service_url,
       p_content_type,
       p_request_content,
       to_date(p_request_date, 'yyyy-mm-dd hh24:mi:ss'),
       p_response_content,
       to_date(p_response_date, 'yyyy-mm-dd hh24:mi:ss'),
       p_error_log,
       p_attribute1,
       p_attribute2,
       p_attribute3,
       p_attribute4,
       p_attribute5,
       p_response_code);
  END proc_add_service_log;
END dcld_message_pkg;

/

