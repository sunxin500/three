create view DBPM_WF_TASK_V as
SELECT TASK.INSTANCEID,
          TASK.TASKID,
          ASS.ASSIGNEE,
          (CASE TASK.SUBSTATE
              WHEN 'DELEGATED' THEN REPLACE (TASK.ASSIGNEESDISPLAYNAME, ':', ',') || ',' || TASK.FROMUSERDISPLAYNAME
              ELSE REPLACE (TASK.ASSIGNEESDISPLAYNAME, ':', ',')
           END)
             ASSIGNEENAME,
          ASS.ISGROUP,
          ASS.ASSIGNEETYPE,
           nvl(TASK.Protectedformattribute1,TASK.ACTIVITYNAME) ACTIVITYNAME,
          TASK.TASKDEFINITIONNAME,
          TASK.ASSIGNEDDATE,
          'BPM' TASK_SOURCE,
          TASK.Protectedtextattribute1 DOC_ID,
          TASK.PROTECTEDTEXTATTRIBUTE2 node_name,
          TASK.PROTECTEDTEXTATTRIBUTE3 processFormNo,
          TASK.PROTECTEDTEXTATTRIBUTE4 processCode,
          TASK.PROTECTEDTEXTATTRIBUTE5 businessSysCode,
            nvl(task.title,
                          TASK.PROTECTEDTEXTATTRIBUTE6)
           processTitle,
          task.protectedtextattribute9 nodecode,
          task.protectedtextattribute10 processParam,
          task.protectednumberattribute1 node_id,
          TASK.COMPOSITEINSTANCEID,
          TASK.OUTCOME,
          TASK.WORKFLOWPATTERN,
          task.creator
     FROM WFTASK TASK, WFASSIGNEE ASS
    WHERE TASK.STATE = 'ASSIGNED' AND ASS.TASKID = TASK.TASKID
   UNION ALL
   SELECT TASK.INSTANCEID,
          TASK.TASKID,
          TASK.ORIGINALASSIGNEEUSER,
          REPLACE (TASK.ASSIGNEESDISPLAYNAME, ':', ',') || ',' || TASK.FROMUSERDISPLAYNAME ASSIGNEENAME,
          ASS.ISGROUP,
          ASS.ASSIGNEETYPE,
          nvl(TASK.Protectedformattribute1,TASK.ACTIVITYNAME) ACTIVITYNAME,
          TASK.TASKDEFINITIONNAME,
          TASK.ASSIGNEDDATE,
          'BPM' TASK_SOURCE,
          TASK.Protectedtextattribute1 DOC_ID,
          TASK.PROTECTEDTEXTATTRIBUTE2 node_name,
          TASK.PROTECTEDTEXTATTRIBUTE3 processFormNo,
          TASK.PROTECTEDTEXTATTRIBUTE4 processCode,
          TASK.PROTECTEDTEXTATTRIBUTE5 businessSysCode,
          nvl(task.title,
                          TASK.PROTECTEDTEXTATTRIBUTE6)
           processTitle,
          task.protectedtextattribute9 nodecode,
          task.protectedtextattribute10 processParam,
          task.protectednumberattribute1 node_id,
          TASK.COMPOSITEINSTANCEID,
          TASK.OUTCOME,
          TASK.WORKFLOWPATTERN,
          task.creator
     FROM WFTASK TASK, WFASSIGNEE ASS
    WHERE TASK.STATE = 'ASSIGNED' AND TASK.SUBSTATE = 'DELEGATED' AND ASS.TASKID = TASK.TASKID
/

