create PACKAGE BODY CUX_COMM_PKG is

  /*==================================================
  Procedure/Function Name :
      func_get_company_id
  Description:
      This function perform:
      查询员工所在的二级公司
  Argument:
     p_user_code： 员工编号
  History:
      1.00  2017-12-01  liangjun.wu  Creation
  ==================================================*/
  function func_get_company_id(p_user_code varchar2) return number as
    v_user_code  varchar2(30) := p_user_code;
    v_company_id number;
  begin
    SELECT TO_NUMBER(DOT.COMPANY_ID)
      INTO V_COMPANY_ID
      FROM DFND_ORG_EMPLOYEES T, DFND_ORGANIZATIONS DOT
     WHERE T.ORGANIZATION_ID = DOT.ORGANIZATION_ID(+)
       AND UPPER(T.EMPLOYEE_CODE) = UPPER(V_USER_CODE)
          --AND T.IS_MASTER_ORGANIZATION = 'Y'
       AND T.ENABLED_FLAG = 'Enabled';
    return V_COMPANY_ID;
  exception
    when others then
      return null;
  end;
  /*==================================================
  Procedure/Function Name :
      func_get_concatStr
  Description:
      This function perform:
     用逗号拼接字符串
  Argument:
     p_str1： 字符串1，
     p_str2： 字符串2
  History:
      1.00  2018-05-25  liangjun.wu  Creation
  ==================================================*/
  function func_get_concatStr(p_str1 varchar2, p_str2 varchar2)
    return varchar as
    v_concat_str varchar(200) := null;
  begin
    if p_str1 is null or p_str2 is null then
      v_concat_str := nvl(p_str1, p_str2);
    elsif instr(p_str1, p_str2) > 0 then
      v_concat_str := p_str1;
    elsif instr(p_str2, p_str1) > 0 then
      v_concat_str := p_str2;
    else
      v_concat_str := p_str1 || ',' || p_str2;
    end if;
    return v_concat_str;
  end;

  /*==================================================
  Procedure/Function Name :
      proc_get_company_list
  Description:
      This Procedure perform:
      获取二级公司列表
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-12-04  liangjun.wu  Creation
  ==================================================*/
  procedure proc_get_company_list(p_request IN CLOB, x_response OUT CLOB) as
    v_request      json;
    v_response     pl_json := pl_json;
    v_company_list pl_json := pl_json;
    v_company_item pl_json := pl_json;
    --查询参数
    --  v_search_fields json;
    v_total       number;
    v_size        number := 200;
    v_page        number := 1;
    v_search_text varchar2(4000);
    cursor v_company_cursor is
      SELECT *
        FROM (SELECT v.*, rownum cnt
                FROM (select count(1) over(partition by 1) total,
                             OT.ORGANIZATION_NAME,
                             OT.ORGANIZATION_ID
                        FROM DFND_ORGANIZATIONS OT
                       where regexp_like(ot.organization_name, '^\d{3}01_')
                         and ot.organization_status = 'Enabled'
                            --and ot.organization_name like '%机关'
                         and ot.attribute1 = 'CCEED5'
                         and not exists
                       (select 1
                                from dbpm_spaces ds
                               where ds.space_code = ot.organization_id)
                            /*and (instr(OT.organization_name,
                                  nvl(v_search_text, OT.organization_name)) > 0 or
                            instr(to_char(OT.ORGANIZATION_ID),
                                  nvl(v_search_text,
                                      to_char(OT.ORGANIZATION_ID))) > 0)*/
                         and instr(NVL(OT.organization_name ||
                                       to_char(OT.ORGANIZATION_ID),
                                       'NL'),
                                   nvl(v_search_text,
                                       NVL(OT.organization_name ||
                                           to_char(OT.ORGANIZATION_ID),
                                           'NL'))) > 0
                       order by ot.organization_name) v
               WHERE rownum <= v_page * v_size)
       WHERE cnt > (v_page - 1) * v_size;
  begin
    v_request := json(p_request, 'OBJECT');
    v_company_list.set_data_type('ARRAY');

    if v_request.exist('page') then
      v_page := v_request.get_number('page');
    end if;
    if v_request.exist('size') then
      v_size := v_request.get_number('size');
    end if;

    v_search_text := dcld_comm_pkg.get_filter_value('all', v_request);

    /*    if v_request.exist('filter') then
      v_search_fields := json(v_request.get('filter'));
      v_search_text   := v_search_fields.get_string('all');
    end if;*/

    for v_company in v_company_cursor loop
      v_company_item := pl_json;
      v_total        := v_company.total;
      v_company_item.set_value('organizationName',
                               v_company.organization_name);
      v_company_item.set_value('organizationId', v_company.organization_id);
      v_company_list.add_list_item(v_company_item);
    end loop;
    v_response.set_value('companyList', v_company_list);
    v_response.set_value('total', v_total);
    x_response := v_response.to_json;
  end proc_get_company_list;


end CUX_COMM_PKG;

/

