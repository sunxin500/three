create package     DBPM_TASK_TODO_PKG is

  -- Author  : WLJ
  -- Created : 2018/5/17 10:52:22
  -- Purpose : 待办功能

  /*==================================================
  Procedure/Function Name :
      proc_save_todo_task
  Description:
      This function perform:
       维护第三方待办
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-05-10  wlj  Creation
  ==================================================*/
  PROCEDURE proc_save_todo_task(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_merge_begin_task
  Description:
      This function perform:
       维护第三方待办
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-06-20  wlj  Creation
  ==================================================*/
  PROCEDURE proc_merge_begin_task(p_begin_item             clob,
                                  p_process_name           varchar2,
                                  p_doc_number             varchar2,
                                  p_assigneeDate           varchar2,
                                  p_approveDate            varchar2,
                                  p_createDate             varchar2,
                                  p_assignee               varchar2,
                                  p_taskId                 varchar2,
                                  p_title                  varchar2,
                                  p_taskUrl                varchar2,
                                  p_creator                varchar2,
                                  p_mobileViewUrl          varchar2,
                                  p_todo_flag              varchar2,
                                  p_parent_sys_code        varchar2,
                                  p_parent_process_name    varchar2,
                                  p_parent_document_number varchar2,
                                  p_parent_title           varchar2,
                                  p_parent_process_code    varchar2,
                                  p_process_code           varchar2,
                                  p_sys_code               varchar2,
                                  p_is_mob_data            varchar2);

  /*==================================================
  Procedure/Function Name :
      proc_merge_complete_task
  Description:
      This function perform:
       维护第三方已办
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-06-20  wlj  Creation
  ==================================================*/
  PROCEDURE proc_merge_complete_task(p_approveDate varchar2,
                                     p_approver    varchar2,
                                     p_taskId      varchar2,
                                     p_outcome     varchar2,
                                     p_sys_code    varchar2);

  /*==================================================
  Procedure/Function Name :
      proc_check_sys_code
  Description:
      This function perform:
       检查系统编码
  Argument:
  History:
      1.00  2018-06-29  wlj  Creation
  ==================================================*/
  PROCEDURE proc_check_sys_code(p_sys_code varchar2, x_flag out varchar2);
end DBPM_TASK_TODO_PKG;

/

