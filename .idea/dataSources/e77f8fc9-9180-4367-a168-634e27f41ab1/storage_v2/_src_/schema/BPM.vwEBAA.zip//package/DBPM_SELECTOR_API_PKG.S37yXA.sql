create PACKAGE     dbpm_selector_api_pkg IS

  /*==================================================
  Procedure/Function Name :
      proc_query_selector_employees
  Description:
      This function perform:
      获取人员信息
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-09-27  zhiheng.wei  Creation
  ==================================================*/

  PROCEDURE proc_query_selector_employees(p_request  CLOB,
                                          x_response OUT CLOB);

END dbpm_selector_api_pkg;

/

