create package     dbpm_import_pkg is

  -- Author  : YAOSHALLWE
  -- Created : 2019/3/7 18:20:10
  -- Purpose : 流程导入

  /*==================================================
  Procedure/Function Name :
      func_export_process
  Description:
      This function perform:
      导出对应的流程
  Argument:
     p_process_id：流程id
  History:
      1.00  2019-04-21  xiaowei.yao  Creation
  ==================================================*/
  FUNCTION func_export_process(p_process_id NUMBER) RETURN CLOB;

  /*==================================================
  Procedure/Function Name :
      func_import_process
  Description:
      This function perform:
      导入对应的流程
  Argument:
     p_process_content ：流程的相关信息
  History:
     1.00  2019-04-21  xiaowei.yao  Creation
  ==================================================*/
  procedure proc_import_process(p_request CLOB, x_response out clob);

end dbpm_import_pkg;

/

