create procedure     test3(v_rule_ex        in varchar2,
                                  p_business_param in dbpm_business_param_tbl,
                                  x_out            out varchar2) is
  v_rule_exs  varchar2(128);
  v_index     number;
  v_tmp       varchar2(2);
  v_index_tmp number := 0;
begin
  v_rule_exs := v_rule_ex;
  --循环传入的参数
  for i in 1 .. p_business_param.count loop

    while 1 = 1 loop
      test2(v_rule_exs, p_business_param(i), x_out, v_tmp);
      v_rule_exs := x_out;
      if v_tmp = 'F' then
        exit;
      end if;
    end loop;
  end loop;
  x_out := 'select count(1) from dual where ' || v_rule_exs;
end test3;

/

