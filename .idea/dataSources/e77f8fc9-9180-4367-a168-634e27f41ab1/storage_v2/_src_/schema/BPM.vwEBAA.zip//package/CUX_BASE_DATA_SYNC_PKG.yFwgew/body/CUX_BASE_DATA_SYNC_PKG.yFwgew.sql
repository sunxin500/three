create PACKAGE BODY     CUX_BASE_DATA_SYNC_PKG IS

  PROCEDURE GET_LAST_SYNC_DATE(P_SYSCODE   IN VARCHAR2,
                               P_DATA_TYPE IN VARCHAR2,
                               X_DATE      OUT DATE) IS
  BEGIN
    IF P_SYSCODE IS NULL THEN
      X_DATE := NULL;
      RETURN;
    ELSIF P_DATA_TYPE = 'USER' THEN

      SELECT MAX(T.LAST_UPDATE_DATE)
        INTO X_DATE
        FROM CUX_EMPLOYEE_TMP T
       WHERE T.CREATED_BY = P_SYSCODE;

    ELSIF P_DATA_TYPE = 'ORG' THEN

      SELECT MAX(T.LAST_UPDATE_DATE)
        INTO X_DATE
        FROM CUX_ORGANIZATION_TMP T
       WHERE T.CREATED_BY = P_SYSCODE;
    ELSIF P_DATA_TYPE = 'ROLE' THEN

      SELECT MAX(T.LAST_UPDATE_DATE)
        INTO X_DATE
        FROM CUX_ROLE_TMP T
       WHERE T.CREATED_BY = P_SYSCODE;
    ELSIF P_DATA_TYPE = 'BIND' THEN

      SELECT

       MAX(T.LAST_UPDATE_DATE)
        INTO X_DATE
        FROM CUX_ROLE_PARAM_EMP_TMP T
       WHERE T.CREATED_BY = P_SYSCODE;

    END IF;
    IF X_DATE IS NULL OR LENGTH(X_DATE) = 0 THEN
      X_DATE := TO_DATE('1970/01/01', 'YYYY/MM/DD');
    END IF;
  END GET_LAST_SYNC_DATE;

  PROCEDURE PROC_ORG_COPY IS
    V_COUNT   NUMBER;
    V_PORGID  NUMBER;
    V_GORGID  NUMBER;
    V_SQLERRM VARCHAR2(2000);
  BEGIN
    --1、同步组织信息到正式表
    --CUX_KEMS_ORG_TMP
    --DFND_ORGANIZATIONS
    --写入全部的组织数据
    FOR ORGTMP IN (SELECT * FROM CUX_ORGANIZATION_TMP WHERE IS_UPDATE = '1') LOOP
      BEGIN
        SELECT COUNT(1)
          INTO V_COUNT
          FROM DFND_ORGANIZATIONS T
         WHERE T.ORGANIZATION_CODE =
               ORGTMP.ORGANIZATION_TYPE || ORGTMP.ORGANIZATION_CODE;

        --获取根组织
        SELECT MIN(T.ORGANIZATION_ID)
          INTO V_GORGID
          FROM DFND_ORGANIZATIONS T
         WHERE T.PARENT_ORGANIZATION_ID IS NULL;
        --新增组织
        IF V_COUNT = 0 AND ORGTMP.IS_DELETE = '0' THEN
          INSERT INTO DFND_ORGANIZATIONS DO
            (DO.ORGANIZATION_ID,
             DO.ORGANIZATION_CODE,
             DO.ORGANIZATION_NAME,
             DO.PARENT_ORGANIZATION_ID,
             DO.ORGANIZATION_LEVEL,
             DO.ORGANIZATION_TYPE,
             DO.ORGANIZATION_STATUS,
             DO.ORDER_NUM,
             DO.CREATED_BY,
             DO.CREATION_DATE,
             DO.LAST_UPDATED_BY,
             DO.LAST_UPDATE_DATE)
          VALUES
            (DFND_ORGANIZATIONS_S.NEXTVAL,
             ORGTMP.ORGANIZATION_TYPE || ORGTMP.ORGANIZATION_CODE,
             ORGTMP.ORGANIZATION_NAME,
             V_GORGID,
             ORGTMP.ORGANIZATION_LEVEL,
             ORGTMP.ORGANIZATION_TYPE,
             'Y',
             ORGTMP.ORDER_NUM,
             ORGTMP.Created_By,
             SYSDATE,
             ORGTMP.Last_Updated_By,
             SYSDATE);
          --更新组织
        ELSIF V_COUNT <> 0 THEN
          UPDATE DFND_ORGANIZATIONS DO
             SET DO.ORGANIZATION_NAME   = ORGTMP.ORGANIZATION_NAME,
                 DO.ORGANIZATION_LEVEL  = ORGTMP.ORGANIZATION_LEVEL,
                 DO.ORGANIZATION_TYPE   = ORGTMP.ORGANIZATION_TYPE,
                 DO.ORGANIZATION_STATUS = DECODE(ORGTMP.IS_DELETE,
                                                 '0',
                                                 'Y',
                                                 'N'),
                 DO.ORDER_NUM           = ORGTMP.ORDER_NUM,
                 DO.LAST_UPDATED_BY     = ORGTMP.Last_Updated_By,
                 DO.LAST_UPDATE_DATE    = SYSDATE
           WHERE DO.ORGANIZATION_CODE =
                 ORGTMP.ORGANIZATION_TYPE || ORGTMP.ORGANIZATION_CODE;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          V_SQLERRM := SQLERRM;
          UPDATE CUX_ORGANIZATION_TMP T
             SET T.ATTRIBUTE10 = V_SQLERRM
           WHERE T.ID = ORGTMP.ID;
      END;
    END LOOP;
    --更新组织树关系PARENTID 更新1.44分钟之前更新的数据的父组织
    FOR BPMORG IN (SELECT * FROM CUX_ORGANIZATION_TMP WHERE IS_UPDATE = '1') LOOP
      BEGIN
        --获取正式表中的PID
        SELECT P.ORGANIZATION_ID
          INTO V_PORGID
          FROM DFND_ORGANIZATIONS P
         WHERE P.ORGANIZATION_CODE =
               BPMORG.ORGANIZATION_TYPE || BPMORG.PARENT_ORGANIZTION_CODE;

        --将PID更新到正式表
        UPDATE DFND_ORGANIZATIONS T
           SET T.PARENT_ORGANIZATION_ID = V_PORGID
         WHERE T.ORGANIZATION_CODE =
               BPMORG.ORGANIZATION_TYPE || BPMORG.ORGANIZATION_CODE;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          --没有找到父级组织，默认挂到根组织下面
          UPDATE DFND_ORGANIZATIONS T
             SET T.PARENT_ORGANIZATION_ID = V_GORGID
           WHERE T.ORGANIZATION_CODE =
                 BPMORG.ORGANIZATION_TYPE || BPMORG.ORGANIZATION_CODE;
      END;
    END LOOP;

    --清除中间表待更新字段
    UPDATE CUX_ORGANIZATION_TMP T
       SET T.IS_UPDATE = '0'
     WHERE T.IS_UPDATE = '1';

  END PROC_ORG_COPY;

  PROCEDURE PROC_USER_COPY IS
    V_COUNT   NUMBER;
    V_EMP     DFND_EMPLOYEES%ROWTYPE;
    V_SQLERRM VARCHAR2(2000);
  BEGIN
    --写入全部的人员数据
    FOR USERTMP IN (SELECT * FROM CUX_EMPLOYEE_TMP T WHERE T.IS_UPDATE = '1') LOOP
      BEGIN
        SELECT COUNT(1)
          INTO V_COUNT
          FROM DFND_EMPLOYEES T
         WHERE T.EMPLOYEE_CODE = USERTMP.EMPLOYEE_CODE;

        IF V_COUNT = 0 AND USERTMP.IS_DELETE = '0' THEN
          --新增人员信息
          INSERT INTO DFND_EMPLOYEES DE
            (DE.EMPLOYEE_ID,
             DE.EMPLOYEE_CODE,
             DE.ENGLISH_NAME,
             DE.STATUS,
             DE.EMAIL,
             DE.EMPLOYEE_NAME,
             DE.MANAGER,
             DE.CREATED_BY,
             DE.CREATION_DATE,
             DE.LAST_UPDATED_BY,
             DE.LAST_UPDATE_DATE,
             DE.SOURCE_TYPE,
             DE.SEC_MANAGER)
          VALUES
            (DFND_EMPLOYEES_S.NEXTVAL,
             USERTMP.EMPLOYEE_CODE,
             USERTMP.EMPLOYEE_NAME,
             'Y',
             USERTMP.ATTRIBUTE1,
             USERTMP.EMPLOYEE_NAME,
             USERTMP.FIRST_MANGER,
             USERTMP.CREATED_BY,
             SYSDATE,
             USERTMP.LAST_UPDATED_BY,
             SYSDATE,
             USERTMP.CREATED_BY,
             USERTMP.SECOND_MANGER);
          --存在数据，如果员工状态为为删除更更新，为删除不做更改
        ELSIF V_COUNT <> 0 THEN
          SELECT *
            INTO V_EMP
            FROM DFND_EMPLOYEES T
           WHERE T.EMPLOYEE_CODE = USERTMP.EMPLOYEE_CODE;
          --如果数据是此系统创建，则运行更新
          IF V_EMP.CREATED_BY = USERTMP.CREATED_BY THEN
            UPDATE DFND_EMPLOYEES T
               SET T.STATUS           = DECODE(USERTMP.IS_DELETE,
                                               '0',
                                               'Y',
                                               'N'),
                   T.EMPLOYEE_NAME    = USERTMP.EMPLOYEE_NAME,
                   T.EMAIL            = USERTMP.ATTRIBUTE1,
                   T.LAST_UPDATED_BY  = USERTMP.LAST_UPDATED_BY,
                   T.LAST_UPDATE_DATE = SYSDATE
             WHERE T.EMPLOYEE_CODE = USERTMP.EMPLOYEE_CODE;

          ELSE

            UPDATE CUX_EMPLOYEE_TMP T
               SET T.ATTRIBUTE2 = '当前人员创建人为：' || V_EMP.CREATED_BY ||
                                  '，不允许修改'
             WHERE T.ID = USERTMP.ID;

          END IF;
        END IF;
        UPDATE CUX_EMPLOYEE_TMP T
           SET T.IS_UPDATE = '0'
         WHERE T.ID = USERTMP.ID;
      EXCEPTION
        WHEN OTHERS THEN
          V_SQLERRM := SQLERRM;
          UPDATE CUX_EMPLOYEE_TMP T
             SET T.IS_UPDATE = '0', T.ATTRIBUTE10 = V_SQLERRM
           WHERE T.ID = USERTMP.ID;
      END;
    END LOOP;

    --更新GEMS人员国际化配置表
    FOR DFND_EMP IN (SELECT T.EMPLOYEE_CODE, T.EMPLOYEE_NAME, T.CREATED_BY
                       FROM DFND_EMPLOYEES T, CUX_EMPLOYEE_TMP TMP
                      WHERE t.Employee_Name IS NOT NULL
                        AND UPPER(T.EMPLOYEE_NAME) <> 'NULL'
                        AND TMP.EMPLOYEE_CODE = T.EMPLOYEE_CODE
                        AND NOT EXISTS
                      (SELECT 1
                               FROM CUX_GEMS_USER_TL T1
                              WHERE upper(T1.USER_CODE) = upper(T.EMPLOYEE_CODE)
                                and t1.locale = 'zh_CN')) LOOP
      BEGIN
        INSERT INTO CUX_GEMS_USER_TL
          (USER_CODE,
           LOCALE,
           USER_NAME,
           CREATED_BY,
           LAST_UPDATED_BY,
           STATUS)
        VALUES
          (DFND_EMP.EMPLOYEE_CODE,
           'zh_CN',
           DFND_EMP.EMPLOYEE_NAME,
           DFND_EMP.CREATED_BY,
           DFND_EMP.CREATED_BY,
           'Y');
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;
    END LOOP;

  END PROC_USER_COPY;

  PROCEDURE PROC_ROLE_COPY IS
    V_COUNT     NUMBER;
    V_SPACECODE VARCHAR2(100);
    V_SQLERRM   VARCHAR2(2000);
  BEGIN
    --1、利用ROLECODE将 将关系中间表 ROLE_ID更新；

    FOR ROLETMP IN (SELECT * FROM CUX_ROLE_TMP T WHERE T.IS_UPDATE = '1') LOOP
      BEGIN
        SELECT COUNT(1)
          INTO V_COUNT
          FROM DBPM_ROLES T
         WHERE T.ROLE_CODE = ROLETMP.ROLE_CODE;

        IF V_COUNT = 0 THEN
          --不存在，新增
          INSERT INTO DBPM_ROLES
            (ROLE_ID,
             ROLE_CODE,
             ROLE_NAME,
             STATUS,
             CREATION_DATE,
             CREATED_BY,
             LAST_UPDATED_BY,
             LAST_UPDATE_DATE,
             SPACE_ID,
             CREATE_TYPE)
          VALUES
            (DBPM_ROLES_S.NEXTVAL,
             ROLETMP.ROLE_CODE,
             ROLETMP.ROLE_NAME,
             DECODE(ROLETMP.IS_DELETE, '0', 'Y', 'N'),
             SYSDATE,
             ROLETMP.CREATED_BY,
             ROLETMP.LAST_UPDATED_BY,
             SYSDATE,
             (SELECT T.SPACE_ID
                FROM DBPM_SPACES T
               WHERE T.SPACE_CODE = ROLETMP.CREATED_BY),
             'External');
        ELSE
          --存在，更新

          --获取当前角色所属系统
          SELECT S.SPACE_CODE
            INTO V_SPACECODE
            FROM DBPM_ROLES T, DBPM_SPACES S
           WHERE T.SPACE_ID = S.SPACE_ID(+)
             AND T.ROLE_CODE = ROLETMP.ROLE_CODE;

          --判断当前角色是否属于当前系统
          IF V_SPACECODE = ROLETMP.CREATED_BY THEN

            UPDATE DBPM_ROLES T
               SET T.ROLE_NAME        = ROLETMP.ROLE_NAME,
                   T.STATUS           = DECODE(ROLETMP.IS_DELETE,
                                               '0',
                                               'Y',
                                               'N'),
                   T.LAST_UPDATED_BY  = ROLETMP.LAST_UPDATED_BY,
                   T.LAST_UPDATE_DATE = SYSDATE
             WHERE T.ROLE_CODE = ROLETMP.ROLE_CODE;

          ELSE

            UPDATE CUX_ROLE_TMP T
               SET T.ATTRIBUTE1 = '当前角色属于系统：' || V_SPACECODE || '。不允许修改'
             WHERE T.ID = ROLETMP.ID;

          END IF;
        END IF;

        SELECT COUNT(1)
          INTO V_COUNT
          FROM DBPM_ROLE_PARAMS RP, DBPM_ROLES R
         WHERE RP.ROLE_ID = R.ROLE_ID
           AND R.ROLE_CODE = ROLETMP.ROLE_CODE
           AND RP.Data_Source_Code = 'DbpmOrganization';

        IF V_COUNT = 0 THEN
          --不存在，新增到角色参数表
          INSERT INTO DBPM_ROLE_PARAMS
            (PARAM_ID,
             ROLE_ID,
             PARAM_NAME,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATED_BY,
             LAST_UPDATE_DATE,
             STATUS,
             DATA_SOURCE_CODE)
          VALUES
            (DBPM_ROLE_PARAMS_S.NEXTVAL,
             (SELECT ROLE_ID
                FROM DBPM_ROLES
               WHERE ROLE_CODE = ROLETMP.ROLE_CODE
                 AND SPACE_ID =
                     (SELECT T.SPACE_ID
                        FROM DBPM_SPACES T
                       WHERE T.SPACE_CODE = ROLETMP.CREATED_BY)),
             (SELECT DATA_SOURCE_NAME
                FROM dbpm_data_source
               WHERE DATA_SOURCE_CODE = 'DbpmOrganization'),
             ROLETMP.CREATED_BY,
             SYSDATE,
             ROLETMP.CREATED_BY,
             SYSDATE,
             'Y',
             'DbpmOrganization');
        END IF;

        UPDATE CUX_ROLE_TMP T
           SET T.IS_UPDATE = '0'
         WHERE T.ID = ROLETMP.ID;

      EXCEPTION
        WHEN OTHERS THEN
          V_SQLERRM := SQLERRM;
          UPDATE CUX_ROLE_TMP T
             SET T.IS_UPDATE = '0', T.ATTRIBUTE10 = V_SQLERRM
           WHERE T.ID = ROLETMP.ID;
      END;

    END LOOP;

  END PROC_ROLE_COPY;

  --同步关系表
  PROCEDURE PROC_ROLE_PARAM_USER_COPY IS
    V_PARAM_ID   NUMBER;
    V_ROLEID     VARCHAR2(10);
    V_ORGNAME    VARCHAR2(200);
    V_COUNT      NUMBER;
    V_MEMBER_ID  NUMBER;
    V_SPACE_CODE VARCHAR2(64);
    V_SQLERRM    VARCHAR2(2000);
  BEGIN

    --角色-角色参数 关系表
    FOR ROLEPARAMTMP IN (SELECT ROLE_CODE, PARAM_NAME, CREATED_BY
                           FROM CUX_ROLE_PARAM_EMP_TMP
                          WHERE ROLE_CODE IS NOT NULL
                            AND IS_UPDATE = '1'
                            AND IS_DELETE = '0'
                          GROUP BY ROLE_CODE, PARAM_NAME, CREATED_BY) LOOP

      --判断当前角色是否属于当前系统

      SELECT S.SPACE_CODE
        INTO V_SPACE_CODE
        FROM DBPM_ROLES T, DBPM_SPACES S
       WHERE T.SPACE_ID = S.SPACE_ID(+)
         AND T.ROLE_CODE = ROLEPARAMTMP.ROLE_CODE;

      IF V_SPACE_CODE = ROLEPARAMTMP.CREATED_BY THEN

        SELECT COUNT(1)
          INTO V_COUNT
          FROM DBPM_ROLE_PARAMS RP, DBPM_ROLES R
         WHERE RP.ROLE_ID = R.ROLE_ID
           AND R.ROLE_CODE = ROLEPARAMTMP.ROLE_CODE
           AND RP.Data_Source_Code = ROLEPARAMTMP.PARAM_NAME;

        IF V_COUNT = 0 THEN
          --不存在，新增到角色参数表
          INSERT INTO DBPM_ROLE_PARAMS
            (PARAM_ID,
             ROLE_ID,
             PARAM_NAME,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATED_BY,
             LAST_UPDATE_DATE,
             STATUS,
             DATA_SOURCE_CODE)
          VALUES
            (DBPM_ROLE_PARAMS_S.NEXTVAL,
             (SELECT ROLE_ID
                FROM DBPM_ROLES
               WHERE ROLE_CODE = ROLEPARAMTMP.ROLE_CODE),
             (SELECT DATA_SOURCE_NAME
                FROM dbpm_data_source
               WHERE DATA_SOURCE_CODE = ROLEPARAMTMP.PARAM_NAME),
             ROLEPARAMTMP.CREATED_BY,
             SYSDATE,
             ROLEPARAMTMP.CREATED_BY,
             SYSDATE,
             'Y',
             ROLEPARAMTMP.PARAM_NAME);

        END IF;
      END IF;
    END LOOP;

    --1、角色人员关系表 DBPM_ROLE_MEMBERS

    FOR TMP IN (SELECT *
                  FROM CUX_ROLE_PARAM_EMP_TMP T
                 WHERE T.IS_UPDATE = '1') LOOP
      BEGIN

        --判断 角色是否属于当前系统，不属于不做正式表的更改
        SELECT S.SPACE_CODE
          INTO V_SPACE_CODE
          FROM DBPM_SPACES S
         WHERE S.SPACE_ID =
               (SELECT MAX(R.SPACE_ID)
                  FROM DBPM_ROLES R
                 WHERE R.ROLE_CODE = TMP.ROLE_CODE);

        IF V_SPACE_CODE = TMP.CREATED_BY THEN

          SELECT COUNT(1)
            INTO V_COUNT
            FROM DBPM_ROLE_EMP_ORG_MAP_V V
           WHERE V.MEMBER_CODE = TMP.EMPLOYEE_CODE
             AND V.ROLE_CODE = TMP.ROLE_CODE
             AND V.PARAM_VALUE = TMP.PARAM_TYPE || TMP.PARAM_VALUE;

          IF V_COUNT <> 0 AND TMP.IS_DELETE = '1' THEN
            --关系表存在，中间表为删除状态，需要删除角色参数值关系表，和角色人员关系表

            FOR V_DREOM IN (SELECT *
                              FROM DBPM_ROLE_EMP_ORG_MAP_V V
                             WHERE V.MEMBER_CODE = TMP.EMPLOYEE_CODE
                               AND V.ROLE_CODE = TMP.ROLE_CODE
                               AND V.PARAM_VALUE =
                                   TMP.PARAM_TYPE || TMP.PARAM_VALUE) LOOP

              DELETE FROM DBPM_ROLE_MEMBER_PARAMS T
               WHERE T.PARAM_ID = V_DREOM.param_id
                 AND T.MEMBER_ID = V_DREOM.member_id
                 AND T.PARAM_VALUE = V_DREOM.PARAM_VALUE;

              DELETE FROM DBPM_ROLE_MEMBERS T
               WHERE T.MEMBER_ID = V_DREOM.Member_Id;
            END LOOP;

          ELSIF V_COUNT = 0 AND TMP.IS_DELETE = '0' AND
                TMP.ROLE_CODE IS NOT NULL AND TMP.EMPLOYEE_CODE IS NOT NULL AND
                TMP.PARAM_VALUE IS NOT NULL THEN
            --关系表不存在，中间表为启用状态，需要添加两个关系表‘

            --根据rolecode取到roleid

            SELECT ROLE_ID
              INTO V_ROLEID
              FROM DBPM_ROLES T
             WHERE T.ROLE_CODE = TMP.ROLE_CODE
               AND T.SPACE_ID =
                   (SELECT T.SPACE_ID
                      FROM DBPM_SPACES T
                     WHERE T.SPACE_CODE = TMP.CREATED_BY);

            --人员角色关系，新增
            INSERT INTO DBPM_ROLE_MEMBERS DRM
              (DRM.MEMBER_ID,
               DRM.MEMBER_TYPE,
               DRM.ROLE_ID,
               DRM.MEMBER_CODE,
               DRM.STATUS,
               DRM.CREATED_BY,
               DRM.CREATION_DATE,
               DRM.LAST_UPDATED_BY,
               DRM.LAST_UPDATE_DATE,
               DRM.SPACE_ID)
            VALUES
              (DBPM_ROLE_MEMBERS_S.NEXTVAL,
               'USER',
               V_ROLEID,
               TMP.EMPLOYEE_CODE,
               'Y',
               TMP.CREATED_BY,
               SYSDATE,
               TMP.LAST_UPDATED_BY,
               SYSDATE,
               (SELECT T.SPACE_ID
                  FROM DBPM_SPACES T
                 WHERE T.SPACE_CODE = TMP.CREATED_BY));

            V_MEMBER_ID := DBPM_ROLE_MEMBERS_S.CURRVAL;

            SELECT MAX(T.PARAM_ID)
              INTO V_PARAM_ID
              FROM DBPM_ROLE_PARAMS T
             WHERE T.ROLE_ID = V_ROLEID;

            SELECT T.ORGANIZATION_NAME
              INTO V_ORGNAME
              FROM DFND_ORGANIZATIONS T
             WHERE T.ORGANIZATION_CODE = TMP.PARAM_TYPE || TMP.Param_Value;

            INSERT INTO DBPM_ROLE_MEMBER_PARAMS DRMP
              (DRMP.PARAM_ID,
               DRMP.MEMBER_ID,
               DRMP.PARAM_VALUE,
               DRMP.ATTRIBUTE6,
               DRMP.CREATED_BY,
               DRMP.CREATION_DATE,
               DRMP.LAST_UPDATED_BY,
               DRMP.LAST_UPDATE_DATE,
               DRMP.PARAM_VALUE_NAME,
               DRMP.SOURCE_TYPE)
            VALUES
              (V_PARAM_ID,
               V_MEMBER_ID,
               TMP.PARAM_TYPE || TMP.Param_Value,
               'Y',
               TMP.CREATED_BY,
               SYSDATE,
               TMP.CREATED_BY,
               SYSDATE,
               V_ORGNAME,
               TMP.CREATED_BY);

          ELSIF V_COUNT <> 0 AND TMP.IS_DELETE = '0' THEN
            --关系表存在，中间表状态为启用，不做操作
            NULL;
          ELSIF V_COUNT = 0 AND TMP.IS_DELETE = '1' THEN
            --关系表不存在，中间表状态为失效，不做操作
            NULL;
          END IF;
        ELSE
          UPDATE CUX_ROLE_PARAM_EMP_TMP T
             SET T.ATTRIBUTE1 = '当前角色属于系统:' || V_SPACE_CODE || '，不允许修改'
           WHERE T.ID = TMP.ID;
        END IF;
        UPDATE CUX_ROLE_PARAM_EMP_TMP T
           SET T.IS_UPDATE = '0'
         WHERE T.ID = TMP.ID;

      EXCEPTION
        WHEN OTHERS THEN
          V_SQLERRM := SQLERRM;
          UPDATE CUX_ROLE_PARAM_EMP_TMP T
             SET T.IS_UPDATE = '0', T.ATTRIBUTE10 = V_SQLERRM
           WHERE T.ID = TMP.ID;
      END;

    END LOOP;
  END PROC_ROLE_PARAM_USER_COPY;

END CUX_BASE_DATA_SYNC_PKG;

/

