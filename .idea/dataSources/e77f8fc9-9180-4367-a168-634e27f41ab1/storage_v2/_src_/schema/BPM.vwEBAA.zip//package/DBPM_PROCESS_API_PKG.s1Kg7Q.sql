create package     dbpm_process_api_pkg is

  -- Author  : WLJ
  -- Created : 2018/7/16 16:13:21
  -- Purpose : 用于维护流程信息
  /*==================================================
  Procedure/Function Name :
      proc_save_process
  Description:
      This function perform:
      流程配置-保存流程基本信息，需要判断是新建还是更新
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-07  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_save_process(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_save_process
  Description:
      This function perform:
      流程配置-保存流程国际化值
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-05-14  xiaowei.yao  migrate
  ==================================================*/
  PROCEDURE proc_save_process_tl(p_request CLOB, x_response OUT CLOB);


  /*==================================================
  Procedure/Function Name :
      proc_save_process_owner
  Description:
      This function perform:
      流程配置-维护流程主人
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-07-16  wlj  create
  ==================================================*/
  PROCEDURE proc_save_process_owner(p_request CLOB, x_response OUT CLOB);
end dbpm_process_api_pkg;

/

