create package DBPM_PROXY_API_PKG is

  -- Author  : liangjun.wu
  -- Created : 2017/12/11 15:29:37
  -- Purpose :

  /*==================================================
  Procedure/Function Name :
      proc_get_proxy_list
  Description:
      This function perform:
      查询授权列表
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-12-11  liangjun.wu  Creation
  ==================================================*/
  PROCEDURE proc_get_proxy_list(p_request CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_save_proxy
  Description:
      This function perform:
      查询授权列表
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-12-11  liangjun.wu  Creation
  ==================================================*/
  PROCEDURE proc_save_proxy(p_request CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_delete_proxy
  Description:
      This function perform:
      查询授权列表
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-12-12  liangjun.wu  Creation
  ==================================================*/
  PROCEDURE proc_delete_proxy(p_request CLOB, x_response OUT CLOB);

end DBPM_PROXY_API_PKG;

/

