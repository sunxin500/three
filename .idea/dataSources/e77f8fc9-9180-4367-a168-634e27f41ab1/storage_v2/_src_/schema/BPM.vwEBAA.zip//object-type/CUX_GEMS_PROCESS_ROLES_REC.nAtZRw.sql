create TYPE     "CUX_GEMS_PROCESS_ROLES_REC" IS OBJECT
(
       nodeId       NUMBER,
       processId    VARCHAR2(2000),
       nodeName     VARCHAR2(4000),
       nodeType     VARCHAR2(2000),
       orderNum     NUMBER
)

/

