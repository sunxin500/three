create package body dbpm_workspace_api_pkg is
  /*
  * 创建审批历史
  */
  procedure proc_create_approval_history(p_request  in clob,
                                         x_response out clob) is
    v_api          varchar2(30) := 'proc_create_approval_history';
    v_request      json;
    v_response     pl_json := pl_json;
    v_current_user varchar2(100);
    v_comment      varchar2(4000);
    v_outcome      varchar2(200);
    v_document_id  number;
    v_node_name    varchar2(200);
    v_user_name    varchar2(100);
    v_node_id      number;

  begin
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;
    v_comment      := dcld_comm_pkg.get_string_value(v_request.get('comment'));
    v_outcome      := v_request.get_string('outcome');
    v_document_id  := v_request.get_number('documentId');
    if v_document_id is null then
      v_document_id := v_request.get_string('documentId');
    end if;
    v_node_name := v_request.get_string('nodeName');
    v_node_id   := nvl(v_request.get_string('nodeId'),
                       v_request.get_number('nodeId'));
    select fe.employee_name
      into v_user_name
      from dfnd_employees fe
     where upper(fe.employee_code) = upper(v_current_user);

    insert into dbpm_approval_history
      (history_id,
       document_id,
       node_name,
       approver_code,
       approver_name,
       operation,
       comment_detail,
       created_by,
       last_updated_by,
       node_id)
    values
      (dbpm_approval_history_s.nextval,
       v_document_id,
       v_node_name,
       v_current_user,
       v_user_name,
       v_outcome,
       v_comment,
       v_current_user,
       v_current_user,
       v_node_id);
    x_response := v_response.to_json;

  end proc_create_approval_history;

  /*==================================================
  procedure name :
      proc_task_drafts_query
  description:
      查询我的草稿箱
    1、dbpm_process、dbpm_tasks两表关联查询
    2、dbpm_process与dbpm_tasks根据process_id关联查询
  argument:
      p_request：  请求（json）
      x_response： 响应（json）
  history:
      1.00  2016-11-30  曾勇 creation
  ==================================================*/
  procedure proc_task_drafts_query(p_request in clob, x_response out clob) is
    v_api      varchar2(30) := 'proc_task_drafts_query';
    v_fields   json_list;
    v_field    json;
    v_request  json;
    v_response pl_json := pl_json;
    v_line     pl_json;

    v_search_content varchar2(4000);
    --排序参数
    v_sort_col varchar2(100);
    v_sort     json;
    /*备用字段
    v_order                  varchar2(100);
    v_order_type             varchar2(30);
    */
    v_page         number;
    v_size         number;
    v_field_name   varchar2(100);
    v_row_count    number;
    v_current_user varchar2(100);
    v_platform     varchar2(100); --设备来源标识
    --定义关联查询游标
    cursor v_task_drafts_v_cur is
      select *
        from (select v.*, rownum cnt
                from (select count(1) over(partition by 1) total,
                             v.task_id,
                             v.document_id,
                             v.form_id,
                             v.process_id,
                             v.task_number,
                             v.title,
                             v.status,
                             dcld_comm_pkg.get_data_source_value('DbpmProcessStatus',
                                                                 v.status,
                                                                 v_request.locale) as status_meaning,
                             v.process_name,
                             dpt.type_name process_type,
                             dpt.display_color process_type_color,
                             v.process_code,
                             v.creation_date,
                             v.doc_sys_code,
                             v.process_class,
                             v.doc_url
                        from dbpm_task_drafts_query_v v,
                             dbpm_process_types       dpt
                       where dpt.type_code(+) = v.process_type
                         and (nvl(v.task_number, 'NL') like
                              '%' || v_search_content || '%' or
                              nvl(v.title, 'NL') like
                              '%' || v_search_content || '%' or
                              nvl(v.process_name, 'NL') like
                              '%' || v_search_content || '%' or
                              instr(nvl(dpt.type_name, 'NL'),
                                    nvl(v_search_content,
                                        nvl(dpt.type_name, 'NL'))) > 0)
                         and upper(v.created_user_code) =
                             upper(v_current_user)
                       order by decode(v_sort_col,
                                       'task_number_desc',
                                       nvl(v.task_number, '-'),
                                       'title_desc',
                                       v.title,
                                       'process_type_desc',
                                       dpt.type_name,
                                       'creation_date_desc',
                                       to_char(v.creation_date,
                                               'yyyy-mm-dd hh24:mi:ss')) desc) v
               where rownum <= v_page * v_size)
       where cnt > (v_page - 1) * v_size;
    v_task_drafts_v_row v_task_drafts_v_cur%rowtype;
  begin
    --解析字段
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;
    v_platform     := nvl(v_request.get_string('platform'), 'WEB');

    v_page           := nvl(v_request.get('page').get_number, 1);
    v_size           := nvl(v_request.get('size').get_number, 20);
    v_search_content := dcld_comm_pkg.get_filter_value('all', v_request);
    if v_request.exist('sort') then
      v_sort     := json(v_request.get('sort'));
      v_sort_col := v_sort.get_string('value');
      v_sort_col := v_sort_col || '_' || v_sort.get_string('order');
    end if;
    /*if v_request.get('fields') is not null then
      v_fields := json_list(v_request.get('fields'));
      for v_index in 1 .. v_fields.count loop
        v_field      := json(v_fields.get(v_index));
        v_field_name := v_field.get('field').get_string;
        if 'task_number' = v_field_name then
          v_task_number := v_field.get('value').get_string;
        elsif 'title' = v_field_name then
          v_task_title := v_field.get('value').get_string;
        elsif 'process_name' = v_field_name then
          v_process_name := v_field.get('value').get_string;
        elsif 'process_code' = v_field_name then
          v_process_code := v_field.get('value').get_string;
        end if;
      end loop;
    end if;*/
    --查询记录总条数
    /*    select count(1)
      into v_row_count
      from dbpm_task_drafts_query_v v
     where nvl(v.task_number, 'NL') like '%' || v_task_number || '%'
       and nvl(v.title, 'NL') like '%' || v_task_title || '%'
       and nvl(v.process_name, 'NL') like '%' || v_process_name || '%'
       and nvl(v.process_code, 'NL') =
           nvl(v_process_code, nvl(v.process_code, 'NL'))
       and v.created_user_code = v_current_user;
    v_response.set_value('total', v_row_count);*/
    --查询行
    for v_task_drafts_v_row in v_task_drafts_v_cur loop
      v_line      := pl_json;
      v_row_count := v_task_drafts_v_row.total;
      v_line.set_value('task_id', v_task_drafts_v_row.task_id);
      v_line.set_value('documentId', v_task_drafts_v_row.document_id);
      v_line.set_value('formId', v_task_drafts_v_row.form_id);
      v_line.set_value('processId', v_task_drafts_v_row.process_id);
      v_line.set_value('task_number', v_task_drafts_v_row.task_number);
      v_line.set_value('title', v_task_drafts_v_row.title);
      v_line.set_value('status', v_task_drafts_v_row.status);
      v_line.set_value('status_meaning',
                       v_task_drafts_v_row.status_meaning);
      v_line.set_value('process_name', v_task_drafts_v_row.process_name);
      v_line.set_value('process_code', v_task_drafts_v_row.process_code);
      v_line.set_value('process_type', v_task_drafts_v_row.process_type);
      v_line.set_value('process_type_color',
                       v_task_drafts_v_row.process_type_color);
      v_line.set_value('creation_date',
                       to_char(v_task_drafts_v_row.creation_date,
                               'YYYY-MM-DD HH24:MI'));
      --得云统一工作台begin
      v_line.set_value('processClass',
                       nvl(v_task_drafts_v_row.process_class, 'INTERNAL'));

      if v_task_drafts_v_row.doc_sys_code in ('BPM', 'BPM_EXT') then
        v_line.set_value('docSysCode', v_task_drafts_v_row.doc_sys_code);
      else
        v_line.set_value('docSysCode', 'OTHERS');
      end if;
      v_line.set_value('externalFormUrl', v_task_drafts_v_row.doc_url);
      --得云统一工作台end

      v_response.add_list_item('list', v_line);
    end loop;
    v_response.set_value('total', v_row_count);
    x_response := v_response.to_json;
    /*  exception
    when others then
      rollback;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || sqlerrm);
      x_response := v_response.to_json;*/
  end;
  /*==================================================
  procedure name :
      proc_task_apply_query
  description:
      创建角色
    1、dfnd_employee、dbpm_process、dbpm_tasks、dbpm_tasks_assignees四表关联查询
    2、dfnd_employee与dbpm_tasks_assignees根据员工code关联查询
    3、dbpm_tasks_assignees与dbpm_tasks根据task_id关联查询
    4、dbpm_process与dbpm_tasks根据process_id关联查询（筛选功能）
  argument:
      p_request：  请求（json）
      x_response： 响应（json）
  history:
      1.00  2016-12-01  曾勇 creation
  sample input:
      {
         "fields": [
               {
                 "field": "task_number/title/process_name/process_code",
                 "op": "like/like/like/=",
                  "value": "xxxx/xxxx/xxxx/xxxx"
                }],
          "page": 100,
          "size": 101,
          "order": "xxxx",
          "order_type": "xxxxx"
       }
         task_number:       任务编号
         title:             任务名称
         process_name:      流程名称
     process_code:      流程编号
         page：             当前页码
         size:              分页大小
         order:             排序字段
         order_type:        排序类型
  sample output:
         标准输出
         [
         {
         "task_id":"",
         "task_number": "xxxx",
         "title": "xxxx",
         "status":"xxxx",
         "status_meaning": "xxxx",
         "process_name": "xxxx",
         "process_code": "xxxx",
         "process_type": "xxxx",
         "creation_date": "xxxx",
         "approve_user_name":"xxxx",
         "approve_user_code":"xxxx"
         }
        ]
  ==================================================*/
  PROCEDURE proc_task_apply_query(p_request IN CLOB, x_response OUT CLOB) IS
    v_api      VARCHAR2(30) := 'proc_task_apply_query';
    v_fields   json_list;
    v_field    json;
    v_request  json;
    v_response pl_json := pl_json;
    v_line     pl_json;
    /*    v_task_number  VARCHAR2(30);
    v_task_title   VARCHAR2(400);
    v_process_name VARCHAR2(400);
    v_process_code VARCHAR2(30);*/
    v_search_content varchar2(4000);
    --排序参数
    v_sort_col varchar2(1000);
    v_sort     json;
    /*备用字段
    v_order                  VARCHAR2(100);
    v_order_type             VARCHAR2(30);
    */
    v_page         NUMBER;
    v_size         NUMBER;
    v_field_name   VARCHAR2(1000);
    v_row_count    NUMBER;
    v_current_user VARCHAR2(1000);
    v_platform     varchar2(1000); --设备来源标识
    --定义关联查询游标
    CURSOR v_task_apply_v_cur IS
      SELECT *
        FROM (SELECT v.*,
                     rownum cnt,
                     (select listagg(we.assignee, ',') within GROUP(ORDER BY t.assignees) approve_user_name
                        from wftask t, wfassignee we
                       where t.taskid = we.taskid
                         and t.instanceid = to_char(v.bpm_instance_id)
                         and t.state IN ('ASSIGNED', 'INFO_REQUESTED')) approve_user_code,
                     (select listagg(t.assigneesdisplayname, ',') within GROUP(ORDER BY t.assigneesdisplayname) approve_user_name
                        from wftask t, wfassignee we
                       where t.taskid = we.taskid
                         and t.instanceid = to_char(v.bpm_instance_id)
                         and t.state IN ('ASSIGNED', 'INFO_REQUESTED')) approve_user_name
                FROM (SELECT count(1) over(partition by 1) total,
                             v.task_id,
                             v.document_id,
                             v.form_id,
                             v.process_id,
                             v.task_number,
                             v.title,
                             v.status,
                             dcld_comm_pkg.get_data_source_value('DbpmProcessStatus',
                                                                 v.status,
                                                                 v_request.locale) status_meaning,
                             v.process_name,
                             v.process_code,
                             dpt.type_name process_type,
                             dpt.display_color process_type_color,
                             v.creation_date,
                             --v.approve_user_name,
                             --v.approve_user_code,
                             v.doc_sys_code,
                             v.process_class,
                             v.doc_url,
                             v.bpm_instance_id,
                             v.state,
                             (select nvl(md.mobile_url, 'Y')
                                from cux_process_mob_data md
                               where md.document_number =
                                     to_char(v.bpm_instance_id)) is_has_mob_data
                        FROM (SELECT dd.document_id     task_id,
                                     dd.document_id,
                                     dd.form_id,
                                     dd.process_id,
                                     dd.doc_number      task_number,
                                     dd.title,
                                     dd.status,
                                     dpt.process_name,
                                     dp.process_code,
                                     dp.process_type,
                                     dd.doc_create_time creation_date,
                                     dd.doc_creator     created_user_code,
                                     /*(select listagg(t.assignees, ',') within GROUP(ORDER BY t.assignees) approve_user_name
                                        from wftask t
                                       where t.instanceid =
                                             to_char(dd.bpm_instance_id)
                                         and t.state IN
                                             ('ASSIGNED', 'INFO_REQUESTED')) approve_user_code,
                                     (select listagg(e.employee_name, ',') within GROUP(ORDER BY t.assignees) approve_user_name
                                        from wftask t, dfnd_employees e
                                       where t.instanceid =
                                             to_char(dd.bpm_instance_id)
                                         and t.assignees =
                                             lower(e.employee_code)
                                         and t.state IN
                                             ('ASSIGNED', 'INFO_REQUESTED')) approve_user_name,*/
                                     dd.doc_sys_code,
                                     dp.process_class,
                                     dd.doc_url,
                                     dd.bpm_instance_id,
                                     (select ci.state
                                        from cube_instance ci
                                       where ci.cikey = dd.bpm_instance_id) state
                                FROM dbpm_documents  dd,
                                     dbpm_process    dp,
                                     dbpm_process_tl dpt
                               WHERE dd.process_id = dp.process_id
                                 AND dp.process_id = dpt.process_id
                                 AND dpt.locale =
                                     dbpm_comm_pkg.get_current_locale
                                 AND dd.status <> 'NEW'
                                 and upper(dd.doc_creator) =
                                     upper(v_current_user)) v,
                             dbpm_process_types dpt
                       WHERE dpt.type_code(+) = v.process_type
                         AND (nvl(v.task_number, 'NL') LIKE
                              '%' || v_search_content || '%' OR
                              nvl(v.title, 'NL') LIKE
                              '%' || v_search_content || '%' OR
                              nvl(v.process_name, 'NL') LIKE
                              '%' || v_search_content || '%' OR
                              INSTR(NVL(DPT.TYPE_NAME, 'NL'),
                                    NVL(v_search_content,
                                        nvl(DPT.TYPE_NAME, 'NL'))) > 0 /*OR
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    INSTR(NVL(v.approve_user_name, 'NL'),
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          NVL(v_search_content,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              nvl(v.approve_user_name, 'NL'))) > 0*/)
                       ORDER BY decode(v_sort_col,
                                       'task_number_desc',
                                       nvl(v.task_number, '-'),
                                       'title_desc',
                                       v.title,
                                       'process_type_desc',
                                       dpt.type_name,
                                       /*'approve_user_name_desc',
                                       v.approve_user_name,*/
                                       'creation_date_desc',
                                       to_char(v.creation_date,
                                               'yyyy-mm-dd hh24:mi:ss')) DESC) v
               WHERE rownum <= v_page * v_size)
       WHERE cnt > (v_page - 1) * v_size;
        --定义关联查询游标 add by xiaowei.yao 20190523
    cursor v_task_apply_v_add_cur is
      select *
        from (select v.*,
                     rownum cnt,
                     (select listagg(we.assignee, ',') within group(order by t.assignees) approve_user_name
                        from wftask t, wfassignee we
                       where t.taskid = we.taskid
                         and t.instanceid = to_char(v.bpm_instance_id)
                         and t.state ='ASSIGNED') approve_user_code,
                     (select listagg(t.assigneesdisplayname, ',') within group(order by t.assigneesdisplayname) approve_user_name
                        from wftask t, wfassignee we
                       where t.taskid = we.taskid
                         and t.instanceid = to_char(v.bpm_instance_id)
                         and t.state ='ASSIGNED') approve_user_name
                from (select count(1) over(partition by 1) total,
                             v.task_id,
                             v.document_id,
                             v.form_id,
                             v.process_id,
                             v.task_number,
                             v.title,
                             v.status,
                             dcld_comm_pkg.get_data_source_value('DbpmProcessStatus',
                                                                 v.status,
                                                                 v_request.locale) status_meaning,
                             v.process_name,
                             v.process_code,
                             dpt.type_name process_type,
                             dpt.display_color process_type_color,
                             v.creation_date,

                             v.doc_sys_code,
                             v.process_class,
                             v.doc_url,
                             v.bpm_instance_id,
                             v.state,
                             (select nvl(md.mobile_url, 'Y')
                                from cux_process_mob_data md
                               where md.document_number =
                                     to_char(v.bpm_instance_id)) is_has_mob_data
                        from (select dd.document_id      task_id,
                                     cb.process_form_id document_id,
                                     cb.process_form_id form_id,
                                     dd.process_id,
                                     nvl(dd.doc_number,cb.process_form_id)      task_number,
                                     cb.process_form_info title,
                                     dd.status,
                                     dpt.process_name,
                                     dp.process_code,
                                     dp.process_type,
                                     ci.creation_date    creation_date,
                                     cb.instance_creator created_user_code,
                                     dp.doc_sys_code     doc_sys_code,
                                     dp.process_class,
                                     (dp.form_url||'&formKey='||cb.process_form_id||'&instanceId='||cb.instance_id) doc_url,
                                     cb.instance_id      bpm_instance_id,
                                     ci.state            state
                                from dbpm_documents       dd,
                                     dbpm_process         dp,
                                     dbpm_process_tl      dpt,
                                     cux_bpm_all_instance cb,
                                     cube_instance        ci
                               where cb.process_code = dp.process_code(+)
                                 and dp.process_id = dpt.process_id
                                 and dpt.locale =
                                     dbpm_comm_pkg.get_current_locale
                                 and ci.cikey(+) = cb.instance_id
                                    -- and dd.status <> 'NEW'
                                 and cb.instance_id = dd.bpm_instance_id(+)
                                 and cb.instance_creator =
                                     v_current_user) v,
                             dbpm_process_types dpt
                       where dpt.type_code(+) = v.process_type
                         and (nvl(v.task_number, 'NL') like
                              '%' || v_search_content || '%' or
                              nvl(v.title, 'NL') like
                              '%' || v_search_content || '%' or
                              nvl(v.process_name, 'NL') like
                              '%' || v_search_content || '%' or
                              instr(nvl(dpt.type_name, 'NL'),
                                    nvl(v_search_content,
                                        nvl(dpt.type_name, 'NL'))) > 0 )
                       order by decode(v_sort_col,
                                       'task_number_desc',
                                       nvl(v.task_number, '-'),
                                       'title_desc',
                                       v.title,
                                       'process_type_desc',
                                       dpt.type_name,
                                       'creation_date_desc',
                                       to_char(v.creation_date,
                                               'yyyy-mm-dd hh24:mi:ss')) desc) v
               where rownum <= v_page * v_size)
       where cnt > (v_page - 1) * v_size;
 cursor v_task_apply_v_add_new_cur is
      select *
        from (select v.*,
                     rownum cnt,
                    '' approve_user_code,
                    '' approve_user_name
                from (select count(1) over(partition by 1) total,
                             v.task_id,
                             v.document_id,
                             v.form_id,
                             v.process_id,
                             v.task_number,
                             v.title,
                             v.status,
                             dcld_comm_pkg.get_data_source_value('DbpmProcessStatus',
                                                                 v.status,
                                                                 v_request.locale) status_meaning,
                             v.process_name,
                             v.process_code,
                             dpt.type_name process_type,
                             dpt.display_color process_type_color,
                             v.creation_date,

                             v.doc_sys_code,
                             v.process_class,
                             v.doc_url,
                             v.bpm_instance_id,
                             v.state,
                             (select nvl(md.mobile_url, 'Y')
                                from cux_process_mob_data md
                               where md.document_number =
                                     to_char(v.bpm_instance_id)) is_has_mob_data
                        from (select dd.document_id      task_id,
                                     cb.process_form_id document_id,
                                     cb.process_form_id form_id,
                                     dd.process_id,
                                     nvl(dd.doc_number,cb.process_form_id)      task_number,
                                     cb.process_form_info title,
                                     cb.instance_status status,
                                     dpt.process_name,
                                     dp.process_code,
                                     dp.process_type,
                                      ci.creation_date    creation_date,
                                     cb.instance_creator created_user_code,
                                     dp.doc_sys_code     doc_sys_code,
                                     dp.process_class,
                                     (dp.form_url||'?formKey='||cb.process_form_id||'&instanceId='||cb.instance_id) doc_url,
                                     cb.instance_id      bpm_instance_id,
                                      ci.state         state
                                from dbpm_documents       dd,
                                     dbpm_process         dp,
                                     dbpm_process_tl      dpt,
                                     cux_bpm_all_instance cb,
                                     cube_instance ci
                               where cb.process_code = dp.process_code(+)
                                 and dp.process_id = dpt.process_id
                                 and dpt.locale =
                                     dbpm_comm_pkg.get_current_locale
                                and ci.cikey = cb.instance_id
                                   -- and dd.status <> 'NEW'
                                 and cb.instance_id = dd.bpm_instance_id(+)
                                 and cb.instance_creator =
                                     v_current_user) v,
                             dbpm_process_types dpt
                       where dpt.type_code(+) = v.process_type
                         and (nvl(v.task_number, 'NL') like
                              '%' || v_search_content || '%' or
                              nvl(v.title, 'NL') like
                              '%' || v_search_content || '%' or
                              nvl(v.process_name, 'NL') like
                              '%' || v_search_content || '%' or
                              instr(nvl(dpt.type_name, 'NL'),
                                    nvl(v_search_content,
                                        nvl(dpt.type_name, 'NL'))) > 0 )
                       order by decode(v_sort_col,
                                       'task_number_desc',
                                       nvl(v.task_number, '-'),
                                       'title_desc',
                                       v.title,
                                       'process_type_desc',
                                       dpt.type_name,
                                       'creation_date_desc',
                                       to_char(v.creation_date,
                                               'yyyy-mm-dd hh24:mi:ss')) desc) v
               where rownum <= v_page * v_size)
       where cnt > (v_page - 1) * v_size;
  --  v_task_apply_v_row v_task_apply_v_cur%ROWTYPE;
     v_task_apply_v_row v_task_apply_v_add_new_cur%ROWTYPE;
      v_create_date timestamp;

  BEGIN
    --解析字段
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;
    v_platform     := NVL(v_request.get_string('platform'), 'WEB');

    v_page           := nvl(v_request.get('page').get_number, 1);
    v_size           := nvl(v_request.get('size').get_number, 20);
    v_search_content := dcld_comm_pkg.get_filter_value('all', v_request);
    if v_request.exist('sort') then
      v_sort     := json(v_request.get('sort'));
      v_sort_col := v_sort.get_string('value');
      v_sort_col := v_sort_col || '_' || v_sort.get_string('order');
    end if;
    /*v_fields := json_list(v_request.get('fields'));
    IF v_request.get('fields') IS NOT NULL THEN
      FOR v_index IN 1 .. v_fields.count LOOP
        v_field      := json(v_fields.get(v_index));
        v_field_name := v_field.get('field').get_string;
        IF 'task_number' = v_field_name THEN
          v_task_number := v_field.get('value').get_string;
        ELSIF 'title' = v_field_name THEN
          v_task_title := v_field.get('value').get_string;
        ELSIF 'process_name' = v_field_name THEN
          v_process_name := v_field.get('value').get_string;
        ELSIF 'process_code' = v_field_name THEN
          v_process_code := v_field.get('value').get_string;
        END IF;
      END LOOP;
    END IF;
    --查询记录总条数
    SELECT COUNT(1)
      INTO v_row_count
      FROM dbpm_task_apply_query_v v
     WHERE nvl(v.task_number, 'NL') LIKE '%' || v_task_number || '%'
       AND nvl(v.title, 'NL') LIKE '%' || v_task_title || '%'
       AND nvl(v.process_name, 'NL') LIKE '%' || v_process_name || '%'
       AND nvl(v.process_code, 'NL') =
           nvl(v_process_code, nvl(v.process_code, 'NL'))
       AND v.created_user_code = v_current_user;
    v_response.set_value('total', v_row_count);*/
    --查询行
    FOR v_task_apply_v_row IN v_task_apply_v_add_new_cur LOOP
      v_line      := pl_json;
      v_row_count := v_task_apply_v_row.total;
      v_line.set_value('task_id', v_task_apply_v_row.task_id);
      v_line.set_value('documentId', v_task_apply_v_row.document_id);
      v_line.set_value('formId', v_task_apply_v_row.form_id);
      v_line.set_value('processId', v_task_apply_v_row.process_id);
      v_line.set_value('task_number', v_task_apply_v_row.task_number);
      v_line.set_value('title', v_task_apply_v_row.title);
      if v_task_apply_v_row.process_class = 'EXTERNAL' then
        if v_task_apply_v_row.state = 1 then
          v_line.set_value('status', 'PROCESSING');
          v_line.set_value('status_meaning',
                           DCLD_COMM_PKG.get_lookup_meaning('CUBE_INSTANCE_STATE',
                                                            to_char(v_task_apply_v_row.state),
                                                            v_request.locale));
        elsif v_task_apply_v_row.state = 5 then
          v_line.set_value('status', 'COMPLETED');
          v_line.set_value('status_meaning',
                           DCLD_COMM_PKG.get_lookup_meaning('CUBE_INSTANCE_STATE',
                                                            to_char(v_task_apply_v_row.state),
                                                            v_request.locale));
        ELSE
          v_line.set_value('status', 'PROCESSING');
          v_line.set_value('status_meaning',
                           DCLD_COMM_PKG.get_lookup_meaning('CUBE_INSTANCE_STATE',
                                                            to_char(v_task_apply_v_row.state),
                                                            v_request.locale));
        end if;
      else
        v_line.set_value('status', v_task_apply_v_row.status);
        v_line.set_value('status_meaning',
                         v_task_apply_v_row.status_meaning);
      end if;

      v_line.set_value('process_name', v_task_apply_v_row.process_name);
      v_line.set_value('process_code', v_task_apply_v_row.process_code);
      v_line.set_value('process_type', v_task_apply_v_row.process_type);
      v_line.set_value('process_type_color',
                       v_task_apply_v_row.process_type_color);
  --   select ci.creation_date into v_create_date from cube_instance ci
   --                   where ci.cikey=v_task_apply_v_row.bpm_instance_id;
      v_line.set_value('creation_date',
                       to_char(v_task_apply_v_row.creation_date,
                               'YYYY-MM-DD HH24:MI'));
      IF v_task_apply_v_row.approve_user_name IS NOT NULL THEN
        /*v_line.set_value('approve_user_name',
        v_task_apply_v_row.approve_user_name || '(' ||
        upper(v_task_apply_v_row.approve_user_code) || ')');*/
        v_line.set_value('approve_user_name',
                         v_task_apply_v_row.approve_user_name);
      END IF;
      v_line.set_value('approve_user_code',
                       v_task_apply_v_row.approve_user_code);
      --得云统一工作台begin
      v_line.set_value('processClass',
                       nvl(v_task_apply_v_row.process_class, 'INTERNAL'));
      v_line.set_value('instanceId', v_task_apply_v_row.bpm_instance_id);
      --设置流程执行天数
      v_line.set_value('instanceLiveDay',
                       dbpm_comm_pkg.func_instance_live_day(v_task_apply_v_row.bpm_instance_id));
      --设置docSycCode
      IF v_platform = 'WEB' THEN
        IF v_task_apply_v_row.doc_sys_code IN ('BPM', 'BPM_EXT') THEN
          v_line.set_value('docSysCode', v_task_apply_v_row.doc_sys_code);
        ELSE
          v_line.set_value('docSysCode', 'OTHERS');
        END IF;
      ELSE
        IF v_task_apply_v_row.doc_sys_code IN ('BPM', 'BPM_EXT') THEN
          v_line.set_value('docSysCode', v_task_apply_v_row.doc_sys_code);
        ELSE
          --如果是移动端，并且有传入移动端展示数据
          IF v_task_apply_v_row.Is_Has_Mob_Data = 'Y' THEN
            v_line.set_value('docSysCode', 'CONFIG');
          else
            v_line.set_value('docSysCode', 'OTHERS');
          END IF;
        END IF;
      END IF;
      v_line.set_value('externalFormUrl', v_task_apply_v_row.doc_url);
      --得云统一工作台end
      v_response.add_list_item('list', v_line);
    END LOOP;
    v_response.set_value('total', v_row_count);
    x_response := v_response.to_json;
    /*EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END;
  /*==================================================
  procedure name :
      proc_task_drafts_remove
  description:
      移除草稿，支持批量
    1、非空校验
    2、判断是否存在
    3、存在删除
  argument:
      p_request：  请求（json）
      x_response： 响应（json）
  history:
      1.00  2016-11-21  jianfeng.zheng  creation
  sample input:
      {
    "tasks": [xxxx, xxxx, xxxx]
      }
         task_id: 任务id
  sample output:
         标准输出
  ==================================================*/
  procedure proc_task_drafts_remove(p_request in clob, x_response out clob) is
    v_api               varchar2(30) := 'proc_task_drafts_remove';
    v_tasks             json_list;
    v_task_id           number;
    v_request           json;
    v_response          pl_json := pl_json;
    v_created_user_code varchar2(100);
  begin
    --解析字段
    v_request := json(p_request, 'OBJECT');
    if v_request.get('tasks') is not null then
      v_tasks := json_list(v_request.get('tasks'));
      for v_index in 1 .. v_tasks.count loop
        v_task_id := v_tasks.get(v_index).get_number;
        if upper(v_created_user_code) != upper(v_request.username) then
          --v_response.fail('权限不足');
          v_response.fail(dcld_comm_pkg.func_get_err_msg('DCLD-00018',
                                                         v_request.locale));
          exit;
        end if;
        --删除
        delete from dbpm_documents dd
         where dd.document_id = v_task_id
           and dd.status = 'NEW';
        if sql%rowcount > 0 then
          delete from dbpm_document_lines ddl
           where ddl.document_id = v_task_id;
        end if;
        /*delete from dbpm.dbpm_tasks t                                                                                                                                                                                                                                                                                                                                         and t.status = 'NEW';*/
      end loop;
    end if;
    x_response := v_response.to_json;
    /* exception
    when others then
      rollback;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || sqlerrm);
      x_response := v_response.to_json;*/
  end;
  /*==================================================
  procedure name :
      proc_task_partake_query
  description:
      查询我的参与
    1、从我的参与视图中分页查询出task信息
    2、与我的申请查询一样四表关联查询
    2、视图根据task创建人或者分配人code为user_code的task表中筛选出task
  argument:
      p_request：  请求（json）
      x_response： 响应（json）
  history:
      1.00  2016-12-01  曾勇 creation
  sample input:
      {
         "fields": [
               {
                 "field": "task_number/title/process_name/process_code",
                 "op": "like/like/like/=",
                  "value": "xxxx/xxxx/xxxx/xxxx"
                }],
          "page": 100,
          "size": 101,
          "order": "xxxx",
          "order_type": "xxxx"
       }
         task_number:       任务编号
         title:             任务名称
         process_name:      流程名称
     process_code:      流程编号
         page：             当前页码
         size:              分页大小
         order:             排序字段
         order_type:        排序类型
  sample output:
         标准输出
         [
         {
         "task_id":"",
         "task_number": "xxxx",
         "title": "xxxx",
         "status":"xxxx",
         "status_meaning": "xxxx",
         "process_name": "xxxx",
         "process_code": "xxxx",
         "process_type": "xxxx",
     "created_user_name":"xxxx",
     "created_user_code":"xxxx",
         "creation_date": "xxxx",
         "approve_user_name":"xxxx",
         "approve_user_code":"xxxx"
         }
        ]
  ==================================================*/
  procedure proc_task_partake_query(p_request in clob, x_response out clob) is
    v_api           varchar2(30) := 'proc_task_partake_query';
    v_fields        json_list;
    v_field         json;
    v_request       json;
    v_response      pl_json := pl_json;
    v_line          pl_json;
    v_process_name  varchar2(4000);
    v_process_type  varchar2(300);
    v_process_id    number;
    v_process_color varchar2(300);
    v_base_form_url varchar2(4000);
    v_ext_form_url  varchar2(4000);
    v_creator       varchar2(400);
    v_creator_name  varchar2(400);
    /*    v_task_number  varchar2(30);
    v_task_title   varchar2(400);
    v_process_name varchar2(400);
    v_process_code varchar2(30);*/
    v_search_content varchar2(4000);
    v_platform       varchar2(10);
    v_current_user   varchar2(100);
    v_page           number;
    v_size           number;
    v_field_name     varchar2(100);
    v_row_count      number := 0;
    --排序参数
    v_sort_col varchar2(100);
    v_sort     json;
    --定义关联查询游标
    cursor v_task_partake_v_cur is
      select *
        from (select v.*, rownum cnt
                from (select --count(1) over(partition by 1) total,
                       v1.task_id,
                       v1.document_id,
                       v1.form_id,
                       v1.process_id,
                       v1.task_number,
                       v1.title,
                       v1.status,
                       dbpm_comm_pkg.get_datasource_value_name('DbpmProcessStatus',
                                                               v1.status) as status_meaning,
                       v1.process_name,
                       v1.process_code,
                       dpt.type_name process_type,
                       dpt.display_color process_type_color,
                       v1.created_user_name,
                       v1.created_user_code,
                       v1.creation_date,
                       v1.approve_user_name,
                       v1.approve_user_code,
                       v1.process_class,
                       v1.doc_sys_code,

                       v1.doc_url,
                       v1.state,
                       v1.bpm_instance_id,
                       v1.register_process_code,
                       v1.enddate,
                       (select nvl(md.mobile_url, 'Y')
                          from cux_process_mob_data md
                         where md.document_number = v1.bpm_instance_id) is_has_mob_data
                        from (select his.taskid task_id,
                                     his.protectedtextattribute1 document_id,
                                     dd.form_id,
                                     dd.process_id,
                                     nvl(dd.doc_number,
                                         'INSTANCE-' || his.instanceid) task_number,
                                     his.title title,
                                     nvl(dd.status, 'PROCESSING') status,
                                     dd.process_name,
                                     dd.process_code,
                                     dd.process_type,
                                     ci.creation_date + 0 creation_date,
                                     dd.doc_creator created_user_code,

                                     (select de.english_name
                                        from dfnd_employees de
                                       where de.employee_code = dd.doc_creator) created_user_name,
                                     his.approvers par_user_code,
                                     null /*(select listagg(ass.assignee, ',') within group(order by ass.assignee) approver_code
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      from wftask wf, wfassignee ass
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     where wf.state in ('ASSIGNED', 'INFO_REQUESTED')
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       and ass.taskid = wf.taskid
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       and wf.instanceid = his.instanceid)*/ approve_user_code,
                                     null /*(select listagg(e.employee_name, ',') within group(order by ass.assignee) approver_code
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      from wftask wf, wfassignee ass, dfnd_employees e
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     where wf.state in ('ASSIGNED', 'INFO_REQUESTED')
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       and ass.taskid = wf.taskid
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       and wf.taskid = his.taskid
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       and upper(ass.assignee) = upper(e.employee_code)) */ approve_user_name,
                                     dbpm_comm_pkg.func_get_task_url(p_domain_url  => his.protectedtextattribute5,
                                                                     p_instance_id => his.instanceid,
                                                                     p_form_key    => his.protectedtextattribute7,
                                                                     p_task_id     => his.taskid,
                                                                     p_params      => his.protectedtextattribute6,
                                                                     p_sys_code    => his.protectedtextattribute2) doc_url,
                                     -- nvl(dd.doc_sys_code, '---')
                                     (select dd.doc_sys_code
                                        from dbpm_documents dd
                                       where dd.document_id =
                                             his.protectedtextattribute1) doc_sys_code,
                                     dd.process_class,
                                     nvl(dd.todo_flag, 'BOTH') todo_flag,
                                     ci.state,
                                     ci.domain_name || '/' ||
                                     ci.composite_name || '/' ||
                                     ci.component_name register_process_code,
                                     his.instanceid bpm_instance_id,
                                     his.enddate
                                from wftask his,
                                     cube_instance ci,
                                     (select d.process_form_id form_id,
                                             -- d.process_number document_id,
                                             d.process_number doc_number,
                                             d.instance_id bpm_instance_id,
                                             dp.process_id,
                                             dpt.process_name,
                                             dp.process_code,
                                             dp.process_type,
                                             dp.process_class process_class,
                                             dp.todo_flag todo_flag,
                                             '' doc_sys_code,
                                             --  d.title,
                                             d.instance_creator doc_creator,
                                             d.instance_creator doc_creator_name,
                                             -- d.doc_create_time,
                                             d.instance_status status,
                                             '' doc_url
                                        from cux_bpm_all_instance d,
                                             dbpm_process         dp,
                                             dbpm_process_tl      dpt
                                       where dp.process_id = dpt.process_id
                                         and dpt.locale =
                                             dbpm_comm_pkg.get_current_locale
                                         and d.process_code =
                                             dp.process_code(+)) dd,
                                     dbpm_process_registry dr
                               where his.instanceid = ci.cikey
                                 and ci.cikey = dd.bpm_instance_id(+)
                                 and his.state is null
                                 and his.workflowpattern = 'Participant'
                                 and his.processid = dr.processname
                                 and his.updatedby = lower(v_current_user)
                              union all
                              select ct.df_task_id task_id,
                                     null document_id,
                                     null form_id,
                                     ct.process_id process_id,
                                     decode(ct.document_number,
                                            ct.parent_document_number,
                                            ct.document_number,
                                            ct.parent_document_number || '/' ||
                                            ct.document_number) task_number,
                                     ct.title title,
                                     ct.state status,
                                     ct.process_name,
                                     ct.process_code,
                                     '-' process_type,
                                     ct.createddate creation_date,
                                     ct.creator created_user_code,
                                     (select e.employee_name
                                        from dfnd_employees e
                                       where upper(e.employee_code) =
                                             upper(ct.creator)) created_user_name,
                                     ct.approvers par_user_code,
                                     null approve_user_code,
                                     null approve_user_name,
                                     ct.url doc_url,
                                     'OTHERS' doc_sys_code,
                                     'OTHERS' process_class,
                                     ct.todo_flag,
                                     null state,
                                     null register_process_code,
                                     null bpm_instance_id,
                                     ct.approve_date enddate
                                from cux_process_todo ct
                               where ct.state in ('PROCESSED')
                                 and upper(ct.approvers) =
                                     upper(v_current_user)) v1,
                             dbpm_process_types dpt
                       where dpt.type_code(+) = v1.process_type
                         and v1.todo_flag in ('BOTH', v_platform)
                         and (nvl(v1.task_number, 'NL') like
                              '%' || v_search_content || '%' or
                              nvl(v1.title, 'NL') like
                              '%' || v_search_content || '%' or
                              nvl(v1.process_name, 'NL') like
                              '%' || v_search_content || '%' or
                              instr(nvl(dpt.type_name, 'NL'),
                                    nvl(v_search_content,
                                        nvl(dpt.type_name, 'NL'))) > 0 or
                              instr(nvl(v1.approve_user_name, 'NL'),
                                    nvl(v_search_content,
                                        nvl(v1.approve_user_name, 'NL'))) > 0 or
                              instr(nvl(v1.created_user_name, 'NL'),
                                    nvl(v_search_content,
                                        nvl(v1.created_user_name, 'NL'))) > 0)
                       order by decode(v_sort_col,
                                       'task_number_desc',
                                       nvl(v1.task_number, '-'),
                                       'title_desc',
                                       v1.title,
                                       'process_type_desc',
                                       dpt.type_name,
                                       'approve_user_name_desc',
                                       v1.approve_user_name,
                                       'approveDate_desc',
                                       to_char(v1.enddate,
                                               'yyyy-mm-dd hh24:mi:ss')) desc) v
               where rownum <= v_page * v_size)
       where cnt > (v_page - 1) * v_size;

    v_task_partake_v_row v_task_partake_v_cur%rowtype;
  begin
    --解析字段
    v_request        := json(p_request, 'OBJECT');
    v_platform       := nvl(v_request.get_string('platform'), 'WEB');
    v_current_user   := v_request.username;
    v_page           := nvl(v_request.get('page').get_number, 1);
    v_size           := nvl(v_request.get('size').get_number, 20);
    v_search_content := dcld_comm_pkg.get_filter_value('all', v_request);
    if v_request.exist('sort') then
      v_sort     := json(v_request.get('sort'));
      v_sort_col := v_sort.get_string('value');
      v_sort_col := v_sort_col || '_' || v_sort.get_string('order');
    end if;

    --查询行数
    select count(1) total
      into v_row_count
      from (select his.taskid task_id,
                   dd.document_id,
                   dd.form_id,
                   dd.process_id,
                   nvl(dd.doc_number, 'INSTANCE-' || his.instanceid) task_number,
                   nvl(dd.title, his.title) title,
                   nvl(dd.status, 'PROCESSING') status,
                   dd.process_name,
                   dd.process_code,
                   dd.process_type,
                   nvl(dd.creation_date, ci.creation_date + 0) creation_date,
                   dd.doc_creator created_user_code,
                   dd.doc_creator_name created_user_name,
                   his.approvers par_user_code,
                   null approve_user_code,
                   null approve_user_name,
                   dd.doc_url,
                   nvl(dd.doc_sys_code, '---') doc_sys_code,
                   nvl(dd.process_class, 'EXTERNAL') process_class,
                   nvl(dd.todo_flag, 'BOTH') todo_flag,
                   ci.state,
                   ci.domain_name || '/' || ci.composite_name || '/' ||
                   ci.component_name register_process_code,
                   his.instanceid bpm_instance_id,
                   his.enddate
              from wftask his,
                   cube_instance ci,
                   (select form_id,
                           document_id,
                           doc_number,
                           bpm_instance_id,
                           dp.process_id,
                           dpt.process_name,
                           dp.process_code,
                           dp.process_type,
                           dp.process_class   process_class,
                           dp.todo_flag       todo_flag,
                           d.doc_sys_code     doc_sys_code,
                           d.title,
                           d.doc_creator,
                           d.doc_creator_name,
                           d.doc_create_time,
                           d.status,
                           d.doc_url          doc_url,
                           d.creation_date
                      from dbpm_documents  d,
                           dbpm_process    dp,
                           dbpm_process_tl dpt
                     where dp.process_id = dpt.process_id
                       and dpt.locale = dbpm_comm_pkg.get_current_locale
                       and d.process_id = dp.process_id(+)) dd
             where his.instanceid = ci.cikey
               and ci.cikey = dd.bpm_instance_id(+)
               and his.state is null
               and his.workflowpattern = 'Participant'
               and his.compositedn in
                   (select p.compositedn
                      from dbpm_process_registry re, bpm_cube_process p
                     where re.domainname = p.domainname
                       and re.processname = p.processname
                       and re.compositename = p.compositename
                       and re.process_model_type in ('BPM', 'OBPM')
                       and re.enabled_flag = 'Y')
               and his.updatedby = lower(v_current_user)
            union all
            select ct.df_task_id task_id,
                   null document_id,
                   null form_id,
                   ct.process_id process_id,
                   decode(ct.document_number,
                          ct.parent_document_number,
                          ct.document_number,
                          ct.parent_document_number || '/' ||
                          ct.document_number) task_number,
                   ct.title title,
                   ct.state status,
                   ct.process_name,
                   ct.process_code,
                   '-' process_type,
                   ct.createddate creation_date,
                   ct.creator created_user_code,
                   (select e.employee_name
                      from dfnd_employees e
                     where upper(e.employee_code) = upper(ct.creator)) created_user_name,
                   ct.approvers par_user_code,
                   null approve_user_code,
                   null approve_user_name,
                   ct.url doc_url,
                   'OTHERS' doc_sys_code,
                   'OTHERS' process_class,
                   ct.todo_flag,
                   null state,
                   null register_process_code,
                   null bpm_instance_id,
                   ct.approve_date enddate
              from cux_process_todo ct
             where ct.state in ('PROCESSED')
               and upper(ct.approvers) = upper(v_current_user)) v1,
           dbpm_process_types dpt
     where dpt.type_code(+) = v1.process_type
       and v1.todo_flag in ('BOTH', v_platform)
       and (nvl(v1.task_number, 'NL') like '%' || v_search_content || '%' or
            nvl(v1.title, 'NL') like '%' || v_search_content || '%' or
            nvl(v1.process_name, 'NL') like '%' || v_search_content || '%' or
            instr(nvl(dpt.type_name, 'NL'),
                  nvl(v_search_content, nvl(dpt.type_name, 'NL'))) > 0 or
            instr(nvl(v1.approve_user_name, 'NL'),
                  nvl(v_search_content, nvl(v1.approve_user_name, 'NL'))) > 0 or
            instr(nvl(v1.created_user_name, 'NL'),
                  nvl(v_search_content, nvl(v1.created_user_name, 'NL'))) > 0);

    --查询行
    for v_task_partake_v_row in v_task_partake_v_cur loop
      --v_row_count := v_task_partake_v_row.total;
      --每次循环前使URL值为空 updateby  han.wu  2019.7.10
      v_ext_form_url := null;
      v_line := pl_json;
      v_line.set_value('taskId', v_task_partake_v_row.task_id);
      v_line.set_value('documentId', v_task_partake_v_row.document_id);
      v_line.set_value('formId', v_task_partake_v_row.form_id);
      if v_task_partake_v_row.document_id is null and
         v_task_partake_v_row.process_class = 'EXTERNAL' then
        begin
          --- 修改查找流程类型的逻辑 updateby xiaowei.yao 2018-08-29
          select nvl(dpt.process_name, dp.process_name),
                 pt.type_name,
                 pt.display_color,
                 dp.form_url
            into v_process_name,
                 v_process_type,
                 v_process_color,
                 v_base_form_url
            from dbpm_process          dp,
                 dbpm_process_tl       dpt,
                 dbpm_process_types    pt,
                 dbpm_process_registry dr
           where dp.process_id = dpt.process_id(+)
             and dp.process_type = pt.type_code(+)
             and dr.process_code = dp.process_code
             and dr.compositerdn =
                 v_task_partake_v_row.register_process_code;
          v_ext_form_url := dbpm_comm_pkg.func_get_task_url(v_base_form_url,
                                                            v_task_partake_v_row.bpm_instance_id,
                                                            null,
                                                            v_task_partake_v_row.task_id,
                                                            null,
                                                            null);

        exception
          when others then
            v_process_name := null;
        end;
        v_line.set_value('processId', v_process_id);
        v_line.set_value('process_name', v_process_name);
        v_line.set_value('process_code',
                         v_task_partake_v_row.register_process_code);
        v_line.set_value('process_type', v_process_type);
        v_line.set_value('process_type_color', v_process_color);
      else
        v_line.set_value('processId', v_task_partake_v_row.process_id);
        v_line.set_value('process_name', v_task_partake_v_row.process_name);
        v_line.set_value('process_code', v_task_partake_v_row.process_code);
        v_line.set_value('process_type', v_task_partake_v_row.process_type);
        v_line.set_value('process_type_color',
                         v_task_partake_v_row.process_type_color);
      end if;

      v_line.set_value('task_number', v_task_partake_v_row.task_number);
      v_line.set_value('title', v_task_partake_v_row.title);
      /*      v_line.set_value('status', v_task_partake_v_row.status);
      v_line.set_value('status_meaning',
                       v_task_partake_v_row.status_meaning);*/
      if v_task_partake_v_row.process_class = 'EXTERNAL' then
        if v_task_partake_v_row.state = 1 then
          v_line.set_value('status', 'PROCESSING');
          v_line.set_value('status_meaning',
                           dcld_comm_pkg.get_lookup_meaning('CUBE_INSTANCE_STATE',
                                                            to_char(v_task_partake_v_row.state),
                                                            v_request.locale));
        elsif v_task_partake_v_row.state = 5 then
          v_line.set_value('status', 'COMPLETED');
          v_line.set_value('status_meaning',
                           dcld_comm_pkg.get_lookup_meaning('CUBE_INSTANCE_STATE',
                                                            to_char(v_task_partake_v_row.state),
                                                            v_request.locale));
        else
          v_line.set_value('status', 'PROCESSING');
          v_line.set_value('status_meaning',
                           dcld_comm_pkg.get_lookup_meaning('CUBE_INSTANCE_STATE',
                                                            to_char(v_task_partake_v_row.state),
                                                            v_request.locale));
        end if;
      elsif v_task_partake_v_row.process_class = 'OTHERS' then
        v_line.set_value('status', 'COMPLETED');
        v_line.set_value('status_meaning',
                         v_task_partake_v_row.status_meaning);
      else
        v_line.set_value('status', v_task_partake_v_row.status);
        v_line.set_value('status_meaning',
                         v_task_partake_v_row.status_meaning);
      end if;

      if v_task_partake_v_row.created_user_code is null then
        begin
          select upper(t.creator),
                 (select e.employee_name
                    from dfnd_employees e
                   where e.employee_code = upper(t.creator)
                     and rownum = 1)
            into v_creator, v_creator_name
            from wftask t
           where t.instanceid = v_task_partake_v_row.bpm_instance_id
             and t.creator is not null
             and rownum = 1;
        exception
          when others then
            null;
        end;
        v_line.set_value('created_user_code', v_creator);
        v_line.set_value('created_user_name', v_creator_name);
      else
        v_line.set_value('created_user_code',
                         v_task_partake_v_row.created_user_code);
        v_line.set_value('created_user_name',
                         v_task_partake_v_row.created_user_name);
      end if;

      v_line.set_value('creation_date',
                       to_char(v_task_partake_v_row.creation_date,
                               'YYYY-MM-DD HH24:MI'));
      v_line.set_value('approve_user_name',
                       v_task_partake_v_row.approve_user_name);
      v_line.set_value('approve_user_code',
                       v_task_partake_v_row.approve_user_code);
      v_line.set_value('approveDate', v_task_partake_v_row.enddate);
      v_line.set_value('instanceId', v_task_partake_v_row.bpm_instance_id);
      --设置流程执行天数
      v_line.set_value('instanceLiveDay',
                       dbpm_comm_pkg.func_instance_live_day(v_task_partake_v_row.bpm_instance_id));
      --得云统一工作台begin
      v_line.set_value('processClass',
                       nvl(v_task_partake_v_row.process_class, 'INTERNAL'));

      --设置docsyccode
      if v_platform = 'WEB' then
        if v_task_partake_v_row.doc_sys_code in ('BPM', 'BPM_EXT') then
          v_line.set_value('docSysCode', v_task_partake_v_row.doc_sys_code);
        else
          v_line.set_value('docSysCode', 'OTHERS');
        end if;
      else
        if v_task_partake_v_row.doc_sys_code in ('BPM', 'BPM_EXT') then
          v_line.set_value('docSysCode', v_task_partake_v_row.doc_sys_code);
        else
          --如果是移动端，并且有传入移动端展示数据
          if v_task_partake_v_row.is_has_mob_data = 'Y' then
            v_line.set_value('docSysCode', 'CONFIG');
          else
            v_line.set_value('docSysCode', 'OTHERS');
          end if;
        end if;
      end if;

      if v_ext_form_url is null then
        v_ext_form_url := v_task_partake_v_row.doc_url;
      end if;

      v_line.set_value('externalFormUrl', v_ext_form_url);
      --得云统一工作台end
      v_response.add_list_item('list', v_line);
    end loop;
    v_response.set_value('total', v_row_count);
    x_response := v_response.to_json;
    /*exception
    when others then
      rollback;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || sqlerrm);
      x_response := v_response.to_json;*/
  end;
  /*==================================================
  procedure name :
      proc_task_schedule_query
  description:
      查询我的待办
  argument:
      p_request：  请求（json）
      x_response： 响应（json）
  history:
      1.00  2016-12-04  曾勇 creation
  ==================================================*/
  procedure proc_task_todo_query(p_request in clob, x_response out clob) is
    v_api             varchar2(30) := 'proc_task_todo_query';
    v_request         json;
    v_response        pl_json := pl_json;
    v_line            pl_json;
    v_process_name    varchar2(4000);
    v_process_type    varchar2(300);
    v_process_id      number;
    v_process_color   varchar2(300);
    v_search_content  varchar2(4000);
    v_page            number;
    v_size            number;
    v_total           number := 0;
    v_current_user    varchar2(100);
    v_platform        varchar2(10);
    v_taskliveday     number;
    v_create_username varchar2(100);
    v_create_usercode varchar2(100);
    --排序参数
    v_sort_col varchar2(100);
    v_sort     json;

    --定义关联查询游标
    cursor v_task_todo_v_cur is
      select *
        from (select v.*, rownum cnt
                from (select count(1) over(partition by 1) total,
                             v1.task_id,
                             v1.document_id,
                             v1.form_id,
                             v1.process_id,
                             v1.node_name,
                             v1.node_id,
                             v1.task_number,
                             v1.title,
                             v1.status,
                             dcld_comm_pkg.get_data_source_value('DbpmProcessStatus',
                                                                 v1.status,
                                                                 v_request.locale) status_meaning,
                             v1.state,
                             v1.process_name,
                             v1.process_code,
                             dpt.type_name process_type,
                             dpt.display_color process_type_color,
                             v1.creation_date,
                             v1.assigne_date,
                             v1.created_user_name,
                             v1.created_user_code,
                             v1.is_readed,
                             v1.process_class,
                             (select d.doc_sys_code
                                from dbpm_documents d
                               where to_char(d.document_id) = v1.document_id) doc_sys_code,
                             v1.url,
                             v1.instance_id,
                             v1.mobile_url,
                             v1.process_create_time,
                             v1.register_process_code,
                             (select nvl(md.mobile_url, 'Y')
                                from cux_process_mob_data md
                               where md.document_number = v1.instance_id) is_has_mob_data
                        from (select task.taskid task_id,
                                     task.protectedtextattribute1 document_id,
                                     null form_id,
                                     task.protectedtextattribute7 task_number,
                                     task.title title,
                                     'PROCESSING' status,
                                     task.state,
                                     task.createddate + 0 creation_date,
                                     task.assigneddate assigne_date,
                                     task.creator created_user_code,
                                     (select fe1.employee_name
                                        from dfnd_employees fe1
                                       where upper(fe1.employee_code) =
                                             upper(task.creator)) created_user_name,
                                     task.protectedformattribute1 node_name,
                                     task.protectednumberattribute1 node_id,
                                     task.instanceid instance_id,
                                     task.compositecreatedtime process_create_time,
                                     t.process_code register_process_code,
                                     dbpm_comm_pkg.func_get_task_url(p_domain_url  => task.protectedtextattribute5,
                                                                     p_instance_id => task.instanceid,
                                                                     p_form_key    => task.protectedtextattribute7,
                                                                     p_task_id     => task.taskid,
                                                                     p_params      => task.protectedtextattribute6,
                                                                     p_sys_code    => task.protectedtextattribute2) url,
                                     '' mobile_url,
                                     'N' is_readed,
                                     dp.process_id process_id,
                                     dp.process_name process_name,
                                     task.protectedformattribute3 process_code,
                                     dp.process_type process_type,
                                     dp.process_class process_class,
                                     nvl(dp.todo_flag, 'BOTH') todo_flag
                                from wftask task,
                                     wfassignee ass, -- 修改查询待办的逻辑
                                     dbpm_process_registry t,
                                     (select proces_t.process_code,
                                             dpt.process_name,
                                             proces_t.process_type,
                                             proces_t.process_id,
                                             proces_t.process_class,
                                             proces_t.todo_flag
                                        from dbpm_process    proces_t,
                                             dbpm_process_tl dpt
                                       where proces_t.process_id =
                                             dpt.process_id
                                         and dpt.locale =
                                             dbpm_comm_pkg.get_current_locale) dp
                               where task.taskid = ass.taskid
                                 and ass.assigneetype = 'user'
                                 and task.state = 'ASSIGNED'
                                    -- in('ASSIGNED', 'INFO_REQUESTED')
                                 and task.processid = t.processname
                                 and ass.assignee = v_current_user
                                 and task.protectedformattribute3 =
                                     dp.process_code(+)
                              -- and task.protectedformattribute3 is not null--上生产的时候删除该句
                              union all
                              select t.df_task_id task_id,
                                     null document_id,
                                     null form_id,
                                     t.document_number task_number,
                                     t.title,
                                     'PROCESSING' status,
                                     t.state,
                                     t.createddate creation_date,
                                     t.assigneddate assigne_date,
                                     t.creator created_user_code,
                                     fe2.employee_name created_user_name,
                                     null node_name,
                                     null node_id,
                                     t.document_number instance_id,
                                     t.createddate process_create_time,
                                     null register_process_code,
                                     t.url,
                                     t.mobile_url,
                                     'N' is_readed,
                                     t.process_id,
                                     t.process_name,
                                     null process_code,
                                     '第三方流程' process_type,
                                     'OTHERS' process_class,
                                     t.todo_flag todo_flag
                                from cux_process_todo t, dfnd_employees fe2
                               where upper(t.creator) =
                                     upper(fe2.employee_code)
                                 and t.state = 'PROCESSING'
                                 and upper(t.assignee) = upper(v_current_user)) v1,
                             dbpm_process_types dpt
                       where dpt.type_code(+) = v1.process_type
                         and (nvl(v1.task_number, 'NL') like
                              '%' || v_search_content || '%' or
                              nvl(v1.title, 'NL') like
                              '%' || v_search_content || '%' or
                              nvl(v1.process_name, 'NL') like
                              '%' || v_search_content || '%' or
                              instr(nvl(dpt.type_name, 'NL'),
                                    nvl(v_search_content,
                                        nvl(dpt.type_name, 'NL'))) > 0 or
                              instr(nvl(v1.created_user_name, 'NL'),
                                    nvl(v_search_content,
                                        nvl(v1.created_user_name, 'NL'))) > 0)
                         and v1.todo_flag in ('BOTH', v_platform)
                       order by decode(v_sort_col,
                                       'task_number_desc',
                                       nvl(v1.task_number, '-'),
                                       'title_desc',
                                       v1.title,
                                       'process_type_desc',
                                       dpt.type_name,
                                       'created_user_name_desc',
                                       v1.created_user_name,
                                       'process_name_desc',
                                       v1.process_name,
                                       'creation_date_desc',
                                       to_char(v1.creation_date,
                                               'yyyy-mm-dd hh24:mi:ss')) desc,
                                decode(v_sort_col,
                                       'task_number_asc',
                                       nvl(v1.task_number, '-'),
                                       'title_asc',
                                       v1.title,
                                       'process_type_asc',
                                       dpt.type_name,
                                       'created_user_name_asc',
                                       v1.created_user_name,
                                       'process_name_asc',
                                       v1.process_name,
                                       'creation_date_asc',
                                       to_char(v1.creation_date,
                                               'yyyy-mm-dd hh24:mi:ss')) asc) v
               where rownum <= v_page * v_size)
       where cnt > (v_page - 1) * v_size;
  begin
    --解析字段
    v_request        := json(p_request, 'OBJECT');
    v_current_user   := lower(v_request.username);
    v_platform       := nvl(v_request.get_string('platform'), 'WEB');
    v_page           := nvl(v_request.get('page').get_number, 1);
    v_size           := nvl(v_request.get('size').get_number, 20);
    v_search_content := dcld_comm_pkg.get_filter_value('all', v_request);
    if v_request.exist('sort') then
      v_sort     := json(v_request.get('sort'));
      v_sort_col := v_sort.get_string('value');
      v_sort_col := v_sort_col || '_' || v_sort.get_string('order');
    end if;

    --查询行
    for v_task_todo_row in v_task_todo_v_cur loop
      v_line  := pl_json;
      v_total := v_task_todo_row.total;
      v_line.set_value('taskId', v_task_todo_row.task_id);
      v_line.set_value('documentId', v_task_todo_row.document_id);
      v_line.set_value('formId', v_task_todo_row.form_id);
      v_line.set_value('nodeName', v_task_todo_row.node_name);
      v_line.set_value('nodeId', v_task_todo_row.node_id);
      v_line.set_value('task_number', v_task_todo_row.task_number);
      v_line.set_value('title', v_task_todo_row.title);
      v_line.set_value('status', v_task_todo_row.status);
      v_line.set_value('status_meaning', v_task_todo_row.status_meaning);
      v_line.set_value('state', v_task_todo_row.state);
      v_line.set_value('is_read', v_task_todo_row.is_readed);

      if v_task_todo_row.document_id is null and
         v_task_todo_row.process_class is null then
        begin
          select nvl(dpt.process_name, dp.process_name),
                 pt.type_name,
                 pt.display_color
            into v_process_name, v_process_type, v_process_color
            from dbpm_process       dp,
                 dbpm_process_tl    dpt,
                 dbpm_process_types pt
           where dp.process_id = dpt.process_id(+)
             and dp.process_type = pt.type_code(+)
             and dp.process_code = v_task_todo_row.register_process_code;

        exception
          when others then
            v_process_name := null;
        end;
        begin
          select t.instance_creator, nvl(de.full_name, t.instance_creator)
            into v_create_usercode, v_create_username
            from cux_bpm_all_instance t, dfnd_employees de
           where t.instance_id = v_task_todo_row.instance_id
             and lower(de.employee_code) = lower(t.instance_creator);
        exception
          when others then
            v_create_username := v_task_todo_row.instance_id;
        end;
        v_line.set_value('processId', v_process_id);
        v_line.set_value('process_name', v_process_name);
        v_line.set_value('process_code',
                         v_task_todo_row.register_process_code);
        v_line.set_value('process_type', v_process_type);
        v_line.set_value('process_type_color', v_process_color);
        v_line.set_value('created_user_name', v_create_username);
        v_line.set_value('created_user_code', v_create_usercode);
      else
        v_line.set_value('processId', v_task_todo_row.process_id);
        v_line.set_value('process_name', v_task_todo_row.process_name);
        v_line.set_value('process_code', v_task_todo_row.process_code);
        v_line.set_value('process_type', v_task_todo_row.process_type);
        v_line.set_value('process_type_color',
                         v_task_todo_row.process_type_color);
        v_line.set_value('created_user_name',
                         v_task_todo_row.created_user_name);
        v_line.set_value('created_user_code',
                         v_task_todo_row.created_user_code);
      end if;

      v_line.set_value('creation_date',
                       to_char(v_task_todo_row.creation_date,
                               'YYYY-MM-DD HH24:MI'));
      v_line.set_value('assigne_date',
                       to_char(v_task_todo_row.assigne_date,
                               'YYYY-MM-DD HH24:MI'));
      --设置待办停留天数
      v_taskliveday := round(sysdate - v_task_todo_row.assigne_date);
      if v_taskliveday = 0 then
        v_taskliveday := 0.5;
      end if;
      v_line.set_value('taskLiveDay', v_taskliveday);
      --设置流程执行天数
      if v_task_todo_row.process_class = 'OTHERS' then
        v_line.set_value('instanceLiveDay',
                         round(sysdate - v_task_todo_row.creation_date));
      else
        v_line.set_value('instanceLiveDay',
                         dbpm_comm_pkg.func_instance_live_day(v_task_todo_row.instance_id));
      end if;

      --得云统一工作台
      v_line.set_value('instanceId', v_task_todo_row.instance_id);
      v_line.set_value('processClass',
                       nvl(v_task_todo_row.process_class, 'EXTERNAL'));

      --设置docsyccode
      if v_platform = 'WEB' then
        if v_task_todo_row.doc_sys_code in ('BPM', 'BPM_EXT') then
          v_line.set_value('docSysCode', v_task_todo_row.doc_sys_code);
        else
          v_line.set_value('docSysCode', 'OTHERS');
        end if;
      else
        if v_task_todo_row.doc_sys_code in ('BPM', 'BPM_EXT') then
          v_line.set_value('docSysCode', v_task_todo_row.doc_sys_code);
        else
          --如果是移动端，并且有传入移动端展示数据
          if v_task_todo_row.is_has_mob_data = 'Y' then
            v_line.set_value('docSysCode', 'CONFIG');
          else
            v_line.set_value('docSysCode', 'OTHERS');
          end if;
        end if;
      end if;
      /*v_line.set_value('mobileUrl',
      nvl(v_task_todo_row.mobile_url, v_task_todo_row.url));*/
      v_line.set_value('externalFormUrl', v_task_todo_row.url);
      --添加得云链接
      v_line.set_value('BPMUrl',
                       dcld_comm_pkg.func_get_BPM_url || '&' ||
                       'taskId=' || v_task_todo_row.task_id);
      v_response.add_list_item('list', v_line);
    end loop;
    --v_total := func_get_todo_count(v_current_user);
    v_response.set_value('total', v_total);
    x_response := v_response.to_json;
  end;

  /*==================================================
  procedure/function name :
      proc_query_top_process
  description:
      this function perform:
      业务申请-查询常用流程
  argument:
     p_request： 请求参数
     x_response： 响应结果
  history:
      1.00  2017-04-06  skycloud.wang  creation
      暂停使用，类似功能参考proc_query_business_apply
  ==================================================*/
  procedure proc_query_top_process(p_request in clob, x_response out clob) is
    v_request      json;
    v_response     pl_json := pl_json;
    v_current_user varchar2(100);
    --v_company_id number;
    cursor v_top_process_cur is
      select process_id, process_code, process_name, use_count
        from (select dp.process_id,
                     dp.process_code,
                     dp.process_name,
                     v.use_count
                from dbpm_process dp,
                     (select count(1) use_count, t.process_id
                        from dbpm_documents t
                       where upper(t.doc_creator) = upper(v_current_user)
                         and t.status <> 'NEW'
                       group by t.process_id) v
               where dp.process_id = v.process_id(+)
                 and dp.enabled_flag = 'Y'
                 and dp.process_type != 'AM'
               order by nvl(v.use_count, 0) desc, process_id desc)
       where rownum <= 8;
    v_line    pl_json;
    v_form_id number;
    v_total   number := 0;

  begin
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;
    --获取二级公司
    --v_company_id := cux_comm_pkg.func_get_company_id(v_request.username);
    -- 根据单据数量获取常用流程， todo
    -- 根据人或者组织获取常用流程， todo
    for v_top_process in v_top_process_cur loop
      v_total := v_total + 1;
      v_line  := pl_json;
      v_line.set_value('processId', v_top_process.process_id);
      v_line.set_value('processCode', v_top_process.process_code);
      v_line.set_value('processName', v_top_process.process_name);
      v_form_id := dbpm_comm_pkg.func_get_process_form(p_process_id => v_top_process.process_id);
      v_line.set_value('formId', v_form_id);
      v_response.add_list_item('processList', v_line);
    end loop;

    v_response.set_value('total', v_total);
    x_response := v_response.to_json;
  end proc_query_top_process;

  /*==================================================
  procedure/function name :
      proc_query_all_process
  description:
      this function perform:
      业务申请-查询所有流程
  argument:
     p_request： 请求参数
     x_response： 响应结果
  history:
      1.00  2017-04-06  skycloud.wang  creation
  ==================================================*/
  procedure proc_query_all_process(p_request in clob, x_response out clob) is
    v_request         json;
    v_response        pl_json := pl_json;
    v_process_name    varchar2(200);
    v_total           number := 0;
    v_size            number := 200;
    v_page            number := 1;
    v_isbusinessapply varchar2(10);
    v_space_id        varchar2(100);

    v_current_user      varchar2(30);
    v_is_shared         varchar2(10);
    v_super_admin_count number;
    v_search_content    varchar2(4000);
    v_filter            json;

    --授权管理功能查询流程
    /* cursor v_business_process_cur is
    select *
      from (select v.*, rownum cnt
              from (select count(1) over(partition by 1) total,
                           dp.process_id,
                           dp.process_code,
                           dp.process_name
                      from dbpm_process dp, dbpm_form df
                     where dp.process_id = df.process_id(+)
                       and df.status = 'Published'
                       and dp.enabled_flag = 'Y'
                       and dp.process_type != 'AM'
                       and (instr(nvl(dp.process_name, 'NL'),
                                  nvl(v_search_content,
                                      nvl(dp.process_name, 'NL'))) > 0 or
                           instr(nvl(dp.process_code, 'NL'),
                                  nvl(v_search_content,
                                      nvl(dp.process_code, 'NL'))) > 0)
                    --and dp.space_id = v_business_company_id
                     order by dp.process_id desc) v
             where rownum <= v_page * v_size)
     where cnt > (v_page - 1) * v_size;*/
    --授权管理功能查询流程 --update by xiaowei.yao 2019-02-25
    cursor v_business_process_cur is
      select *
        from (select v.*,
                     rownum cnt,
                     (select e.employee_name
                        from dfnd_employees e
                       where e.employee_code = upper(v.process_owner)) process_owner_name
                from (select count(1) over(partition by 1) total,
                             dp.process_id,
                             dp.process_code,
                             dp.process_name,
                             dp.process_owner,
                             dp.process_class
                        from dbpm_process dp
                       where (instr(nvl(dp.process_name, 'NL'),
                                    nvl(v_search_content,
                                        nvl(dp.process_name, 'NL'))) > 0 or
                             instr(nvl(dp.process_code, 'NL'),
                                    nvl(v_search_content,
                                        nvl(dp.process_code, 'NL'))) > 0)
                       order by dp.process_id desc) v
               where rownum <= v_page * v_size);

    --流程管理功能的查询
    cursor v_process_cur is
      select *
        from (select v.*,
                     rownum cnt,
                     (select e.employee_name
                        from dfnd_employees e
                       where e.employee_code = upper(v.process_owner)) process_owner_name
                from (select count(1) over(partition by 1) total,
                             dp.process_id,
                             dp.process_code,
                             dp.process_name,
                             dp.process_owner,
                             dp.process_class
                        from dbpm_process dp
                       where nvl(dp.space_id, 'NL') =
                             nvl(v_space_id, nvl(dp.space_id, 'NL'))
                            /*and instr(nvl(dp.process_name, 'NL'),
                            nvl(v_process_name,
                                nvl(dp.process_name, 'NL'))) > 0*/
                         and (instr(nvl(dp.process_name, 'NL'),
                                    nvl(v_search_content,
                                        nvl(dp.process_name, 'NL'))) > 0 or
                              instr(nvl(dp.process_code, 'NL'),
                                    nvl(v_search_content,
                                        nvl(dp.process_code, 'NL'))) > 0)
                       order by dp.process_id desc) v
               where rownum <= v_page * v_size)
       where cnt > (v_page - 1) * v_size;
    --where v_process_name is null
    --   or dp.process_name like '%' || v_process_name || '%';
    v_line    pl_json;
    v_form_id number;

  begin
    v_request         := json(p_request, 'OBJECT');
    v_current_user    := v_request.username;
    v_process_name    := dcld_comm_pkg.get_filter_value('processName',
                                                        v_request);
    v_isbusinessapply := v_request.get_string('isBusinessApply');

    v_space_id := v_request.get_string('spaceId');
    if v_space_id is null then
      v_space_id := dfnd_admin_pkg.func_get_space_id(v_current_user);
    end if;
    --v_business_company_id := v_space_id;
    --如果未找到company_id,设置company_id为-1
    --如果是超级管理员,设置company_id为null
    select count(1)
      into v_super_admin_count
      from dbpm_administrators t
     where t.user_code = v_current_user
       and t.admin_type = 'SuperAdmin';
    if v_space_id is null then
      v_space_id := '-';
    end if;
    /*if v_super_admin_count > 0 then
      v_space_id := null;
    end if;*/

    if v_request.exist('page') then
      v_page := v_request.get_number('page');
    end if;
    if v_request.exist('size') then
      v_size := v_request.get_number('size');
    end if;
    v_search_content := dcld_comm_pkg.get_filter_value('all', v_request);
    -- 根据单据数量获取常用流程， todo
    if v_isbusinessapply = 'Y' then
      for v_process in v_business_process_cur loop
        v_total := v_process.total;
        v_line  := pl_json;
        v_line.set_value('processId', v_process.process_id);
        v_line.set_value('processCode', v_process.process_code);
        v_line.set_value('processName', v_process.process_name);
        v_form_id := dbpm_comm_pkg.func_get_process_form(p_process_id => v_process.process_id);
        v_line.set_value('formId', v_form_id);
        v_response.add_list_item('processList', v_line);
      end loop;
    else
      for v_process in v_process_cur loop
        v_total := v_process.total;
        v_line  := pl_json;
        v_line.set_value('processId', v_process.process_id);
        v_line.set_value('processCode', v_process.process_code);
        v_line.set_value('processName', v_process.process_name);
        v_line.set_value('processOwner', v_process.process_owner);
        v_line.set_value('processOwnerName', v_process.process_owner_name);

        v_line.set_value('processClass', v_process.process_class);
        v_form_id := dbpm_comm_pkg.func_get_process_form(p_process_id => v_process.process_id);
        v_line.set_value('formId', v_form_id);
        v_response.add_list_item('processList', v_line);
      end loop;
    end if;
    v_response.set_value('total', v_total);
    x_response := v_response.to_json;
  end proc_query_all_process;
  /*==================================================
  procedure/function name :
      proc_query_business_apply
  description:
      this function perform:
      业务申请
  argument:
     p_request： 请求参数
     x_response： 响应结果
  history:
      1.00  2018-02-08  jinglun.xu  creation
  ==================================================*/
  procedure proc_query_business_apply(p_request  in clob,
                                      x_response out clob) is
    v_request         json;
    v_response        pl_json := pl_json;
    v_array           pl_json := pl_json;
    v_porcess         pl_json := pl_json;
    v_process_name    varchar2(200);
    v_total           number := 0;
    v_size            number := 200;
    v_page            number := 1;
    v_isbusinessapply varchar2(10);
    v_space_id        varchar2(100);
    --v_business_company_id number;
    v_current_user   varchar2(30);
    v_is_shared      varchar2(10);
    v_search_content varchar2(4000);
    v_line           pl_json;
    v_form_id        number;
    v_process_type   pl_json := pl_json;
    --常用流程
    cursor v_top_process_cur is
      select *
        from (select v.*,
                     t1.use_count,
                     (select e.employee_name
                        from dfnd_employees e
                       where e.employee_code = upper(v.process_owner)) process_owner_name
                from dbpm_business_apply_v v,
                     (select count(1) use_count, t.process_id
                        from dbpm_documents t
                       where t.status <> 'NEW'
                       group by t.process_id) t1
               where upper(v.employee_code) = upper(v_current_user)
                 and v.process_id = t1.process_id(+)
               order by nvl(t1.use_count, 0) desc, v.process_id desc)
       where rownum <= 12;
    --发起流程类型
    cursor v_process_type_cur is
      select distinct v.process_type, pt.type_name
        from dbpm_business_apply_v v, dbpm_process_types pt
       where upper(v.employee_code) = upper(v_current_user)
         and pt.type_code = v.process_type;
    --发起流程
    cursor v_business_apply_cur(p_process_type varchar2) is
      select v.*,
             (select e.employee_name
                from dfnd_employees e
               where e.employee_code = upper(v.process_owner)) process_owner_name
        from dbpm_business_apply_v v
       where upper(v.employee_code) = upper(v_current_user)
         and v.process_type = p_process_type
         and instr(nvl(v.process_name, 'NL'),
                   nvl(v_process_name, nvl(v.process_name, 'NL'))) > 0
       order by v.process_id desc;
  begin
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;
    v_process_name := dcld_comm_pkg.get_filter_value('processName',
                                                     v_request);
    -- 根据单据数量获取常用流程， todo
    v_process_type := pl_json;
    v_process_type.set_value('typeCode', 'topProcess');
    v_process_type.set_value('typeName',
                             dcld_comm_pkg.func_get_sys_msg('topProcess',
                                                            v_request.locale));
    for c_business_apply_cur in v_top_process_cur loop
      v_line := pl_json;
      v_line.set_value('processId', c_business_apply_cur.process_id);
      v_line.set_value('spaceId', c_business_apply_cur.space_id); --add by wlj
      v_line.set_value('processCode', c_business_apply_cur.process_code);
      v_line.set_value('processName', c_business_apply_cur.process_name);
      v_line.set_value('externalFormUrl', c_business_apply_cur.form_url);
      v_line.set_value('docSysCode', c_business_apply_cur.doc_sys_code);
      v_line.set_value('processClass', c_business_apply_cur.process_class);
      v_line.set_value('processOwner', c_business_apply_cur.process_owner);
      v_line.set_value('processOwnerName',
                       c_business_apply_cur.process_owner_name);
      v_form_id := dbpm_comm_pkg.func_get_process_form(p_process_id => c_business_apply_cur.process_id);
      v_line.set_value('formId', v_form_id);
      v_porcess.add_list_item(v_line);
    end loop;
    v_porcess.set_data_type('ARRAY');
    v_process_type.set_value('processList', v_porcess);
    v_array.add_list_item(v_process_type);
    --业务申请接口

    for v_process in v_process_type_cur loop
      v_process_type := pl_json;
      v_porcess      := pl_json;
      v_process_type.set_value('typeCode', v_process.process_type);
      v_process_type.set_value('typeName', v_process.type_name);
      for c_business_apply_cur in v_business_apply_cur(v_process.process_type) loop
        v_line := pl_json;
        v_line.set_value('spaceId', c_business_apply_cur.space_id); --add by wlj
        v_line.set_value('processId', c_business_apply_cur.process_id);
        v_line.set_value('processCode', c_business_apply_cur.process_code);
        v_line.set_value('processName', c_business_apply_cur.process_name);
        v_line.set_value('externalFormUrl', c_business_apply_cur.form_url);
        v_line.set_value('docSysCode', c_business_apply_cur.doc_sys_code);
        v_line.set_value('processClass',
                         c_business_apply_cur.process_class);
        v_line.set_value('processOwner',
                         c_business_apply_cur.process_owner);
        v_line.set_value('processOwnerName',
                         c_business_apply_cur.process_owner_name);
        v_form_id := dbpm_comm_pkg.func_get_process_form(p_process_id => c_business_apply_cur.process_id);
        v_line.set_value('formId', v_form_id);
        v_porcess.add_list_item(v_line);
      end loop;
      v_porcess.set_data_type('ARRAY');
      v_process_type.set_value('processList', v_porcess);
      v_array.add_list_item(v_process_type);
    end loop;

    v_array.set_data_type('ARRAY');
    v_response.set_value('data', v_array);
    x_response := v_response.to_json;
  end proc_query_business_apply;

  /*==================================================
  procedure/function name :
      proc_query_comm_process
  description:
      this function perform:
      业务申请-查询通用的流程
  argument:
     p_request： 请求参数
     x_response： 响应结果
  history:
      1.00  2017-11-30  liangjun.wu  creation
  ==================================================*/
  procedure proc_query_comm_process(p_request in clob, x_response out clob) as

    v_request        json;
    v_response       pl_json := pl_json;
    v_process_name   varchar2(200);
    v_total          number := 0;
    v_size           number := 200;
    v_page           number := 1;
    v_search_content varchar2(4000);
    cursor v_process_cur is
      select *
        from (select v.*,
                     rownum cnt,
                     (select e.employee_name
                        from dfnd_employees e
                       where e.employee_code = upper(v.process_owner)) process_owner_name
                from (select count(1) over(partition by 1) total,
                             dp.process_id,
                             dp.process_code,
                             dp.process_name,
                             dp.process_owner
                        from dbpm_process dp
                       where dp.is_shared = 'Y'
                         and dp.enabled_flag = 'Y'
                         and dp.space_id = '1' --默认取超级空间
                         and (instr(nvl(dp.process_name, 'NL'),
                                    nvl(v_search_content,
                                        nvl(dp.process_name, 'NL'))) > 0 or
                             instr(nvl(dp.process_code, 'NL'),
                                    nvl(v_search_content,
                                        nvl(dp.process_code, 'NL'))) > 0)
                       order by dp.process_id desc) v
               where rownum <= v_page * v_size)
       where cnt > (v_page - 1) * v_size;
    --where v_process_name is null
    --   or dp.process_name like '%' || v_process_name || '%';
    v_line    pl_json;
    v_form_id number;

  begin
    v_request := json(p_request, 'OBJECT');
    /*v_process_name := dcld_comm_pkg.get_filter_value('processName',
    v_request);*/
    v_search_content := dcld_comm_pkg.get_filter_value('all', v_request);
    if v_request.exist('page') then
      v_page := v_request.get_number('page');
    end if;
    if v_request.exist('size') then
      v_size := v_request.get_number('size');
    end if;

    for v_process in v_process_cur loop
      v_total := v_process.total;
      v_line  := pl_json;
      v_line.set_value('processId', v_process.process_id);
      v_line.set_value('processCode', v_process.process_code);
      v_line.set_value('processName', v_process.process_name);
      v_line.set_value('processOwner', v_process.process_owner);
      v_line.set_value('processOwnerName', v_process.process_owner_name);
      v_form_id := dbpm_comm_pkg.func_get_process_form(p_process_id => v_process.process_id);
      v_line.set_value('formId', v_form_id);
      v_response.add_list_item('processList', v_line);
    end loop;

    v_response.set_value('total', v_total);
    x_response := v_response.to_json;
  end proc_query_comm_process;

  /*==================================================
  procedure/function name :
      proc_save_process
  description:
      this function perform:
      流程配置-保存流程基本信息，需要判断是新建还是更新
  argument:
     p_request： 请求参数
     x_response： 响应结果
  history:
      1.00  2017-04-07  skycloud.wang  creation
  ==================================================*/
  procedure proc_save_process(p_request in clob, x_response out clob) is
  begin
    dbpm_process_api_pkg.proc_save_process(p_request, x_response);
  end proc_save_process;

  procedure proc_save_process_tl(p_request clob, x_response out clob) is
  begin
    dbpm_process_api_pkg.proc_save_process_tl(p_request, x_response);
  end proc_save_process_tl;
  /*==================================================
  procedure/function name :
      proc_save_node_buttons
  description:
      this function perform:
      保存节点的按钮信息
  argument:
     p_request： 请求参数
     x_response： 响应结果
  history:
      1.00  2017-04-11  chenming  creation
  ==================================================*/
  procedure proc_save_node_buttons(p_request in clob, x_response out clob) is
    v_api         varchar2(100) := 'proc_save_node_buttons';
    v_request     json;
    v_response    pl_json := pl_json;
    v_node_id     number;
    v_count       number;
    v_button_list json_list;
    v_button      json;
  begin
    v_request     := json(p_request, 'OBJECT');
    v_node_id     := v_request.get('nodeId').get_number;
    v_button_list := json_list(v_request.path('buttonList'));

    for i in 1 .. v_button_list.count loop
      v_button := json(v_button_list.get(i));
      if v_button.get('hasButton').get_string = 'false' then
        delete from dbpm_node_buttons dnb
         where dnb.node_id = v_node_id
           and dnb.button_code = v_button.get('buttonCode').get_string;
      else
        select count(1)
          into v_count
          from dbpm_node_buttons dnb
         where dnb.node_id = v_node_id
           and dnb.button_code = v_button.get('buttonCode').get_string;
        if v_count = 0 then
          insert into dbpm_node_buttons
            (node_button_id, node_id, button_code)
          values
            (dbpm_node_buttons_s.nextval,
             v_node_id,
             v_button.get('buttonCode').get_string);
        end if;
      end if;
    end loop;
    x_response := v_response.to_json;
    /* exception
    when others then
      rollback;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || sqlerrm);
      x_response := v_response.to_json;*/
  end proc_save_node_buttons;

  /*==================================================
  procedure/function name :
      proc_query_node_buttons
  description:
      this function perform:
      查询某个审批节点的按钮信息，需要显示所有的按钮信息
  argument:
     p_request： 请求参数
     x_response： 响应结果
  history:
      1.00  2017-04-11  chenming  creation
  ==================================================*/
  procedure proc_query_node_buttons(p_request in clob, x_response out clob) is
    v_api           varchar2(100) := 'proc_query_node_buttons';
    v_request       json;
    v_node_id       number;
    v_buttonlist    pl_json := pl_json;
    v_response      pl_json := pl_json;
    v_total         number := 0;
    v_count         number;
    v_locale        varchar2(10);
    v_process_id    number; --流程id
    v_process_class varchar2(100); --流程种类
    cursor v_button_cur is
      select db.button_code,
             nvl(tl.button_name, db.button_name) button_name,
             (case
               when dnb.button_code is null then
                'N'
               else
                'Y'
             end) has_button
        from dbpm_buttons db, dbpm_buttons_tl tl, dbpm_node_buttons dnb
       where db.button_code = dnb.button_code(+)
         and db.button_code = tl.button_code(+)
         and tl.locale = v_locale
         and dnb.node_id(+) = v_node_id
       order by db.order_num asc;
  begin
    v_request    := json(p_request, 'OBJECT');
    v_locale     := v_request.locale;
    v_node_id    := v_request.get('nodeId').get_number;
    v_process_id := v_request.get_number('processId');

    select nvl(dp.process_class, 'INTERNAL')
      into v_process_class
      from dbpm_process dp
     where dp.process_id = v_process_id;
    v_response.set_value('nodeId', v_node_id);

    for v_button in v_button_cur loop
      v_buttonlist := pl_json;
      if v_process_class = 'INTERNAL' and v_button.button_code = 'SUBMIT' then
        --如果是得云流程，不现实重新提交的按钮
        continue;
      end if;
      v_buttonlist.set_value('buttonCode', v_button.button_code);
      v_buttonlist.set_value('buttonName', v_button.button_name);

      if v_button.has_button = 'Y' then
        v_buttonlist.set_value('hasButton', true);
      else
        v_buttonlist.set_value('hasButton', false);
      end if;

      v_total := v_total + 1;
      v_response.add_list_item('buttonList', v_buttonlist);
    end loop;

    v_response.set_value('total', v_total);
    x_response := v_response.to_json;
    /* exception
    when others then
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || sqlerrm);
      x_response := v_response.to_json;*/
  end proc_query_node_buttons;

  /*==================================================
  procedure/function name :
      proc_query_process_chain_nodes
  description:
      this function perform:
      查询流程的审批链及审批节点信息
  argument:
     p_request： 请求参数
     x_response： 响应结果
  history:
      1.00  2017-04-11  chenming  creation
  ==================================================*/
  procedure proc_query_process_chain_nodes(p_request  in clob,
                                           x_response out clob) is
    v_api              varchar2(100) := 'proc_query_process_chain_nodes';
    v_process_id       number;
    v_organization_id  varchar2(100);
    v_request          json;
    v_line             pl_json;
    v_chain_list       pl_json;
    v_chain_node_list  pl_json;
    v_chain_node_lists pl_json;
    v_process_name     varchar2(20);
    v_response         pl_json := pl_json;
    v_node_id          number;
    v_node_name        varchar2(20);
    cursor v_chain_cur is
      select dac.chain_id, dac.chain_name
        from dbpm_approval_chain dac
       where dac.process_id = v_process_id;
    cursor v_node_cur(p_chain_id number) is
      select dcn.node_id, dcn.node_name
        from dbpm_chain_nodes dcn
       where dcn.chain_id = p_chain_id
         and dcn.is_deleted = 'N'
       order by dcn.order_num;
  begin
    v_request         := json(p_request, 'OBJECT');
    v_process_id      := v_request.get_number('processId');
    v_organization_id := v_request.get('organizationId').get_string;
    v_line            := pl_json;
    v_line.set_value('processId', v_process_id);
    v_line.set_value('organizationId', v_organization_id);
    select dp.process_name
      into v_process_name
      from dbpm_process dp
     where dp.process_id = v_process_id;
    v_line.set_value('processName', v_process_name);
    for v_chain in v_chain_cur loop
      v_chain_list := pl_json;
      v_chain_list.set_value('chainId', v_chain.chain_id);
      v_chain_list.set_value('chainName', v_chain.chain_name);
      for v_node in v_node_cur(v_chain.chain_id) loop
        v_chain_node_list := pl_json;
        v_chain_node_list.set_value('nodeId', v_node.node_id);
        v_chain_node_list.set_value('nodeName', v_node.node_name);
        v_chain_list.add_list_item('chainNodeList', v_chain_node_list);
      end loop;
      v_line.set_value('chainList', v_chain_list);
    end loop;
    x_response := v_line.to_json;
    /* exception
    when others then
      rollback;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || sqlerrm);
      x_response := v_response.to_json;*/
  end proc_query_process_chain_nodes;

  /*==================================================
  procedure/function name :
      proc_query_node_form_fields
  description:
      this function perform:
      查询流程审批节点的表单字段权限信息
  argument:
     p_request： 请求参数
     x_response： 响应结果
  history:
      1.00  2017-04-11  chenming  creation
  ==================================================*/
  procedure proc_query_node_form_fields(p_request  in clob,
                                        x_response out clob) is
    v_api           varchar2(100) := 'proc_query_node_form_fields';
    v_request       json;
    v_response      pl_json := pl_json;
    v_node_id       number;
    v_form_id       number;
    v_formfieldlist pl_json;
    v_locale        varchar2(10);

    /*cursor v_field_cur(p_node_id number, p_form_id number) is
    select dff.id,
           dff.label,
           nvl(dnff.access_code, 'ReadOnly') access_code
      from dbpm_node_form_fields dnff, dbpm_form_field dff
     where dnff.node_id(+) = p_node_id
       and dff.form_id = p_form_id
       and dnff.id(+) = dff.id
       and dff.parent_id is null
     order by dff.field_id desc;*/
    cursor v_field_cur(p_node_id number, p_form_id number) is
      select dff.id,
             dff.label,
             nvl(dnff.access_code, 'ReadOnly') access_code,
             nvl2(t2.component_name, t1.component_name, dff.label) locale_name
        from dbpm_node_form_fields dnff,
             dbpm_form_field dff,
             (select t.component_name, t.component_code
                from dcld_component_tl t
               where instr(t.locale, v_locale) > 0) t1,
             dcld_component_tl t2
       where dnff.node_id(+) = p_node_id
         and dff.form_id = p_form_id
         and dnff.id(+) = dff.id
         and dff.type = t1.component_code(+)
         and dff.type = t2.component_code(+)
         and dff.label = t2.component_name(+)
         and dff.parent_id is null
       order by dff.field_id desc;
  begin
    v_request := json(p_request, 'OBJECT');
    v_node_id := v_request.get('nodeId').get_number;
    v_locale  := v_request.locale;

    begin
      select df.form_id
        into v_form_id
        from dbpm_approval_chain dac, dbpm_chain_nodes dcn, dbpm_form df
       where dac.chain_id = dcn.chain_id
         and dac.process_id = df.process_id
         and df.status = 'Published'
         and dcn.node_id = v_node_id;
    exception
      when no_data_found then
        x_response := v_response.to_json;
        return;
    end;

    v_response.set_value('nodeId', v_node_id);
    for v_field in v_field_cur(v_node_id, v_form_id) loop
      v_formfieldlist := pl_json;
      v_formfieldlist.set_value('id', v_field.id);
      v_formfieldlist.set_value('label', v_field.locale_name);
      v_formfieldlist.set_value('accessCode', v_field.access_code);
      v_response.add_list_item('formFieldList', v_formfieldlist);
    end loop;

    x_response := v_response.to_json;

    /*  exception
    when others then
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || sqlerrm);
      x_response := v_response.to_json;*/
  end proc_query_node_form_fields;

  /*==================================================
  procedure/function name :
      proc_save_node_form_fields
  description:
      this function perform:
       保存流程审批节点的表单字段权限信息
  argument:
     p_request： 请求参数
     x_response： 响应结果
  history:
      1.00  2017-04-11  chenming  creation
  ==================================================*/
  procedure proc_save_node_form_fields(p_request  in clob,
                                       x_response out clob) is
    v_api                   varchar2(100) := 'proc_save_node_form_fields';
    v_request               json;
    v_current_user          varchar2(100);
    v_response              pl_json := pl_json;
    v_node_id               number;
    v_form_field_list       json_list;
    v_form_field            json;
    v_id                    varchar2(100);
    v_label                 varchar2(2000);
    v_accesscode            varchar2(10);
    v_count                 number;
    v_object_version_number number;
  begin
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;

    v_node_id         := v_request.get('nodeId').get_number;
    v_form_field_list := json_list(v_request.path('formFieldList'));
    for i in 1 .. v_form_field_list.count loop
      v_form_field := json(v_form_field_list.get(i));
      v_id         := v_form_field.get('id').get_string;
      v_label      := v_form_field.get('label').get_string;
      v_accesscode := v_form_field.get('accessCode').get_string;
      if v_accesscode = 'ReadOnly' then
        delete from dbpm_node_form_fields dnff
         where id = v_id
           and dnff.node_id = v_node_id;
      else
        select count(1)
          into v_count
          from dbpm_node_form_fields dnff
         where dnff.id = v_id
           and dnff.node_id = v_node_id;
        if v_count = 0 then
          insert into dbpm_node_form_fields
            (node_field_id,
             id,
             access_code,
             node_id,
             object_version_number,
             created_by,
             last_updated_by)
          values
            (dbpm_node_form_fields_s.nextval,
             v_id,
             v_accesscode,
             v_node_id,
             1,
             v_current_user,
             v_current_user);
        else
          update dbpm_node_form_fields dnff
             set dnff.object_version_number = dnff.object_version_number + 1,
                 dnff.access_code           = v_accesscode,
                 dnff.last_updated_by       = v_current_user
           where dnff.node_id = v_node_id
             and dnff.id = v_id;
        end if;
      end if;
    end loop;

    x_response := v_response.to_json;
    /*exception
    when others then
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || sqlerrm);
      x_response := v_response.to_json;*/
  end proc_save_node_form_fields;

  /*==================================================
  procedure/function name :
      proc_query_process_types
  description:
      this function perform:
       查看所有流程分类信息
  argument:
     p_request： 请求参数
     x_response： 响应结果
  history:
      1.00  2017-04-12  chenming  creation
  ==================================================*/
  /*procedure proc_query_process_types(p_request  in clob,
                                       x_response out clob) is
      v_request  json;
      v_response pl_json := pl_json;
      v_line     pl_json;
      v_total    number;
      cursor v_type_cur is
        select type_code, type_name from dbpm_process_types;
    begin
      for v_type in v_type_cur loop
        v_line := pl_json;
        v_line.set_value('typeCode', v_type.type_code);
        v_line.set_value('typeName', v_type.type_name);
        v_response.add_list_item('typeList', v_line);
        v_total := v_total + 1;
      end loop;
      v_response.set_value('total', 2);
      x_response := v_response.to_json;
    end proc_query_process_types;
  */
  /*==================================================
  procedure/function name :
      proc_query_process
  description:
      this function perform:
       查询流程基本信息
  argument:
     p_request： 请求参数
     x_response： 响应结果
  history:
      1.00  2017-04-12  skycloud.wang  creation
  ==================================================*/
  procedure proc_query_process(p_request in clob, x_response out clob) is
    v_request        json;
    v_response       pl_json := pl_json;
    v_process_id     number;
    v_process_code   varchar2(100);
    v_process_name   varchar2(200);
    v_description    varchar2(4000);
    v_enabled_flag   varchar2(10);
    v_process_type   varchar2(100);
    v_form_id        varchar2(100);
    v_form_name      varchar2(4000);
    v_node_name      varchar2(4000);
    v_share_flag     varchar2(10);
    v_isautoapproval varchar2(10);
    v_space_code varchar2(100);
    --add by xiaowei
    v_row pl_json;
    v_itl pl_json;
    --扩展流程
    v_process_class  varchar2(500); --流程种类（得云流程/其他obpm流程）
    v_bpm_process_id number; --obpm流程在官方表中的id
    v_doc_sys_code   varchar2(100); --表单类型（得云表单/外部表单）
    v_form_url       varchar2(4000); --外部表单链接
    --扩展流程
    v_process_org_type varchar2(100); --海尔客户化的组织类型
    --流程邮件模板
    cursor v_process_email_cur(p_processid number) is
      select dm.send_stage,
             dm.email_id,
             dm.content,
             dm.email_name,
             dm.recipients_type,
             dm.recipients
        from dbpm_process_email_map dm
       where dm.process_id = p_processid;
    /* union all
    select 'ALL' send_stage, dm.email_id, dm.content, dm.email_name
      from (select de.email_content content,
                   de.id            email_id,
                   de.email_name    email_name
              from dbpm_email_teamplate de, dbpm_process dp
             where de.space_id = dp.space_id
               and dp.process_id = p_processid
               and de.email_catalog = 'System') dm
     where not exists (select *
              from dbpm_process_email_map d
             where d.process_id = p_processid);*/
    --流程服务
    cursor v_process_service_cur(p_process_id number) is
      select dm.invoke_stage,
             dm.invoke_order,
             dm.service_id,
             ds.service_name,
             dm.service_req
        from dbpm_process_service_map dm, dbpm_service ds
       where dm.service_id = ds.id
         and dm.process_id = p_process_id;

    --流程国际化值
    cursor v_processtl_cur(p_processid number) is
      select dt.locale, dt.process_name
        from dbpm_process_tl dt
       where dt.process_id = p_processid;
       --流程超期规则
       cursor v_expire_cur(p_processCode varchar2) is
       select *
       from dbpm_process_expire_rule de
        where de.process_code=p_processCode
        and de.rule_type='INSTANCE';
  begin
    v_request    := json(p_request, 'OBJECT');
    v_process_id := v_request.get('processId').get_number;
    select dp.process_code,
           dp.process_name,
           dp.process_type,
           dp.description,
           dp.enabled_flag,
           dp.is_shared,
           dp.bpm_process_id,
           dp.process_class,
           dp.doc_sys_code,
           dp.form_url,
           dp.cux_org_type,
           dp.cux_auto_approve_flag,
           ds.space_code
    --decode(mod(v_process_id, 2), 0, 'EXTERNAL', 'INTERNAL')
      into v_process_code,
           v_process_name,
           v_process_type,
           v_description,
           v_enabled_flag,
           v_share_flag,
           v_bpm_process_id,
           v_process_class,
           v_doc_sys_code,
           v_form_url,
           v_process_org_type,
           v_isautoapproval,
           v_space_code
      from dbpm_process dp,dbpm_spaces ds
     where dp.process_id = v_process_id
     and dp.space_id=ds.space_id(+);
    v_form_id := dbpm_comm_pkg.func_get_process_form(p_process_id => v_process_id);
    v_response.set_value('processId', v_process_id);
    v_response.set_value('processCode', v_process_code);
    v_response.set_value('processName', v_process_name);
    v_response.set_value('processType', v_process_type);
    v_response.set_value('description', v_description);
    v_response.set_value('bpmProcessId', v_bpm_process_id);
    v_response.set_value('processClass', v_process_class);
    v_response.set_value('externalFormUrl', v_form_url);
    v_response.set_value('docSysCode', v_doc_sys_code);
    v_response.set_value('processOrgType', v_process_org_type);
    v_response.set_value('spaceCode', v_space_code);
    --流程邮件
    for v_email_row in v_process_email_cur(v_process_id) loop
      v_row := pl_json;
      v_row.set_value('emailId', v_email_row.email_id);
      v_row.set_value('sendStage', v_email_row.send_stage);
      v_row.set_value('emailName', v_email_row.email_name);
      v_row.set_value('recipients', v_email_row.recipients);
      v_row.set_value('recipientsType', v_email_row.recipients_type);
      v_row.set_value('content', json(v_email_row.content));
      v_response.add_list_item('emails', v_row);
    end loop;
    --流程服务
    --流程服务
    for v_service_row in v_process_service_cur(v_process_id) loop
      v_row := pl_json;
      v_row.set_value('serviceId', v_service_row.service_id);
      v_row.set_value('invokeStage', v_service_row.invoke_stage);
      v_row.set_value('invokeOrder', v_service_row.invoke_order);
      v_row.set_value('serviceName', v_service_row.service_name);
      v_row.set_value('serviceReq', json(v_service_row.service_req));
      v_response.add_list_item('services', v_row);
    end loop;
    --国际化值
    for v_itl_row in v_processtl_cur(v_process_id) loop
      v_itl := pl_json;
      v_itl.set_value('lang', v_itl_row.process_name);
      v_itl.set_value('locale', v_itl_row.locale);
      v_response.add_list_item('processNametl', v_itl);
    end loop;
    --超期规则
     for v_expire_row in v_expire_cur(v_process_code) loop
      v_row := pl_json;
      v_row.set_value('ruleUuid', v_expire_row.rule_uuid);
      v_row.set_value('paramName', v_expire_row.param_name);
      v_row.set_value('paramMeaning', v_expire_row.param_meaning);
      v_row.set_value('deloyDay', v_expire_row.deloy_day);
      v_row.set_value('paramValue', v_expire_row.param_value);
      v_row.set_value('startTime', v_expire_row.start_time);
      v_row.set_value('endTime', v_expire_row.end_time);
      v_row.set_value('warningDur', v_expire_row.warning_dur);
      v_row.set_value('warningNum', v_expire_row.warning_num);
      v_response.add_list_item('expires', v_row);
       end loop;
    begin
      select df.form_name
        into v_form_name
        from dbpm_form df
       where df.form_id = v_form_id;
    exception
      when no_data_found then
        v_form_name := null;
    end;
    for v_node in (select dpn.node_name
                     from dbpm_process_nodes dpn
                    where dpn.process_id = v_process_id
                    order by dpn.order_num) loop
      v_node_name := v_node_name || (case
                       when v_node_name is null then
                        ''
                       else
                        '，'
                     end) || v_node.node_name;
    end loop;
    v_response.set_value('processNodes', v_node_name);
    if v_enabled_flag = 'Y' then
      v_response.set_value('isEnabled', true);
    else
      v_response.set_value('isEnabled', false);
    end if;

    if v_share_flag = 'Y' then
      v_response.set_value('isShared', true);
    else
      v_response.set_value('isShared', false);
    end if;
    if v_isautoapproval = 'Y' then
      v_response.set_value('isAutoApproval', true);
    else
      v_response.set_value('isAutoApproval', false);
    end if;

    v_response.set_value('formIdStr', v_form_id);
    v_response.set_value('formName', v_form_name);
    v_response.set_value('formId', to_number(v_form_id));
    x_response := v_response.to_json;
  end proc_query_process;

  /*==================================================
  procedure/function name :
      proc_get_type_count
  description:
      this function perform:
       查询各种类型的数量，比如待办数量
  argument:
     p_request： 请求参数
     x_response： 响应结果
  history:
      1.00  2017-04-18  skycloud.wang  creation
  ==================================================*/
  procedure proc_get_type_count(p_request in clob, x_response out clob) is
    v_request      json;
    v_response     pl_json := pl_json;
    v_current_user varchar2(100);
    v_todo_count   number := 0;
    v_task_to_read number := 0;
    v_count_type   varchar2(50);
  begin
    v_request      := json(p_request, 'OBJECT');
    v_count_type   := v_request.get_string('countType');
    v_current_user := v_request.username;
    if v_count_type = 'todoCount' then
      v_todo_count := func_get_todo_count(v_current_user);
    end if;
    if v_count_type = 'readCount' then
      v_todo_count := func_get_read_count(v_current_user);
    end if;
    v_response.set_value('count', v_todo_count);
    x_response := v_response.to_json;
  end proc_get_type_count;

  /*==================================================
  procedure/function name :
      proc_query_approval_history
  description:
      this function perform:
       查询流程审批历史
  argument:
     p_request： 请求参数
     x_response： 响应结果
  history:
      1.00  2017-04-26  skycloud.wang  creation
  ==================================================*/
  procedure proc_query_approval_history(p_request  in clob,
                                        x_response out clob) is
    v_request       json;
    v_response      pl_json := pl_json;
    v_history_json  pl_json;
    v_document_id   number;
    v_process_class varchar2(100);
    v_process_id    number;
    v_creator       varchar2(10);
    v_creator_name  varchar2(400);

    cursor v_history_cur(p_document_id number) is
      select dah.history_id,
             dah.document_id,
             nvl(pht.custom_role_name, dah.node_name) node_name,
             dah.approver_code,
             dah.approver_name,
             (select ddsv.value_name
                from dbpm_data_source_values ddsv
               where ddsv.data_source_code = 'DbpmApprovalOperation'
                 and ddsv.value_code = dah.operation) operation,
             dah.comment_detail,
             dah.creation_date
        from dbpm_approval_history dah, cux_node_parallel_history_t pht
       where dah.document_id = pht.document_id(+)
         and dah.node_name = pht.node_name(+)
         and dah.approver_code = pht.approver(+)
         and dah.document_id = p_document_id
       order by dah.history_id;
    /*select dah.history_id,
          dah.document_id,
          dah.node_name,
          dah.approver_code,
          dah.approver_name,
          (select ddsv.value_name
             from dbpm_data_source_values ddsv
            where ddsv.data_source_code = 'DbpmApprovalOperation'
              and ddsv.value_code = dah.operation) operation,
          dah.comment_detail,
          dah.creation_date
     from dbpm_approval_history dah
    where dah.document_id = p_document_id
    order by dah.history_id;*/
  begin
    --v_request := json(p_request, 'OBJECT');
    --暂时统一使用官方查询
    dbpm_process_history_pkg.proc_query_official_history(p_request,
                                                         x_response);
    return;

    v_document_id := v_request.get('documentId').get_number;
    v_response.set_value('documentId', v_document_id);

    --流程种类
    select d.process_id, d.doc_creator, d.doc_creator_name
      into v_process_id, v_creator, v_creator_name
      from dbpm_documents d
     where d.document_id = v_document_id;
    select nvl(dp.process_class, 'INTERNAL')
      into v_process_class
      from dbpm_process dp
     where dp.process_id = v_process_id;
    --如果是其他obpm流程，则查询官方的审批历史表wftaskhistory
    if v_process_class = 'EXTERNAL' then
      dbpm_process_history_pkg.proc_query_official_history(p_request,
                                                           x_response);
      return;
    end if;

    --加入申请人节点
    v_history_json := pl_json;
    v_history_json.set_value('historyId', '');
    v_history_json.set_value('nodeName', '申请人');
    v_history_json.set_value('approverCode', v_creator);
    v_history_json.set_value('approverName', v_creator_name);
    v_history_json.set_value('operation', 'SUBMIT');
    v_history_json.set_value('comment', '提交申请');
    v_response.add_list_item('historyList', v_history_json);
    for v_history in v_history_cur(v_document_id) loop
      v_history_json := pl_json;
      v_history_json.set_value('historyId', v_history.history_id);
      v_history_json.set_value('nodeName', v_history.node_name);
      v_history_json.set_value('approverCode', v_history.approver_code);
      v_history_json.set_value('approverName', v_history.approver_name);
      v_history_json.set_value('operation', v_history.operation);
      v_history_json.set_value('comment', v_history.comment_detail);
      v_history_json.set_value('approvalDate',
                               to_char(v_history.creation_date,
                                       'YYYY-MM-DD HH24:MI:SS'));
      v_response.add_list_item('historyList', v_history_json);
    end loop;

    x_response := v_response.to_json;
  end proc_query_approval_history;

  /*==================================================
  procedure/function name :
      proc_query_get_approvers_type
  description:
      this function perform:
       查询审批人类型
  argument:
     p_request： 请求参数
     x_response： 响应结果
  history:
      1.00  2017-07-11  zhiheng.wei  creation
  ==================================================*/
  procedure proc_query_get_approvers_type(p_request  clob,
                                          x_response out clob) is
    v_response  pl_json := pl_json;
    v_request   json;
    v_node_type pl_json;
    v_approvers pl_json;
    v_api       varchar2(50) := 'proc_query_get_approvers_type';
    v_total     number := 0;

    cursor dbpm_data_source_cur(p_data_source_code varchar2) is
      select dds.value_code,
             dcld_comm_pkg.get_data_source_value(p_data_source_code,
                                                 dds.value_code,
                                                 v_request.locale) value_name
        from dbpm_data_source_values dds
       where dds.data_source_code = p_data_source_code
         and dds.status = 'Y'
       order by dds.display_seq;
    /*union
    select dgae.approvers_type, dgae.approvers_type_name
      from dbpm_get_approvers_ext dgae;*/

  begin
    v_request := json(p_request, 'OBJECT');
    -- 审批人类型需要从两个地方获取（数据字典和扩展审批人类型中）
    for v_node in dbpm_data_source_cur('DbpmNodeType') loop
      v_total     := v_total + 1;
      v_node_type := pl_json;
      v_node_type.set_value('nodeTypeCode', v_node.value_code);
      v_node_type.set_value('nodeTypeName', v_node.value_name);
      if v_node.value_code = 'SubProcess' then
        for v_data_source in (select dds.value_code,
                                     dcld_comm_pkg.get_data_source_value('DbpmGetApproversType',
                                                                         dds.value_code,
                                                                         v_request.locale) value_name
                                from dbpm_data_source_values dds
                               where dds.data_source_code =
                                     'DbpmGetApproversType'
                                 and dds.value_code in ('SubProcess')
                                 and dds.status = 'Y'
                               order by dds.display_seq) loop
          v_approvers := pl_json;
          v_approvers.set_value('approversType', v_data_source.value_code);
          v_approvers.set_value('apporversTypeName',
                                v_data_source.value_name);
          v_node_type.add_list_item('getApproversTypeList', v_approvers);
        end loop;
      else
        for v_data_source in (select dds.value_code,
                                     dcld_comm_pkg.get_data_source_value('DbpmGetApproversType',
                                                                         dds.value_code,
                                                                         v_request.locale) value_name
                                from dbpm_data_source_values dds
                               where dds.data_source_code =
                                     'DbpmGetApproversType'
                                 and dds.value_code not in ('SubProcess')
                                 and dds.status = 'Y'
                               order by dds.display_seq) loop
          v_approvers := pl_json;
          v_approvers.set_value('approversType', v_data_source.value_code);
          v_approvers.set_value('apporversTypeName',
                                v_data_source.value_name);
          dbms_output.put_line(v_data_source.value_code);
          dbms_output.put_line(v_data_source.value_name);
          v_node_type.add_list_item('getApproversTypeList', v_approvers);
        end loop;
      end if;
      v_response.add_list_item('nodeTypeList', v_node_type);
    end loop;

    v_response.set_value('total', v_total);
    x_response := v_response.to_json;
    /* exception
    when others then
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || sqlerrm);
      x_response := v_response.to_json;*/
  end proc_query_get_approvers_type;

  /*
  * 获取待办数量
  */
  function func_get_todo_count(p_current_user varchar2) return number is
    v_todo_count number;
  begin
    select count(1)
      into v_todo_count
      from dbpm_task_todo_query_v todo
     where upper(todo.assigness_user_code) = upper(p_current_user);
    return v_todo_count;
  end func_get_todo_count;
  /*
  * 获取待办数量
  */
  function func_get_read_count(p_current_user varchar2) return number is
    v_todo_count number;
  begin
    select count(*)
      into v_todo_count
      from dbpm_task_read_query_v v1,
           dbpm_document_read     ddr,
           dbpm_process_types     dpt
     where dpt.type_code(+) = v1.process_type
       and ddr.document_id = v1.document_id
       and ddr.is_read = 'N'
       and upper(v1.created_user_code) = upper(p_current_user);
    return v_todo_count;
  end func_get_read_count;

  /*==================================================
  procedure/function name :
      proc_add_add_select_approvers
  description:
      this function perform:
       添加选中的审批人
  argument:
     p_request： 请求参数
     x_response： 响应结果
  history:
      1.00  2017-07-11  skycloud.wang  creation
  ==================================================*/
  procedure proc_add_select_approvers(p_request clob, x_response out clob) is
    v_request      json;
    v_response     pl_json := pl_json;
    v_api          varchar2(50) := 'proc_query_get_approvers_type';
    v_document_id  number;
    v_node_id      number;
    v_next_node_id number;
    v_approvers    varchar2(4000);
    v_current_user varchar2(100);
  begin
    v_request      := json(p_request, 'OBJECT');
    v_document_id  := v_request.get('documentId').get_number;
    v_node_id      := v_request.get('nodeId').get_number;
    v_approvers    := v_request.get('approvers').get_string;
    v_current_user := v_request.username;

    v_next_node_id := dbpm_comm_pkg.get_next_node_id(v_node_id);
    if v_next_node_id is null then
      --v_response.fail('下级审批节点为空');
      v_response.fail(dcld_comm_pkg.func_get_err_msg('DCLD-00020',
                                                     v_request.locale));
      x_response := v_response.to_json;
      return;
    end if;

    delete dbpm_selected_approvers dsa
     where dsa.document_id = v_document_id
       and dsa.node_id = v_next_node_id;
    if v_approvers is not null then
      insert into dbpm_selected_approvers
        (approver_id,
         document_id,
         node_id,
         approvers,
         object_version_number,
         created_by,
         creation_date,
         last_updated_by,
         last_update_date)
      values
        (dbpm_selected_approvers_s.nextval,
         v_document_id,
         v_next_node_id,
         v_approvers,
         1,
         v_current_user,
         sysdate,
         v_current_user,
         sysdate);
    end if;
    x_response := v_response.to_json;
    /*  exception
    when others then
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || sqlerrm);
      x_response := v_response.to_json;*/
  end proc_add_select_approvers;

  /*==================================================
  procedure/function name :
      proc_query_data_operation_type
  description:
      this function perform:
       查询数据判断类型
  argument:
     p_request： 请求参数
     x_response： 响应结果
  history:
      1.00  2017-09-29  skycloud.wang  creation
  ==================================================*/
  procedure proc_query_data_operation_type(p_request  clob,
                                           x_response out clob) is
    v_request        json;
    v_response       pl_json := pl_json;
    v_api            varchar2(50) := 'proc_query_data_operation_type';
    v_data_type      varchar2(100);
    v_count          number := 0;
    v_operation_json pl_json;
    cursor v_operation_type_cur is
      select *
        from dbpm_data_compare_type ddc
       where ddc.data_type = v_data_type;
  begin
    v_request   := json(p_request, 'OBJECT');
    v_data_type := v_request.get('dataType').get_string;
    for v_operation in v_operation_type_cur loop
      v_operation_json := pl_json;
      v_count          := v_count + 1;
      v_operation_json.set_value('operationType',
                                 v_operation.operation_type);
      v_operation_json.set_value('operationName',
                                 dcld_comm_pkg.func_get_sys_msg(v_operation.operation_type,
                                                                v_request.locale));
      v_response.add_list_item('dataOperationTypeList', v_operation_json);
    end loop;
    v_response.set_value('count', v_count);
    x_response := v_response.to_json;
    /* exception
    when others then
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || sqlerrm);
      x_response := v_response.to_json;*/
  end proc_query_data_operation_type;

  /*==================================================
  procedure/function name :
      proc_query_history_graph
  description:
      this function perform:
       查询审批历史流程图
  argument:
     p_request： 请求参数
     x_response： 响应结果
  history:
      1.00  2018-05-08  wlj  creation
  ==================================================*/
  procedure proc_query_history_graph(p_request  in clob,
                                     x_response out clob) as

  begin
    dbpm_process_history_pkg.proc_query_history_graph(p_request,
                                                      x_response);
  end;
  /*==================================================
  procedure/function name :
      proc_copy_process
  description:
      this function perform:
      流程配置-复制流程，
      当某些流程是一样的（或者大体一样），但是不能当做一条流程的时候，更加快捷方便的配置
  argument:
     p_request： 请求参数
      {
        "targetProcess": {
          "processName": "dad",
          "processCode": "cccccc",
          "processType": "BD"
        },
        "sourceProcess": {
          "processId": 111
        },
        "copyField": ['process_basic_info', 'process_params', 'process_nodes', 'process_chains', 'process_auths']
      }
     x_response： 响应结果
  history:
      1.00  2018-02-28  echo.zeng  creation
  ==================================================*/
  procedure proc_copy_process(p_request in clob, x_response out clob) is
    v_request        json;
    v_response       pl_json := pl_json;
    v_current_user   varchar2(100);
    v_process_id     number;
    v_id             number;
    v_count          number := 0;
    v_enabled_flag   varchar2(10) := 'N';
    v_source_process json;
    v_target_process json;
    v_copy_fields    json_list;
    v_field          varchar2(300);
    v_process_name   dbpm_process.process_name%type;
    v_process_code   dbpm_process.process_code%type;
    v_process_type   dbpm_process.process_type%type;
    v_chain_id       number;
    v_node_id        number;
    v_spaceid        varchar2(300);

    cursor v_process_node_cur(p_process_id number) is
      select t.node_id,
             t.node_name,
             t.node_type,
             t.order_num,
             t.approver_type,
             t.is_required,
             t.is_auto_approve
        from dbpm_process_nodes t
       where t.process_id = p_process_id;
    cursor v_process_chain_cur(p_process_id number) is
      select t.chain_id,
             t.chain_name,
             t.chain_type,
             t.organization_id,
             t.from_chain_id,
             t.status,
             t.is_deleted,
             t.space_id,
             t.version,
             tree.chain_rule_tree
        from dbpm_approval_chain t, dbpm_chain_rules_tree tree
       where t.process_id = p_process_id
         and t.chain_id = tree.chain_id(+)
            --update by xiaowei 20180628
         and t.is_deleted = 'N'
       order by t.chain_id;
    cursor v_chain_rule_cur(p_chain_id number) is
      select t.rule_id,
             t.chain_id,
             t.param_name,
             t.param_meaning,
             t.param_type,
             t.operation_type,
             t.param_value,
             t.get_value_type,
             t.rule_uuid
        from dbpm_chain_rules t
       where t.chain_id = p_chain_id;
    cursor v_chain_node_cur(p_chain_id number) is
      select t.node_id,
             t.chain_id,
             t.node_name,
             t.node_type,
             t.order_num,
             t.approver_type,
             t.is_required,
             t.is_auto_approve,
             t.version,
             t.is_deleted
        from dbpm_chain_nodes t
       where t.chain_id = p_chain_id
            --update by xuge 20180628
         and t.is_deleted = 'N';
  begin
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;

    if v_current_user is null then
      v_current_user := 'weblogic';
    end if;
    v_source_process := json(v_request.get('sourceProcess'));
    if v_source_process is null or
       v_source_process.get('processId') is null then
      v_response.fail('源流程不存在，请重新选择！');
    else
      v_process_id := v_source_process.get('processId').get_number;
      select t.space_id
        into v_spaceid
        from dbpm_process t
       where t.process_id = v_process_id;
      v_target_process := json(v_request.get('targetProcess'));
      if v_target_process is null or
         v_target_process.get('processName') is null or
         v_target_process.get('processCode') is null or
         v_target_process.get('processType') is null then
        v_response.fail('目标流程参数错误，请重新输入！');
      else
        --获取参数
        v_copy_fields  := json_list(v_request.get('copyField'));
        v_process_name := v_target_process.get('processName').get_string;
        v_process_code := v_target_process.get('processCode').get_string;
        v_process_type := v_target_process.get('processType').get_string;
        select count(1)
          into v_count
          from dbpm_process dp
         where dp.process_code = v_process_code;
        if v_count > 0 then
          v_response.fail('流程编号为' || v_process_code || '已存在,请重新输入!');
          x_response := v_response.to_json;
          return;
        end if;
        if v_copy_fields is not null and v_copy_fields.count > 0 then
          v_field := v_copy_fields.get(1).get_string;
          --复制所有流程配置
          if v_copy_fields.count = 1 and v_field = 'ALL' then
            --获取流程id
            v_id := dbpm_process_s.nextval;
            --流程基本信息
            insert into dbpm_process dp
              (process_id,
               process_code,
               process_name,
               process_type,
               enabled_flag,
               created_by,
               last_updated_by,
               space_id)
            values
              (v_id,
               v_process_code,
               v_process_name,
               v_process_type,
               'N',
               v_current_user,
               v_current_user,
               v_spaceid);
            --流程表单信息
            /*insert into dbpm_form
            (form_id,
             process_id,
             form_name,
             form_icon,
             config_html,
             process_html,
             created_by,
             last_updated_by)
            select t.form_id,
                   v_id,
                   t.form_name,
                   t.form_icon,
                   t.config_html,
                   t.process_html,
                   t.created_by,
                   t.last_updated_by
              from dbpm_form t
             where t.process_id = v_process_id;*/
            --流程参数信息
            insert into dbpm_process_params
              (param_id,
               process_id,
               param_code,
               param_name,
               param_type,
               created_by,
               last_updated_by)
              select dbpm_process_params_s.nextval,
                     v_id,
                     t.param_code,
                     t.param_name,
                     t.param_type,
                     v_current_user,
                     v_current_user
                from dbpm_process_params t
               where t.process_id = v_process_id;
            --流程节点
            for v_process_node_cur_row in v_process_node_cur(v_process_id) loop
              --复制节点基本信息
              v_node_id := dbpm_process_nodes_s.nextval;
              insert into dbpm_process_nodes
                (node_id,
                 process_id,
                 node_name,
                 node_type,
                 order_num,
                 approver_type,
                 created_by,
                 last_updated_by)
              values
                (v_node_id,
                 v_id,
                 v_process_node_cur_row.node_name,
                 v_process_node_cur_row.node_type,
                 v_process_node_cur_row.order_num,
                 v_process_node_cur_row.approver_type,
                 v_current_user,
                 v_current_user);
              --节点中文国际化
              insert into dbpm_process_nodes_tl
                (node_id, locale, node_name, created_by, last_updated_by)
                select v_node_id,
                       'zh_CN',
                       t.node_name,
                       v_current_user,
                       v_current_user
                  from dbpm_process_nodes_tl t
                 where t.node_id = v_process_node_cur_row.node_id
                   and t.locale = 'zh_CN';
              proc_copy_role(v_process_node_cur_row.node_id,
                             v_current_user,
                             v_node_id,
                             'ProcessNode');
            end loop;
            --审批链信息
            for v_process_chain_cur_row in v_process_chain_cur(v_process_id) loop
              v_chain_id := dbpm_approval_chain_s.nextval;
              --基本信息
              insert into dbpm_approval_chain
                (chain_id,
                 chain_name,
                 chain_type,
                 process_id,
                 organization_id,
                 status,
                 created_by,
                 last_updated_by,
                 is_deleted,
                 version)
              values
                (v_chain_id,
                 v_process_chain_cur_row.chain_name,
                 v_process_chain_cur_row.chain_type,
                 v_id,
                 v_process_chain_cur_row.organization_id,
                 v_process_chain_cur_row.status,
                 v_current_user,
                 v_current_user,
                 v_process_chain_cur_row.is_deleted,
                 v_process_chain_cur_row.version);
              --维护规则树
              insert into dbpm_chain_rules_tree
                (chain_id,
                 chain_rule_tree,
                 chain_name,
                 chain_type,
                 process_id,
                 organization_id,
                 status,
                 created_by,
                 last_updated_by,
                 is_deleted,
                 version)
              values
                (v_chain_id,
                 v_process_chain_cur_row.chain_rule_tree,
                 v_process_chain_cur_row.chain_name,
                 v_process_chain_cur_row.chain_type,
                 v_id,
                 v_process_chain_cur_row.organization_id,
                 v_process_chain_cur_row.status,
                 v_current_user,
                 v_current_user,
                 v_process_chain_cur_row.is_deleted,
                 v_process_chain_cur_row.version);
              --审批链规则
              for v_chain_rule_cur_row in v_chain_rule_cur(v_process_chain_cur_row.chain_id) loop
                insert into dbpm_chain_rules
                  (rule_id,
                   chain_id,
                   param_name,
                   param_meaning,
                   param_type,
                   operation_type,
                   param_value,
                   created_by,
                   last_updated_by,
                   get_value_type,
                   rule_uuid)
                values
                  (dbpm_chain_rules_s.nextval,
                   v_chain_id,
                   v_chain_rule_cur_row.param_name, -- 表单组件上面的id
                   v_chain_rule_cur_row.param_meaning, -- 表单组件上的显示名称
                   v_chain_rule_cur_row.param_type,
                   v_chain_rule_cur_row.operation_type,
                   v_chain_rule_cur_row.param_value,
                   v_current_user,
                   v_current_user,
                   v_chain_rule_cur_row.get_value_type,
                   v_chain_rule_cur_row.rule_uuid --维护规则树关联的ruleuuid
                   );
              end loop;
              --审批链节点
              for v_chain_node_cur_row in v_chain_node_cur(v_process_chain_cur_row.chain_id) loop
                v_node_id := dbpm_chain_nodes_s.nextval;
                insert into dbpm_chain_nodes
                  (node_id,
                   chain_id,
                   node_name,
                   node_type,
                   approver_type,
                   order_num,
                   created_by,
                   last_updated_by,
                   is_required,
                   is_auto_approve,
                   version)
                values
                  (v_node_id,
                   v_chain_id,
                   v_chain_node_cur_row.node_name,
                   v_chain_node_cur_row.node_type,
                   v_chain_node_cur_row.approver_type,
                   v_chain_node_cur_row.order_num,
                   v_current_user,
                   v_current_user,
                   v_chain_node_cur_row.is_required,
                   v_chain_node_cur_row.is_auto_approve,
                   v_chain_node_cur_row.version);
                --审批链节点中文国际化
                insert into dbpm_chain_nodes_tl
                  (node_id, locale, node_name, created_by, last_updated_by)
                  select v_node_id,
                         'zh_CN',
                         t.node_name,
                         v_current_user,
                         v_current_user
                    from dbpm_chain_nodes_tl t
                   where t.node_id = v_chain_node_cur_row.node_id
                     and t.locale = 'zh_CN';
                --角色以及客户化规则数据
                proc_copy_role(v_chain_node_cur_row.node_id,
                               v_current_user,
                               v_node_id,
                               'ChainNode');
              end loop;
            end loop;
            --国际化数据与节点参数
            insert into cux_lang
              (process_code,
               lang_code,
               lang_data,
               using_type,
               node_no,
               node_name)
              select v_process_code,
                     t.lang_code,
                     t.lang_data,
                     t.using_type,
                     t.node_no,
                     t.node_name
                from cux_lang t
               where t.process_code =
                     (select dp.process_code
                        from dbpm_process dp
                       where dp.process_id = v_process_id);
            --节点参数
            insert into cux_gems_node_status_tmp
              (process_code, node_name, node_status)
              select v_process_code, st.node_name, st.node_status
                from cux_gems_node_status_tmp st
               where st.process_code =
                     (select dp.process_code
                        from dbpm_process dp
                       where dp.process_id = v_process_id);
            --基础数据维护
            basic_data_pkg.proc_itl_param_correct(v_process_code);
          end if;
        end if;
      end if;
    end if;
    x_response := v_response.to_json;
  exception
    when others then
      rollback;
      v_response.fail('操作出错，请稍后再试！');
      x_response := v_response.to_json;
      return;
  end proc_copy_process;
  /*==================================================
  procedure/function name :
      proc_copy_role
  description:
      this function perform:
      流程配置-复制流程-复制角色信息和动态找人规则
  argument:
     p_request： 请求参数
     x_response： 响应结果
  history:
      1.00  2018-02-28  echo.zeng  creation
  ==================================================*/
  procedure proc_copy_role(p_node_id      in number,
                           p_current_user in varchar2,
                           v_to_node_id   in number,
                           p_node_type    in varchar2) is
    cursor v_node_role_cur(p_node_id number) is
      select dnr.node_role_id, dnr.business_role, dnr.node_from_type
        from dbpm_node_roles dnr
       where dnr.node_id = p_node_id
         and dnr.node_from_type = p_node_type;
    cursor v_common_rule_cur(p_node_id number) is
      select t.rule_expression, t.rule_value, t.priority
        from cux_bpm_common_rule t
       where t.node_id = p_node_id;
    v_node_role_id number;
  begin
    --复制节点角色信息
    for v_node_role_cur_row in v_node_role_cur(p_node_id) loop
      v_node_role_id := dbpm_node_roles_s.nextval;
      insert into dbpm_node_roles
        (node_role_id,
         node_id,
         business_role,
         node_from_type,
         created_by,
         last_updated_by)
      values
        (v_node_role_id,
         v_to_node_id,
         v_node_role_cur_row.business_role,
         v_node_role_cur_row.node_from_type,
         p_current_user,
         p_current_user);
      --复制节点角色参数信息
      insert into dbpm_node_role_param_value
        (node_role_id, param_id, param_value, get_value_type)
        select v_node_role_id, t.param_id, t.param_value, t.get_value_type
          from dbpm_node_role_param_value t
         where t.node_role_id = v_node_role_cur_row.node_role_id;
    end loop;
    --动态找人配置或者静态找人配置
    insert into dbpm_dynamic_approvers
      (approver_id,
       node_id,
       dynamic_value,
       get_value_type,
       operation_type,
       created_by,
       last_updated_by)
      select dbpm_dynamic_approvers_s.nextval,
             v_to_node_id,
             t.dynamic_value,
             t.get_value_type,
             t.operation_type,
             p_current_user,
             p_current_user
        from dbpm_dynamic_approvers t
       where t.node_id = p_node_id;
       
    for v_common_rule_cur_row in v_common_rule_cur(p_node_id) loop
      insert into cux_bpm_common_rule t
        (common_rule_id, node_id, rule_expression, rule_value)
      values
        (cux_bpm_common_rule_s.nextval,
         v_to_node_id,
         v_common_rule_cur_row.rule_expression,
         v_common_rule_cur_row.rule_value);
    end loop;
  end proc_copy_role;

end dbpm_workspace_api_pkg;
/

