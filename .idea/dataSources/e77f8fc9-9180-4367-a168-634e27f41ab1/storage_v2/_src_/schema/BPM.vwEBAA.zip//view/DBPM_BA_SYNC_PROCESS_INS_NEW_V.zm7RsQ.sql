create view DBPM_BA_SYNC_PROCESS_INS_NEW_V as
select distinct "INSTANCE_ID","PROCESS_CODE","SYSTEM_CODE","CREATOR","PROCESS_FORM_ID","STATE","CREATION_DATE","MODIFY_DATE" from (
select distinct ci.cikey                   instance_id,
                dbp.process_id,
                dbp.process_code,
                dbp.system_code,
                wt.creator,
                wt.protectedtextattribute3 process_form_id,
                ci.state,
                ci.creation_date,
                ci.modify_date
  from cube_instance ci, wftask wt, dbpm_process dp, dbpm_ba_process dbp
 where ci.cikey = wt.instanceid
   and wt.protectedtextattribute4 = dp.process_code
   and dbp.attribute1 = 'BPM' || dp.process_id
   and wt.taskid != wt.instanceid
   and ci.composite_name='DbpmCoreProcess'
   union
select ins.instance_id,
       dbp.process_id,
       dbp.process_code,
       dbp.system_code,
       ins.instance_creator creator,
       ins.process_form_id,
       dci.state,
       dci.creation_date,
       dci.modify_date
  from cux_bpm_all_instance ins,
       cube_instance        dci,
       bpm_process_def_conf bp,
       dbpm_ba_process      dbp
 where ins.instance_id = dci.cikey
   and ins.process_code = bp.process_code
   and dbp.attribute1 = 'dbpm' || bp.id
   and dci.composite_name='GpmsOverseaBpmProcess'
union
select oins.instance_id,
       dbp.process_id,
       dbp.process_code,
       dbp.system_code,
       oins.instance_creator creator,
       oins.process_form_id,
       oci.state,
       oci.creation_date,
       oci.modify_date
  from cux_bpm_all_instance oins,
       cube_instance        oci,
       bpm_cube_process     bcp,
       dbpm_ba_process      dbp
 where oci.cikey = oins.instance_id
   and oci.composite_label = bcp.scalabel
   and dbp.attribute1 = 'obpm' || bcp.processid) v
   where not exists(
   select 1 from dbpm_ba_process_instance di where di.instance_id=v.instance_id )
/

