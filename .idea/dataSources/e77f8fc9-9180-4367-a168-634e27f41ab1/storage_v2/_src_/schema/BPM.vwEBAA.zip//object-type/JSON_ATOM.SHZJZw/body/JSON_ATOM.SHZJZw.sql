create TYPE BODY     "JSON_ATOM" is
  constructor function json_atom(p_obj_name varchar2, p_obj_value varchar2)
    return self as result is
  begin
    obj_name  := p_obj_name;
    obj_value := '"' || p_obj_value || '"';
    obj_type  := 'base';
    return;
  end;

  constructor function json_atom(p_obj_name varchar2, p_obj_value number)
    return self as result is
  begin
    obj_name  := p_obj_name;
    obj_value := p_obj_value;
    --update by Echo.Zeng 2018-01-25
    --解决0.1或-0.1变成.1和-.1问题
    IF -1 < p_obj_value AND p_obj_value < 0 THEN
      obj_value := '-0' || abs(p_obj_value);
    END IF;
    IF 0 < p_obj_value AND p_obj_value < 1 THEN
      obj_value := '0' || p_obj_value;
    END IF;
    obj_type  := 'base';
    return;
  end;

  constructor function json_atom(p_obj_name varchar2, p_obj_value BOOLEAN)
    return self as result is
  begin
    obj_name  := p_obj_name;
    IF p_obj_value THEN
      obj_value := 'true';
    ELSE
      obj_value := 'false';
    END IF;
    obj_type  := 'base';
    return;
  end;

  constructor function json_atom(p_obj_name varchar2, p_obj_value date)
    return self as result is
  begin
    obj_name  := p_obj_name;
    obj_value := '"';
    obj_value := obj_value || to_char(p_obj_value, 'yyyy-mm-dd HH24:mi:ss');
    obj_value := obj_value || '"';
    obj_type  := 'base';
    return;
  end;

  constructor function json_atom(p_obj_name varchar2, p_obj_clob clob)
    return self as result is
  begin
    obj_name := p_obj_name;
    obj_clob := '"';
    dbms_lob.append(obj_clob, p_obj_clob);
    obj_clob := obj_clob || '"';
    obj_type := 'base';
    return;
  end;

  constructor function json_atom(p_obj_name varchar2,
                                 p_obj_clob clob,
                                 p_obj_type varchar2) return self as result is
  begin
    obj_name := p_obj_name;
    obj_type := p_obj_type;
    obj_clob := p_obj_clob;
    return;
  end;

  constructor function json_atom(p_obj_name  varchar2,
                                 p_obj_value varchar2,
                                 p_obj_type  varchar2) return self as result is
  begin
    obj_name  := p_obj_name;
    obj_type  := p_obj_type;
    obj_value := p_obj_value;
    return;
  end;

  member procedure append(p_obj_value varchar2) is
  begin
    if obj_value is not null then
      obj_value := obj_value || p_obj_value;
    else
      dbms_lob.append(obj_clob, p_obj_value);
    end if;
  end;

  member procedure append(p_obj_clob clob) is
  begin
    dbms_lob.append(obj_clob, p_obj_clob);
  end;

end;

/

