create PACKAGE     "DBPM_BA_NOTI_PKG" is
  /*==================================================
  Procedure/Function Name :
      proc_query_notis
  Description:
      This function perform:
      查询预警配置，支持分页
  Argument:
     --入参 p_request json
          {
              "user": "",
              "data":
                {
                    "systemCode": "GEMS",
                    "params": {
                        "templateName": "test",
                        "templateType": "test",
                        "locale": "test",
                        "createBy": "test",
                        "enable": "test"
                    },
                    "pageNo": 1,
                    "size": 10
                }
          }
     --出参 x_response  json
          {
              "code": "SUCCESS",
              "data":
              {
                  "templates": [
                  {
                      "templateId": 1,
                      "templateName": "xxxx",
                      "type":
                      {
                          "code": "email",
                          "name": "邮件"
                      },
                      "locale":
                      {
                          "code": "en_US",
                          "name": "英语"
                      },
                      "createBy":
                      {
                          "code": "a0017702",
                          "name": "曾勇"
                      },
                      "enable":
                      {
                          "code": "Y",
                          "name": "启用"
                      }
                  },
                  {
                      "templateId": 1,
                      "templateName": "xxxx",
                      "type":
                      {
                          "code": "email",
                          "name": "邮件"
                      },
                      "locale":
                      {
                          "code": "en_US",
                          "name": "英语"
                      },
                      "createBy":
                      {
                          "code": "a0017702",
                          "name": "曾勇"
                      },
                      "enable":
                      {
                          "code": "Y",
                          "name": "启用"
                      }
                  }],
                  "pageNo": 1,
                  "total": 2
              }
          }
  History:
      1.00  2018-01-30    Echo.Zeng
  ==================================================*/
  procedure proc_query_notis(p_request  IN CLOB,x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_get_noti
  Description:
      This function perform:
      根据预警id查询预警信息
  Argument:
     --入参 p_request json
          {
              "systemCode": "GEMS",
              "warningId": 100
          }
     --出参 x_response  json
          {
              "code": "SUCCESS",
              "data":
              {
                  "warningId": 1,
                  "warningName": "",
                  "process":
                  {
                      "code": "xxxx",
                      "name": "测试"
                  },
                  "template":
                  {
                      "id": 1,
                      "name": "xxx"
                  },
                  "type": "email"
                  "startDate": "",
                  "endDate": "",
                  "enable": "Y",
                  "notificaRecipients": [
                  {
                      "code": "a0017702",
                      "name": "曾勇"
                  },
                  {
                      "code": "a0017702",
                      "name": "曾勇"
                  }],
                  "notificaCC": [
                  {
                      "code": "a0017702",
                      "name": "曾勇"
                  },
                  {
                      "code": "a0017702",
                      "name": "曾勇"
                  }],
                  "rules":
                  {
                      "ruleType": "BTW_GROUP",
                      "ruleKey": "",
                      "ruleOp": "AND",
                      "ruleValue": "",
                      "childs": [
                      {
                          "ruleType": "BTW_GROUP",
                          "ruleKey": "",
                          "ruleOp": "AND",
                          "ruleValue": "",
                          "childs": []
                      },
                      {
                          "ruleType": "BTW_GROUP",
                          "ruleKey": "",
                          "ruleOp": "AND",
                          "ruleValue": "",
                          "childs": []
                      }]
                  }
              }
          }

  History:
      1.00  2018-01-30    Echo.Zeng
  ==================================================*/
  procedure proc_get_noti(p_request  IN CLOB,x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_add_noti
  Description:
      This function perform:
      添加/编辑预警配置，支持批量
  Argument:
     --入参 p_request json
            {
                "systemCode":"GEMS",
                "warnings": [
                        "warningId": 1,
                        "warningName": "",
                        "process":"",
                        "notification":{
                            "type":"email",
                            "templateId":1
                        },
                        "startDate": "",
                        "endDate": "",
                        "enable":"Y",
                        "notificaRecipients": ["a0017702","a0017701"],
                        "notificaCC":["a0017702","a0017701"],
                        "rules":{
                            "ruleType":"BTW_GROUP",
                            "ruleKey":"",
                            "ruleOp":"AND",
                            "ruleValue":"",
                            "childs":[
                                {
                                    "ruleType":"BTW_GROUP",
                                    "ruleKey":"",
                                    "ruleOp":"AND",
                                    "ruleValue":"",
                                    "childs":[]
                                },
                                {
                                    "ruleType":"BTW_GROUP",
                                    "ruleKey":"",
                                    "ruleOp":"AND",
                                    "ruleValue":"",
                                    "childs":[]
                                }
                            ]
                        }
                    ],
                "op":"add"
            }
     --出参 x_response  json
          {
              "code": "SUCCESS",
              "userMsg":"添加/编辑成功",
              "data":{}
          }
  History:
      1.00  2018-01-30    Echo.Zeng
  ==================================================*/
  procedure proc_add_noti(p_request  IN CLOB,x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_delete_noti
  Description:
      This function perform:
      删除预警配置，支持批量
  Argument:
     --入参 p_request json
            {
                "systemCode":"GEMS",
                "warningIds": [1,2,3,4,5,6]
            }
     --出参 x_response  json
            {
                "code": "SUCCESS",
                "userMsg":"删除成功",
                "data":{}
            }
  History:
      1.00  2018-01-30    Echo.Zeng
  ==================================================*/
  procedure proc_delete_noti(p_request  IN CLOB,x_response OUT CLOB);
end DBPM_BA_NOTI_PKG;

/

