create PROCEDURE     "TEST" is
--姬洪帅
begin
  dbpa_ba_sync_pkg.proc_sync_ba_process_instance(null);
  commit;
  dbpa_ba_sync_pkg.proc_sync_ba_process_ins_act(null);
end Test;

/

