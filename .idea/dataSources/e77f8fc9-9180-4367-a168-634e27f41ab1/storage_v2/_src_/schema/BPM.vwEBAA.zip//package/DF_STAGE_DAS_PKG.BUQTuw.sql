create PACKAGE     df_stage_das_pkg IS

  -- Author  : ADOBE
  -- Created : 2016/9/22 14:43:22
  -- Purpose :
  /*==================================================
  Procedure Name :
      df_stage_instance_log
  Description:
      记录das平台接口日志
  Argument:
     p_uuid：             本次请求uuid
     p_service：          服务名称
     p_key：              关键字
     p_request_date:      请求时间
     p_request_content:   请求内容
     p_response_date:     响应时间
     p_response_content:  响应内容
     p_result:            接口调用接口（SUCCESS/FAILURE)
     p_error_log:         p_result='FAILURE'的错误日志
     p_instance_log:      标记是否记录日志
     p_request_log:       标记是否记录请求日志
     p_response_log:      标记是否记录响应日志
     x_msg:               调用结果
  History:
      1.00  2016-11-16  jianfeng.zheng  Creation
  ==================================================*/

  PROCEDURE df_stage_instance_log(p_uuid             IN VARCHAR2,
                                  p_service          IN VARCHAR2,
                                  p_key              IN VARCHAR2,
                                  p_request_date     IN DATE,
                                  p_request_content  IN CLOB,
                                  p_response_date    IN DATE,
                                  p_response_content IN CLOB,
                                  p_result           IN VARCHAR2,
                                  p_error_log        IN CLOB,
                                  p_instance_log     IN VARCHAR2,
                                  p_request_log      IN VARCHAR2,
                                  p_response_log     IN VARCHAR2,
                                  p_token            IN VARCHAR2,
                                  x_msg              OUT VARCHAR2);

  PROCEDURE df_stage_api_auth(p_token IN VARCHAR2,
                              x_code  OUT VARCHAR2,
                              x_msg   OUT VARCHAR2);
  /*==================================================
  Procedure Name :
      df_stage_login_success
  Description:
      登录成功后记录登录信息
  Argument:
     p_uid：     用户名
     p_platform: 平台
     x_token:    分配的token
     x_json：    如果接口调用失败,保存错误信息
  History:
      1.00  2016-12-10  jianfeng.zheng  Creation
  ==================================================*/
  PROCEDURE df_stage_login_success(p_uid      IN VARCHAR2,
                                   p_platform IN VARCHAR2,
                                   x_token    OUT VARCHAR2,
                                   x_json     OUT VARCHAR2);

  /*FUNCTION CURRENT_USER RETURN VARCHAR2;*/
  /*==================================================
  Procedure Name :
      get_login_user
  Description:
      根据token获取用户名
  Argument:
     p_token：             token
     x_code:              SUCCESS/FAIL
     x_msg:               错误信息
  History:
      1.00  2016-12-10  jianfeng.zheng  Creation
  ==================================================*/
  PROCEDURE df_stage_get_user(p_token IN VARCHAR2,
                              x_code  OUT VARCHAR2,
                              x_msg   OUT VARCHAR2);
  /*==================================================
  Procedure Name :
      df_stage_execute
  Description:
      动态执行存储过程或者函数
  Argument:
     p_token：            token
     p_proc_type:         PROCEDURE/FUNCTION
     p_pkg:               pkg名称
     p_proc_name:         存储过程或者函数名
     p_service:           服务名称
     x_code:              SUCCESS/FAIL
     x_msg:               错误信息
  History:
      1.00  2016-12-10  jianfeng.zheng  Creation
  ==================================================*/
  PROCEDURE df_stage_execute(p_token     IN VARCHAR2,
                             p_proc_type IN VARCHAR2,
                             p_pkg       IN VARCHAR2,
                             p_proc_name IN VARCHAR2,
                             p_service   IN VARCHAR2,
                             p_request   IN CLOB,
                             x_response  OUT CLOB);

END df_stage_das_pkg;

/

