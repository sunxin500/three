create package CUX_COMM_PKG is

  -- Author  : liangjun.wu
  -- Created : 2017/12/1 11:40:11
  -- Purpose :

  /*==================================================
  Procedure/Function Name :
      func_get_company_id
  Description:
      This function perform:
      查询员工所在的二级公司
  Argument:
     p_user_code： 员工编号
  History:
      1.00  2017-12-01  liangjun.wu  Creation
  ==================================================*/
  function func_get_company_id(p_user_code varchar2) return number;

  /*==================================================
  Procedure/Function Name :
      proc_get_company_list
  Description:
      This Procedure perform:
      获取二级公司列表
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-12-04  liangjun.wu  Creation
  ==================================================*/
  procedure proc_get_company_list(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      func_get_concatStr
  Description:
      This function perform:
     用逗号拼接字符串
  Argument:
     p_str1： 字符串1，
     p_str2： 字符串2
  History:
      1.00  2018-05-25  liangjun.wu  Creation
  ==================================================*/
  function func_get_concatStr(p_str1 varchar2, p_str2 varchar2)
    return varchar;

end CUX_COMM_PKG;

/

