create PACKAGE BODY "CUX_BPM_EXT_PKG" is

  function get_reassign_flag(p_task_id in varchar2, p_new_assignee in varchar2) return varchar2 as
    v_old_num number :=0;
    v_new_num number :=0; 
    v_flag    varchar2(100) := 'false';
 begin
    select count(1)
      into v_old_num
      from (select t.assignee
              from wfassignee t
             where t.taskid = p_task_id 
            minus
            select column_value
              from table(split(p_new_assignee, ',')));
    select count(1)
      into v_new_num
      from (select column_value
              from table(split(p_new_assignee, ','))
            minus
            select t.assignee
              from wfassignee t
             where t.taskid = p_task_id);
    --return false if  new assignees is null or null string
    if p_new_assignee is null  then
      v_flag := 'false';
      --return 'false';
    elsif v_old_num = 0 and v_new_num = 0 then
      v_flag := 'false';
      --return 'false';
    else
      v_flag := 'true';
      --return 'true';
    end if;
    cux_bpm_logger.INFO('get_reassign_flag','[p_task_id='||p_task_id||',p_new_assignee='||p_new_assignee||']'||v_flag);
    return v_flag;
  exception
    when others then
      cux_bpm_logger.INFO('get_reassign_flag_error','[p_task_id='||p_task_id||',p_new_assignee='||p_new_assignee||']'||v_flag);
      return 'false';
  end;


  function split(p_list varchar2, p_sep varchar2) return type_split
    pipelined is
    l_idx  pls_integer;
    v_list varchar2(4000) := p_list; --长度多给点
  begin
    --循环递归
    loop
      l_idx := instr(v_list, p_sep); --获取位置
      if l_idx > 0 then
        pipe row(substr(v_list, 1, l_idx - 1)); --截取
        v_list := substr(v_list, l_idx + length(p_sep)); --递归
      else
        pipe row(v_list);
        exit;
      end if;
    end loop;
    return;
  end split;

end cux_bpm_ext_pkg;
/

