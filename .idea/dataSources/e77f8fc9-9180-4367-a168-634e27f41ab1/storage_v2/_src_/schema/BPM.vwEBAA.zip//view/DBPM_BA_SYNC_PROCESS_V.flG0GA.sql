create view DBPM_BA_SYNC_PROCESS_V as
select          bcp.domainname,
                bcp.compositename,
                (select ds.space_code from dbpm_spaces ds where ds.space_id=dp.space_id) system_code,
                dp.process_name prcoess_name,
                dp.object_version_number revision,
                dp.creation_date creationdate,
                dp.last_update_date lastupdated,
                dp.process_code process_code,
                dp.created_by created_by,
                dp.last_updated_by updated_by,
                dp.process_id bpm_process_id
  from dbpm_process dp,   bpm_cube_process bcp
   where dp.bpm_process_id=bcp.processid(+)
/

