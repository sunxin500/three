create view BPM_BA_AUDIT_QUERY_V as
select tmp.start_query_id,
       tmp.end_query_id,
       baq.component_instance_id,
       baq.component_type,
       baq.step,
       baq.component_name,
       baq.composite_instance_id,
       baq.composite_dn,
       baq.composite_name,
       baq.process_name,
       baq.activity_name,
       baq.activity_id,
       baq.activity_type,
       baq.flow_element_type,
       tmp.fault_type,
       baq.scope_id,
       baq.source_activity,
       tmp.target_activity,
       baq.title,
       baq.label,
       baq.role_id,
       baq.loop_count,
       baq.instance_count,
       baq.audit_level,
       baq.ecid,
       baq.flow_id,
       baq.process_title,
       tmp.start_time,
       tmp.end_time
  from (select min(decode(t.audit_instance_type, 'START', t.query_id, null)) as start_query_id,
       min(decode(t.audit_instance_type, 'START', t.create_time, null)) as start_time,
       max(decode(t.audit_instance_type, 'END', t.query_id, null)) as end_query_id,
       max(decode(t.audit_instance_type, 'END', t.create_time, null)) as end_time,
       max(decode(t.audit_instance_type, 'END', t.target_activity, null)) as target_activity,
       max(case
             when t.fault_type is not null then
              t.fault_type
             else
              null
           end) as fault_type
  from BPM_AUDIT_QUERY t where t.component_type = 'BPMN'
 group by t.scope_id) tmp,
       BPM_AUDIT_QUERY baq
 where tmp.start_query_id = baq.query_id
/

