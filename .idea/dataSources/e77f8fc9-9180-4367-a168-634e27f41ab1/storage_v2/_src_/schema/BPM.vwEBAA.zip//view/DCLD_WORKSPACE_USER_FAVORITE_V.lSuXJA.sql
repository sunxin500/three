create view DCLD_WORKSPACE_USER_FAVORITE_V as
SELECT t.user_code,
       t.weight,
       t.space_type,
       t.business_url,
       p.process_code,
       p.process_name,
       p.process_type,
       p.description,
       p.enabled_flag,
       p.creation_date,
       p.created_by
  FROM dcld_workspace_user_favorite t, dbpm_process p
 WHERE t.process_code = p.process_code
 ORDER BY t.weight DESC
/

