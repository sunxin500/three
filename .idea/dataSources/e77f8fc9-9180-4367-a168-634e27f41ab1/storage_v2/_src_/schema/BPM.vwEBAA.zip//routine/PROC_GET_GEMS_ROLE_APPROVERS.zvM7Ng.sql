create function     proc_get_gems_role_approvers(p_role_id in varchar2,
                                                        p_org_id  in varchar2)
  return varchar2 is
  v_approvers varchar2(4000);
begin
  if p_role_id is null or p_org_id is null then
     return '';
  end if;
end proc_get_gems_role_approvers;

/

