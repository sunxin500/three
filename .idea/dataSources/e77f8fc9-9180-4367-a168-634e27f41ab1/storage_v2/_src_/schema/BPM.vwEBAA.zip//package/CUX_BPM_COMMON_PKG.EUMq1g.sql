create PACKAGE "CUX_BPM_COMMON_PKG" is

  -- AUTHOR  : xiaowei.yao 
  -- CREATED : 2020-03-17 11:52:42
  -- PURPOSE : BPM常规方法工具包

  type tasklist_cur is ref cursor;
  type approvelist_cur is ref cursor;
  type docapprovelist_cur is ref cursor;
  type process_role_cur is ref cursor;
  type process_task_step_cur is ref cursor;
  type userlist is table of varchar2(20) index by binary_integer;

  function get_user_task_count(p_emp_id    in varchar2,
                               p_sql_query in varchar2) return number;

  function get_task_url(p_sys_code in varchar2,
                        p_form_url in varchar2,
                        p_paras    in varchar2,
                        p_task_id  in varchar2,
                        p_form_key in varchar2) return varchar2;

  function get_his_form_url(p_sys_code in varchar2,
                            p_form_url in varchar2,
                            p_paras    in varchar2,
                            p_ins_id   in varchar2,
                            p_form_key in varchar2,
                            p_type     in varchar2) return varchar2;

  /**
   获取已发起流程的发起表单URL地址
  **/
  function get_request_form_url(p_instance_id in varchar2,
                                p_form_key    in varchar2) return varchar2;

  procedure get_all_user_tasks(p_emp_id            in varchar2,
                               p_orderby           in varchar2,
                               p_isasc             in varchar2,
                               p_idisplaystart     in number,
                               p_getidisplaylength in number,
                               p_sql_query         in varchar2,
                               p_count             out number,
                               p_tasklist_cur      out tasklist_cur);

  function create_approve_history(p_his_type              in varchar2,
                                  p_his_comment_detail    in varchar2,
                                  p_his_creator_id        in varchar2,
                                  p_his_approve_node      in varchar2,
                                  p_his_approve_operation in varchar2,
                                  p_his_process_code      in varchar2,
                                  p_his_form_id           in varchar2,
                                  p_instance_id           in varchar2)
    return number;

  function create_approve_his_by_taskid(p_his_type              in varchar2,
                                        p_his_comment_detail    in varchar2,
                                        p_his_creator_id        in varchar2,
                                        p_his_approve_node      in varchar2,
                                        p_his_approve_operation in varchar2,
                                        p_his_taskid            in varchar2)
    return number;

  function register_instance(p_instance_id       in varchar2,
                             p_process_code      in varchar2,
                             p_process_form_id   in varchar2,
                             p_requester_id      in varchar2,
                             p_approve_node      in varchar2,
                             p_process_desc      in varchar2,
                             p_requester_comment in varchar2) return number;

  procedure finish_instance_status(p_instance_id in varchar2);

  /***************************************************************************************
  * * * * * * * * * * * * * * * * 根据INSTANCE_ID获取到当前待办的上一个审批人  * * * * * * * * *
  ***************************************************************************************/
  function get_task_from_userid(p_instance_id in varchar2) return varchar2;


  function get_users_by_grouplist(v_group_list in userlist) return varchar2;

  function get_all_mem_groups(p_root_group in varchar2,
                              p_groups     in varchar2) return varchar2;

  /***************************************************************************************
  * * * * * * * * * * * * * * * * 根据流程编码和用户获取待办信息并分页* * * * * * * * *
  ***************************************************************************************/
  procedure get_user_tasks_process_code(p_emp_id            in varchar2,
                                        p_orderby           in varchar2,
                                        p_isasc             in varchar2,
                                        p_idisplaystart     in number,
                                        p_getidisplaylength in number,
                                        p_process_code      in varchar2,
                                        p_sql_query         in varchar2,
                                        p_count             out number,
                                        p_tasklist_cur      out tasklist_cur);
  /*procedure update_fl_contracts_status(p_form_id in varchar2,p_type in varchar2);*/

  /***************************************************************************************
  * * * * * * * * * * * * * * * * 插入审批历史的方法 - 基于instanceId* * * * * * * * *
  ***************************************************************************************/
  procedure create_his_by_instanceid(p_his_type              in varchar2,
                                     p_his_comment_detail    in varchar2,
                                     p_his_approve_node      in varchar2,
                                     p_his_approve_operation in varchar2,
                                     p_his_instanceid        in varchar2,
                                     p_his_creator           in varchar2);

  /***************************************************************************************
  * * * * * * * * * * * * * * * * 获取对应实例ID审批历史，包括待办* * * * * * * * *
  ***************************************************************************************/
  procedure get_approve_history(p_instance_id in varchar2,
                                p_locale      in varchar2,
                                p_history_cur out approvelist_cur);

  /***************************************************************************************
  * * * * * * * * * * * * * * * * 获取对应单据的审批历史，包括待办* * * * * * * * *
  ***************************************************************************************/
  procedure get_approve_history_by_doc(p_form_id     in varchar2,
                                       p_instance_id IN VARCHAR2,
                                       p_locale      in varchar2,
                                       p_history_cur out docapprovelist_cur);
  /**
      获取用户显示名称
  **/
  function get_user_displayname(p_usercode in varchar2) return varchar2;

  /**
  *  获取国际化值
     p_process_code  流程编号
     p_sys_code  系统编号
     p_locale    语言编号
     p_tl_type   国际化类型
     p_tl_key    国际化关键字
  
  
     x_tl_data   国际化数据
  **/
  FUNCTION get_tl_value(p_process_code IN VARCHAR2,
                        p_sys_code     IN VARCHAR2,
                        p_locale       IN VARCHAR2,
                        p_tl_type      IN VARCHAR2,
                        p_tl_key       IN VARCHAR2) RETURN VARCHAR2;

  /*
  获得节点的国际化值
  */
  FUNCTION get_node_tl_value(p_process_code IN VARCHAR2,
                             p_locale       IN VARCHAR2,
                             p_task_id      IN VARCHAR2,
                             p_approve_node IN VARCHAR2) RETURN VARCHAR2;

  /***************************************************************************************
  * * * * * * * * * * * * * * * *分页获取已办、已发起信息* * * * * * * * *
  ***created by xiaowei.yao 2020-03-09
  ***************************************************************************************/
  procedure get_done_submit_task(p_emp_id            in varchar2,
                                 p_orderby           in varchar2,
                                 p_isasc             in varchar2,
                                 p_his_type          in varchar2,
                                 p_sql_query         in varchar2,
                                 p_idisplaystart     in number,
                                 p_getidisplaylength in number,
                                 p_count             out number,
                                 p_approvelist_cur   out approvelist_cur);

  /**
  *  获取用户名称
     p_user_code  工号
  
     return       名称
  **/
  FUNCTION get_user_name(p_user_code IN VARCHAR2) RETURN VARCHAR2;

  /***************************************************************************************
  * * * * * * * * * * * * * * * * 撤回插入审批历史的方法 * * * * * * * * *
  ***************************************************************************************/
  function create_withrown_his(p_user              in varchar2,
                               p_task_id           in varchar2,
                               p_comment           in varchar2,
                               p_approve_operation in varchar2,
                               p_instanceid        in varchar2) return number;
  /***************************************************************************************
  * * * * * * * * * * * * * * * * 修改审批意见 * * * * * * * * *
  ***************************************************************************************/
  function update_task_comment(p_task_id in varchar2,
                               p_user    in varchar2,
                               p_comment in varchar2) return varchar2;

  /**
  *  根据instanceId批量获取当前审批人
     p_instance_ids  多个实例号用,隔开
  
     return       实例号对应的当前审批人
  **/
  PROCEDURE proc_get_approvers_by_ins(p_instance_ids IN VARCHAR2,
                                      x_approve_cur  OUT approvelist_cur);

  /*==================================================
  Procedure/Function Name :
      proc_query_process_roles
  Description:
      This function perform:
      查找流程图数据-查找流程图的角色
  Argument:
     p_instance_id：   流程实例
     p_process_code：  流程processCode
     x_process_form_id 流程单据号
     p_process_name：  流程processName
     p_process_roles:  流程配置角色
  History:
      1.00  created by xiaowei.yao 2020-03-09
  ==================================================*/
  

  /***************************************************************************************
  * * * * * * * * * * * * * * * * 插入抓取实例的审批历史* * * * * * * * *
  ***************************************************************************************/
  function create_grab_instance_his(p_user in varchar2,
                                    
                                    p_comment           in varchar2,
                                    p_approve_operation in varchar2,
                                    p_instanceid        in varchar2)
    return number;

end cux_bpm_common_pkg;
/

