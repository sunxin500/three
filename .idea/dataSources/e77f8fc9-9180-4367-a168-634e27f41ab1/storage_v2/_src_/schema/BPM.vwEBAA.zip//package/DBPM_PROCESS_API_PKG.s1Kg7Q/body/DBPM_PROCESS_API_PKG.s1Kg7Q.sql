create PACKAGE BODY     "DBPM_PROCESS_API_PKG" is

  /*==================================================
  Procedure/Function Name :
      proc_save_process
  Description:
      This function perform:
      流程配置-保存流程基本信息，需要判断是新建还是更新
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-07  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_save_process(p_request IN CLOB, x_response OUT CLOB) IS
    v_request          json;
    v_response         pl_json := pl_json;
    v_current_user     VARCHAR2(100);
    v_process_id       NUMBER;
    v_process_code     VARCHAR2(100);
    v_count            NUMBER := 0;
    v_enabled_flag     VARCHAR2(10) := 'N';
    v_space_id         number; --员工所属space
    v_is_shared        varchar2(10) := 'N'; --流程是否共享
    v_isAutoApproval   varchar2(10) := 'N'; --流程是否执行自动审批规则
    v_process_org_type VARCHAR2(100); --海尔客户化的组织类型
    --扩展外部流程
    v_process_class varchar2(500);
    v_code          varchar2(100);
    v_err_msg       varchar2(4000);
    --扩展外部流程
    --绑定流程服务
    v_services     json_list;
    v_service      json;
    v_service_id   number;
    v_invoke_stage varchar2(100);
    v_invoke_order number;
    v_service_req  clob;
    --绑定流程邮件
    v_emails       json_list;
    v_email        json;
    v_email_id     number;
    v_email_name   varchar2(100);
    v_send_stage   varchar2(100);
    v_content_clob clob;
    v_recipients   varchar2(2000);
    --保存国际化值
    v_process_itl_list json_list;
    v_itl_item         json;
    v_itl_lang         VARCHAR2(300);
    v_itl_locale       VARCHAR2(300);
    v_locale           varchar2(24);
    --绑定超期规则
    v_expires json_list;
    v_expire  json;
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;
    if v_request.locale = 'en' then
      v_locale := 'en_US';
    else
      v_locale := 'zh_CN';
    end if;
    v_process_code := v_request.get('processCode').get_string;
    v_space_id     := v_request.get_string('spaceId');
    if v_space_id is null then
      v_space_id := DFND_ADMIN_PKG.func_get_space_id(v_current_user);
    end if;
    IF v_request.get('processId') IS NULL OR v_request.get('processId')
      .get_number = 0 THEN
      v_process_id := dbpm_process_s.nextval;
      -- 先验证同一空间下流程编码不能重复
      SELECT COUNT(1)
        INTO v_count
        FROM dbpm_process dp
       WHERE dp.process_code = v_process_code;
      --  AND dp.space_id = v_space_id;
      IF v_count > 0 THEN
        --v_response.fail('流程编码不能重复，请确认！');
        v_response.fail(DCLD_COMM_PKG.func_get_err_msg('DCLD-00019',
                                                       v_request.locale));
        x_response := v_response.to_json;
        RETURN;
      END IF;
    ELSE
      v_process_id := v_request.get('processId').get_number;
      -- 先验证同一空间下流程编码不能重复
      SELECT COUNT(1)
        INTO v_count
        FROM dbpm_process dp
       WHERE dp.process_code = v_process_code;
      -- AND dp.space_id = v_space_id;
      IF v_count = 1 THEN
        null;
      else
        --v_response.fail('流程编码不能重复，请确认！');
        v_response.fail(DCLD_COMM_PKG.func_get_err_msg('DCLD-00019',
                                                       v_request.locale));
        x_response := v_response.to_json;
        RETURN;
      END IF;
    END IF;

    IF v_request.get('isEnabled') IS NOT NULL AND v_request.get('isEnabled')
      .get_bool = TRUE THEN
      v_enabled_flag := 'Y';
    END IF;

    IF v_request.get('isShared') IS NOT NULL AND v_request.get('isShared')
      .get_bool = TRUE THEN
      v_is_shared := 'Y';
    END IF;
    IF v_request.get('isAutoApproval') IS NOT NULL AND v_request.get('isAutoApproval')
      .get_bool = TRUE THEN
      v_isAutoApproval := 'Y';
    END IF;

    SELECT COUNT(1)
      INTO v_count
      FROM dbpm_process dp
     WHERE dp.process_id = v_process_id;
    v_process_org_type := v_request.get_string('processOrgType');

    IF v_count > 0 THEN
      UPDATE dbpm_process dp
         SET dp.process_code          = v_request.get('processCode')
                                        .get_string,
             dp.process_name          = v_request.get('processName')
                                        .get_string,
             dp.description           = v_request.get('description')
                                        .get_string,
             dp.process_type          = v_request.get('processType')
                                        .get_string,
             dp.enabled_flag          = v_enabled_flag,
             dp.is_shared             = v_is_shared,
             dp.cux_auto_approve_flag = v_isAutoApproval,
             dp.bpm_process_id        = v_request.get_number('bpmProcessId'),
             dp.process_class         = v_request.get_string('processClass'),
             dp.form_url              = v_request.get_string('externalFormUrl'),
             dp.doc_sys_code          = v_request.get_string('docSysCode'),
             dp.cux_org_type          = v_process_org_type
       WHERE dp.process_id = v_process_id;
      -- 修改多语言表
      UPDATE dbpm_process_tl dpt
         SET dpt.process_name = v_request.get('processName').get_string,
             dpt.description  = v_request.get('description').get_string
       WHERE dpt.process_id = v_process_id
         AND dpt.locale = v_locale;
    ELSE
      INSERT INTO dbpm_process
        (process_id,
         process_code,
         process_name,
         process_type,
         description,
         enabled_flag,
         created_by,
         last_updated_by,
         space_id,
         is_shared,
         bpm_process_id,
         process_class,
         form_url,
         doc_sys_code,
         cux_org_type,
         cux_auto_approve_flag)
      VALUES
        (v_process_id,
         v_request.get('processCode').get_string,
         v_request.get('processName').get_string,
         v_request.get('processType').get_string,
         v_request.get('description').get_string,
         v_enabled_flag,
         v_current_user,
         v_current_user,
         v_space_id,
         nvl(v_is_shared, 'N'),
         v_request.get_number('bpmProcessId'),
         NVL(v_request.get_string('processClass'), 'INTERNAL'),
         v_request.get_string('externalFormUrl'),
         NVL(v_request.get_string('docSysCode'), 'BPM'),
         v_process_org_type,
         v_isAutoApproval);
      -- 插入多语言表

      INSERT INTO dbpm_process_tl
        (process_id,
         locale,
         process_name,
         description,
         created_by,
         last_updated_by)
      VALUES
        (v_process_id,
         'zh_CN',
         v_request.get('processName').get_string,
         v_request.get_string('description'),
         v_current_user,
         v_current_user);
      INSERT INTO dbpm_process_tl
        (process_id,
         locale,
         process_name,
         description,
         created_by,
         last_updated_by)
      VALUES
        (v_process_id,
         'en_US',
         v_request.get('processName').get_string,
         v_request.get_string('description'),
         v_current_user,
         v_current_user);
    END IF;
    --保存流程名称国际化值
    if v_request.path('processNametl') is not null then
      v_process_itl_list := json_list(v_request.path('processNametl'));
      if v_process_itl_list.count > 0 then
        delete from dbpm_process_tl dt where dt.process_id = v_process_id;
      end if;
      ---  v_process_id := v_request.get('processId').get_number;
      for v_index in 1 .. v_process_itl_list.count loop
        v_itl_item   := json(v_process_itl_list.get(v_index));
        v_itl_lang   := v_itl_item.get_string('lang');
        v_itl_locale := v_itl_item.get_string('locale');
        INSERT into dbpm_process_tl
          (process_id,
           locale,
           process_name,
           last_updated_by,
           last_update_date)
        VALUES
          (v_process_id,
           v_itl_locale,
           v_itl_lang,
           v_request.username,
           sysdate);
      end loop;
    end if;
    --关联流程和服务信息
    if v_request.path('services') is not null then
      v_services := json_list(v_request.path('services'));
      --覆盖保存
      delete from dbpm_process_service_map dm
       where dm.process_id = v_process_id;
      for i in 1 .. v_services.count loop
        v_service      := json(v_services.get(i));
        v_service_id   := v_service.get_number('serviceId');
        v_invoke_stage := v_service.get_string('invokeStage');
        v_invoke_order := v_service.get_number('invokeOrder');
        if v_service.path('serviceReq') is not null then
          dbms_lob.createtemporary(v_service_req, false);
          json(v_service.get('serviceReq')).to_clob(v_service_req);
        end if;
        insert into dbpm_process_service_map
          (map_id,
           invoke_stage,
           process_id,
           object_version_number,
           service_id,
           created_by,
           creation_date,
           last_updated_by,
           last_update_date,
           invoke_order,
           service_req)
        values
          (dbpm_process_service_map_s.nextval,
           v_invoke_stage,
           v_process_id,
           1,
           v_service_id,
           v_current_user,
           sysdate,
           v_current_user,
           sysdate,
           v_invoke_order,
           v_service_req);
      end loop;
    end if;
    --关联流程和邮件信息
    if v_request.path('emails') is not null then
      delete from dbpm_process_email_map dm
       where dm.process_id = v_process_id;
      v_emails := json_list(v_request.path('emails'));
      for j in 1 .. v_emails.count loop
        v_email      := json(v_emails.get(j));
        v_email_id   := v_email.get_number('emailId');
        v_send_stage := v_email.get_string('sendStage');
        v_email_name := v_email.get_string('emailName');
        v_recipients := v_email.get_string('recipients');
        if v_email.path('content') is not null then
          dbms_lob.createtemporary(v_content_clob, false);
          json(v_email.get('content')).to_clob(v_content_clob);
        end if;
        insert into dbpm_process_email_map
          (map_id,
           send_stage,
           process_id,
           object_version_number,
           email_id,
           created_by,
           creation_date,
           last_updated_by,
           last_update_date,
           content,
           email_name,
           recipients， recipients_type)
        values
          (dbpm_process_email_map_s.nextval,
           v_send_stage,
           v_process_id,
           1,
           v_email_id,
           v_current_user,
           sysdate,
           v_current_user,
           sysdate,
           v_content_clob,
           v_email_name,
           v_recipients,
           v_email.get_string('recipientsType'));
      end loop;
    end if;
    --关联流程和超期信息
    if v_request.path('expires') is not null then
      null;
      delete from dbpm_process_expire_rule dr
       where dr.process_code = v_request.get('processCode').get_string;
      v_expires := json_list(v_request.get('expires'));
      for i in 1 .. v_expires.count loop
        v_expire := json(v_expires.get(i));
        null;
        insert into dbpm_process_expire_rule
          (id,
           rule_uuid,
           rule_type,
           process_code,
           param_name,
           param_meaning,
           status,
           param_value,
           start_time,
           end_time,
           creation_date,
           created_by,deloy_day,
           warning_dur,
           warning_num)
        values
          (dbpm_process_expire_rule_s.nextval,
           v_expire.get_string('ruleUuid'),
           'INSTANCE',
           v_request.get('processCode').get_string,
           v_expire.get_string('paramName'),
           v_expire.get_string('paramMeaning'),
           'Y',
           v_expire.get_number('paramValue'),
           v_expire.get_date('startTime'),
           v_expire.get_date('endTime'),
           sysdate,
           v_current_user,
           v_expire.get_number('deloyDay'),
            v_expire.get_number('warningDur'),
            v_expire.get_number('warningNum'));
      end loop;
    end if;

    -- 关联流程表单与表单信息
    IF v_request.get('formId') IS NOT NULL THEN
      -- 先把流程关联的原来表单置空
      UPDATE dbpm_form df
         SET df.process_id = ''
       WHERE df.process_id = v_process_id;

      -- 根据表单code更新表单流程
      UPDATE dbpm_form df
         SET df.process_id = v_process_id
       WHERE df.form_code =
             (select dft.form_code
                from dbpm_form dft
               where dft.form_id = v_request.get('formId').get_number);
    END IF;
    --扩展外部流程
    v_process_class := v_request.get_string('processClass');
    if v_process_class = 'EXTERNAL' THEN
      null;
      DBPM_PROCESS_EXT_PKG.proc_save_ext_process(v_process_id,
                                                 '',
                                                 v_request.locale,
                                                 v_code,
                                                 v_err_msg);
      if v_code = 'N' then
        v_response.fail(v_err_msg);
        x_response := v_response.to_json;
        ROLLBACK;
        RETURN;
      end if;
    END IF;
    --扩展外部流程
    v_response.set_value('processId', v_process_id);
    x_response := v_response.to_json;
  END proc_save_process;

  PROCEDURE proc_save_process_tl(p_request CLOB, x_response OUT CLOB) IS
    v_request          json;
    v_response         pl_json := pl_json;
    v_process_itl_list json_list;
    v_itl_item         json;
    v_itl_code         VARCHAR2(300);
    v_itl_value        VARCHAR2(300);
    v_process_id       VARCHAR2(300);
    v_process_code     VARCHAR2(300);
    v_count            NUMBER;
  BEGIN
    v_request          := json(p_request);
    v_process_itl_list := json_list(v_request.path('processItl'));
    v_process_id       := v_request.get('processId').get_number;
    FOR v_index IN 1 .. v_process_itl_list.count LOOP
      v_itl_item  := json(v_process_itl_list.get(v_index));
      v_itl_code  := v_itl_item.get('itlCode').get_string;
      v_itl_value := v_itl_item.get('itlValue').get_string;
      IF v_process_id IS NOT NULL THEN
        SELECT MAX(t.process_code)
          INTO v_process_code
          FROM dbpm_process t
         WHERE t.process_id = v_process_id;
        --导入流程国际化中间表
        SELECT COUNT(1)
          INTO v_count
          FROM cux_lang t
         WHERE t.process_code = v_process_code
           AND t.lang_code = v_itl_code
           AND t.using_type = '流程名';
        IF v_count > 0 THEN
          UPDATE cux_lang t
             SET t.lang_data = v_itl_value
           WHERE t.process_code = v_process_code
             AND t.lang_code = v_itl_code
             AND t.using_type = '流程名';
        ELSE
          INSERT INTO CUX_LANG
            (PROCESS_CODE, LANG_CODE, LANG_DATA, USING_TYPE)
          VALUES
            (v_process_code, v_itl_code, v_itl_value, '流程名');
        END IF;

      END IF;
    END LOOP;
    x_response := v_response.to_json;
  END proc_save_process_tl;

  /*==================================================
  Procedure/Function Name :
      proc_save_process_owner
  Description:
      This function perform:
      流程配置-维护流程主人
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-07-16  wlj  create
  ==================================================*/
  PROCEDURE proc_save_process_owner(p_request CLOB, x_response OUT CLOB) AS
    v_request       json;
    v_response      pl_json := pl_json;
    v_process_owner varchar2(100);
    v_current_user  varchar2(100);
    v_process_id    number;
  BEGIN
    v_request       := json(p_request, 'OBJECT');
    v_current_user  := v_request.username;
    v_process_owner := v_request.get_string('processOwner');
    v_process_id    := v_request.get_number('processId');
    update dbpm_process dp
       set dp.process_owner    = upper(v_process_owner),
           dp.last_updated_by  = v_current_user,
           dp.last_update_date = sysdate
     where dp.process_id = v_process_id;
    x_response := v_response.to_json;
  END;

end dbpm_process_api_pkg;

/

