create view DBPM_TASK_DRAFTS_QUERY_V as
SELECT NULL task_id,
       dd.document_id,
       dd.form_id,
       dd.process_id,
       dd.doc_number      task_number,
       dd.title,
       dd.status,
       dpt.process_name,
       dp.process_code,
       dp.process_type,
       dd.doc_create_time creation_date,
       dd.doc_creator     created_user_code,
       dd.doc_sys_code,
       dp.process_class,
       dd.doc_url
  FROM dbpm_documents dd, dbpm_process dp, dbpm_process_tl dpt
 WHERE dd.process_id = dp.process_id
   AND dp.process_id = dpt.process_id
   AND dpt.locale = dbpm_comm_pkg.get_current_locale
   AND dd.status = 'NEW'
/

