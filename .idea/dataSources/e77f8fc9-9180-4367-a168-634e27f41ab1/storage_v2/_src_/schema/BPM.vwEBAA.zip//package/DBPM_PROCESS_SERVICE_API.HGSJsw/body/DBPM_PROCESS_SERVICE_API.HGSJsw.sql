create package body     DBPM_PROCESS_SERVICE_API is
  -- Author  : yxw
  -- Created : 2019/02/20 12:00
  -- Purpose : 流程服务功能

  /*==================================================
  Procedure/Function Name :
      proc_save_service
  Description:
      This function perform:
      保存服务配置
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2019-02-20  yxw  Creation
  ==================================================*/
  procedure proc_save_service(p_request in clob, x_response out clob) is
    v_service_id   number;
    v_service_code varchar2(200);
    v_request      json;
    v_count        number;
    v_response     pl_json := pl_json;
    v_service_req  clob;
  begin
    v_request      := json(p_request, 'OBJECT');
    v_service_code := v_request.get_string('serviceCode');
    v_service_id   := v_request.get_number('serviceId');
    select count(1)
      into v_count
      from dbpm_service ds
     where ds.service_code = v_service_code
       and ds.delete_flag = 'N';
      IF v_request.path('serviceReq') IS NOT NULL THEN
      dbms_lob.createtemporary(v_service_req, false);
      json(v_request.get('serviceReq')).to_clob(v_service_req);
    END IF;
    if v_service_id is null then
      if v_count > 0 then
        --服务编码不可重复
        v_response.fail(DCLD_COMM_PKG.func_get_err_msg('DCLD-00028',
                                                       v_request.locale));
        x_response := v_response.to_json;
        return;
      end if;
      v_service_id := dbpm_service_s.nextval;
      insert into dbpm_service
        (id,
         service_name,
         service_catalog,
         service_path,
         service_desc,
         enabled_flag,
         object_version_number,
         creation_date,
         created_by,
         last_updated_by,
         last_update_date,
         SERVICE_CODE,
         service_req,
         service_contentType,
         request_method
         )
      values
        (v_service_id,
         v_request.get_string('serviceName'),
         v_request.get_string('serviceType'),
         v_request.get_string('servicePath'),
         v_request.get_string('serviceDesc'),
         v_request.get_string('enabledFlag'),
         1,
         sysdate,
         v_request.username,
         v_request.username,
         sysdate,
         v_service_code,
         v_service_req,
         v_request.get_string('contentType'),
         v_request.get_string('requestMethod'));
    else
      update dbpm_service ds
         set ds.service_name          = v_request.get_string('serviceName'),
             ds.service_catalog       = v_request.get_string('serviceType'),
             ds.service_path          = v_request.get_string('servicePath'),
             ds.service_desc          = v_request.get_string('serviceDesc'),
             ds.enabled_flag          = v_request.get_string('enabledFlag'),
             ds.last_updated_by       = v_request.username,
             ds.last_update_date      = sysdate,
             ds.object_version_number = ds.object_version_number + 1,
             ds.service_req =v_service_req,
             ds.service_contenttype=v_request.get_string('contentType'),
             ds.request_method=v_request.get_string('requestMethod')
       where ds.id = v_service_id;
    end if;
    v_response.set_value('serviceId', v_service_id);
    x_response := v_response.to_json;
  end proc_save_service;
  /*==================================================
  Procedure/Function Name :
      proc_query_service
  Description:
      This function perform:
      查询服务配置
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2019-02-20  yxw  Creation
  ==================================================*/
  procedure proc_query_service(p_request in clob, x_response out clob) is
    v_service_name varchar2(2000);
    v_service_id   number;
    v_service_path varchar2(2000);
    --v_search_content varchar2(4000);
    v_page     NUMBER;
    v_size     NUMBER;
    v_request  json;
    v_line     pl_json;
    v_response pl_json := pl_json;
    CURSOR v_service_cursor is
      select *
        from (select v.*, rownum cnt
                from (SELECT count(1) over(partition by 1) total,
                             ds.id,
                             ds.service_name,
                             ds.service_path,
                             ds.service_code,
                             ds.service_catalog,
                             ds.service_desc,
                             ds.enabled_flag,
                             ds.creation_date，
                             ds.service_req,
                             ds.service_contenttype,
                             ds.request_method
                        FROM dbpm_service ds
                       WHERE ds.delete_flag = 'N'
                         and INSTR(NVL(ds.service_name, 'NL'),
                                   NVL(v_service_name,
                                       NVL(ds.service_name, 'NL'))) > 0
                         AND INSTR(NVL(ds.service_path, 'NL'),
                                   NVL(v_service_path,
                                       NVL(ds.service_path, 'NL'))) > 0
                         and ds.id=nvl(v_service_id,ds.id)
                       order by ds.last_update_date asc) v
               where rownum <= v_page * v_size)
       where cnt > (v_page - 1) * v_size;

  begin
    v_request := json(p_request, 'OBJECT');
    v_page    := nvl(v_request.get_number('page'), 1);
    v_size    := nvl(v_request.get_number('size'), 20);

    v_service_id :=v_request.get_number('serviceId');

    for v_service_row in v_service_cursor loop
      v_line := pl_json;
      v_response.set_value('total', v_service_row.total);
      v_line.set_value('serviceId', v_service_row.id);
      v_line.set_value('serviceName', v_service_row.service_name);
      v_line.set_value('servicePath', v_service_row.service_path);
      v_line.set_value('serviceCode', v_service_row.service_code);
      v_line.set_value('serviceType', v_service_row.service_catalog);
      v_line.set_value('serviceDesc', v_service_row.service_desc);
      v_line.set_value('enabledFlag', v_service_row.enabled_flag);
       v_line.set_value('requestMethod', v_service_row.request_method);
      v_line.set_value('createDate',
                       to_char(v_service_row.creation_date, 'yyyy-mm-dd'));
      v_line.set_value('contentType', v_service_row.service_contenttype);
      if v_service_row.service_req is not null then
        v_line.set_value('serviceReq', json(v_service_row.service_req));
      end if;
      v_response.add_list_item('services', v_line);

    end loop;

    x_response := v_response.to_json;
  end proc_query_service;
  /*==================================================
  Procedure/Function Name :
      proc_del_service
  Description:
      This function perform:
      删除服务配置
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2019-02-21  yxw  Creation
  ==================================================*/
  procedure proc_del_service(p_request in clob, x_response out clob) is
    v_service_id number;
    v_request    json;
    v_ids        json_list;
    v_id         json := json;
    v_response   pl_json := pl_json;
  begin
    v_request := json(p_request, 'OBJECT');

    v_ids := json_list(v_request.get('serviceIds'));
    for i in 1 .. v_ids.count loop
      v_id := json(v_ids.get(i));
      update dbpm_service ds
         set ds.delete_flag = 'Y'
       where ds.id = v_id.get_number('serviceId');
    end loop;
    x_response := v_response.to_json;
  end proc_del_service;
end DBPM_PROCESS_SERVICE_API;

/

