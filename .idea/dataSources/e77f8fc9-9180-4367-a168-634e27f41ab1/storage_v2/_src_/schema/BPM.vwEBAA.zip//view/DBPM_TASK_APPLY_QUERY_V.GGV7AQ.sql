create view DBPM_TASK_APPLY_QUERY_V as
SELECT dd.document_id      task_id,
       dd.document_id,
       dd.form_id,
       dd.process_id,
       dd.doc_number       task_number,
       dd.title,
       dd.status,
       dpt.process_name,
       dp.process_code,
       dp.process_type,
       dd.doc_create_time  creation_date,
       dd.doc_creator      created_user_code,
       t.approve_user_code,
       t.approve_user_name,
       dd.doc_sys_code,
       dp.process_class,
       dd.doc_url,
       dd.bpm_instance_id,
       ci.state
  FROM dbpm_documents dd,
       dbpm_process dp,
       dbpm_process_tl dpt,
       cube_instance ci,
       (select instanceid, approve_user_code, approve_user_name
          from (SELECT instanceid,
                       listagg(otv.assignee, ',') within GROUP(ORDER BY otv.assignee) OVER(PARTITION BY otv.instanceid) as approve_user_code,
                       listagg(otv.employee_name, ',') within GROUP(ORDER BY otv.employee_name) OVER(PARTITION BY otv.instanceid) as approve_user_name
                  FROM (SELECT otv.instanceid, df.employee_name, otv.assignee
                          FROM dbpm_obpm_todo_v otv, dfnd_employees df
                         WHERE upper(df.employee_code) = upper(otv.assignee)) otv)
         group by instanceid, approve_user_code, approve_user_name) t
 WHERE dd.process_id = dp.process_id
   and dd.bpm_instance_id = t.instanceid(+)
   and dd.bpm_instance_id = ci.cikey
   AND dp.process_id = dpt.process_id
   AND dpt.locale = dbpm_comm_pkg.get_current_locale
   AND dd.status <> 'NEW'
/

