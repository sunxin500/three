create PACKAGE dbpm_form_api_pkg IS

  /*==================================================
  Procedure/Function Name :
      proc_query_all_process_form
  Description:
      This function perform:
      查询所有流程表单
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-01  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_query_all_process_form(p_request  CLOB,
                                        x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_save_process_form
  Description:
      This function perform:
      保存流程表单
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-01  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_save_process_form(p_request CLOB, x_response OUT CLOB);
  /*==================================================
  Procedure/Function Name :
      proc_get_form_config_html
  Description:
      This function perform:
      获取流程表单配置模版
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-01  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_get_form_config_html(p_request CLOB, x_response OUT CLOB);
  /*==================================================
  Procedure/Function Name :
      proc_delete_form
  Description:
      This function perform:
      删除流程表单配置
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-05  chenming  Creation
  ==================================================*/

  /*==================================================
  Procedure/Function Name :
      proc_get_form_process_html
  Description:
      This function perform:
      获取流程表单数据模块
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-01  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_get_form_process_html(p_request CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_delete_process_form
  Description:
      This function perform:
      删除流程表单配置
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-05  chenming  Creation
  ==================================================*/
  PROCEDURE proc_delete_process_form(p_request CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_get_process_form
  Description:
      This function perform:
      获取流程表单配置
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-05  chenming  Creation
  ==================================================*/
  PROCEDURE proc_get_process_form(p_request CLOB, x_response OUT CLOB);
  /*
  * 生成configlist
  */
  FUNCTION func_get_form_config(p_request CLOB, p_response pl_json)
    RETURN pl_json;

  /*==================================================
  Procedure/Function Name :
      proc_save_document_data
  Description:
      This function perform:
      保存表单数据，需要判断是新建还更新
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-05  chenming  Creation
  ==================================================*/
  PROCEDURE proc_save_document_data(p_request CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_get_document_data
  Description:
      This function perform:
      获取表单数据
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-08  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_get_document_data(p_request CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_query_form_fields
  Description:
      This function perform:
      查询某个表单的所有字段
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-11  chenming  Creation
  ==================================================*/
  PROCEDURE proc_query_form_fields(p_request CLOB, x_response OUT CLOB);
  /*==================================================
  Procedure/Function Name :
      proc_relate_process_form
  Description:
      This function perform:
      关联流程与表单
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-11  chenming  Creation
  ==================================================*/
  PROCEDURE proc_relate_process_form(p_request CLOB, x_response OUT CLOB);
  /*
  * 获取复选框显示值
  */
  FUNCTION func_get_checkbox_disvalue(p_data_source_code VARCHAR2,
                                      p_value            VARCHAR2)
    RETURN VARCHAR2;

  /*==================================================
  Procedure/Function Name :
      proc_edit_process_form
  Description:
      This function perform:
      编辑流程表单（升级）
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-10-06  zhoujian.wang  Creation
  ==================================================*/
  PROCEDURE proc_edit_process_form(p_request CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_query_process_form
  Description:
      This function perform:
      查询所有的表单
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-10-06  zhiheng.wei  Creation
  ==================================================*/
  PROCEDURE proc_query_process_form(p_request CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_query_comm_process_form
  Description:
      This function perform:
      查询通用表单
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-11-30  liangjun.wu  Creation
  ==================================================*/
  PROCEDURE proc_query_comm_process_form(p_request  CLOB,
                                         x_response OUT CLOB);
  /*==================================================
  Procedure/Function Name :
      proc_delete_process_form
  Description:
      This function perform:
      删除表单
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-01-31  jinglun.xu  Creation
  ==================================================*/
  PROCEDURE proc_delete_process(p_request CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_save_document_data_ext
  Description:
      This function perform:
      扩展外部表单
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-05-16  wlj  Creation
  ==================================================*/
  PROCEDURE proc_save_document_data_ext(p_request  CLOB,
                                        x_response OUT CLOB);

END dbpm_form_api_pkg;

/

