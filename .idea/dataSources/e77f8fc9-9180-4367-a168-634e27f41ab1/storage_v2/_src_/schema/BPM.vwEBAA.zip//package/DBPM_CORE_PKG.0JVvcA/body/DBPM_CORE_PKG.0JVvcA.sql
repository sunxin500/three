create PACKAGE BODY     dbpm_core_pkg IS

  /*
  * 获取单据信息
  */
  PROCEDURE proc_get_document_info(p_document_id     VARCHAR2,
                                   x_creator         OUT VARCHAR2,
                                   x_creator_name    OUT VARCHAR2,
                                   x_creation_time   OUT VARCHAR2,
                                   x_title           OUT VARCHAR2,
                                   x_process_id      OUT NUMBER,
                                   x_process_code    OUT VARCHAR2,
                                   x_form_id         OUT NUMBER,
                                   x_document_number OUT VARCHAR2) IS
    v_process_name VARCHAR2(200);
  BEGIN
    SELECT dd.doc_creator,
           dd.doc_creator_name,
           dd.doc_create_time,
           dd.title,
           dd.process_id,
           dd.form_id,
           dd.doc_number
      INTO x_creator,
           x_creator_name,
           x_creation_time,
           x_title,
           x_process_id,
           x_form_id,
           x_document_number
      FROM BPM.dbpm_documents dd
     WHERE dd.document_id = p_document_id;

    SELECT dpt.process_name, dp.process_code
      INTO v_process_name, x_process_code
      FROM dbpm_process dp, dbpm_process_tl dpt
     WHERE dp.process_id = dpt.process_id
       AND dpt.locale = dbpm_comm_pkg.get_current_locale
       AND dp.process_id = x_process_id;

    IF x_title IS NULL THEN
      x_title := '由' || x_creator_name || '在' || x_creation_time || '发起的' ||
                 v_process_name || '，需要您的审批';
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      x_creator         := '';
      x_creator_name    := '';
      x_creation_time   := '';
      x_title           := '';
      x_document_number := '';

  END proc_get_document_info;
  /*
  * 关联单据与流程ID
  */
  PROCEDURE proc_update_instance_id(p_document_id     VARCHAR2,
                                    p_bpm_instance_id VARCHAR2) IS

  BEGIN
    UPDATE BPM.dbpm_documents dd
       SET dd.bpm_instance_id = p_bpm_instance_id
     WHERE dd.document_id = p_document_id;
  END proc_update_instance_id;

  /*
  * 修改单据状态
  */
  PROCEDURE proc_update_document_status(p_document_id VARCHAR2,
                                        p_status      VARCHAR2) IS

  BEGIN
    UPDATE BPM.dbpm_documents dd
       SET dd.status = p_status
     WHERE dd.document_id = p_document_id;
  END proc_update_document_status;
  /*
  * 获取审批链ID
  */
  PROCEDURE proc_get_chain_id(p_organization_id VARCHAR2,
                              p_process_id      NUMBER,
                              p_document_id     NUMBER,
                              p_process_param   dbpm_process_param_rec,
                              p_business_param  dbpm_business_param_tbl,
                              x_chain_id        OUT NUMBER,
                              x_result_flag     OUT VARCHAR2,
                              x_error_msg       OUT VARCHAR2) IS
    v_compare_result  VARCHAR2(10);
    v_organization_id VARCHAR2(100);
    v_count           NUMBER := 0;
    v_exist_flag      VARCHAR2(10) := 'N';
    -- 有规则的审批链
    CURSOR v_chain_cur(p_organization_id VARCHAR2) IS
      SELECT *
        FROM BPM.dbpm_approval_chain dac
       WHERE /*dac.organization_id =
                                                                                                                                                                                                                                                                                                                   nvl(p_organization_id, dac.organization_id)
                                                                                                                                                                                                                                                                                                               AND*/
       dac.process_id = p_process_id
       AND dac.chain_type <> 'SubChain'
       and nvl(dac.is_deleted, 'N') = 'N'
       and (SELECT COUNT(1)
          FROM dbpm_chain_rules dcr
         WHERE dcr.chain_id = dac.chain_id) > 0;
  BEGIN
    /* IF p_document_id IS NOT NULL THEN
      -- 从p_organization_id开始，逐级向上查找维护了审批链的组织ID
      FOR v_organization IN (SELECT do.organization_id
                               FROM dfnd_organizations do
                              START WITH do.organization_id =
                                         p_organization_id
                             CONNECT BY do.organization_id = PRIOR
                                        do.parent_organization_id) LOOP
        SELECT COUNT(1)
          INTO v_count
          FROM BPM.dbpm_approval_chain dac
         WHERE dac.process_id = p_process_id
           AND dac.organization_id = v_organization.organization_id
           AND dac.chain_type <> 'SubChain';
        IF v_count > 0 THEN
          v_organization_id := v_organization.organization_id;
          v_exist_flag      := 'Y';
          EXIT;
        END IF;
      END LOOP;

      IF v_exist_flag = 'N' THEN
        x_chain_id    := NULL;
        x_result_flag := 'N';
        x_error_msg   := '当前组织或其上级组织，没有维护审批链信息，请确认！';
        RETURN;
      END IF;
    END IF;*/

    FOR v_chain IN v_chain_cur(v_organization_id) LOOP
      proc_get_chain_rule_result(p_chain_id       => v_chain.chain_id,
                                 p_document_id    => p_document_id,
                                 p_process_param  => p_process_param,
                                 p_business_param => p_business_param,
                                 x_result         => v_compare_result,
                                 x_result_flag    => x_result_flag,
                                 x_error_msg      => x_error_msg);
      /* updated by 2017-7-17 yong.zeng
      IF x_result_flag = 'N' THEN
        RETURN;
      END IF;
      */
      IF v_compare_result = 'Y' THEN
        x_chain_id := v_chain.chain_id;
        RETURN;
      END IF;
    END LOOP;
    /* created by 2017-7-17 yong.zeng
    * 当没有存在有规则的审批链或者所有的规则审批链都不满足
    * 查找默认审批链
    */
    BEGIN
      SELECT dac.chain_id
        INTO x_chain_id
        FROM BPM.dbpm_approval_chain dac
       WHERE dac.organization_id =
             nvl(v_organization_id, dac.organization_id) --update by wlj 2018-06-28
            --nvl(p_organization_id, dac.organization_id)
         AND dac.process_id = p_process_id
         and nvl(dac.is_deleted, 'N') = 'N'
         AND (SELECT COUNT(1)
                FROM dbpm_chain_rules dcr
               WHERE dcr.chain_id = dac.chain_id) = 0;
      x_result_flag := 'Y';
      x_error_msg   := '';
    EXCEPTION
      WHEN OTHERS THEN
        x_result_flag := 'N';
        x_error_msg   := '未找到符合条件的审批链';
    END;
  END proc_get_chain_id;

  /*
  * 判断当前审批链的审批规则是否满足
  */
  PROCEDURE proc_get_chain_rule_result(p_chain_id       NUMBER,
                                       p_document_id    VARCHAR2,
                                       p_process_param  dbpm_process_param_rec,
                                       p_business_param dbpm_business_param_tbl,
                                       x_result         OUT VARCHAR2,
                                       x_result_flag    OUT VARCHAR2,
                                       x_error_msg      OUT VARCHAR2) IS
    CURSOR v_chain_param_cur IS
      SELECT dcr.param_name,
             dcr.param_type,
             dcr.param_value,
             dcr.operation_type,
             dcr.get_value_type, --migrate by xiaowei.yao 20180416
             dcr.rule_uuid
        FROM dbpm_chain_rules dcr
       WHERE dcr.chain_id = p_chain_id;
    v_result          VARCHAR2(10);
    v_field_value     VARCHAR2(4000);
    v_exist_rule_tree boolean := true; --add by wlj 是否存在规则树
    v_rule_list       json_list; --add by wlj 表示规则树的json
    v_rule_str        VARCHAR2(32767 byte); --add by wlj 规则字符串
    v_rule_sql        VARCHAR2(32767 byte) := 'select count(1) from dual where '; --add by wlj
    v_compare_result  number; --add by wlj 比较的结果true = 1,false =0
    v_rule_tree       clob;
  BEGIN
    x_result_flag := 'Y';
    x_error_msg   := '';

    BEGIN
      SELECT TREE.CHAIN_RULE_TREE
        INTO v_rule_tree
        FROM DBPM_CHAIN_RULES_TREE TREE
       WHERE TREE.CHAIN_ID = p_chain_id;
      v_rule_list := json_list(v_rule_tree);
      v_rule_str  := dbpm_rule_api_pkg.func_parse_rule(v_rule_list);
    EXCEPTION
      WHEN OTHERS THEN
        v_exist_rule_tree := false;
    END;

    FOR v_param IN v_chain_param_cur LOOP
      -- 循环每一组参数，判断是否成立
      -- 获取参数值--海尔没有表单所以当表单ID为空是，走老逻辑。表单不为空走新逻辑
      IF p_document_id IS NOT NULL THEN
        -- 内部表单，从表单中获取
        IF v_param.get_value_type = 'FIELD' THEN
          -- 内部表单，从表单中获取
          v_field_value := func_get_form_field_value(p_id          => v_param.param_name,
                                                     p_document_id => p_document_id);
        ELSIF v_param.get_value_type = 'PROCESSPARAM' THEN
          -- 外部表单，从参数中获取
          v_field_value := func_get_process_param_value(p_param_code  => v_param.param_name,
                                                        p_document_id => p_document_id);
        END IF;

      ELSE
        -- 外部表单，从参数中获取
        v_field_value := func_get_process_param_value(p_business_param     => p_business_param,
                                                      p_process_param_code => v_param.param_name);
      END IF;
      -- 获取条件判断结果
      v_result := func_get_compare_result(p_data_type => v_param.param_type,
                                          p_operation => v_param.operation_type,
                                          p_from_data => v_field_value,
                                          p_to_data   => v_param.param_value);
      -- 若不存在规则树
      IF not (v_exist_rule_tree) THEN
        -- 默认为AND操作，只要有一个条件不成立，则返回N
        IF v_result <> 'Y' THEN
          x_result := 'N';
          RETURN;
        END IF;
      ELSE
        IF v_result <> 'Y' THEN
          v_compare_result := 0;
        ELSE
          v_compare_result := 1;
        END IF;
        v_rule_str := replace(v_rule_str,
                              ':' || v_param.rule_uuid,
                              v_compare_result);
      END IF;
    END LOOP;
    IF v_exist_rule_tree THEN
      --使用利用sql语法判断规则的结果
      v_rule_sql := v_rule_sql || v_rule_str;
      --  dbms_output.put_line(p_chain_id);
      dbms_output.put_line(p_chain_id || 'rules :' || v_rule_sql);
      execute immediate v_rule_sql
        INTO v_compare_result;
      IF v_compare_result = 1 THEN
        x_result := 'Y';
      ELSE
        x_result := 'N';
      END IF;
    END IF;
  END proc_get_chain_rule_result;

  /*
  * 获取比较结果
  */
  FUNCTION func_get_compare_result(p_data_type VARCHAR2,
                                   p_operation VARCHAR2,
                                   p_from_data VARCHAR2,
                                   p_to_data   VARCHAR2) RETURN VARCHAR2 IS
    v_to_data VARCHAR2(4000);
    v_count   number;
  BEGIN
    IF p_data_type = 'NUMBER' THEN
      IF p_operation = '>' THEN
        IF to_number(p_from_data) > to_number(p_to_data) THEN
          RETURN 'Y';
        ELSE
          RETURN 'N';
        END IF;
      ELSIF p_operation = '>=' THEN
        IF to_number(p_from_data) >= to_number(p_to_data) THEN
          RETURN 'Y';
        ELSE
          RETURN 'N';
        END IF;
      ELSIF p_operation = '<' THEN
        IF to_number(p_from_data) < to_number(p_to_data) THEN
          RETURN 'Y';
        ELSE
          RETURN 'N';
        END IF;
      ELSIF p_operation = '<=' THEN
        IF to_number(p_from_data) <= to_number(p_to_data) THEN
          RETURN 'Y';
        ELSE
          RETURN 'N';
        END IF;
      ELSIF p_operation = '=' THEN
        IF to_number(p_from_data) = to_number(p_to_data) THEN
          RETURN 'Y';
        ELSE
          RETURN 'N';
        END IF;
      ELSIF p_operation = '<>' THEN
        IF to_number(p_from_data) <> to_number(p_to_data) THEN
          RETURN 'Y';
        ELSE
          RETURN 'N';
        END IF;
      END IF;
    ELSIF p_data_type = 'VARCHAR' THEN
      IF p_operation = '=' THEN
        IF p_from_data = p_to_data THEN
          RETURN 'Y';
        ELSE
          RETURN 'N';
        END IF;
      ELSIF p_operation = '<>' THEN
        IF p_from_data <> p_to_data THEN
          RETURN 'Y';
        ELSE
          RETURN 'N';
        END IF;
        ---增加对空值的判断 add by xiaoweri.yao  2019-2-26 begin
      ELSIF p_operation = 'IS' THEN
        select count(1) into v_count from dual where p_from_data is null;
        IF v_count = 1 THEN
          RETURN 'Y';
        ELSE
          RETURN 'N';
        END IF;
      ELSIF p_operation = 'IS NOT' THEN
        select count(1)
          into v_count
          from dual
         where p_from_data is not null;
        IF v_count = 1 THEN
          RETURN 'Y';
        ELSE
          RETURN 'N';
        END IF;
        ---增加对空值的判断 add by xiaoweri.yao 2019-2-26 end
      ELSIF p_operation = 'IN' THEN
        v_to_data := REPLACE(p_to_data, '，', ',');
        FOR v_data IN (SELECT regexp_substr(v_to_data, '[^,]+', 1, rownum) sub_date
                         FROM dual
                       CONNECT BY rownum <=
                                  length(v_to_data) -
                                  length(REPLACE(v_to_data, ',', '')) + 1) LOOP
          IF TRIM(p_from_data) = TRIM(v_data.sub_date) THEN
            RETURN 'Y';
          END IF;
        END LOOP;
        RETURN 'N';
        --update by xuy 20170715
        --comment: add (not in) 判断条件
      ELSIF TRIM(p_operation) = TRIM('NOTIN') THEN
        v_to_data := REPLACE(p_to_data, '，', ',');
        FOR v_data IN (SELECT regexp_substr(v_to_data, '[^,]+', 1, rownum) sub_date
                         FROM dual
                       CONNECT BY rownum <=
                                  length(v_to_data) -
                                  length(REPLACE(v_to_data, ',', '')) + 1) LOOP
          IF TRIM(p_from_data) = TRIM(v_data.sub_date) THEN
            RETURN 'N';
          END IF;
        END LOOP;
        RETURN 'Y';
      ELSIF p_operation = 'LIKE' THEN
        IF instr(p_from_data, p_to_data) > 0 THEN
          RETURN 'Y';
        ELSE
          RETURN 'N';
        END IF;
      END IF;
    END IF;
    RETURN 'N';
  END func_get_compare_result;

  /*
  * 获取审批链
  */
  PROCEDURE proc_get_approval_chain(p_document_id    VARCHAR2,
                                    p_process_param  dbpm_process_param_rec,
                                    p_business_param dbpm_business_param_tbl,
                                    x_chain          OUT dbpm_approval_chain_rec,
                                    x_result_flag    OUT VARCHAR2,
                                    x_error_msg      OUT VARCHAR2) IS
    v_chain_id NUMBER;
    -- 流程参数
    v_process_param dbpm_process_param_rec := dbpm_process_param_rec(NULL,
                                                                     NULL,
                                                                     NULL,
                                                                     NULL,
                                                                     NULL,
                                                                     NULL,
                                                                     NULL);
    -- 业务参数
    /*   v_business_param  dbpm_business_param_tbl := dbpm_business_param_tbl();
    v_chain           dbpm_approval_chain_rec := dbpm_approval_chain_rec(NULL,
                                                                         NULL,
                                                                         NULL,
                                                                         NULL,
                                                                         NULL,
                                                                         NULL);
    v_chain_nodes     dbpm_chain_node_tbl := dbpm_chain_node_tbl();
    v_index           NUMBER;*/ --把获取审批链的逻辑抽离出来。
    v_process_id      NUMBER;
    v_organization_id VARCHAR2(100);
  BEGIN
    x_result_flag := 'Y';
    x_error_msg   := '';

    -- 1. 获取审批链ID
    IF p_document_id IS NOT NULL THEN
      BEGIN
        SELECT dd.organization_id
          INTO v_organization_id
          FROM dbpm_documents dd
         WHERE dd.document_id = p_document_id;
      EXCEPTION
        WHEN OTHERS THEN
          x_result_flag := 'N';
          x_error_msg   := '获取表单对应的OrganizationId时出错，错误信息为：' || SQLERRM;
          RETURN;
      END;
    END IF;
    SELECT dp.process_id
      INTO v_process_id
      FROM dbpm_process dp
     WHERE dp.process_code = p_process_param.processcode;
    --通过流程的发起的传进来的参数流程编码就可以找到流程ID，不需要去DOC表里通过DocId查找ProcessId。--comment by xiaowei.yao 20180416
    proc_get_chain_id(p_organization_id => v_organization_id,
                      p_process_id      => v_process_id,
                      p_document_id     => p_document_id,
                      p_process_param   => p_process_param,
                      p_business_param  => p_business_param,
                      x_chain_id        => v_chain_id,
                      x_result_flag     => x_result_flag,
                      x_error_msg       => x_error_msg);
    IF x_result_flag = 'N' THEN
      raise_application_error(-20001, p_process_param.processCode);
    END IF;

    -- 2. 根据审批链ID获取审批链基本信息
    /*   BEGIN
      SELECT dac.chain_id,
             dac.chain_name,
             dac.chain_type,
             dac.organization_id,
             dac.process_id
        INTO v_chain.chain_id,
             v_chain.chain_name,
             v_chain.chain_type,
             v_chain.organization_id,
             v_chain.process_id
        FROM dbpm_approval_chain dac
       WHERE dac.chain_id = v_chain_id;
    EXCEPTION
      WHEN OTHERS THEN
        x_result_flag := 'N';
        x_error_msg   := '获取审批链基本信息时出错，错误信息为：' || SQLERRM;
        RETURN;
    END;

    -- 3. 循环获取审批链环节信息
    v_index := 1;
    FOR v_chain_node IN (SELECT dcn.node_id, dcn.node_name, dcn.node_type
                           FROM dbpm_chain_nodes dcn
                          WHERE dcn.chain_id = v_chain_id
                          ORDER BY dcn.order_num) LOOP
      v_chain_nodes.extend;
      v_chain_nodes(v_index) := dbpm_chain_node_rec(v_chain_node.node_id,
                                                    v_chain_node.node_name,
                                                    v_chain_node.node_type);

      v_index := v_index + 1;
    END LOOP;

    v_chain.chain_nodes := v_chain_nodes;

    x_chain := v_chain;*/
    proc_get_approval_chain(p_chain_id    => v_chain_id,
                            x_chain       => x_chain,
                            x_result_flag => x_result_flag,
                            x_error_msg   => x_error_msg);

  END proc_get_approval_chain;
  /*
  * 获取审批链
  */
  PROCEDURE proc_get_approval_chain(p_chain_id    NUMBER,
                                    x_chain       OUT dbpm_approval_chain_rec,
                                    x_result_flag OUT VARCHAR2,
                                    x_error_msg   OUT VARCHAR2) IS
    v_chain       dbpm_approval_chain_rec := dbpm_approval_chain_rec(NULL,
                                                                     NULL,
                                                                     NULL,
                                                                     NULL,
                                                                     NULL,
                                                                     NULL);
    v_chain_nodes dbpm_chain_node_tbl := dbpm_chain_node_tbl();
    v_index       NUMBER;
  BEGIN
    x_result_flag := 'Y';
    x_error_msg   := '';

    -- 2. 根据审批链ID获取审批链基本信息
    BEGIN
      SELECT dac.chain_id,
             dac.chain_name,
             dac.chain_type,
             dac.organization_id,
             dac.process_id
        INTO v_chain.chain_id,
             v_chain.chain_name,
             v_chain.chain_type,
             v_chain.organization_id,
             v_chain.process_id
        FROM dbpm_approval_chain dac
       WHERE dac.chain_id = p_chain_id;
    EXCEPTION
      WHEN OTHERS THEN
        x_result_flag := 'N';
        x_error_msg   := '获取审批链基本信息时出错，错误信息为：' || SQLERRM;
        RETURN;
    END;

    -- 3. 循环获取审批链环节信息
    v_index := 1;
    FOR v_chain_node IN (SELECT dcn.node_id, dcn.node_name, dcn.node_type
                           FROM dbpm_chain_nodes dcn
                          WHERE dcn.chain_id = p_chain_id
                            AND DCN.IS_DELETED = 'N'
                          ORDER BY dcn.order_num) LOOP
      v_chain_nodes.extend;
      v_chain_nodes(v_index) := dbpm_chain_node_rec(v_chain_node.node_id,
                                                    v_chain_node.node_name,
                                                    v_chain_node.node_type);

      v_index := v_index + 1;
    END LOOP;

    v_chain.chain_nodes := v_chain_nodes;

    x_chain := v_chain;
  END proc_get_approval_chain;

  /*
  * 获取审批人
  */
  PROCEDURE proc_get_approvers(p_node_id        NUMBER,
                               p_document_id    VARCHAR2,
                               p_process_param  dbpm_process_param_rec,
                               p_business_param dbpm_business_param_tbl,
                               x_approvers      OUT VARCHAR2,
                               x_result_flag    OUT VARCHAR2,
                               x_error_msg      OUT VARCHAR2) IS
    v_approver_type   VARCHAR2(100);
    v_process_id      NUMBER;
    v_sql             VARCHAR2(4000);
    v_admin_user      varchar2(4000);
    v_is_require      varchar2(10); --节点找不到人时，是否可以跳过,add by wlj
    v_is_auto_approve varchar2(10); --是否允许自动审批,add by wlj
    v_node_name       varchar2(4000); --add by wlj
    v_latest_approver varchar2(1000); --上一个审批人,add by wlj
    v_doc_creator     varchar2(30); --流程发起人,add by wlj
  BEGIN
    -- 先判断是否存在客户化扩展方式的取人逻辑，如果存在，使用扩展方式取人逻辑，否则使用标准方式
    SELECT dp.process_id
      INTO v_process_id
      FROM dbpm_process dp
     WHERE dp.process_code = p_process_param.processcode;

    -- 1. 获取审批节点的审批人类型
    --migrate by xiaowei.yao 20180416
    SELECT dcn.approver_type,
           dcn.is_required,
           dcn.node_name,
           dcn.is_auto_approve
      INTO v_approver_type, v_is_require, v_node_name，v_is_auto_approve
      FROM dbpm_chain_nodes dcn
     WHERE dcn.node_id = p_node_id;
    --update by zengyong 20171127
    if v_approver_type is null then
      SELECT dcn.approver_type
        INTO v_approver_type
        FROM dbpm_chain_nodes_reversion dcn
       WHERE dcn.node_id = p_node_id;
    end if;
    --update by Echo.Zeng 2017-11-27 end

    if v_approver_type = 'StaticUser' THEN
      -- 静态人员获取审批人

      select da.dynamic_value
        into x_approvers
        from dbpm_dynamic_approvers da
       where da.node_id = p_node_id;

    ELSIF v_approver_type = 'ManagementChain' THEN
      -- 管理链获取审批人
      NULL;
      --节点子审批链
    ELSIF v_approver_type = 'SubProcess' THEN
      NULL;
    ELSIF v_approver_type = 'Creator' THEN
      -- 创建人获取审批人
      x_approvers   := p_process_param.processapplier;
      x_result_flag := 'Y';
      x_error_msg   := '';
    ELSIF v_approver_type = 'SelectUsers' THEN
      -- 获取选择的审批人-就是审批人可以指定下一个审批人
      SELECT listagg(dsa.approvers, ',') within GROUP(ORDER BY dsa.approver_id)
        INTO x_approvers
        FROM dbpm_selected_approvers dsa
       WHERE dsa.document_id = p_document_id
         AND dsa.node_id = p_node_id;
      x_result_flag := 'Y';
      x_error_msg   := '';
      -- add by chenzhibin begin
    ELSIF v_approver_type = 'DynamicUser' THEN
      proc_get_node_dynamic_users(p_node_id        => p_node_id,
                                  p_document_id    => p_document_id,
                                  p_process_param  => p_process_param,
                                  p_business_param => p_business_param,
                                  x_approvers      => x_approvers,
                                  x_result_flag    => x_result_flag,
                                  x_error_msg      => x_error_msg);
      -- add by chenzhibin begin
    ELSE
      proc_get_approvers_plugin(p_approver_type  => v_approver_type,
                                p_node_id        => p_node_id,
                                p_document_id    => p_document_id,
                                p_process_param  => p_process_param,
                                p_business_param => p_business_param,
                                x_approvers      => x_approvers,
                                x_result_flag    => x_result_flag,
                                x_error_msg      => x_error_msg);
      IF x_result_flag = 'NO_DATA_FOUND' THEN
        -- 如果插件没找到，调用标准的参数化角色获取审批人
        proc_get_role_approvers(p_node_id        => p_node_id,
                                p_document_id    => p_document_id,
                                p_process_param  => p_process_param,
                                p_business_param => p_business_param,
                                x_approvers      => x_approvers,
                                x_result_flag    => x_result_flag,
                                x_error_msg      => x_error_msg);
      END IF;
    END IF;
    --如果返回x_result_flag=N,则抛出异常，防止滑批
    IF x_result_flag = 'N' THEN
      raise_application_error(-20001, '查找的审批人为空');
    END IF;
    --获取上一个审批人-migrate by xiaowei.yao 20180416 begin
    begin
      select approver_code
        into v_latest_approver
        from (select *
                from DBPM_APPROVAL_HISTORY t
               where t.document_id = p_document_id
               order by t.history_id desc)
       where rownum = 1;
    exception
      when no_data_found then
        v_latest_approver := v_doc_creator;
    end;
    if v_latest_approver is not null and x_approvers = v_latest_approver and
       v_is_auto_approve = 'Y' then
      INSERT INTO DBPM_APPROVAL_HISTORY
        (HISTORY_ID,
         DOCUMENT_ID,
         NODE_NAME,
         APPROVER_CODE,
         APPROVER_NAME,
         OPERATION,
         COMMENT_DETAIL)
      VALUES
        (DBPM_APPROVAL_HISTORY_S.NEXTVAL,
         p_document_id,
         v_node_name,
         x_approvers,
         '系统管理员',
         'APPROVE',
         '自动审批');
      x_approvers := '';
      return;
    end if;
    -- add by chenzhibin begin
    -- 如果是没有找到审批人的话，需要把代办分配至对应二级公司的管理员

    if instr(upper(x_approvers), upper('weblogic')) > 0 then

      -- add by wlj begin
      -- 如果配置了找不到人可以跳过的话，则直接调到下个节点
      if v_is_require = 'Y' then
        --填写审批历史
        INSERT INTO DBPM_APPROVAL_HISTORY
          (HISTORY_ID,
           DOCUMENT_ID,
           NODE_NAME,
           APPROVER_CODE,
           APPROVER_NAME,
           OPERATION,
           COMMENT_DETAIL)
        VALUES
          (DBPM_APPROVAL_HISTORY_S.NEXTVAL,
           p_document_id,
           v_node_name,
           x_approvers,
           '系统管理员',
           'APPROVE',
           '找不到审批人，跳到下一个节点');
        --将x_approvers设置为空，则会自动调到下个节点
        x_approvers := '';
        return;
      end if;
      -- add by wlj end
      begin
        select da.user_code
          into v_admin_user
          from dbpm_documents dd, dbpm_administrators da
         where dd.document_id = p_document_id
           and dd.company_id = da.organization_id
           and rownum = 1;
      exception
        when others then
          v_admin_user := 'weblogic';
      end;
      select REPLACE(x_approvers, upper('weblogic'), v_admin_user)
        into x_approvers
        from dual;

      select REPLACE(x_approvers, 'weblogic', v_admin_user)
        into x_approvers
        from dual;
    end if;
    --获取上一个审批人-migrate by xiaowei.yao 20180416 end
  EXCEPTION
    WHEN OTHERS THEN
      x_error_msg   := '调用proc_get_approvers获取审批人时出错，错误信息为：' || x_error_msg ||
                       '异常为：' || SQLERRM;
      x_result_flag := 'N';
      raise_application_error(-20001,
                              x_error_msg || '查找的审批人为空   ' || p_node_id ||
                              'processCode =  ' ||
                              p_process_param.processCode ||
                              ',processFormNo =  ' ||
                              p_process_param.processFormNo);
  END proc_get_approvers;
  /*
  * 根据参数化角色获取审批人
  */
  PROCEDURE proc_get_role_approvers(p_node_id        NUMBER,
                                    p_document_id    VARCHAR2,
                                    p_process_param  dbpm_process_param_rec,
                                    p_business_param dbpm_business_param_tbl,
                                    x_approvers      OUT VARCHAR2,
                                    x_result_flag    OUT VARCHAR2,
                                    x_error_msg      OUT VARCHAR2) IS
    TYPE role_member_cursor_type IS REF CURSOR; -- 动态游标
    v_role_member_cursor role_member_cursor_type;
    v_role_code          VARCHAR2(100);
    v_member_code        VARCHAR2(100);
    -- 节点审批角色
    CURSOR v_node_role_cur IS
      SELECT *
        FROM BPM.dbpm_node_roles dnr
       WHERE dnr.node_id = p_node_id;
    -- 角色成员（包含参数）
    CURSOR v_role_member_cur(p_role_code VARCHAR2, p_node_id NUMBER) IS
      SELECT dr.role_code, drm.member_code
        FROM BPM.dbpm_roles              dr,
             BPM.dbpm_role_members       drm,
             BPM.dbpm_role_params        drp,
             BPM.dbpm_role_member_params drmp
       WHERE dr.role_id = drm.role_id
         AND dr.role_id = drp.role_id
         AND drp.param_id = drmp.param_id
         AND drp.role_id = dr.role_id
         AND drmp.member_id = drm.member_id
         AND drmp.param_value =
             dbpm_core_pkg.func_get_node_role_param_value(p_node_id,
                                                          dr.role_code,
                                                          drp.param_id,
                                                          p_document_id,
                                                          p_business_param)
         AND dr.role_code = p_role_code;
    v_role_id        NUMBER;
    v_role_has_param VARCHAR2(10);
    v_sql            VARCHAR2(4000);
    v_where          VARCHAR2(4000);
    v_operation_type VARCHAR2(100);
    v_param_value    VARCHAR2(4000);
  BEGIN
    -- 1. 获取审批节点配置的业务角色
    FOR v_node_role IN v_node_role_cur LOOP
      SELECT dr.role_id
        INTO v_role_id
        FROM BPM.dbpm_roles dr
       WHERE dr.role_code = v_node_role.business_role;
      -- 2. 获取角色成员
      v_role_has_param := func_is_role_has_param(p_role_id => v_role_id);

      IF v_role_has_param = 'Y' THEN
        -- 循环参数
        v_sql := 'SELECT member_code FROM dbpm_role_members drm WHERE drm.role_id = ''' ||
                 v_role_id || ''' ';
        FOR v_node_role_param IN (SELECT *
                                    FROM dbpm_role_params drp
                                   WHERE drp.role_id = v_role_id) LOOP
          -- 拿到角色成员参数值，拿到配置的参数值
          v_operation_type := dbpm_core_pkg.func_get_node_role_param_ope(p_node_id,
                                                                         v_node_role.business_role,
                                                                         v_node_role_param.param_id,
                                                                         p_document_id,
                                                                         p_business_param);
          v_param_value    := dbpm_core_pkg.func_get_node_role_param_value(p_node_id,
                                                                           v_node_role.business_role,
                                                                           v_node_role_param.param_id,
                                                                           p_document_id,
                                                                           p_business_param);
          -- 设置只校验 param value 不等于 空的情况下  modify by chenzhibin
          IF (v_operation_type = '=' OR v_operation_type = '>' OR
             v_operation_type = '<' OR v_operation_type = '>=' OR
             v_operation_type = '<=' OR v_operation_type = '<>') and
             v_operation_type is not null and v_param_value is not null THEN
            -- 从members表中过滤出符合条件的人员
            v_where := v_where || 'AND EXISTS ' ||
                       '(SELECT 1 FROM dbpm_role_member_params drmp ' ||
                       'WHERE drmp.member_id = drm.member_id ' ||
                       'AND drmp.param_id = ' || v_node_role_param.param_id || ' ' ||
                       'AND drmp.param_value ' || v_operation_type || '''' ||
                       v_param_value || ''') ';
          ELSIF v_operation_type = 'IN' and v_operation_type is not null and
                v_param_value is not null THEN
            v_where := v_where || 'AND EXISTS ' ||
                       '(SELECT 1 FROM dbpm_role_member_params drmp ' ||
                       'WHERE drmp.member_id = drm.member_id ' ||
                       'AND drmp.param_id = ' || v_node_role_param.param_id || ' ' ||
                       'AND instr(''' || v_param_value ||
                       ''',drmp.param_value) > 0)';
          ELSIF v_operation_type = 'LIKE' and v_operation_type is not null and
                v_param_value is not null THEN
            v_where := v_where || 'AND EXISTS ' ||
                       '(SELECT 1 FROM dbpm_role_member_params drmp ' ||
                       'WHERE drmp.member_id = drm.member_id ' ||
                       'AND drmp.param_id = ' || v_node_role_param.param_id || ' ' ||
                       'AND instr(drmp.param_value, ''' || v_param_value ||
                       ''') > 0)';
          END IF;
          -- modify by chenzhibin  end
        END LOOP;

        v_sql := v_sql || v_where;
        dbms_output.put_line(v_sql);
        -- 2.1 如果包含角色参数的，需计算角色参数值，然后过滤角色成员
        OPEN v_role_member_cursor FOR v_sql;
        LOOP
          FETCH v_role_member_cursor
            INTO v_member_code;
          EXIT WHEN v_role_member_cursor%NOTFOUND;
          x_approvers := x_approvers || v_member_code || ',';
        END LOOP;
        CLOSE v_role_member_cursor;

        /*   -- 2.1 如果包含角色参数的，需计算角色参数值，然后过滤角色成员
        FOR v_role_member IN v_role_member_cur(v_node_role.business_role,
                                               p_node_id) LOOP
          x_approvers := x_approvers || v_role_member.member_code || ',';
        END LOOP;*/
      ELSE
        -- 2.2 如果不包含角色参数的，直接取角色成员
        FOR v_role_member IN (SELECT *
                                FROM BPM.dbpm_role_members drm
                               WHERE drm.role_id = v_role_id) LOOP
          x_approvers := x_approvers || v_role_member.member_code || ',';
        END LOOP;
      END IF;
    END LOOP;
    IF x_approvers IS NULL THEN
      x_approvers   := 'weblogic';
      x_result_flag := 'N';
    ELSE
      x_approvers   := substr(x_approvers, 0, length(x_approvers) - 1);
      x_result_flag := 'Y';
    END IF;

    x_error_msg := '';

  EXCEPTION
    WHEN OTHERS THEN
      x_error_msg   := '调用proc_get_role_approvers获取审批人时出错，错误信息为：' ||
                       SQLERRM;
      x_result_flag := 'N';
  END proc_get_role_approvers;

  /*
  * 获取动态参数用户
  */
  procedure proc_get_node_dynamic_users(p_node_id        NUMBER,
                                        p_document_id    VARCHAR2,
                                        p_process_param  dbpm_process_param_rec,
                                        p_business_param dbpm_business_param_tbl,
                                        x_approvers      OUT VARCHAR2,
                                        x_result_flag    OUT VARCHAR2,
                                        x_error_msg      OUT VARCHAR2) is
    v_op_type            varchar2(100);
    v_dynamic_filed_id   varchar2(100);
    v_value_type         varchar2(100);
    v_dynamic_value      varchar2(400);
    v_process_param_code varchar2(100);
  begin
    select dda.dynamic_value, dda.get_value_type, dda.operation_type
      into v_dynamic_filed_id, v_value_type, v_op_type
      from DBPM_DYNAMIC_APPROVERS dda
     where dda.node_id = p_node_id;
    if v_value_type = 'FIELD' then
      x_approvers := func_get_form_field_value(p_id          => v_dynamic_filed_id,
                                               p_document_id => p_document_id);

    elsif v_value_type = 'PROCESSPARAM' then
      /* select t.param_code
       into v_process_param_code
       from dbpm_process_params t
      where t.param_id = v_dynamic_filed_id;*/
      x_approvers := func_get_process_param_value(p_business_param,
                                                  v_dynamic_filed_id);
    elsif v_value_type = 'SQL' then
      begin
        x_approvers := func_get_approver_by_sql(p_node_id,
                                                p_document_id,
                                                p_process_param,
                                                p_business_param);

      exception
        when no_data_found then
          --不满足规则，根据部门找人
          /* cux_gems_user_org_pkg.proc_get_approvers_ext(p_node_id        => p_node_id,
          p_document_id    => p_document_id,
          p_process_param  => p_process_param,
          p_business_param => p_business_param,
          x_approvers      => x_approvers,
          x_result_flag    => x_result_flag,
          x_error_msg      => x_error_msg);*/
          proc_get_approvers_plugin(p_approver_type  => 'DynamicUser',
                                    p_node_id        => p_node_id,
                                    p_document_id    => p_document_id,
                                    p_process_param  => p_process_param,
                                    p_business_param => p_business_param,
                                    x_approvers      => x_approvers,
                                    x_result_flag    => x_result_flag,
                                    x_error_msg      => x_error_msg);
      end;
    end if;
    /*if x_approvers is null or trim(x_approvers) = '' then
      x_approvers := 'weblogic';
    end if;*/
    dbms_output.put_line(x_approvers);
    begin
      if x_approvers is null then
        raise_application_error(-20001,
                                'nodeId:' || p_node_id ||
                                ',根据客户化找人规则查询审批人为空！');
      end if;
    exception
      when others then
        x_result_flag := 'N';
        x_error_msg   := '根据动态用户获取审批人失败';
    end;
    --节点人是weblogic，标识该节点需要滑过。
    if x_approvers = 'weblogic' then
      x_result_flag := 'Y';
      x_approvers   := NULL;
      x_error_msg   := '该节点需要自动滑过';
    end if;
  end;

  procedure proc_get_sql(v_sqlq     in varchar2,
                         p_business in DBPM_BUSINESS_PARAM_REC,
                         x_sql      out varchar2,
                         x_flag     out varchar2) is
    v_rule_exs    varchar2(128);
    v_index       number := -1;
    v_next_tmp    varchar2(2);
    v_Previou_tmp varchar2(2);
  begin
    --循环传入的参数
    x_sql := v_sqlq;
    --循环sql语句，查询 paramkey在 sql语句中的位置，直到查询不到 paramkey
    for m in 1 .. length(v_sqlq) loop
      --一直循环到去不到
      v_index := instr(v_sqlq, p_business.paramkey, 1, m);

      if v_index = 0 then
        --查询不到，退出本循环
        x_flag := 'F';
        exit;
      else
        --获取之后一个字符，和之前一个字符
        v_next_tmp    := substr(v_sqlq,
                                v_index + length(p_business.paramkey),
                                1);
        v_Previou_tmp := substr(v_sqlq, v_index - 1, 1);
        --如果为 之后一个字符为 = < > 或者空格  并且 之前一个字符 为 或者空格 说明为参数
        if ((v_next_tmp = '=' or v_next_tmp = '<' or v_next_tmp = ' ' or
           v_next_tmp = '>') and
           (v_Previou_tmp = '(' or v_Previou_tmp = ')' or
           v_Previou_tmp = ' ' or v_Previou_tmp is null or v_index = 1)) or
           ((v_Previou_tmp = '(' or v_Previou_tmp = ')' or
           v_Previou_tmp = '=' or v_Previou_tmp = '<' or
           v_Previou_tmp = ' ' or v_next_tmp = '>') and
           (v_next_tmp = ' ' or v_next_tmp is null)) then
          x_sql  := substr(v_sqlq, 1, v_index - 1) || '''' ||
                    p_business.paramvalue || '''' ||
                    substr(v_sqlq,
                           v_index + length(p_business.paramkey),
                           length(v_sqlq));
          x_flag := 'T';
          exit;
        end if;

      end if;
    end loop;
  end proc_get_sql;

  /*
  * 根据sql获取审批人
  */
  FUNCTION func_get_approver_by_sql(p_node_id        NUMBER,
                                    p_document_id    VARCHAR2,
                                    p_process_param  dbpm_process_param_rec,
                                    p_business_param dbpm_business_param_tbl)
    RETURN VARCHAR2 IS
    CURSOR v_rule_cur(v_node_id number) IS
      select t.rule_expression, t.rule_value, t.get_value_type
        from cux_bpm_common_rule t
       where t.node_id = v_node_id
       order by t.priority;
    v_rule_ex         varchar2(3000);
    v_rule_exs        varchar2(3000);
    v_sql_str         varchar2(4000);
    v_approvers       varchar2(4000);
    v_count           number;
    v_approver_type   varchar2(300);
    v_result_flag     varchar2(300);
    v_error_msg       varchar2(300);
    v_paramvalue_temp varchar2(300); --update by xiaowei.yao 20180703
    v_index           number;
    v_index_tmp       number := 0;
    v_tmp             varchar2(2);
  BEGIN
    --判断规则
    for v_rule_cur_row in v_rule_cur(p_node_id) loop
      --获取规则表达式
      v_rule_ex  := v_rule_cur_row.rule_expression;
      v_rule_exs := v_rule_cur_row.rule_expression;
      --替换表达式中的变量成具体值
      for i in 1 .. p_business_param.count loop
        --add by xiaowei.yao 20180703 begin

        -- 以下代码为将传入参数的paramvalue字符串按照','分割后，排序输出到v_paramvalue_temp，存在问题：将输入参数的字符串进行了改变，不符合逻辑，所以去掉 --zsq 20200221
        /*select LISTAGG(col, ',') WITHIN GROUP(ORDER BY col)
        into v_paramvalue_temp
        from (select regexp_substr(p_business_param(i).paramvalue,
                                   '[^,]+',
                                   1,
                                   level) col
                from dual
              connect by level <=
                         regexp_count(p_business_param(i).paramvalue, ',') + 1) t;*/
        --add by xiaowei.yao 20180703 end;
        /*        v_paramvalue_temp := p_business_param(i).paramvalue;

        --以下代码为将 页面配置sql中的字符串以 paramkey 进行替换，存在问题：所有与paramkey匹配的字符串都会被替换为paramvalue的值，不符合逻辑；暂时不知道怎么修改 -zsq 20200221
        -- 希望达到的效果：能正确匹配字符串中的参数 ，如   abc = 'abc',发起参数中有 ab = ab不会被替换为 'ab'c = ''ab'c';  -zsq 20200221
        v_rule_ex := replace(v_rule_ex,
                             p_business_param(i).paramkey,
                             '''' || v_paramvalue_temp || '''');*/

        while 1 = 1 loop
          proc_get_sql(v_rule_ex, p_business_param(i), v_rule_exs, v_tmp);
          v_rule_ex := v_rule_exs;
          if v_tmp = 'F' then
            exit;
          end if;
        end loop;

      end loop;
      --拼接sql
      v_sql_str := 'select count(1) from dual where ' || v_rule_exs;
      --执行sql
      execute immediate v_sql_str
        into v_count;
      if v_count > 0 then
        /*v_approvers := v_rule_cur_row.rule_value;
        return v_approvers;*/
        --判断是直接取值，还是从参数中取值 update by xiaowei.yao 2019-3-25
        if v_rule_cur_row.get_value_type = 'VALUE' then
          v_approvers := v_rule_cur_row.rule_value;
          -- return v_approvers;
        elsif v_rule_cur_row.get_value_type = 'PARAM' then
          v_approvers := func_get_process_param_value(p_business_param,
                                                      v_rule_cur_row.rule_value);
        end if;
        if v_approvers is not null then
          return v_approvers;
        end if;
      end if;
    end loop;
    raise no_data_found;
  exception
    when no_data_found then
      raise no_data_found;
    when others then
      raise_application_error(-20001,
                              'nodeId:' || p_node_id ||
                              ',根据客户化找人规则查询审批人为空！');
  END;

  /*
  * 根据申请人获取审批人
  */
  PROCEDURE proc_get_creator_approvers(p_document_id VARCHAR2,
                                       x_approvers   OUT VARCHAR2,
                                       x_result_flag OUT VARCHAR2,
                                       x_error_msg   OUT VARCHAR2) IS

  BEGIN
    x_result_flag := 'Y';
    x_error_msg   := '';
    SELECT dd.doc_creator
      INTO x_approvers
      FROM dbpm_documents dd
     WHERE dd.document_id = p_document_id;
  EXCEPTION
    WHEN OTHERS THEN
      x_error_msg   := '调用proc_get_creator_approvers获取审批人时出错，错误信息为：' ||
                       SQLERRM;
      x_result_flag := 'N';
  END proc_get_creator_approvers;

  /*
  * 通过扩展插件方式，客户化获取审批人
  */
  PROCEDURE proc_get_approvers_plugin(p_approver_type  VARCHAR2,
                                      p_node_id        NUMBER,
                                      p_document_id    VARCHAR2,
                                      p_process_param  dbpm_process_param_rec,
                                      p_business_param dbpm_business_param_tbl,
                                      x_approvers      OUT VARCHAR2,
                                      x_result_flag    OUT VARCHAR2,
                                      x_error_msg      OUT VARCHAR2) IS
    v_process_id    NUMBER;
    v_method_type   VARCHAR2(100);
    v_method        VARCHAR2(100);
    v_sql           VARCHAR2(4000);
    v_uuid          varchar2(300);
    v_be_authorizer varchar2(300);
    v_spilt_array  /*cux_gems_user_org_pkg.*/
    type_split;
    v_space_id      varchar2(100); --add by wlj 20180629 增加空间维度的插件
  BEGIN
    SELECT dp.process_id, dp.space_id
      INTO v_process_id, v_space_id
      FROM dbpm_process dp
     WHERE dp.process_code = p_process_param.processcode;
    -- 判断是否配置到流程级别
    SELECT gae.method_type, gae.method
      INTO v_method_type, v_method
      FROM dbpm_get_approvers_ext gae
     WHERE gae.ext_type = 'Process'
       AND gae.process_id = v_process_id
       AND gae.approvers_type = p_approver_type;
    IF v_method_type = 'Package' THEN
      v_sql := 'begin ' || v_method || '(:1,:2,:3,:4,:5,:6,:7); end;';
      EXECUTE IMMEDIATE v_sql
        USING IN p_node_id, IN p_document_id, IN p_process_param, IN p_business_param, OUT x_approvers, OUT x_result_flag, OUT x_error_msg;
      RETURN;
    END IF;
  EXCEPTION
    WHEN no_data_found THEN
      -- 如果没配置流程级别，判断是否配置空间级别
      BEGIN
        SELECT gae.method_type, gae.method
          INTO v_method_type, v_method
          FROM dbpm_get_approvers_ext gae
         WHERE gae.ext_type = 'Space'
           AND gae.approvers_type = p_approver_type
           AND gae.space_id = v_space_id;

        IF v_method_type = 'Package' THEN
          v_sql := 'begin ' || v_method || '(:1,:2,:3,:4,:5,:6,:7); end;';
          EXECUTE IMMEDIATE v_sql
            USING IN p_node_id, IN p_document_id, IN p_process_param, IN p_business_param, OUT x_approvers, OUT x_result_flag, OUT x_error_msg;
          RETURN;
        END IF;
      EXCEPTION
        WHEN no_data_found THEN
          -- 如果没配置流程级别，判断是否配置全局级别
          BEGIN
            SELECT gae.method_type, gae.method
              INTO v_method_type, v_method
              FROM dbpm_get_approvers_ext gae
             WHERE gae.ext_type = 'Global'
               AND gae.approvers_type = p_approver_type;

            IF v_method_type = 'Package' THEN
              v_sql := 'begin ' || v_method ||
                       '(:1,:2,:3,:4,:5,:6,:7); end;';
              EXECUTE IMMEDIATE v_sql
                USING IN p_node_id, IN p_document_id, IN p_process_param, IN p_business_param, OUT x_approvers, OUT x_result_flag, OUT x_error_msg;
              RETURN;
            END IF;
          EXCEPTION
            WHEN no_data_found THEN
              -- 三个级别都没配置，直接报错
              x_result_flag := 'NO_DATA_FOUND';
              x_approvers   := '';
            WHEN OTHERS THEN
              x_approvers   := '';
              x_result_flag := 'N';
              -- x_error_msg   := '通过扩展插件方式获取审批人失败！';
          END;
        WHEN OTHERS THEN
          x_approvers   := '';
          x_result_flag := 'N';
          -- x_error_msg   := '通过扩展插件方式获取审批人失败！';
      END;
    WHEN OTHERS THEN
      x_approvers   := '';
      x_result_flag := 'N';
      -- x_error_msg   := '通过扩展插件方式获取审批人失败！';
  END proc_get_approvers_plugin;

  /*
  * 获取参数值
  */
  FUNCTION func_get_node_role_param_value(p_node_id        NUMBER,
                                          p_role_code      VARCHAR2,
                                          p_param_id       NUMBER,
                                          p_document_id    VARCHAR2,
                                          p_business_param dbpm_business_param_tbl)
    RETURN VARCHAR2 IS
    v_node_role_id   NUMBER;
    v_get_value_type VARCHAR2(30);
    v_param_value    VARCHAR2(4000);
  BEGIN
    SELECT dnr.node_role_id
      INTO v_node_role_id
      FROM BPM.dbpm_node_roles dnr
     WHERE dnr.node_id = p_node_id
       AND dnr.business_role = p_role_code;

    SELECT dnrp.param_value, dnrp.get_value_type
      INTO v_param_value, v_get_value_type
      FROM BPM.dbpm_node_role_param_value dnrp
     WHERE dnrp.node_role_id = v_node_role_id
       AND dnrp.param_id = p_param_id;

    IF v_get_value_type = 'STATIC' THEN
      -- 静态值
      RETURN v_param_value;
    ELSIF v_get_value_type = 'FIELD' THEN
      -- 表单域值
      RETURN func_get_form_field_value(p_id          => v_param_value,
                                       p_document_id => p_document_id);
    ELSIF v_get_value_type = 'PROCESSPARAM' THEN
      -- 流程参数
      RETURN func_get_process_param_value(p_business_param     => p_business_param,
                                          p_process_param_code => v_param_value);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      RETURN '';
  END func_get_node_role_param_value;
  /*
  * 获取节点参数判断类型
  */
  FUNCTION func_get_node_role_param_ope(p_node_id        NUMBER,
                                        p_role_code      VARCHAR2,
                                        p_param_id       NUMBER,
                                        p_document_id    VARCHAR2,
                                        p_business_param dbpm_business_param_tbl)
    RETURN VARCHAR2 IS
    v_node_role_id    NUMBER;
    v_param_operation VARCHAR2(100);
  BEGIN
    SELECT dnr.node_role_id
      INTO v_node_role_id
      FROM BPM.dbpm_node_roles dnr
     WHERE dnr.node_id = p_node_id
       AND dnr.business_role = p_role_code;

    SELECT dnrp.operation_type
      INTO v_param_operation
      FROM BPM.dbpm_node_role_param_value dnrp
     WHERE dnrp.node_role_id = v_node_role_id
       AND dnrp.param_id = p_param_id;

    RETURN v_param_operation;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN '';
  END func_get_node_role_param_ope;
  /*
  * 获取表单域值
  */
  FUNCTION func_get_form_field_value(p_id VARCHAR2, p_document_id VARCHAR2)
    RETURN VARCHAR2 IS
    v_column_name VARCHAR2(100);
    v_form_id     NUMBER;
    v_doc_number  VARCHAR2(100);
    v_apply_user  VARCHAR2(100);
    v_apply_dept  VARCHAR2(100);
    v_comp_type   VARCHAR2(100);
    v_sql         VARCHAR2(4000);
    v_result      VARCHAR2(4000);
  BEGIN

    dbms_output.put_line(p_id);
    dbms_output.put_line(p_document_id);
    SELECT dd.form_id,
           dd.doc_number,
           dd.doc_creator,
           --update by xiaowei 20190423
           /*   (select t.organization_name
            from dfnd_organizations t
           where t.organization_id = dd.organization_id)*/
           dd.organization_id
      INTO v_form_id, v_doc_number, v_apply_user, v_apply_dept
      FROM BPM.dbpm_documents dd
     WHERE dd.document_id = p_document_id;

    SELECT max(dff.type)
      INTO v_comp_type
      FROM dbpm_form_field dff
     WHERE dff.id = p_id;
    IF v_comp_type = 'document-number-readonly' THEN
      RETURN v_doc_number;
    ELSIF v_comp_type = 'usercode-readonly' THEN
      RETURN v_apply_user;
    ELSIF v_comp_type = 'department-readonly' THEN
      RETURN v_apply_dept;
    END IF;

    SELECT dfem.attr_name
      INTO v_column_name
      FROM BPM.dbpm_form_field_mapping dfem
     WHERE dfem.form_id = v_form_id
       AND dfem.id = p_id;

    v_sql := 'select ' || v_column_name ||
             ' from BPM.dbpm_documents dd where dd.document_id = ' ||
             p_document_id;

    EXECUTE IMMEDIATE v_sql
      INTO v_result;

    RETURN v_result;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN '';
  END func_get_form_field_value;

  /*
  * 获取动态参数值
  */
  FUNCTION func_get_process_param_value(p_business_param     dbpm_business_param_tbl,
                                        p_process_param_code VARCHAR2)
    RETURN VARCHAR2 IS
    v_param dbpm_business_param_rec;
  BEGIN
    FOR i IN 1 .. p_business_param.count LOOP
      v_param := p_business_param(i);
      IF v_param.paramkey = p_process_param_code THEN
        RETURN v_param.paramvalue;
      END IF;
    END LOOP;

    RETURN NULL;
  END func_get_process_param_value;
  /*
  * 获取动态参数值-新逻辑migrate by xiaowei.yao 20180416
  */
  FUNCTION func_get_process_param_value(p_param_code  VARCHAR2,
                                        p_document_id VARCHAR2)
    RETURN VARCHAR2 IS
    v_param_value VARCHAR2(4000);
  BEGIN
    SELECT dppv.param_value
      INTO v_param_value
      FROM dbpm_process_param_value dppv, dbpm_process_params dpp
     WHERE dppv.param_id = dpp.param_id
       AND dpp.param_code = p_param_code
       AND dppv.document_id = p_document_id;
    RETURN v_param_value;
    /*FOR i IN 1 .. p_business_param.count LOOP
      v_param := p_business_param(i);
      IF v_param.paramkey = p_process_param_code THEN
        RETURN v_param.paramvalue;
      END IF;
    END LOOP;
    RETURN NULL;*/
  END func_get_process_param_value;

  /*
  * 判断角色是否配置了参数
  */
  FUNCTION func_is_role_has_param(p_role_id NUMBER) RETURN VARCHAR2 IS
    v_count NUMBER;
  BEGIN
    SELECT COUNT(1)
      INTO v_count
      FROM BPM.dbpm_role_params drp
     WHERE drp.role_id = p_role_id;
    IF v_count > 0 THEN
      RETURN 'Y';
    ELSE
      RETURN 'N';
    END IF;
  END func_is_role_has_param;
  /*
  * 获取审批节点下的审批链
  */
  PROCEDURE proc_get_node_chains(p_node_id     NUMBER,
                                 x_node_chains OUT dbpm_node_chain_tbl) IS
    CURSOR v_node_chain_cur IS
      SELECT *
        FROM dbpm_node_chains dnc
       WHERE dnc.node_id = p_node_id
         AND dnc.node_from_type = 'ChainNode';
    v_index NUMBER;
  BEGIN
    x_node_chains := dbpm_node_chain_tbl();
    v_index       := 1;
    FOR v_node_chain IN v_node_chain_cur LOOP
      x_node_chains.extend;
      x_node_chains(v_index) := dbpm_node_chain_rec(v_node_chain.chain_id);
      v_index := v_index + 1;
    END LOOP;
  END proc_get_node_chains;

  /*\*
  * 获取成立的代理规则
  *\
  PROCEDURE proc_get_proxy_rules(p_owner          VARCHAR2,
                                 p_node_id        NUMBER,
                                 p_document_id    VARCHAR2,
                                 p_process_param  dbpm_process_param_rec,
                                 p_business_param dbpm_business_param_tbl,
                                 x_proxy_rules    OUT VARCHAR2,
                                 x_result_flag    OUT VARCHAR2,
                                 x_error_msg      OUT VARCHAR2) IS

  BEGIN
    -- 先执行插件
    cux_gems_user_org_pkg.proc_get_proxy_rules_ext(p_owner          => p_owner,
                                                   p_node_id        => p_node_id,
                                                   p_document_id    => p_document_id,
                                                   p_process_param  => p_process_param,
                                                   p_business_param => p_business_param,
                                                   x_proxy_rules    => x_proxy_rules,
                                                   x_result_flag    => x_result_flag,
                                                   x_error_msg      => x_error_msg);
    -- TODO
    -- 执行标准的代理规则
  END proc_get_proxy_rules;*/

  /*解决DbpmCoreProcess [1.1]版本调用此方法报错问题  20191230 by Quan*/
  PROCEDURE proc_get_proxy_rules(p_owner           VARCHAR2,
                                 p_node_id         NUMBER,
                                 p_document_id     VARCHAR2,
                                 p_process_param   dbpm_process_param_rec,
                                 p_business_param  dbpm_business_param_tbl,
                                 x_proxy_approvers OUT VARCHAR2,
                                 x_proxy_rules     OUT VARCHAR2,
                                 x_result_flag     OUT VARCHAR2,
                                 x_error_msg       OUT VARCHAR2) IS
    p_approvers VARCHAR2(200);
  BEGIN
    p_approvers := p_owner;
    proc_get_proxy_rules(p_approvers       => p_approvers,
                         p_node_id         => p_node_id,
                         p_document_id     => p_document_id,
                         p_process_param   => p_process_param,
                         p_business_param  => p_business_param,
                         x_proxy_approvers => x_proxy_approvers,
                         x_proxy_rules     => x_proxy_rules,
                         x_result_flag     => x_result_flag,
                         x_error_msg       => x_error_msg);

  END;

  /*
  * 获取成立的代理规则 v2.0
  * 增加返回被授权人信息 update by xuy 2017-12-02
  */
  PROCEDURE proc_get_proxy_rules(p_approvers       VARCHAR2,
                                 p_node_id         NUMBER,
                                 p_document_id     VARCHAR2,
                                 p_process_param   dbpm_process_param_rec,
                                 p_business_param  dbpm_business_param_tbl,
                                 x_proxy_approvers OUT VARCHAR2,
                                 x_proxy_rules     OUT VARCHAR2,
                                 x_result_flag     OUT VARCHAR2,
                                 x_error_msg       OUT VARCHAR2) IS

    v_process_id number;
    v_node_name  varchar2(4000);
    v_approvers  VARCHAR2(4000);
  BEGIN
    --根据p_document_id判断是否启用得云授权规则 OTDO

    begin
      -- 先执行插件
      proc_get_proxy_rules_plugin(p_approvers       => p_approvers,
                                  p_node_id         => p_node_id,
                                  p_document_id     => p_document_id,
                                  p_process_param   => p_process_param,
                                  p_business_param  => p_business_param,
                                  x_proxy_approvers => x_proxy_approvers,
                                  x_proxy_rules     => x_proxy_rules,
                                  x_result_flag     => x_result_flag,
                                  x_error_msg       => x_error_msg);

    end;
    --没配置插件，则执行标准找代理规则
    IF x_result_flag = 'NO_DATA_FOUND' THEN
      --获取流程
      begin

        /*      select d.process_id
         into v_process_id
         from dbpm_documents d
        where d.document_id = p_document_id;*/

        select dp.process_id
          into v_process_id
          from dbpm_process dp
         where dp.process_code = p_process_param.processCode;

        select cn.node_name
          into v_node_name
          from dbpm_chain_nodes cn
         where cn.node_id = p_node_id;
      exception
        when others then
          v_process_id := null;
      end;
      --根据节点类型去授权：
      --根据配置好的规则授权
      select LISTAGG(to_char(r.uuid), ',') WITHIN GROUP(ORDER BY r.uuid)
        into x_proxy_rules
        from dbpm_prox_rules r
       where r.process_id = v_process_id
         and r.process_node = v_node_name
         and sysdate between r.proxy_start_time and r.proxy_end_time
         and upper(r.proxy_from_user) in
             (select regexp_substr(p_approvers, '[^,]+', 1, level) col
                from dual
              connect by level <= regexp_count(p_approvers, ',') + 1);
      SELECT LISTAGG(AFTER_APPROVER, ',') WITHIN GROUP(ORDER BY AFTER_APPROVER)
        INTO v_approvers
        FROM (SELECT NVL((select r.proxy_to_user
                           from dbpm_prox_rules r
                          where r.process_id = v_process_id
                            and r.process_node = v_node_name
                            AND R.PROXY_FROM_USER = BEFORE_APPROVER
                            and sysdate between r.proxy_start_time and
                                r.proxy_end_time),
                         BEFORE_APPROVER) AFTER_APPROVER
                FROM (select regexp_substr(p_approvers, '[^,]+', 1, level) BEFORE_APPROVER
                        from dual
                      connect by level <= regexp_count(p_approvers, ',') + 1) T) T;

      IF v_approvers IS NULL THEN
        x_proxy_approvers := p_approvers;
      ELSE
        x_proxy_approvers := v_approvers;
      END IF;
      x_result_flag := 'Y';
      /* ELSE
      -- 先执行插件
      cux_gems_user_org_pkg.proc_get_proxy_rules_ext(p_approvers       => p_approvers,
                                                     p_node_id         => p_node_id,
                                                     p_document_id     => p_document_id,
                                                     p_process_param   => p_process_param,
                                                     p_business_param  => p_business_param,
                                                     x_proxy_approvers => x_proxy_approvers,
                                                     x_proxy_rules     => x_proxy_rules,
                                                     x_result_flag     => x_result_flag,
                                                     x_error_msg       => x_error_msg);*/
    END IF;
    -- TODO
    -- 执行标准的代理规则
  END proc_get_proxy_rules;

  /*
  * 升级表单版本
  */
  PROCEDURE proc_upgrade_form_version(p_form_id      VARCHAR2,
                                      p_current_user VARCHAR2,
                                      x_form_id      OUT NUMBER) IS
    v_form_code       VARCHAR2(100);
    v_lastest_version NUMBER;
    v_status          VARCHAR2(100);
  BEGIN
    -- 更新如下表：
    -- 表单DBPM_FORM
    -- 表单域DBPM_FORM_FIELD
    -- 表单域关联DBPM_FORM_FIELD_MAPPING

    -- 1. 获取最后一个版本的流程表单表单
    SELECT df.form_code
      INTO v_form_code
      FROM dbpm_form df
     WHERE df.form_id = p_form_id;
    v_lastest_version := dbpm_core_pkg.func_get_lastest_version(v_form_code);

    SELECT df.status, df.form_id
      INTO v_status, x_form_id
      FROM dbpm_form df
     WHERE df.form_code = v_form_code
       AND df.version = v_lastest_version;
    IF v_status = 'Saved' THEN
      -- 2. 如果是保存状态，直接进入编辑
      RETURN;
    ELSIF v_status = 'Published' THEN
      -- 3. 如果是发布状态，升版本编辑
      x_form_id := dbpm_form_s.nextval;
      INSERT INTO dbpm_form
        (form_id,
         form_code,
         process_id,
         form_name,
         form_icon,
         config_html,
         process_html,
         version,
         from_form_id,
         status,
         object_version_number,
         creation_date,
         created_by,
         last_updated_by,
         last_update_date,
         space_id,
         FORM_MAX_COLUMN)
        SELECT x_form_id,
               form_code,
               process_id,
               form_name,
               form_icon,
               config_html,
               process_html,
               v_lastest_version + 1,
               p_form_id,
               'Saved',
               1,
               SYSDATE,
               p_current_user,
               p_current_user,
               SYSDATE,
               space_id,
               FORM_MAX_COLUMN
          FROM dbpm_form df
         WHERE df.form_id = p_form_id;
      FOR v_form_field IN (SELECT *
                             FROM dbpm_form_field dff
                            WHERE dff.form_id = p_form_id) LOOP
        INSERT INTO dbpm_form_field
          (field_id,
           form_id,
           id,
           TYPE,
           label,
           tip,
           is_required,
           is_preview,
           is_print,
           display_width,
           default_value,
           suffix,
           data_source_text,
           data_source_code,
           data_format,
           arrange,
           default_date_value,
           default_time_value,
           number_range,
           parent_id,
           n1_id,
           n2_id,
           is_visiable,
           cal_table_id,
           cal_column_id,
           cal_formula,
           is_title,
           attr_code,
           object_version_number,
           creation_date,
           created_by,
           last_updated_by,
           last_update_date,
           is_mobileshow,
           order_seq --add by wlj
           )
        VALUES
          (dbpm_form_field_s.nextval,
           x_form_id,
           v_form_field.id,
           v_form_field.type,
           v_form_field.label,
           v_form_field.tip,
           v_form_field.is_required,
           v_form_field.is_preview,
           v_form_field.is_print,
           v_form_field.display_width,
           v_form_field.default_value,
           v_form_field.suffix,
           v_form_field.data_source_text,
           v_form_field.data_source_code,
           v_form_field.data_format,
           v_form_field.arrange,
           v_form_field.default_date_value,
           v_form_field.default_time_value,
           v_form_field.number_range,
           v_form_field.parent_id,
           v_form_field.n1_id,
           v_form_field.n2_id,
           v_form_field.is_visiable,
           v_form_field.cal_table_id,
           v_form_field.cal_column_id,
           v_form_field.cal_formula,
           v_form_field.is_title,
           v_form_field.attr_code,
           1,
           SYSDATE,
           p_current_user,
           p_current_user,
           SYSDATE,
           v_form_field.is_mobileshow,
           v_form_field.order_seq --add by wlj
           );
      END LOOP;
      FOR v_field_mapping IN (SELECT *
                                FROM dbpm_form_field_mapping dffm
                               WHERE dffm.form_id = p_form_id) LOOP
        INSERT INTO dbpm_form_field_mapping
          (form_id,
           id,
           attr_name,
           table_name,
           object_version_number,
           creation_date,
           created_by,
           last_updated_by,
           last_update_date)
        VALUES
          (x_form_id,
           v_field_mapping.id,
           v_field_mapping.attr_name,
           v_field_mapping.table_name,
           1,
           SYSDATE,
           p_current_user,
           p_current_user,
           SYSDATE);
      END LOOP;
    END IF;
  END proc_upgrade_form_version;

  /*
  * 获取升级后的版本号
  */
  FUNCTION func_get_lastest_version(p_form_code VARCHAR2) RETURN NUMBER IS
    v_max_version NUMBER;
  BEGIN
    SELECT MAX(version)
      INTO v_max_version
      FROM dbpm_form df
     WHERE df.form_code = p_form_code;
    RETURN v_max_version;
  END func_get_lastest_version;

  /*==================================================
  Procedure/Function Name :
      proc_export_process_form
  Description:
      This function perform:
      导出对应的表单
  Argument:
     p_form_id： 表单id
     x_form： 表单关联信息
  History:
      1.00  2017-11-01  zhiheng.wei  Creation
      1.00  2017-11-08  chenmy.zhang@definsys.com         Update
            添加内容：REPLACE(REPLACE(v_config_html,chr(10),NULL),'"','\"')
  ==================================================*/
  FUNCTION func_export_process_form(p_form_id NUMBER) RETURN CLOB IS
    v_response              CLOB;
    v_form                  pl_json := pl_json;
    v_form_field            pl_json;
    v_form_field_mapping    pl_json;
    v_process_id            NUMBER;
    v_form_name             VARCHAR2(100);
    v_form_icon             VARCHAR2(100);
    v_config_html           CLOB;
    v_process_html          CLOB;
    v_object_version_number NUMBER;
    v_version               VARCHAR2(50);
    v_from_form_id          NUMBER;
    v_status                VARCHAR2(50);
    v_form_code             VARCHAR2(50);
    v_space_code            varchar2(100);
    CURSOR v_form_field_cur IS
      SELECT * FROM dbpm_form_field dff WHERE dff.form_id = p_form_id;
    CURSOR v_form_field_mapping_cur IS
      SELECT *
        FROM dbpm_form_field_mapping dffm
       WHERE dffm.form_id = p_form_id;
  BEGIN
    SELECT df.process_id,
           df.form_name,
           df.form_icon,
           df.config_html,
           df.process_html,
           df.object_version_number,
           df.version,
           df.from_form_id,
           df.status,
           df.form_code,
           (select ds.space_code
              from dbpm_spaces ds
             where ds.space_id = df.space_id)
      INTO v_process_id,
           v_form_name,
           v_form_icon,
           v_config_html,
           v_process_html,
           v_object_version_number,
           v_version,
           v_from_form_id,
           v_status,
           v_form_code,
           v_space_code
      FROM dbpm_form df
     WHERE df.form_id = p_form_id;
    v_form.set_value('processId', v_process_id);
    v_form.set_value('formId', p_form_id);
    v_form.set_value('spaceCode', v_space_code);
    v_form.set_value('formName', v_form_name);
    v_form.set_value('formIcon', v_form_icon);
    v_form.set_value('configHtml',
                     REPLACE(REPLACE(v_config_html, chr(10), NULL),
                             '"',
                             '\"'));
    v_form.set_value('processHtml',
                     REPLACE(REPLACE(v_process_html, chr(10), NULL),
                             '"',
                             '\"'));
    v_form.set_value('objectVersionNumber', v_object_version_number);
    v_form.set_value('version', v_version);
    v_form.set_value('fromFormId', v_from_form_id);
    v_form.set_value('status', v_status);
    v_form.set_value('formCode', v_form_code);
    FOR form_field IN v_form_field_cur LOOP
      v_form_field := pl_json;

      v_form_field.set_value('fieldId', form_field.field_id);
      v_form_field.set_value('formId', form_field.form_id);
      v_form_field.set_value('id', form_field.id);
      v_form_field.set_value('type', form_field.type);
      v_form_field.set_value('label', form_field.label);
      v_form_field.set_value('tip', form_field.tip);
      v_form_field.set_value('isRequired', form_field.is_required);
      v_form_field.set_value('isPreview', form_field.is_preview);
      v_form_field.set_value('isPrint', form_field.is_print);
      v_form_field.set_value('displayWidth', form_field.display_width);
      v_form_field.set_value('defaultValue', form_field.default_value);
      v_form_field.set_value('suffix', form_field.suffix);
      v_form_field.set_value('dataSourceText', form_field.data_source_text);
      v_form_field.set_value('dataSourceCode', form_field.data_source_code);
      v_form_field.set_value('dataFormat', form_field.data_format);
      v_form_field.set_value('arrange', form_field.arrange);
      v_form_field.set_value('defaultDataValue',
                             form_field.default_date_value);
      v_form_field.set_value('defaultTimeValue',
                             form_field.default_time_value);
      v_form_field.set_value('numberRange', form_field.number_range);
      v_form_field.set_value('parentId', form_field.parent_id);
      v_form_field.set_value('n1Id', form_field.n1_id);
      v_form_field.set_value('n2Id', form_field.n2_id);
      v_form_field.set_value('isVisiable', form_field.is_visiable);
      v_form_field.set_value('calTableId', form_field.cal_table_id);
      v_form_field.set_value('calColumnId', form_field.cal_column_id);
      v_form_field.set_value('formula', form_field.cal_formula);
      v_form_field.set_value('isTitle', form_field.is_title);
      v_form_field.set_value('attrCode', form_field.attr_code);
      v_form_field.set_value('displayRows', form_field.display_rows);
      v_form_field.set_value('style', form_field.style);
      v_form_field.set_value('isKeyword', form_field.is_keyword);
      v_form_field.set_value('orderSeq', form_field.order_seq);
      v_form_field.set_value('isMobileShow', form_field.is_mobileshow);
      v_form_field.set_value('url', form_field.url); --
      v_form_field.set_value('fnOperation', form_field.operation); --
      v_form.add_list_item('formField', v_form_field);
    END LOOP;
    FOR mapping IN v_form_field_mapping_cur LOOP
      v_form_field_mapping := pl_json;
      v_form_field_mapping.set_value('formId', mapping.form_id);
      v_form_field_mapping.set_value('id', mapping.id);
      v_form_field_mapping.set_value('attrName', mapping.attr_name);
      v_form_field_mapping.set_value('tableName', mapping.table_name);
      v_form.add_list_item('formFieldMapping', v_form_field_mapping);
    END LOOP;
    v_response := v_form.to_data_json;
    RETURN v_response;
  END func_export_process_form;
  /*==================================================
  Procedure/Function Name :
      func_import_process_form
  Description:
      This function perform:
      导入对应的表单
      成功：返回 SUCCESS
      失败：返回 FAIL
  Argument:
     p_form_content： 表单内容
  History:
      1.00  2017-12-1  jinglun.xu Creation
  ==================================================*/
  PROCEDURE proc_import_process_form(p_request CLOB, x_response OUT CLOB) IS
    v_request               json;
    v_response              pl_json := pl_json;
    v_form_id               NUMBER;
    v_process_id            NUMBER;
    v_form_name             VARCHAR2(100);
    v_config_html           CLOB;
    v_process_html          CLOB;
    v_object_version_number NUMBER;
    v_version               number;
    v_from_form_id          NUMBER;
    v_status                VARCHAR2(50);
    v_form_code             VARCHAR2(100);
    v_form_fields           json_list;
    v_form_field_keys       json_list;
    v_form_field_key        VARCHAR2(50);
    v_form_field            json;
    v_form_field_mapping    json;
    v_form_field_mappings   json_list;
    v_field_id              NUMBER;
    v_id                    VARCHAR2(1000);
    v_type                  VARCHAR2(100);
    v_label                 VARCHAR2(4000);
    v_tip                   VARCHAR2(4000);
    v_is_required           VARCHAR2(5);
    v_is_preview            VARCHAR2(5);
    v_is_print              VARCHAR2(5);
    v_display_width         NUMBER;
    v_defalut_value         VARCHAR2(100);
    v_suffix                VARCHAR2(100);
    v_data_source_text      VARCHAR2(1000);
    v_data_source_code      VARCHAR2(100);
    v_data_format           VARCHAR2(100);
    v_arrange               number;
    v_default_data_value    VARCHAR2(100);
    v_default_time_value    VARCHAR2(100);
    v_number_range          NUMBER;
    v_parent_id             varchar2(1000);
    v_n1_id                 VARCHAR2(100);
    v_n2_id                 VARCHAR2(100);
    v_is_visiable           VARCHAR2(5);
    v_caltable_id           VARCHAR2(100);
    v_calcolumn_id          VARCHAR2(100);
    v_formula               VARCHAR2(100);
    v_is_title              VARCHAR2(5);
    v_attrcode              VARCHAR2(100);
    v_display_rows          VARCHAR2(100);
    v_style                 VARCHAR2(100);
    v_is_keyword            VARCHAR2(100);
    v_mapping_id            VARCHAR2(1000);
    v_attrname              VARCHAR2(100);
    v_tablename             VARCHAR2(100);
    v_CAL_FORMULA           varchar2(1000);
    v_space_Code            varchar2(100);
    v_space_id              varchar2(100);
    v_ORDER_SEQ             number;
    --是否导入
    v_isImport     varchar2(10);
    v_isMobileShow varchar2(100);
    v_temp_form_id number;
  BEGIN
    v_request    := json(p_request, 'OBJECT');
    v_process_id := v_request.get_number('processId');
    v_form_id    := v_request.get_number('formId');
    v_form_name  := v_request.get_string('formName');

    v_config_html := ' ';
    v_request.get('configHtml').get_string(v_config_html);

    v_process_html := ' ';
    v_request.get('processHtml').get_string(v_process_html);

    v_space_Code := v_request.get_string('spaceCode');
    begin
      select ds.space_id
        into v_space_id
        from dbpm_spaces ds
       where ds.space_code = v_space_Code;
    exception
      when no_data_found then
        --v_response.fail('权限数据不存在！');
        v_response.fail(DCLD_COMM_PKG.func_get_err_msg('DCLD-00002',
                                                       v_request.locale));
        x_response := v_response.to_json;
        return;
    end;
    v_version   := 1;
    v_status    := 'Saved';
    v_form_code := v_request.get_string('formCode');

    v_form_fields         := json_list(v_request.get('formField'));
    v_form_field_mappings := json_list(v_request.get('formFieldMapping'));
    --导入表单
    v_temp_form_id := dbpm_form_s.nextval;
    INSERT INTO dbpm_form df
      (df.form_id,
       df.form_name,
       df.config_html,
       df.process_html,
       df.version,
       df.status,
       df.form_code,
       df.space_id)
    VALUES
      (v_temp_form_id,
       v_form_name,
       v_config_html,
       v_process_html,
       v_version,
       v_status,
       v_temp_form_id,
       v_space_id);
    --导入表单组件
    FOR i IN 1 .. v_form_fields.count LOOP
      v_form_field := json(v_form_fields.get(i));

      v_field_id := v_form_field.get_number('fieldId');
      v_id       := v_form_field.get_string('id');
      --判断组件ID是否存在 如果存在不允许再次导入
      /*      select count(1)
       into v_isImport
       from dbpm_form_field dff
      where dff.id = v_id;*/
      /* if v_isImport != 0 then*/
      v_type               := v_form_field.get_string('type');
      v_label              := v_form_field.get_string('label');
      v_tip                := v_form_field.get_string('tip');
      v_is_required        := v_form_field.get_string('isRequired');
      v_is_preview         := v_form_field.get_string('isPreview');
      v_is_print           := v_form_field.get_string('isPrint');
      v_display_width      := v_form_field.get_number('displayWidth');
      v_defalut_value      := v_form_field.get_string('defalutValue');
      v_suffix             := v_form_field.get_string('suffix');
      v_data_source_text   := v_form_field.get_string('dataSourceText');
      v_data_source_code   := v_form_field.get_string('dataSourceCode');
      v_data_format        := v_form_field.get_string('dataFormat');
      v_arrange            := v_form_field.get_number('arrange');
      v_default_data_value := v_form_field.get_string('defaultDataValue');
      v_default_time_value := v_form_field.get_string('defaultTimeValue');
      v_number_range       := v_form_field.get_string('numberRange');
      v_parent_id          := v_form_field.get_string('parentId');
      v_n1_id              := v_form_field.get_string('n1Id');
      v_n2_id              := v_form_field.get_string('n2Id');
      v_calcolumn_id       := v_form_field.get_string('calcolumnId');
      v_caltable_id        := v_form_field.get_string('caltableId');
      v_CAL_FORMULA        := v_form_field.get_string('calFormula');
      v_style              := v_form_field.get_string('style');
      v_is_keyword         := v_form_field.get_string('isKeyword');
      v_ORDER_SEQ          := v_form_field.get_number('orderSeq');
      v_is_visiable        := v_form_field.get_string('isVisiable');
      v_is_title           := v_form_field.get_string('isTitle');
      v_attrcode           := v_form_field.get_string('attrCode');
      v_display_rows       := v_form_field.get_string('displayRows');
      v_isMobileShow       := v_form_field.get_string('isMobileShow');
      INSERT INTO dbpm_form_field
        (field_id,
         form_id,
         id,
         type,
         label,
         tip,
         is_required,
         is_preview,
         is_print,
         display_width,
         default_value,
         suffix,
         data_source_text,
         data_source_code,
         data_format,
         arrange,
         default_date_value,
         default_time_value,
         number_range,
         parent_id,
         n1_id,
         n2_id,
         cal_column_id,
         cal_table_id,
         cal_formula,
         style,
         is_keyword,
         is_visiable,
         is_title,
         attr_code,
         order_seq,
         is_mobileshow,
         url,
         operation)
      VALUES
        (dbpm_form_field_s.nextval,
         v_temp_form_id,
         v_id,
         v_type,
         v_label,
         v_tip,
         v_is_required,
         v_is_preview,
         v_is_print,
         v_display_width,
         v_defalut_value,
         v_suffix,
         v_data_source_text,
         v_data_source_code,
         v_data_format,
         v_arrange,
         v_default_data_value,
         v_default_time_value,
         v_number_range,
         v_parent_id,
         v_n1_id,
         v_n2_id,
         v_calcolumn_id,
         v_caltable_id,
         v_CAL_FORMULA,
         v_style,
         v_is_keyword,
         v_is_visiable,
         v_is_title,
         v_attrcode,
         v_ORDER_SEQ,
         v_isMobileShow,
         v_form_field.get_string('url'),
         v_form_field.get_string('fnOperation'));
      /* else
        v_response.fail('不存在组件！');
        x_response := v_response.to_json;
        rollback;
        return;
      end if;*/
    END LOOP;
    --导入表单和组件的配置表
    FOR j IN 1 .. v_form_field_mappings.count LOOP
      v_form_field_mapping := json(v_form_field_mappings.get(j));
      v_mapping_id         := v_form_field_mapping.get_string('id');
      v_attrname           := v_form_field_mapping.get_string('attrName');
      v_tablename          := v_form_field_mapping.get_string('tableName');
      INSERT INTO dbpm_form_field_mapping dffm
        (dffm.form_id, dffm.id, dffm.attr_name, dffm.table_name)
      VALUES
        (v_temp_form_id, v_mapping_id, v_attrname, v_tablename);
    END LOOP;
    v_response.set_value('formId', v_temp_form_id);
    x_response := v_response.to_json;
  END proc_import_process_form;

  /*==================================================
  Procedure/Function Name :
      func_export_process
  Description:
      This function perform:
      导出对应的流程
  Argument:
     p_process_id：流程id
  History:
      1.00  2017-11-10  zhiheng.wei  Creation
  ==================================================*/
  FUNCTION func_export_process(p_process_id NUMBER) RETURN CLOB IS
    v_response      CLOB;
    v_process       pl_json := pl_json;
    v_process_code  VARCHAR2(100);
    v_process_name  VARCHAR2(50);
    v_description   VARCHAR2(100);
    v_process_type  VARCHAR2(100);
    v_enabled_flag  VARCHAR2(5);
    v_space_code    VARCHAR2(100);
    v_is_shared     varchar2(100);
    v_role_json     pl_json;
    v_param_json    pl_json;
    v_process_node  pl_json;
    v_process_param pl_json;
    v_node_chain    pl_json;
    /*v_process_param_value   pl_json;*/
    v_node_role             pl_json;
    v_node_role_param_value pl_json;
    v_approval_chain        pl_json;
    v_chain_node            pl_json;
    v_chain_node_tl         pl_json;
    v_chain_rule            pl_json;
    v_process_tl            pl_json;
    v_auth_relation         pl_json;
    v_param_id              NUMBER;
    v_dynamic_user          pl_json;
    v_dynamic_value_type    varchar2(100);
    v_dynamic_value         varchar2(100);
    v_rule_tree_clob        clob; -- add by wlj 规则树
    v_rule_tree_json_list   json_list; -- add by wlj 规则树
    --流程节点
    CURSOR v_process_nodes_cur IS
      SELECT *
        FROM dbpm_process_nodes dpn
       WHERE dpn.process_id = p_process_id;
    --流程参数
    CURSOR v_process_params_cur IS
      SELECT *
        FROM dbpm_process_params dpp
       WHERE dpp.process_id = p_process_id;
    --流程参数值
    /*CURSOR v_process_param_values_cur(p_param_id NUMBER) IS
    SELECT *
      FROM dbpm_process_param_value dppv
     WHERE dppv.param_id = p_param_id;*/
    --流程节点角色
    CURSOR v_node_roles_cur(p_node_id NUMBER) IS
      SELECT * FROM dbpm_node_roles dnr WHERE dnr.node_id = p_node_id;
    --流程角色参数
    CURSOR v_node_role_param_values_cur(p_node_role_id NUMBER) IS
      SELECT dnrpv.*,
             drp.param_name,
             drp.order_num,
             drp.role_id,
             drp.status,
             drp.data_source_code,
             (select dr.role_code
                from dbpm_roles dr
               where dr.role_id = drp.role_id) role_code,
             COUNT(1) over(PARTITION BY 1) role_count
        FROM dbpm_node_role_param_value dnrpv, DBPM_ROLE_PARAMS drp
       WHERE dnrpv.node_role_id = p_node_role_id
         and drp.param_id = dnrpv.param_id;
    --流程审批链
    CURSOR v_approval_chains_cur IS
      SELECT dac.*, TREE.CHAIN_RULE_TREE
        FROM dbpm_approval_chain dac, DBPM_CHAIN_RULES_TREE TREE
       WHERE dac.process_id = p_process_id
         AND dac.chain_id = tree.chain_id(+)
         and nvl(dac.is_deleted, 'N') <> 'Y'
       order by dac.chain_id;
    --流程审批节点
    CURSOR v_chain_nodes_cur(p_chain_id NUMBER) IS
      SELECT *
        FROM dbpm_chain_nodes dcn
       WHERE dcn.chain_id = p_chain_id
         AND DCN.IS_DELETED = 'N';

    --审批节点多语言表
    CURSOR v_chain_node_tls_cur(p_node_id NUMBER) IS
      SELECT *
        FROM dbpm_chain_nodes_tl dcnt
       WHERE dcnt.node_id = p_node_id;
    --流程多多语言
    CURSOR v_process_tl_cur IS
      SELECT *
        FROM dbpm_process_tl dpt
       WHERE dpt.process_id = p_process_id;
    --流程审批规则
    CURSOR v_chain_rules_cur(p_chain_id NUMBER) IS
      SELECT * FROM dbpm_chain_rules dcr WHERE dcr.chain_id = p_chain_id;
    CURSOR v_role_cur(p_node_id NUMBER) IS
      SELECT dnr.*, dr.role_id, dr.role_name
        FROM dbpm_node_roles dnr, dbpm_roles dr
       WHERE dnr.business_role = dr.role_code
         AND dnr.node_id = p_node_id
         AND dnr.node_from_type = 'ChainNode';
    -- 审批角色参数
    CURSOR v_param_cur(p_node_role_id NUMBER) IS
      SELECT dnrp.*,
             drp.param_name,
             drp.order_num,
             drp.role_id,
             drp.status,
             drp.data_source_code,
             (select dr.role_code
                from dbpm_roles dr
               where dr.role_id = drp.role_id) role_code,
             COUNT(1) over(PARTITION BY 1) role_count
        FROM dbpm_node_role_param_value dnrp,
             dbpm_node_roles            dnr,
             dbpm_role_params           drp
       WHERE dnrp.node_role_id = dnr.node_role_id
         AND dnr.node_from_type = 'ChainNode'
         AND dnrp.param_id = drp.param_id
         AND dnrp.node_role_id = p_node_role_id;
    CURSOR v_chain_cur(p_node_id NUMBER, p_process_id NUMBER) IS
      SELECT dac.chain_id,
             dac.chain_name,
             (CASE
               WHEN dnc.chain_id IS NULL THEN
                'N'
               ELSE
                'Y'
             END) is_checked
        FROM dbpm_node_chains dnc, dbpm_approval_chain dac
       WHERE dnc.node_id(+) = p_node_id
         AND dnc.chain_id(+) = dac.chain_id
         AND dac.process_id = p_process_id
         AND dnc.node_from_type(+) = 'ProcessNode'
         AND dac.chain_type = 'SubChain';

    cursor v_dynamic_user_cur(p_node_id number) is
      select t.dynamic_value, t.get_value_type
        from DBPM_DYNAMIC_APPROVERS t
       where t.node_id = p_node_id;
    v_selected_users varchar2(4000);
    --流程权限关联
    cursor v_auth_relation_cur is
      select *
        from dbpm_process_group_realtion t
       where t.process_id = p_process_id;
  BEGIN
    SELECT dp.process_code,
           dp.process_name,
           dp.description,
           dp.process_type,
           dp.enabled_flag,
           (select ds.space_code
              from dbpm_spaces ds
             where ds.space_id = dp.space_id),
           dp.is_shared
      INTO v_process_code,
           v_process_name,
           v_description,
           v_process_type,
           v_enabled_flag,
           v_space_code,
           v_is_shared
      FROM dbpm_process dp
     WHERE dp.process_id = p_process_id;
    v_process.set_value('processCode', v_process_code);
    v_process.set_value('processName', v_process_name);
    v_process.set_value('description', v_description);
    v_process.set_value('processType', v_process_type);
    v_process.set_value('enabledFlag', v_enabled_flag);
    v_process.set_value('spaceCode', v_space_code);
    v_process.set_value('isShared', v_is_shared);
    --发起权限
    for c_auth_relation in v_auth_relation_cur loop
      v_auth_relation := pl_json;
      v_auth_relation.set_value('authCode', c_auth_relation.auth_code);
      v_auth_relation.set_value('authType', c_auth_relation.auth_type);
      v_auth_relation.set_value('processId', c_auth_relation.process_id);
      v_process.add_list_item('authRelation', v_auth_relation);
    end loop;
    --流程多多语言
    FOR v_process_tls IN v_process_tl_cur LOOP
      v_process_tl := pl_json;
      v_process_tl.set_value('processId', v_process_tls.process_id);
      v_process_tl.set_value('locale', v_process_tls.locale);
      v_process_tl.set_value('processName', v_process_tls.process_name);
      v_process_tl.set_value('description', v_process_tls.description);
      v_process.add_list_item('processTlList', v_process_tl);
    end loop;
    FOR v_process_nodes IN v_process_nodes_cur LOOP
      v_process_node := pl_json;
      v_process_node.set_value('nodeId', v_process_nodes.node_id);
      v_process_node.set_value('processId', v_process_nodes.process_id);
      v_process_node.set_value('nodeName', v_process_nodes.node_name);
      v_process_node.set_value('nodeType', v_process_nodes.node_type);
      v_process_node.set_value('orderNum', v_process_nodes.order_num);
      v_process_node.set_value('objectVersionNumber',
                               v_process_nodes.object_version_number);
      v_process_node.set_value('approverType',
                               v_process_nodes.approver_type);
      IF v_process_nodes.is_required = 'Y' THEN
        --add by wlj
        v_process_node.set_value('isRequired', TRUE);
      ELSE
        v_process_node.set_value('isRequired', FALSE);
      END IF;
      IF v_process_nodes.is_auto_approve = 'Y' THEN
        --add by wlj
        v_process_node.set_value('isAutoApprove', TRUE);
      ELSE
        v_process_node.set_value('isAutoApprove', FALSE);
      END IF;
      if v_process_nodes.approver_type = 'StaticUser' then
        begin
          select t.approvers
            into v_selected_users
            from dbpm_selected_approvers t
           where t.node_id = v_process_nodes.node_id;
        exception
          when others then
            v_selected_users := '';
        end;
        v_process_node.set_value('approverUsers', v_selected_users);
      end if;
      FOR v_node_roles IN v_node_roles_cur(v_process_nodes.node_id) LOOP
        v_node_role := pl_json;
        v_node_role.set_value('nodeRoleId', v_node_roles.node_role_id);
        v_node_role.set_value('nodeId', v_node_roles.node_id);
        v_node_role.set_value('businessRole', v_node_roles.business_role);
        v_node_role.set_value('nodeFromType', v_node_roles.node_from_type);
        v_node_role.set_value('customRoleName',
                              v_node_roles.custom_role_name);
        FOR v_node_role_param_values IN v_node_role_param_values_cur(v_node_roles.node_role_id) LOOP
          v_node_role_param_value := pl_json;
          v_node_role_param_value.set_value('nodeRoleId',
                                            v_node_role_param_values.node_role_id);
          v_node_role_param_value.set_value('paramId',
                                            v_node_role_param_values.param_id);
          --新增导出角色数据

          v_node_role_param_value.set_value('paramName',
                                            v_node_role_param_values.param_name);
          v_node_role_param_value.set_value('orderNum',
                                            v_node_role_param_values.order_num);
          v_node_role_param_value.set_value('roleId',
                                            v_node_role_param_values.role_id);
          v_node_role_param_value.set_value('roleCode',
                                            v_node_role_param_values.role_code);
          v_node_role_param_value.set_value('status',
                                            v_node_role_param_values.status);
          v_node_role_param_value.set_value('dataSourceCode',
                                            v_node_role_param_values.data_source_code);

          v_node_role_param_value.set_value('paramValue',
                                            v_node_role_param_values.param_value);
          v_node_role_param_value.set_value('getValueType',
                                            v_node_role_param_values.get_value_type);
          v_node_role_param_value.set_value('operationType',
                                            v_node_role_param_values.operation_type);
          v_node_role_param_value.set_value('roleCount',
                                            v_node_role_param_values.role_count);
          v_node_role.add_list_item('nodeRoleParamValueList',
                                    v_node_role_param_value);
        END LOOP;
        v_process_node.add_list_item('nodeRolesList', v_node_role);

      END LOOP;
      for v_dynamic In v_dynamic_user_cur(v_process_nodes.node_id) loop
        v_dynamic_user := pl_json;
        v_dynamic_user.set_value('getValueType', v_dynamic.get_value_type);
        v_dynamic_user.set_value('dynamicValue', v_dynamic.dynamic_value);
        v_process_node.set_object('dynamicUser', v_dynamic_user);
      end loop;

      FOR v_chain IN v_chain_cur(v_process_nodes.node_id, p_process_id) LOOP
        v_node_chain := pl_json;
        v_node_chain.set_value('chainId', v_chain.chain_id);
        v_node_chain.set_value('chainName', v_chain.chain_name);
        IF v_chain.is_checked = 'Y' THEN
          v_node_chain.set_value('isChecked', TRUE);
        ELSE
          v_node_chain.set_value('isChecked', FALSE);
        END IF;
        v_process_node.add_list_item('nodeChains', v_node_chain);
      END LOOP;
      v_process.add_list_item('processNodeLists', v_process_node);
    END LOOP;
    FOR v_process_params IN v_process_params_cur LOOP
      v_process_param := pl_json;
      v_process_param.set_value('paramId', v_process_params.param_id);
      v_process_param.set_value('processId', v_process_params.process_id);
      v_process_param.set_value('paramCode', v_process_params.param_code);
      v_process_param.set_value('paramName', v_process_params.param_name);
      v_process_param.set_value('paramType', v_process_params.param_type);
      /*FOR v_process_param_values IN v_process_param_values_cur(v_process_params.param_id) LOOP
        v_process_param_value := pl_json;
        v_process_param_value.set_value('paramId',
                                        v_process_param_values.param_id);
        v_process_param_value.set_value('documentId',
                                        v_process_param_values.document_id);
        v_process_param_value.set_value('paramValue',
                                        v_process_param_values.param_value);
        v_process_param.add_list_item('processParamValueLists',
                                      v_process_param_value);
      END LOOP;*/
      v_process.add_list_item('processParamLists', v_process_param);
    END LOOP;
    FOR v_approval_chains IN v_approval_chains_cur LOOP
      v_approval_chain := pl_json;
      v_approval_chain.set_value('chainId', v_approval_chains.chain_id);
      v_approval_chain.set_value('spaceId', v_approval_chains.space_id);
      v_approval_chain.set_value('chainName', v_approval_chains.chain_name);
      v_approval_chain.set_value('chainType', v_approval_chains.chain_type);
      v_approval_chain.set_value('processId', v_approval_chains.process_id);
      v_approval_chain.set_value('organizationId',
                                 v_approval_chains.organization_id);
      v_approval_chain.set_value('version', v_approval_chains.version);
      v_approval_chain.set_value('chainId',
                                 v_approval_chains.from_chain_id);
      v_approval_chain.set_value('status', v_approval_chains.status);
      begin
        --维护ruleTree add by wlj end
        v_rule_tree_clob      := v_approval_chains.chain_rule_tree;
        v_rule_tree_json_list := json_list(v_rule_tree_clob);
        v_approval_chain.set_value('ruleTree', v_rule_tree_json_list);
      exception
        when no_data_found then
          null;
      end;
      FOR v_chain_roles IN v_chain_rules_cur(v_approval_chains.chain_id) LOOP
        v_chain_rule := pl_json;
        v_chain_rule.set_value('ruleId', v_chain_roles.rule_id);
        v_chain_rule.set_value('chainId', v_chain_roles.chain_id);
        v_chain_rule.set_value('paramName', v_chain_roles.param_name);
        v_chain_rule.set_value('paramMeaning', v_chain_roles.param_meaning);
        v_chain_rule.set_value('paramType', v_chain_roles.param_type);
        v_chain_rule.set_value('operationType',
                               v_chain_roles.operation_type);
        v_chain_rule.set_value('paramValue', v_chain_roles.param_value);
        v_chain_rule.set_value('getValueType',
                               v_chain_roles.get_value_type);
        v_chain_rule.set_value('ruleUuid', v_chain_roles.rule_uuid);
        v_approval_chain.add_list_item('chainRulesLists', v_chain_rule);
      END LOOP;
      FOR v_chain_nodes IN v_chain_nodes_cur(v_approval_chains.chain_id) LOOP
        v_chain_node := pl_json;

        v_chain_node.set_value('nodeId', v_chain_nodes.node_id);
        v_chain_node.set_value('chainId', v_chain_nodes.chain_id);
        v_chain_node.set_value('nodeName', v_chain_nodes.node_name);
        v_chain_node.set_value('nodeType', v_chain_nodes.node_type);
        v_chain_node.set_value('orderNum', v_chain_nodes.order_num);
        v_chain_node.set_value('approverType', v_chain_nodes.approver_type);
        v_chain_node.set_value('isAutoApprove',
                               v_chain_nodes.is_auto_approve);
        v_chain_node.set_value('isRequired', v_chain_nodes.is_required);
        FOR v_chain_node_tls IN v_chain_node_tls_cur(v_chain_nodes.node_id) LOOP
          v_chain_node_tl := pl_json;
          v_chain_node_tl.set_value('nodeId', v_chain_node_tls.node_id);
          v_chain_node_tl.set_value('locale', v_chain_node_tls.locale);
          v_chain_node_tl.set_value('nodeName', v_chain_node_tls.node_name);
          v_chain_node.add_list_item('chainNodeTlLists', v_chain_node_tl);
        END LOOP;

        FOR v_role IN v_role_cur(v_chain_nodes.node_id) LOOP
          v_role_json := pl_json;
          v_role_json.set_value('roleId', v_role.role_id);
          v_role_json.set_value('roleCode', v_role.business_role);
          v_role_json.set_value('roleName', v_role.role_name);
          v_role_json.set_value('nodeFromType', v_role.node_from_type);
          v_role_json.set_value('customRoleName', v_role.custom_role_name);
          FOR v_param IN v_param_cur(v_role.node_role_id) LOOP
            v_param_json := pl_json;
            v_param_json.set_value('nodeRoleId', v_param.node_role_id);
            v_param_json.set_value('paramId', v_param.param_id);
            --新增导出角色数据

            v_param_json.set_value('paramName', v_param.param_name);
            v_param_json.set_value('orderNum', v_param.order_num);
            v_param_json.set_value('roleId', v_param.role_id);
            v_param_json.set_value('roleCode', v_param.role_code);
            v_param_json.set_value('status', v_param.status);
            v_param_json.set_value('dataSourceCode',
                                   v_param.data_source_code);
            v_param_json.set_value('roleCount', v_param.role_count);
            v_param_json.set_value('paramValue', v_param.param_value);
            v_param_json.set_value('getValueType', v_param.get_value_type);
            v_param_json.set_value('operationType', v_param.operation_type);
            /*
            v_param_json.set_value('getValueType', v_param.get_value_type);
            v_param_json.set_value('operationType', v_param.operation_type);
            v_param_json.set_value('paramId', v_param.param_id);
            v_param_json.set_value('paramName', v_param.param_name);
            v_param_json.set_value('paramValue', v_param.param_value);*/
            v_role_json.add_list_item('paramList', v_param_json);
          END LOOP;

          v_chain_node.add_list_item('businessRoles', v_role_json);
        END LOOP;

        if v_chain_nodes.approver_type = 'DynamicUser' then
          v_dynamic_user := pl_json;
          begin
            select nvl(t.dynamic_value, ''), nvl(t.get_value_type, '')
              into v_dynamic_value, v_dynamic_value_type
              from DBPM_DYNAMIC_APPROVERS t
             where t.node_id = v_chain_nodes.node_id;
          exception
            when no_data_found then
              v_dynamic_value      := '';
              v_dynamic_value_type := '';
          end;
          v_dynamic_user.set_value('getValueType', v_dynamic_value_type);
          v_dynamic_user.set_value('dynamicValue', v_dynamic_value);
          v_chain_node.set_value('dynamicUser', v_dynamic_user);
        end if;

        if v_chain_nodes.approver_type = 'StaticUser' then
          begin
            select nvl(t.approvers, '')
              into v_dynamic_value
              from dbpm_selected_approvers t
             where t.node_id = v_chain_nodes.node_id;
          exception
            when no_data_found then
              v_dynamic_value := '';
          end;
          v_chain_node.set_value('StaticUser', v_dynamic_value);
        end if;

        v_approval_chain.add_list_item('chainNodeLists', v_chain_node);
      END LOOP;
      v_process.add_list_item('approvalChainLists', v_approval_chain);
    END LOOP;
    RETURN v_process.to_data_json;
  END func_export_process;

  /*==================================================
  Procedure/Function Name :
      func_import_process
  Description:
      This function perform:
      导入对应的流程
  Argument:
     p_process_content ：流程的相关信息
  History:
      1.00  2017-11-13  zhiheng.wei  Creation
  ==================================================*/
  procedure proc_import_process(p_request CLOB, x_response out clob) IS
    v_request                json;
    v_response               pl_json := pl_json;
    v_process_node           json;
    v_data                   json;
    v_process_nodes          json_list;
    v_process_relation_list  json_list;
    v_node_roles             json_list;
    v_approval_chains        json_list;
    v_chain_nodes            json_list;
    v_node_role_param_values json_list;
    v_chain_rules            json_list;
    v_process_params         json_list;
    v_chain_node_tls         json_list;
    v_process_tls            json_list;
    v_chain_role_nodes       json_list;
    v_parm_lists             json_list;
    v_process_param          json;
    v_parm_list              json;
    v_process_tl             json;
    v_node_role              json;
    v_chain_role_node        json;
    v_node_role_param_value  json;
    v_dynamic_User           json;
    v_approval_chain         json;
    v_chain_node             json;
    v_chain_node_tl          json;
    v_chain_rule             json;
    v_process_relation       json;
    v_username               varchar2(100);
    v_process_code           VARCHAR2(100);
    v_role_id                VARCHAR2(100);
    v_process_name           VARCHAR2(50);
    v_description            VARCHAR2(100);
    v_process_type           VARCHAR2(100);
    v_enabled_flag           VARCHAR2(5);
    v_space_id               VARCHAR2(100);
    v_space_Code             VARCHAR2(100);
    v_temp_role              VARCHAR2(200);
    v_is_shared              varchar2(100);
    v_PARAM_ID               number;
    v_role_node_id           number;
    v_space_count            number;
    v_process_id             number;
    v_node_id                number;
    v_node_role_id           number;
    v_temp_role_id           number;
    v_chain_id               number;
    v_chain_node_id          number;
    v_is_role                number; --判断是否有角色数据信息
    v_isProcess              number; --流程编码是否冲突
    v_role_count             number; --流程角色参数数量
    v_relation_count         number;
    v_rule_tree_clob         clob; --add by wlj
  BEGIN
    v_data     := json(p_request, 'OBJECT');
    v_username := v_data.username;
    --dbpm_process dp 流程基本信息
    v_process_code := v_data.get_string('processCode');
    v_process_name := v_data.get_string('processName');
    v_description  := v_data.get_string('description');
    v_process_type := v_data.get_string('processType');
    v_enabled_flag := v_data.get_string('enabledFlag');
    v_space_Code   := v_data.get_string('spaceCode');
    --验证spce空间是否配置
    begin
      select ds.space_id
        into v_space_id
        from dbpm_spaces ds
       where ds.space_code = v_space_Code;
    exception
      when no_data_found then
        v_response.fail('空间不存在！');
        x_response := v_response.to_json;
        return;
    end;
    select count(1)
      into v_space_count
      from dbpm_administrators da
     where da.user_code = v_username
       and da.admin_type = 'SuperAdmin';
    if v_space_count = 0 then
      select count(1)
        into v_space_count
        from dbpm_administrators da, dbpm_spaces ds
       where da.user_code = v_username
         and da.space_id = ds.space_id
         and ds.space_code = v_space_Code;
      if v_space_count = 0 then
        --v_response.fail('当前用户空间与该流程空间不符！');
        v_response.fail(DCLD_COMM_PKG.func_get_err_msg('DCLD-00003',
                                                       v_request.locale));
        x_response := v_response.to_json;
        return;
      end if;
    end if;
    v_is_shared := v_data.get_string('isShared');
    --判断是否已存在流程编码
    select count(1)
      into v_isProcess
      from dbpm_process dp
     where dp.process_code = v_process_code;
    if v_isProcess = 0 then
      v_process_id := dbpm_process_s.nextval;
      insert into dbpm_process
        (process_id,
         process_code,
         process_name,
         description,
         process_type,
         enabled_flag,
         space_id,
         is_shared)
      values
        (v_process_id,
         v_process_code,
         v_process_name,
         v_description,
         v_process_type,
         v_enabled_flag,
         v_space_id,
         v_is_shared);
      --流程发起权限
      if v_data.exist('authRelation') then
        v_process_relation_list := json_list(v_data.get('authRelation'));
        for a in 1 .. v_process_relation_list.count loop
          v_process_relation := json(v_process_relation_list.get(a));
          if v_process_relation.get_string('authType') = 'GROUP' then
            select count(1)
              into v_relation_count
              from dbpm_process_auth_group t
             where t.group_code = v_process_relation.get_string('authCode');
            if v_relation_count = 0 then
              v_response.fail('缺少权限组' ||
                              v_process_relation.get_string('authCode') ||
                              '数据!');
              x_response := v_response.to_json;
              rollback;
              return;
            end if;
            insert into dbpm_process_group_realtion
              (realtion_id, process_id, auth_code, auth_type)
            values
              (dbpm_process_group_realtion_s.nextval,
               v_process_id,
               v_process_relation.get_string('authCode'),
               v_process_relation.get_string('authType'));
          end if;
          if v_process_relation.get_string('authType') = 'ROLE' then
            select count(1)
              into v_relation_count
              from DBPM_ROLES t
             where t.role_code = v_process_relation.get_string('authCode');
            if v_relation_count = 0 then
              v_response.fail('缺少角色权限组' ||
                              v_process_relation.get_string('authCode') ||
                              '数据!');
              x_response := v_response.to_json;
              rollback;
              return;
            end if;
            insert into dbpm_process_group_realtion
              (realtion_id, process_id, auth_code, auth_type)
            values
              (dbpm_process_group_realtion_s.nextval,
               v_process_id,
               v_process_relation.get_string('authCode'),
               v_process_relation.get_string('authType'));
          end if;
        end loop;
      end if;
      if v_data.exist('processNodeLists') then
        v_process_nodes := json_list(v_data.get('processNodeLists'));
        FOR i IN 1 .. v_process_nodes.count LOOP
          v_process_node := json(v_process_nodes.get(i));
          --dbpm_process_nodes dpn 节点配置信息
          v_node_id := dbpm_process_nodes_s.nextval;
          insert into dbpm_process_nodes
            (node_id,
             process_id,
             node_name,
             node_type,
             order_num,
             approver_type,
             is_auto_approve,
             is_required)
          values
            (v_node_id,
             v_process_id,
             v_process_node.get_string('nodeName'),
             v_process_node.get_string('nodeType'),
             v_process_node.get_number('orderNum'),
             v_process_node.get_string('approverType'),
             v_process_node.get_string('isAutoApprove'),
             v_process_node.get_string('isRequired'));
          if v_process_node.get_string('approverType') = 'StaticUser' and
             v_process_node.get_string('approverUsers') is not null then
            insert into dbpm_selected_approvers
              (approver_id, approvers, node_id)
            values
              (dbpm_selected_approvers_s.nextval,
               v_process_node.get_string('approverUsers'),
               v_node_id);
          end if;
          if v_process_node.get_string('approverType') = 'DynamicUser' and
             v_process_node.exist('dynamicUser') then
            v_dynamic_User := json(v_process_node.get('dynamicUser'));
            if v_dynamic_User.get_string('dynamicValue') is not null then
              insert into DBPM_DYNAMIC_APPROVERS
                (APPROVER_ID, NODE_ID, DYNAMIC_VALUE, GET_VALUE_TYPE)
              values
                (DBPM_DYNAMIC_APPROVERS_s.Nextval,
                 v_node_id,
                 v_dynamic_User.get_string('dynamicValue'),
                 v_dynamic_User.get_string('getValueType'));
            end if;
          end if;
          if v_process_node.exist('nodeRolesList') then
            v_node_roles := json_list(v_process_node.get('nodeRolesList'));
            FOR o IN 1 .. v_node_roles.count LOOP
              v_node_role := json(v_node_roles.get(o));
              --dbpm_node_roles dnr  节点审批角色
              select count(1)
                into v_is_role
                from DBPM_ROLES dr
               where dr.role_code = v_node_role.get_string('businessRole');
              if v_is_role <> 0 then

                v_node_role_id := dbpm_node_roles_s.nextval;
                insert into dbpm_node_roles
                  (node_role_id,
                   node_id,
                   business_role,
                   node_from_type,
                   custom_role_name)
                values
                  (v_node_role_id,
                   v_node_id,
                   v_node_role.get_string('businessRole'),
                   v_node_role.get_string('nodeFromType'),
                   v_node_role.get_string('customRoleName'));
              else
                v_response.fail('缺少角色' ||
                                v_node_role.get_string('businessRole') ||
                                '数据!');
                x_response := v_response.to_json;
                rollback;
                return;
              end if;
              if v_node_role.exist('nodeRoleParamValueList') then
                v_node_role_param_values := json_list(v_node_role.get('nodeRoleParamValueList'));
                FOR p IN 1 .. v_node_role_param_values.count LOOP
                  v_node_role_param_value := json(v_node_role_param_values.get(p));
                  --dbpm_node_role_param_value dnrpv  节点角色规则
                  --校验导入角色数据 并查询角色ID
                  begin
                    select dr.role_id
                      into v_role_id
                      from dbpm_roles dr
                     where dr.role_code =
                           v_node_role_param_value.get_string('roleCode');
                  exception
                    when no_data_found then

                      v_response.fail('缺少' ||
                                      v_chain_role_node.get_string('roleCode') ||
                                      '角色数据！');
                      x_response := v_response.to_json;
                      rollback;
                      return;
                  end;
                  --角色参数数量校验
                  select count(*)
                    into v_role_count
                    from DBPM_ROLE_PARAMS rp
                   where rp.role_id = v_role_id;
                  if v_role_count <>
                     v_node_role_param_value.get_string('roleCount') then
                    v_response.fail(v_node_role.get_string('businessRole') ||
                                    '角色参数数量与导入环境不一致！');
                    x_response := v_response.to_json;
                    rollback;
                    return;
                  end if;
                  --新增角色参数
                  begin
                    select rp.param_id
                      into v_PARAM_ID
                      from DBPM_ROLE_PARAMS rp
                     where rp.role_id = v_role_id
                       and rp.param_name =
                           v_node_role_param_value.get_string('paramName')
                       and rp.status =
                           v_node_role_param_value.get_string('status');

                  exception
                    when no_data_found then
                      v_response.fail(v_node_role.get_string('businessRole') ||
                                      '角色参数与导入环境不一致！');
                      x_response := v_response.to_json;
                      rollback;
                      return;
                  end;
                  --新增节点角色参数
                  insert into dbpm_node_role_param_value
                    (node_role_id,
                     param_id,
                     param_value,
                     get_value_type,
                     operation_type)
                  values
                    (v_node_role_id,
                     v_PARAM_ID,
                     v_node_role_param_value.get_string('paramValue'),
                     v_node_role_param_value.get_string('getValueType'),
                     v_node_role_param_value.get_string('operationType'));
                END LOOP;
              end if;
            END LOOP;
          end if;
        END LOOP;
      end if;
      if v_data.exist('processParamLists') then
        v_process_params := json_list(v_data.get('processParamLists'));
        --dbpm_process_params dpp 流程参数
        FOR j IN 1 .. v_process_params.count LOOP
          v_process_param := json(v_process_params.get(j));
          insert into dbpm_process_params
            (param_id, process_id, param_code, param_name, param_type)
          values
            (dbpm_process_params_s.nextval,
             v_process_id,
             v_process_param.get_string('paramCode'),
             v_process_param.get_string('paramName'),
             v_process_param.get_string('paramType'));
        END LOOP;
      end if;
      --流程多多语言
      if v_data.exist('processTlList') then
        v_process_tls := json_list(v_data.get('processTlList'));
        FOR x IN 1 .. v_process_tls.count LOOP
          v_process_tl := json(v_process_tls.get(x));
          insert into dbpm_process_tl
            (process_id, locale, process_name, description)
          values
            (v_process_id,
             v_process_tl.get_string('locale'),
             v_process_tl.get_string('processName'),
             v_process_tl.get_string('description'));
        END LOOP;
      end if;
      if v_data.exist('approvalChainLists') then
        v_approval_chains := json_list(v_data.get('approvalChainLists'));
        FOR k IN 1 .. v_approval_chains.count LOOP
          v_approval_chain := json(v_approval_chains.get(k));
          --dbpm_approval_chain dac 审批链信息
          v_chain_id := dbpm_approval_chain_s.nextval;
          insert into dbpm_approval_chain
            (chain_id,
             chain_name,
             chain_type,
             process_id,
             organization_id,
             version,
             from_chain_id,
             status,
             space_id)
          values
            (v_chain_id,
             v_approval_chain.get_string('chainName'),
             v_approval_chain.get_string('chainType'),
             v_process_id,
             v_approval_chain.get_string('organizationId'),
             nvl(v_approval_chain.get_string('version'), 1),
             null,
             v_approval_chain.get_string('status'),
             v_approval_chain.get_string('spaceId'));
          --维护规则树
          IF v_approval_chain.path('ruleTree') IS NOT NULL THEN
            dbms_lob.createtemporary(v_rule_tree_clob, false);
            json_list(v_approval_chain.get('ruleTree')).to_clob(v_rule_tree_clob);
            INSERT INTO dbpm_chain_rules_tree
              (chain_id,
               chain_name,
               chain_type,
               process_id,
               organization_id,
               status,
               space_id,
               chain_rule_tree,
               version)
            VALUES
              (v_chain_id,
               v_approval_chain.get('chainName').get_string,
               v_approval_chain.get('chainType').get_string,
               v_approval_chain.get('processId').get_number,
               v_approval_chain.get('organizationId').get_string,
               'Y',
               v_space_id,
               v_rule_tree_clob,
               nvl(v_approval_chain.get_string('version'), 1));
          END IF;
          if v_approval_chain.exist('chainRulesLists') then
            v_chain_rules := json_list(v_approval_chain.get('chainRulesLists'));
            FOR l IN 1 .. v_chain_rules.count LOOP
              v_chain_rule := json(v_chain_rules.get(l));
              --dbpm_chain_rules dcr 审批链规则
              insert into dbpm_chain_rules
                (rule_id,
                 chain_id,
                 param_name,
                 param_meaning,
                 param_type,
                 operation_type,
                 param_value,
                 get_value_type,
                 rule_uuid)
              values
                (dbpm_chain_rules_s.nextval,
                 v_chain_id,
                 v_chain_rule.get_string('paramName'),
                 v_chain_rule.get_string('paramMeaning'),
                 v_chain_rule.get_string('paramType'),
                 v_chain_rule.get_string('operationType'),
                 v_chain_rule.get_string('paramValue'),
                 v_chain_rule.get_string('getValueType'),
                 v_chain_rule.get_string('ruleUuid'));

            END LOOP;
          end if;
          if v_approval_chain.exist('chainNodeLists') then
            v_chain_nodes := json_list(v_approval_chain.get('chainNodeLists'));
            FOR b IN 1 .. v_chain_nodes.count LOOP
              v_chain_node    := json(v_chain_nodes.get(b));
              v_chain_node_id := dbpm_chain_nodes_s.nextval;
              --dbpm_chain_nodes dcn 审批链节点
              insert into dbpm_chain_nodes
                (node_id,
                 chain_id,
                 node_name,
                 node_type,
                 order_num,
                 approver_type,
                 is_auto_approve,
                 is_required)
              values
                (v_chain_node_id,
                 v_chain_id,
                 v_chain_node.get_string('nodeName'),
                 v_chain_node.get_string('nodeType'),
                 v_chain_node.get_number('orderNum'),
                 v_chain_node.get_string('approverType'),
                 v_chain_node.get_string('isAutoApprove'),
                 v_chain_node.get_string('isRequired'));
              if v_chain_node.get_string('approverType') = 'StaticUser' and
                 v_chain_node.get_string('StaticUser') is not null then
                insert into dbpm_selected_approvers
                  (approver_id, approvers, node_id)
                values
                  (dbpm_selected_approvers_s.nextval,
                   v_chain_node.get_string('StaticUser'),
                   v_chain_node_id);
              end if;
              if v_chain_node.get_string('approverType') = 'DynamicUser' and
                 v_chain_node.exist('dynamicUser') then
                v_dynamic_User := json(v_chain_node.get('dynamicUser'));
                if v_dynamic_User.get_string('dynamicValue') is not null then
                  insert into DBPM_DYNAMIC_APPROVERS
                    (APPROVER_ID, NODE_ID, DYNAMIC_VALUE, GET_VALUE_TYPE)
                  values
                    (DBPM_DYNAMIC_APPROVERS_s.Nextval,
                     v_chain_node_id,
                     v_dynamic_User.get_string('dynamicValue'),
                     v_dynamic_User.get_string('getValueType'));
                end if;
              end if;

              if v_chain_node.exist('chainNodeTlLists') then
                v_chain_node_tls := json_list(v_chain_node.get('chainNodeTlLists'));
                FOR n IN 1 .. v_chain_node_tls.count LOOP
                  v_chain_node_tl := json(v_chain_node_tls.get(n));
                  --dbpm_chain_nodes_tl dcnt 审批链节点角色
                  insert into dbpm_chain_nodes_tl
                    (node_id, locale, node_name)
                  values
                    (v_chain_node_id,
                     v_chain_node_tl.get_string('locale'),
                     v_chain_node_tl.get_string('nodeName'));
                END LOOP;
              end if;
              if v_chain_node.exist('businessRoles') then
                v_chain_role_nodes := json_list(v_chain_node.get('businessRoles'));
                FOR o IN 1 .. v_chain_role_nodes.count LOOP
                  v_chain_role_node := json(v_chain_role_nodes.get(o));
                  --dbpm_node_roles dnr  节点审批角色
                  select count(1)
                    into v_is_role
                    from DBPM_ROLES dr
                   where dr.role_code =
                         v_chain_role_node.get_string('roleCode');
                  if v_is_role <> 0 then

                    v_node_role_id := dbpm_node_roles_s.nextval;
                    insert into dbpm_node_roles
                      (node_role_id,
                       node_id,
                       business_role,
                       node_from_type,
                       custom_role_name)
                    values
                      (v_node_role_id,
                       v_chain_node_id,
                       v_chain_role_node.get_string('roleCode'),
                       v_chain_role_node.get_string('nodeFromType'),
                       v_chain_role_node.get_string('customRoleName'));
                  else
                    v_response.fail('审批链缺少' ||
                                    v_chain_role_node.get_string('roleCode') ||
                                    '角色数据！！');
                    x_response := v_response.to_json;
                    rollback;
                    return;
                  end if;
                  if v_chain_role_node.exist('paramList') then
                    v_parm_lists := json_list(v_chain_role_node.get('paramList'));
                    FOR p IN 1 .. v_parm_lists.count LOOP
                      v_parm_list := json(v_parm_lists.get(p));
                      --dbpm_node_role_param_value dnrpv  节点角色规则
                      --校验导入角色数据 并查询角色ID
                      begin
                        select dr.role_id
                          into v_role_id
                          from dbpm_roles dr
                         where dr.role_code =
                               v_chain_role_node.get_string('roleCode');
                      exception
                        when no_data_found then

                          v_response.fail('审批链缺少' ||
                                          v_chain_role_node.get_string('roleCode') ||
                                          '角色数据！');
                          x_response := v_response.to_json;
                          rollback;
                          return;
                      end;
                      --角色参数数量校验
                      select count(*)
                        into v_role_count
                        from DBPM_ROLE_PARAMS rp
                       where rp.role_id = v_role_id;
                      if v_role_count <>
                         v_parm_list.get_string('roleCount') then
                        v_response.fail(v_chain_role_node.get_string('roleCode') ||
                                        '角色参数数量与导入环境不一致！');
                        x_response := v_response.to_json;
                        rollback;
                        return;
                      end if;
                      --新增角色参数
                      begin
                        select rp.param_id
                          into v_PARAM_ID
                          from DBPM_ROLE_PARAMS rp
                         where rp.role_id = v_role_id
                           and rp.param_name =
                               v_parm_list.get_string('paramName')
                           and rp.status = v_parm_list.get_string('status');

                      exception
                        when no_data_found then
                          v_response.fail(v_chain_role_node.get_string('roleCode') ||
                                          '角色参数与导入环境不一致！');
                          x_response := v_response.to_json;
                          rollback;
                          return;
                      end;
                      begin
                        --新增节点角色参数
                        insert into dbpm_node_role_param_value
                          (node_role_id,
                           param_id,
                           param_value,
                           get_value_type,
                           operation_type)
                        values
                          (v_node_role_id,
                           v_PARAM_ID,
                           v_parm_list.get_string('paramValue'),
                           v_parm_list.get_string('getValueType'),
                           v_parm_list.get_string('operationType'));
                      exception
                        when others then
                          v_response.fail(v_chain_role_node.get_string('roleCode') ||
                                          '角色参数与导入环境不一致！');
                          x_response := v_response.to_json;
                          rollback;
                          return;
                      end;
                    END LOOP;
                  end if;
                END LOOP;
                /*    FOR z IN 1 .. v_chain_role_nodes.count LOOP
                  v_chain_role_node := json(v_chain_role_nodes.get(z));
                  begin
                    select dr.role_id
                      into v_temp_role
                      from dbpm_roles dr
                     where dr.role_code =
                           v_chain_role_node.get_string('roleCode');
                  exception
                    when no_data_found then
                      v_response.fail('审批链缺少角色数据！');
                      x_response := v_response.to_json;
                      rollback;
                      return;
                  end;
                  v_role_node_id := dbpm_node_roles_s.nextval;
                  insert into dbpm_node_roles
                    (node_role_id, node_id, business_role, node_from_type)
                  values
                    (v_role_node_id,
                     v_chain_node_id,
                     v_chain_role_node.get_string('roleCode'),
                     v_chain_role_node.get_string('nodeFromType'));
                  if v_chain_role_node.exist('paramList') then
                    v_parm_lists := json_list(v_chain_role_node.get('paramList'));
                    FOR a IN 1 .. v_parm_lists.count LOOP
                      v_parm_list := json(v_parm_lists.get(a));
                      insert into dbpm_node_role_param_value
                        (param_id,
                         param_value,
                         operation_type,
                         node_role_id,
                         get_value_type)
                      values
                        (dbpm_node_role_param_value_s.nextval,
                         v_parm_list.get_string('paramName'),
                         v_parm_list.get_string('operationType'),
                         v_role_node_id,
                         v_parm_list.get_string('getValueType'));
                    end loop;
                  end if;
                end loop;*/
              end if;
            END LOOP;
          end if;
        END LOOP;
      end if;
    else
      v_response.fail('已存在此流程编码！');
      x_response := v_response.to_json;
      rollback;
      return;
    end if;
    v_response.set_value('processId', v_process_id);
    x_response := v_response.to_json;
  END proc_import_process;

  /*==================================================
  Procedure/Function Name :
      proc_get_back_policy
  Description:
      This function perform:
      获取回退的策略
  Argument:
     p_process_content ：流程的相关信息
  History:
      1.00  2018-05-09  wlj  Creation
  ==================================================*/
  procedure proc_get_back_policy(p_cur_node_id IN NUMBER,
                                 x_outcome     OUT VARCHAR2,
                                 x_offset      OUT NUMBER,
                                 x_result_flag OUT VARCHAR2,
                                 x_error_msg   OUT VARCHAR2) AS
    v_back_nodeid number;
    v_cur_seq     number;
    v_back_seq    number;
    v_offset      number;
  BEGIN
    --回退至上一节点

    select dn.back_node_id, dn.order_num
      into v_back_nodeid, v_cur_seq
      from dbpm_chain_nodes dn
     where dn.node_id = p_cur_node_id;
    --退回申请人
    if v_back_nodeid = -1 then
      select max(dns.order_num)
        into v_back_seq
        from dbpm_chain_nodes dn, dbpm_chain_nodes dns
       where dn.chain_id = dns.chain_id
         and dn.version = dns.version
         and dn.node_id = p_cur_node_id;
      v_offset := v_cur_seq - (v_back_seq + 1);
      --退回上一级
    elsif v_back_nodeid = 1 then

      v_offset := 1;
      --退回指定节点
    elsif v_back_nodeid > 1 then
      select dns.order_num
        into v_back_seq
        from dbpm_chain_nodes dn, dbpm_chain_nodes dns
       where dn.back_node_id = dns.parent_id
         and dn.chain_id = dns.chain_id
         and dn.version = dns.version
         and dn.node_id = p_cur_node_id;
      v_offset := v_cur_seq - v_back_seq;

    end if;
    x_offset := v_offset;
  exception
    when others then
      x_offset      := 1;
      x_result_flag := '求退回节点发生异常';
  END;

  /*==================================================
  Procedure/Function Name :
      proc_get_form_url
  Description:
      This function perform:
      获取表单链接（外部表单）
  Argument:
     P_DOCUMENT_ID ：得云表单ID
     X_URL : 外部表单链接
  History:
      1.00  2018-05-09  wlj  Creation
  ==================================================*/
  procedure proc_get_form_url(P_DOCUMENT_ID IN VARCHAR2,
                              X_URL         OUT VARCHAR2,
                              x_result_flag OUT VARCHAR2,
                              x_error_msg   OUT VARCHAR2) AS
    v_process_id   number;
    v_doc_sys_code varchar2(100);
    v_instance_id  varchar2(100);
    v_form_key     varchar2(100);
    v_process_code varchar2(4000);
  BEGIN
    SELECT D.DOC_SYS_CODE, D.PROCESS_ID, d.doc_form_id, d.bpm_instance_id
      INTO v_doc_sys_code, v_process_id, v_form_key, v_instance_id
      FROM DBPM_DOCUMENTS D
     WHERE D.DOCUMENT_ID = P_DOCUMENT_ID;
    IF v_doc_sys_code = 'BPM_EXT' THEN
      --流程配置了外部表单
      SELECT NVL(DP.FORM_URL, ''), dp.process_code
        INTO X_URL, v_process_code
        FROM DBPM_PROCESS DP
       WHERE DP.PROCESS_ID = v_process_id;
      --拼接参数
      --1.拼接defineSys
      X_URL := X_URL || '?' || 'defineSys=' || 'defineSys';
      --2.拼接formKey
      if v_form_key is not null then
        X_URL := X_URL || '&' || 'formKey=' || v_form_key;
      end if;
      --3.拼接instanceId
      if v_instance_id is not null then
        X_URL := X_URL || '&' || 'instanceId=' || v_instance_id;
      end if;
      --4.拼接processCode
      if v_process_code is not null then
        X_URL := X_URL || '&' || 'processCode=' || v_process_code;
      end if;
    END IF;
    x_result_flag := 'Y';
  EXCEPTION
    WHEN OTHERS THEN
      x_result_flag := 'N';
      X_URL         := '';
      x_error_msg   := SQLERRM;
  END;
  /*==================================================
  Procedure/Function Name :
      proc_get_approval_Formurl
  Description:

      获得节点绑定的审批页地址
  Argument:
      p_nodeid ：节点ID
      p_processCode ：流程编号
      p_attr ：备用属性
     X_URL : 审批页地址
  History:
      1.00  2019-01-06  xiaowei.yao  Creation
  ==================================================*/
  procedure proc_get_approval_formurl(p_nodeid      IN number,
                                      p_processCode IN VARCHAR2,
                                      p_attr        IN VARCHAR2,
                                      x_url         OUT VARCHAR2,
                                      x_nodename    OUT VARCHAR2,
                                      x_result_flag OUT VARCHAR2,
                                      x_error_msg   OUT VARCHAR2) is
  begin
    if p_nodeid > 0 then
      select dn.node_formurl, dn.node_name
        into x_url, x_nodename
        from dbpm_process_nodes dn, dbpm_chain_nodes dcn
       where dcn.node_id = p_nodeid
         and dn.node_id = dcn.parent_id;
    end if;
    if p_nodeid = -1 then
      select dn.node_formurl, dn.node_name
        into x_url, x_nodename
        from dbpm_process_nodes dn, dbpm_process dp
       where dn.process_id = dp.process_id
         and dn.order_num = 1
         and dp.process_code = p_processCode;
    end if;
  EXCEPTION
    WHEN OTHERS THEN
      x_nodename    := '';
      x_url         := 'www.nopagefound.com';
      x_result_flag := 'N';
      x_error_msg   := '获取节点信息有误';
  end proc_get_approval_formurl;

  /*==================================================
  Procedure/Function Name :
      proc_save_doc_chain
  Description:
      This function perform:
      proc_save_instance_detail
  Argument:
     p_bpm_instance_id ：流程实例
     x_chain : 审批链详情
  History:
      1.00  2018-05-21  wlj  Creation
  ==================================================*/
  procedure proc_save_instance_detail(p_bpm_instance_id IN VARCHAR2,
                                      x_chain           IN dbpm_approval_chain_rec,
                                      x_result_flag     OUT VARCHAR2,
                                      x_error_msg       OUT VARCHAR2) AS
  BEGIN
    /*x_chain.
    MERGE INTO DBPM_PROCESS_INSTANCE_DETAIL D
    USING (SELECT x_chain.chain_id chain_id,  FROM DUAL) TMP*/
    NULL;
  END;
  /*
  * 获取子审批流流程编号
  * add by xiaowei.yao 20181228
  */
  PROCEDURE proc_get_sub_approval_chain(p_instanceid      VARCHAR2,
                                        p_document_id     VARCHAR2,
                                        p_process_param   dbpm_process_param_rec,
                                        p_business_param  dbpm_business_param_tbl,
                                        x_sub_porcesscode OUT VARCHAR2,
                                        x_porcesscode     OUT VARCHAR2,
                                        x_attr            OUT VARCHAR2,
                                        x_result_flag     OUT VARCHAR2,
                                        x_error_msg       OUT VARCHAR2) is
    v_total_count number;
    v_tmp_count   number;
    v_approver    VARCHAR2(2000);
  begin

    x_result_flag := 'N';
    --判断是否需要启动子流程
    if p_process_param.businessSysCode = 'GEMS' then
      select count(*), max(wf.approvers)
        into v_tmp_count, v_approver
        from wftaskhistory wf
       where wf.instanceid = p_instanceid
         and wf.approvers <> 'workflowsystem'
         and wf.creator = wf.approvers;
      select count(*), max(wf.approvers)
        into v_total_count, v_approver
        from wftaskhistory wf
       where wf.instanceid = p_instanceid
         and wf.approvers <> 'workflowsystem';

      if v_tmp_count = v_total_count and v_tmp_count > 0 then
        x_result_flag     := 'N';
        x_sub_porcesscode := 'gems_subprocess_manager';
        x_porcesscode     := p_process_param.processCode;
      end if;
      x_result_flag := 'N';
    end if;

  end proc_get_sub_approval_chain;
  /*
  * 通过扩展插件方式，客户化获取代理规则
  */
  PROCEDURE proc_get_proxy_rules_plugin(p_approvers       VARCHAR2,
                                        p_node_id         NUMBER,
                                        p_document_id     VARCHAR2,
                                        p_process_param   dbpm_process_param_rec,
                                        p_business_param  dbpm_business_param_tbl,
                                        x_proxy_approvers OUT VARCHAR2,
                                        x_proxy_rules     OUT VARCHAR2,
                                        x_result_flag     OUT VARCHAR2,
                                        x_error_msg       OUT VARCHAR2) is
    v_process_id    NUMBER;
    v_method_type   VARCHAR2(100);
    v_method        VARCHAR2(100);
    v_sql           VARCHAR2(4000);
    v_uuid          varchar2(300);
    v_be_authorizer varchar2(300);
    v_space_id      varchar2(100);
  BEGIN
    SELECT dp.process_id, dp.space_id
      INTO v_process_id, v_space_id
      FROM dbpm_process dp
     WHERE dp.process_code = p_process_param.processcode;
    -- 判断是否配置到空间级别
    begin
      SELECT gae.method_type, gae.method
        INTO v_method_type, v_method
        FROM dbpm_get_proxy_rules_ext gae
       WHERE gae.ext_type = 'Process'
         AND gae.process_id = v_process_id;
    EXCEPTION
      WHEN no_data_found THEN
        begin
          SELECT gae.method_type, gae.method
            INTO v_method_type, v_method
            FROM dbpm_get_proxy_rules_ext gae
           WHERE gae.ext_type = 'Space'
             AND gae.space_id = v_space_id;
        EXCEPTION
          WHEN no_data_found THEN
            begin
              SELECT gae.method_type, gae.method
                INTO v_method_type, v_method
                FROM dbpm_get_proxy_rules_ext gae
               WHERE gae.ext_type = 'Glogal';
            EXCEPTION
              WHEN no_data_found THEN
                x_result_flag := 'NO_DATA_FOUND';
                return;
            end;
        end;
    end;
    IF v_method_type = 'Package' THEN
      v_sql := 'begin ' || v_method || '(:1,:2,:3,:4,:5,:6,:7,:8,:9); end;';
      EXECUTE IMMEDIATE v_sql
        USING IN p_approvers, IN p_node_id, IN p_document_id, IN p_process_param, IN p_business_param, OUT x_proxy_approvers, OUT x_proxy_rules, OUT x_result_flag, OUT x_error_msg;
      RETURN;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      x_proxy_approvers := '';
      x_proxy_rules     := '';
      x_result_flag     := 'N';
      x_error_msg       := '通过扩展插件方式获取代理规则失败！';

  end proc_get_proxy_rules_plugin;
  /*==================================================
  Procedure/Function Name :
      proc_get_email_ext
  Description:
      This function perform:
      使用扩展方式生成邮件的主题和body
  History:
      1.00  2019-03-01  xiaower.yao  Creation
  ==================================================*/
  PROCEDURE proc_get_email_ext(p_taskid         VARCHAR2,
                               P_locale         VARCHAR2,
                               p_process_param  dbpm_process_param_rec,
                               p_business_param dbpm_business_param_tbl,
                               x_email_title    OUT VARCHAR2,
                               x_email_body     OUT VARCHAR2,
                               x_result_flag    OUT VARCHAR2,
                               x_error_msg      OUT VARCHAR2) is
    v_task_url     varchar2(2000) := 'https://ssosci.haier.net:444/authority/login-dd.jsp';
    v_process_name varchar2(2000);

  begin

    proc_get_email_plugin(p_taskid         => p_taskid,
                          P_locale         => P_locale,
                          p_process_param  => p_process_param,
                          p_business_param => p_business_param,
                          x_email_title    => x_email_title,
                          x_email_body     => x_email_body,
                          x_result_flag    => x_result_flag,
                          x_error_msg      => x_error_msg);

    IF x_result_flag = 'NO_DATA_FOUND' THEN
      ---通用查找邮件模板的方式
      dbpm_event_pkg.proc_get_email_ext(p_taskid         => p_taskid,
                                        P_locale         => P_locale,
                                        p_process_param  => p_process_param,
                                        p_business_param => p_business_param,
                                        x_email_title    => x_email_title,
                                        x_email_body     => x_email_body,
                                        x_result_flag    => x_result_flag,
                                        x_error_msg      => x_error_msg);
    end if;
  end proc_get_email_ext;

  /*==================================================
  Procedure/Function Name :
      proc_get_email_ext
  Description:
      This function perform:
      插件化的方式生成邮件的主题和body
  History:
      1.00  2019-03-01  xiaower.yao  Creation
  ==================================================*/
  PROCEDURE proc_get_email_plugin(p_taskid         VARCHAR2,
                                  P_locale         VARCHAR2,
                                  p_process_param  dbpm_process_param_rec,
                                  p_business_param dbpm_business_param_tbl,
                                  x_email_title    OUT VARCHAR2,
                                  x_email_body     OUT VARCHAR2,
                                  x_result_flag    OUT VARCHAR2,
                                  x_error_msg      OUT VARCHAR2) is
    v_process_id  number;
    v_method_type varchar2(2000);
    v_method      varchar2(2000);
    v_space_id    number;
    v_sql         varchar2(2000);
    -- 判断查找插件
  begin
    SELECT dp.process_id, dp.space_id
      INTO v_process_id, v_space_id
      FROM dbpm_process dp
     WHERE dp.process_code = p_process_param.processcode;
    begin
      SELECT gae.method_type, gae.method
        INTO v_method_type, v_method
        FROM dbpm_get_email_ext gae
       WHERE gae.ext_type = 'Process'
         AND gae.process_id = v_process_id;
    EXCEPTION
      WHEN no_data_found THEN
        begin
          SELECT gae.method_type, gae.method
            INTO v_method_type, v_method
            FROM dbpm_get_email_ext gae
           WHERE gae.ext_type = 'Space'
             AND gae.space_id = v_space_id;
        EXCEPTION
          WHEN no_data_found THEN
            begin
              SELECT gae.method_type, gae.method
                INTO v_method_type, v_method
                FROM dbpm_get_email_ext gae
               WHERE gae.ext_type = 'Glogal';
            EXCEPTION
              WHEN no_data_found THEN
                x_result_flag := 'NO_DATA_FOUND';
                return;
            end;
        end;
    end;
    IF v_method_type = 'Package' THEN
      v_sql := 'begin ' || v_method || '(:1,:2,:3,:4,:5,:6,:7,:8); end;';
      EXECUTE IMMEDIATE v_sql
        USING IN p_taskid, IN P_locale, IN p_process_param, IN p_business_param, OUT x_email_title, OUT x_email_body, OUT x_result_flag, OUT x_error_msg;
      RETURN;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      x_email_title := '';
      x_email_body  := '';
      x_result_flag := 'N';
      x_error_msg   := '通过扩展插件方式获取邮件模板失败！';
  end proc_get_email_plugin;
  /*==================================================
  Procedure/Function Name :
      proc_get_business_param
  Description:
      This function perform:
      查询流程参数
  History:
      1.00  2019-06-26  xiaower.yao  Creation
  ==================================================*/
  PROCEDURE proc_get_business_param(p_instanceId     VARCHAR2,
                                    p_business_param dbpm_business_param_tbl,
                                    x_business_param out dbpm_business_param_tbl,
                                    x_result_flag    OUT VARCHAR2,
                                    x_error_msg      OUT VARCHAR2) is
    v_business_param dbpm_business_param_tbl := dbpm_business_param_tbl();
    v_recontent      clob;
    v_re             json;
    v_business       json;
    v_params         json_list;
    v_param          json;
    v_count          number;
  begin
    --获取流程参数
    begin
      select dsp.request_content
        into v_recontent
        from dbpm_process_start_param dsp
       where dsp.instanceid = p_instanceid
         and dsp.create_date <> dsp.update_date
         and not exists (select 1
                from dbpm_start_param_reversion dr
               where dr.instanceid = p_instanceid);
    EXCEPTION
      WHEN no_data_found THEN
        x_business_param := p_business_param;
        x_result_flag    := 'N';
        x_error_msg      := '用BPM自带API进行参数更新，不需要自定义方式更新';
        return;
    end;
    v_re := json(v_recontent);
    if (v_re.path('businessParam') is not null) then
      v_business := json(v_re.get('businessParam'));
      if v_business.path('param') is not null then
        v_params := json_list(v_business.get('param'));
        for i in 1 .. v_params.count loop
          v_param := json(v_params.get(i));
          v_business_param.extend();
          v_business_param(i) := dbpm_business_param_rec(v_param.get_string('key'),
                                                         v_param.get_string('value'));
        end loop;
      else
        x_business_param := p_business_param;
        x_result_flag    := 'N';
        x_error_msg      := '自定义方式更新失败';
        return;
      end if;
      x_business_param := v_business_param;
      x_result_flag    := 'Y';
      x_error_msg      := '自定义方式更新成功';
    end if;
  EXCEPTION
    WHEN others THEN
      x_business_param := p_business_param;
      x_result_flag    := 'N';
      x_error_msg      := '未知错误，更新失败';
  end proc_get_business_param;
END dbpm_core_pkg;

/

