create package body     CUX_EXT_SYS_PKG is

  /*==================================================
  Procedure/Function Name :
      proc_save_mob_data
  Description:
      This function perform:
      关联单据/维护移动端数据
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-06-14  wlj   Creation
  ==================================================*/
  PROCEDURE proc_save_mob_data(p_request CLOB, x_response OUT CLOB) AS
    v_request    json;
    v_response   pl_json := pl_json;
    v_doc_number varchar2(100);
    v_sys_code   varchar2(100);
    v_mob_data   clob;
    v_mob_url    varchar2(4000);
  BEGIN
    v_request    := json(p_request);
    v_doc_number := v_request.get_string('documentNumber');
    v_sys_code   := nvl(v_request.get_string('sysCode'), 'UNKNOW');
    v_mob_url    := v_request.get_string('mobileViewUrl');

    if v_request.exist('mobileData') then
      dbms_lob.createtemporary(v_mob_data, true);
      v_request.to_clob(v_mob_data);
    end if;

    MERGE INTO CUX_PROCESS_MOB_DATA T
    USING (SELECT v_doc_number doc_number, v_sys_code sys_code FROM DUAL) TMP
    ON (T.SYS_CODE = TMP.SYS_CODE AND T.DOCUMENT_NUMBER = TMP.DOC_NUMBER)
    WHEN MATCHED THEN
      UPDATE
         SET T.MOBILE_DATA           = v_mob_data,
             T.MOBILE_URL            = v_mob_url,
             T.LAST_UPDATE_DATE      = SYSDATE,
             T.OBJECT_VERSION_NUMBER = T.OBJECT_VERSION_NUMBER + 1
    WHEN NOT MATCHED THEN
      INSERT
        (T.DOCUMENT_NUMBER,
         T.TASK_ID,
         T.MOBILE_DATA,
         T.MOBILE_URL,
         T.SYS_CODE)
      VALUES
        (v_doc_number, NULL, v_mob_data, v_mob_url, v_sys_code);
    x_response := v_response.to_json;
  END;
end CUX_EXT_SYS_PKG;

/

