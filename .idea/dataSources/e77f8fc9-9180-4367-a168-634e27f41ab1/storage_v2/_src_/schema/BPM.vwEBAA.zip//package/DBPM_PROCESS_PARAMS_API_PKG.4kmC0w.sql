create PACKAGE     dbpm_process_params_api_pkg IS

  /*==================================================
  Procedure/Function Name :
      proc_query_process_params
  Description:
      This function perform:
      查询流程参数
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-07-06  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_query_process_params(p_request CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_save_process_param
  Description:
      This function perform:
      保存流程参数，需要判断是新增还是修改
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-07-06  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_save_process_param(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_del_process_param
  Description:
      This function perform:
      删除流程参数
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-05-13  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_del_process_param(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_get_process_req_params
  Description:
      This function perform:
      获取json格式
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-09-30  张俊强~  Creation
  ==================================================*/
  PROCEDURE proc_get_process_req_params(p_request  IN CLOB,
                                        x_response OUT CLOB);

END dbpm_process_params_api_pkg;

/

