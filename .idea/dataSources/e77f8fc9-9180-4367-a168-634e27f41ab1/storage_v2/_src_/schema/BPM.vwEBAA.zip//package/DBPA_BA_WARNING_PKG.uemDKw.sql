create PACKAGE "DBPA_BA_WARNING_PKG" is

  -- Author  : Echo.Zeng
  -- Created : 2018-01-11 09:00:00
  --TYPE
  type refcur is ref cursor;

  /*==================================================
  Procedure/Function Name :
      proc_create_warning_event
  Description:
      This function perform:
      创建预警事件


  Argument:
     --入参
     p_waring_id       预警id
     --出参
     无
  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  procedure proc_create_warning_event(p_waring_id in number);

  /*==================================================
  Procedure/Function Name :
      proc_query_warnings
  Description:
      This function perform:
      查询预警配置，支持分页
  Argument:
     --入参 p_request json
          {
              "user": "",
              "data":
              {
                  "systemCode": "GEMS",
                  "params": [
                      "warningName": "test",
                      "processName": "test",
                      "notificaType": "test",
                      "startDate": "test",
                      "endDate": "test",
                      "createBy": "",
                      "notificaRecipients": "",
                      "notificaCC": ""
                  ],
                  "pageNo": 1,
                  "size": 10
              }
          }
     --出参 x_response  json
            {
                "code": "SUCCESS",
                "data":
                {
                    "warnings": [
                    {
                        "warningId": 1,
                        "warningName": "",
                        "process":
                        {
                            "code": "xxxx",
                            "name": "测试"
                        },
                        "notificaType":
                        {
                            "code": "email",
                            "name": "邮件"
                        },
                        "startDate": "",
                        "endDate": "",
                        "createBy":
                        {
                            "code": "a0017702",
                            "name": "曾勇"
                        },
                        "enable":
                        {
                            "code": "Y",
                            "name": "启用"
                        },
                        "notificaRecipients": [
                        {
                            "code": "a0017702",
                            "name": "曾勇"
                        },
                        {
                            "code": "a0017702",
                            "name": "曾勇"
                        }],
                        "notificaCC": [
                        {
                            "code": "a0017702",
                            "name": "曾勇"
                        },
                        {
                            "code": "a0017702",
                            "name": "曾勇"
                        }]
                    },
                    {
                        "warningId": 1,
                        "warningName": "",
                        "process":
                        {
                            "code": "xxxx",
                            "name": "测试"
                        },
                        "notificaType":
                        {
                            "code": "email",
                            "name": "邮件"
                        },
                        "startDate": "",
                        "endDate": "",
                        "createBy":
                        {
                            "code": "a0017702",
                            "name": "曾勇"
                        },
                        "enable":
                        {
                            "code": "Y",
                            "name": "启用"
                        },
                        "notificaRecipients": [
                        {
                            "code": "a0017702",
                            "name": "曾勇"
                        },
                        {
                            "code": "a0017702",
                            "name": "曾勇"
                        }],
                        "notificaCC": [
                        {
                            "code": "a0017702",
                            "name": "曾勇"
                        },
                        {
                            "code": "a0017702",
                            "name": "曾勇"
                        }]
                    }],
                    "pageNo": 1,
                    "total": 50
                }
            }
  History:
      1.00  2018-01-30    Echo.Zeng
  ==================================================*/
  procedure proc_query_warnings(p_request  IN CLOB,x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_get_warning
  Description:
      This function perform:
      根据预警id查询预警信息
  Argument:
     --入参 p_request json
          {
              "systemCode": "GEMS",
              "warningId": 100
          }
     --出参 x_response  json
          {
              "code": "SUCCESS",
              "data":
              {
                  "warningId": 1,
                  "warningName": "",
                  "process":
                  {
                      "code": "xxxx",
                      "name": "测试"
                  },
                  "template":
                  {
                      "id": 1,
                      "name": "xxx"
                  },
                  "type": "email"
                  "startDate": "",
                  "endDate": "",
                  "enable": "Y",
                  "notificaRecipients": [
                  {
                      "code": "a0017702",
                      "name": "曾勇"
                  },
                  {
                      "code": "a0017702",
                      "name": "曾勇"
                  }],
                  "notificaCC": [
                  {
                      "code": "a0017702",
                      "name": "曾勇"
                  },
                  {
                      "code": "a0017702",
                      "name": "曾勇"
                  }],
                  "rules":
                  {
                      "ruleType": "BTW_GROUP",
                      "ruleKey": "",
                      "ruleOp": "AND",
                      "ruleValue": "",
                      "childs": [
                      {
                          "ruleType": "BTW_GROUP",
                          "ruleKey": "",
                          "ruleOp": "AND",
                          "ruleValue": "",
                          "childs": []
                      },
                      {
                          "ruleType": "BTW_GROUP",
                          "ruleKey": "",
                          "ruleOp": "AND",
                          "ruleValue": "",
                          "childs": []
                      }]
                  }
              }
          }

  History:
      1.00  2018-01-30    Echo.Zeng
  ==================================================*/
  procedure proc_get_warning(p_request  IN CLOB,x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_add_warning
  Description:
      This function perform:
      添加/编辑预警配置，支持批量
  Argument:
     --入参 p_request json
            {
                "systemCode":"GEMS",
                "warnings": [
                        "warningId": 1,
                        "warningName": "",
                        "process":"",
                        "notification":{
                            "type":"email",
                            "templateId":1
                        },
                        "startDate": "",
                        "endDate": "",
                        "enable":"Y",
                        "notificaRecipients": ["a0017702","a0017701"],
                        "notificaCC":["a0017702","a0017701"],
                        "rules":{
                            "ruleType":"BTW_GROUP",
                            "ruleKey":"",
                            "ruleOp":"AND",
                            "ruleValue":"",
                            "childs":[
                                {
                                    "ruleType":"BTW_GROUP",
                                    "ruleKey":"",
                                    "ruleOp":"AND",
                                    "ruleValue":"",
                                    "childs":[]
                                },
                                {
                                    "ruleType":"BTW_GROUP",
                                    "ruleKey":"",
                                    "ruleOp":"AND",
                                    "ruleValue":"",
                                    "childs":[]
                                }
                            ]
                        }
                    ],
                "op":"add"
            }
     --出参 x_response  json
          {
              "code": "SUCCESS",
              "userMsg":"添加/编辑成功",
              "data":{}
          }
  History:
      1.00  2018-01-30    Echo.Zeng
  ==================================================*/
  procedure proc_add_warning(p_request  IN CLOB,x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_delete_warning
  Description:
      This function perform:
      删除预警配置，支持批量
  Argument:
     --入参 p_request json
            {
                "systemCode":"GEMS",
                "warningIds": [1,2,3,4,5,6]
            }
     --出参 x_response  json
            {
                "code": "SUCCESS",
                "userMsg":"删除成功",
                "data":{}
            }
  History:
      1.00  2018-01-30    Echo.Zeng
  ==================================================*/
  procedure proc_delete_warning(p_request  IN CLOB,x_response OUT CLOB);


  /*==================================================
  Procedure/Function Name :
      func_get_rule_json
  Description:
      This function perform:
      添加规则，用于递归
  Argument:
     --入参

     --出参
     无
  History:
      1.00  2018-02-01    Echo.Zeng Creation
  ==================================================*/
  function func_add_rule(p_json IN json,p_rule_id IN NUMBER,p_user IN VARCHAR2) return number;

  /*==================================================
  Procedure/Function Name :
      func_delete_rule
  Description:
      This function perform:
      删除规则，删除父规则以及所有的子规则
  Argument:
     --入参

     --出参
     无
  History:
      1.00  2018-02-01    Echo.Zeng Creation
  ==================================================*/
  function func_delete_rule(p_rule_id IN NUMBER) return varchar2;

  /*==================================================
  Procedure/Function Name :
      func_get_rule_json
  Description:
      This function perform:
      解析预警规则返回json对象
  Argument:
     --入参
     p_rule_id       预警id
     --出参
     无
  History:
      1.00  2018-02-01    Echo.Zeng Creation
  ==================================================*/
  function func_get_rule_json(p_rule_id in number) return json;

  function func_get_rule_childs(p_rule_id in number) return json_list;
  /*==================================================
  Procedure/Function Name :
      func_get_rule_op
  Description:
      This function perform:
      创建预警事件


  Argument:
     --入参
     p_waring_id       预警id
     --出参
     无
  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  function func_get_rule_op(p_op_code in varchar2) return varchar2;

  /*==================================================
  Procedure/Function Name :
      func_get_rule_cdt
  Description:
      This function perform:
      获取预警条件表达式


  Argument:
     --入参
     p_rule_id       根规则
     --出参
     无
  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  function func_get_rule_cdt(p_rule_id in number) return varchar2;

  /*==================================================
  Procedure/Function Name :
      func_replace_rule_key
  Description:
      This function perform:
      替换关键字为流程信息


  Argument:
     --入参
     p_rule_cdt       规则表达式
     --出参
     无
  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  function func_replace_rule_key(p_rule_cdt in varchar2) return varchar2;

  /*==================================================
  Procedure/Function Name :
      func_get_notification_address
  Description:
      This function perform:
      获取通知地址


  Argument:
     --入参
     p_user_delim_str     用户规则集合，使用分隔符分隔的字符串
     p_delimiter          分隔符
     p_noti_type          通知类型：邮件、短信
     --出参
     替换成地址的字符串
  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  function func_get_notification_address(p_user_delim_str in varchar2,p_delimiter in varchar2,p_noti_type in varchar2) return varchar2;

end DBPA_BA_WARNING_PKG;

/

