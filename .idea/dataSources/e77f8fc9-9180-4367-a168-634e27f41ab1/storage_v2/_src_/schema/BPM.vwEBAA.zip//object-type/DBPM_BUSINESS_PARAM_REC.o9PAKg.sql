create TYPE     "DBPM_BUSINESS_PARAM_REC" IS OBJECT
(
       paramKey      VARCHAR2(2000),
       paramValue    VARCHAR2(2000)
)

/

