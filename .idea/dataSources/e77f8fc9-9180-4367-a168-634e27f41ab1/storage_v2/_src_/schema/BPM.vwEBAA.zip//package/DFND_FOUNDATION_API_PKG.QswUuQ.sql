create PACKAGE dfnd_foundation_api_pkg IS
  v_df_sex_type VARCHAR2(30) := 'DF_SEX';
  -- Author  : ADOBE
  -- Created : 2016/11/21 13:50:21
  -- Purpose :
  --值列表维护接口(吴晨瑞)
  --涉及表DFND_LOOKUP_TYPES,DFND_LOOKUP_VALUES
  /*==================================================
  Procedure Name :
      proc_lookup_add_type
  Description:
      创建值列表类型
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2016-11-21  jianfeng.zheng  Creation
  Sample input:
      {
         "lookup_type": "xxx",
         "meaning": "xxxx",
         "description": "xxxx",
         "status": "Y"
       }
         lookup_type: 值列表类型
         meaning:     值列表含义
         description: 值列表描述
         status:      状态（Y/N）
  Sample output:
         标准输出
  ==================================================*/
  PROCEDURE proc_lookup_add_type(p_request IN CLOB, x_response OUT CLOB);
  /*==================================================
  Procedure Name :
      proc_lookup_add_type
  Description:
      移除值列表类型
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2016-11-21  jianfeng.zheng  Creation
  Sample input:
      {
         "lookup_type": "xxx",
       }
         lookup_type: 值列表类型
  Sample output:
         标准输出
  ==================================================*/
  PROCEDURE proc_lookup_remove_type(p_request IN CLOB, x_response OUT CLOB);
  /*==================================================
  Procedure Name :
      proc_lookup_add_value
  Description:
      创建值列表值
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2016-11-21  jianfeng.zheng  Creation
  Sample input:
      {
         "lookup_type": "xxxx",
         "lookup_code": "xxxx",
         "meaning": "xxxx",
         "description": "xxxx",
         "status": "xxxx",
         "tag": "xxxx",
         "order_num": 1
       }
         lookup_type: 值列表类型
         lookup_code: 值编码
         meaning:     值含义
         description: 描述
         status:      状态（Y/N）
         tag：        标签
         order_num:   显示顺序
  Sample output:
         标准输出
  ==================================================*/
  PROCEDURE proc_lookup_add_value(p_request IN CLOB, x_response OUT CLOB);
  /*==================================================
  Procedure Name :
      proc_lookup_query_types
  Description:
      查询值列表类型
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2016-11-21  jianfeng.zheng  Creation
  Sample input:
      {
         "fields": [
               {
                 "field": "lookup_type/meaning",
                 "op": "like/like",
                  "value": "xxxx"
                }],
          "page": 100,
          "size": 101,
          "order": "xxxx",
          "order_type": "xxxxx"
       }
  Sample output:
         [
         "lookup_type": "xxxx",
         "meaning": "xxxx",
         "description": "xxxx",
         "status": "xxxx",
       ]
  ==================================================*/
  PROCEDURE proc_lookup_query_types(p_request IN CLOB, x_response OUT CLOB);
  /*==================================================
  Procedure Name :
      proc_lookup_query_types
  Description:
      查询值列表值
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2016-11-21  jianfeng.zheng  Creation
  Sample input:
      {
         "fields": [
               {
                 "field": "lookup_type",
                 "op": "=",
                  "value": "xxxx"
                }],
          "page": 100,
          "size": 101,
          "order": "xxxx",
          "order_type": "xxxxx"
       }
  Sample output:
         [
         "lookup_code": "xxxx",
         "meaning": "xxxx",
         "description": "xxxx",
         "status": "xxxx",
         "tag": "xxxx",
        ]
  ==================================================*/
  PROCEDURE proc_lookup_query_values(p_request  IN CLOB,
                                     x_response OUT CLOB);

  /*==================================================
  Procedure Name :
      proc_lookup_remove_values
  Description:
      移除值列表类型
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2016-12-29  Kerry.Wu  Creation
  Sample input:
      {
         "lookup_type": "xxx",
         "lookup_code": "xxx"
       }
         lookup_type: 值列表类型
         lookup_code: 值列表值
  Sample output:
         标准输出
  ==================================================*/
  PROCEDURE proc_lookup_remove_values(p_request  IN CLOB,
                                      x_response OUT CLOB);

  /*==================================================
  Procedure Name :
      proc_lookup_type_update
  Description:
      编辑值列表类型
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2016-12-29  Kerry.Wu  Creation
  Sample input:
      {
         "lookup_type": "xxx",
         "meaning": "xxxx",
         "description": "xxxx",
         "status": "Y"
       }
         lookup_type: 值列表类型
         meaning:     值列表含义
         description: 值列表描述
         status:      状态（Y/N）
  Sample output:
         标准输出
  ==================================================*/
  PROCEDURE proc_lookup_type_update(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure Name :
      proc_lookup_edit_value
  Description:
      编辑值列表值
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2016-11-29  Kerry.Wu  Creation
  Sample input:
      {
         "lookup_type": "xxxx",
         "lookup_code": "xxxx",
         "meaning": "xxxx",
         "description": "xxxx",
         "status": "xxxx",
         "tag": "xxxx",
         "order_num": 1
       }
         lookup_type: 值列表类型
         lookup_code: 值编码
         meaning:     值含义
         description: 描述
         status:      状态（Y/N）
         tag：        标签
         order_num:   显示顺序
  Sample output:
         标准输出
  ==================================================*/
  PROCEDURE proc_lookup_value_update(p_request  IN CLOB,
                                     x_response OUT CLOB);

  --个人资料接口(曾勇)
  /*==================================================
  Procedure Name :
      proc_role_add
  Description:
      个人资料查询接口
      涉及表dfnd_employees
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2016-12-08  yong.zeng  Creation
  Sample input:

  Sample output:
         标准输出
    {
     "login_name":"xxxx",
     "name":"xxxx",
     "sex":"xxxx",
     "phone":"xxxx",
     "email":"xxxx",
     "office_phone":"xxxx"
    }
     login_name      登录名
     name            姓名
     sex             性别
     phone           手机
     email           邮箱
     office_phone    办公电话
  ==================================================*/
  PROCEDURE proc_user_info_query(p_request CLOB, x_response OUT CLOB);
  /*==================================================
  Procedure Name :
      proc_role_add
  Description:
      个人资料保存接口
      涉及表dfnd_employees
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2016-12-08  yong.zeng  Creation
  Sample input:
      {
     "login_name":"xxxx",
     "name":"xxxx",
     "sex":"xxxx",
     "phone":"xxxx",
     "email":"xxxx",
     "office_phone":"xxxx"
    }

     login_name      登录名
     name            姓名
     sex             性别
     phone           手机
     email           邮箱
     office_phone    办公电话
  Sample output:
         标准输出
  ==================================================*/
  PROCEDURE proc_user_info_edit(p_request IN CLOB, x_response OUT CLOB);
  --属性管理接口(许浩池)
  --涉及表DFND_PROPERTIES
  /*==================================================
  Procedure Name :
      proc_prop_add
  Description:
      创建属性
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2016-11-21  jianfeng.zheng  Creation
  Sample input:
      {
         "property_key": "xxxx",
         "property_value": "xxxx",
         "description": "xxxx",
         "status": "xxx"
     }
         property_key:         属性key
         property_value:       属性值
         description:          属性描述
         status:               状态Y/N
  Sample output:
         标准输出
  ==================================================*/
  PROCEDURE proc_prop_add(p_request IN CLOB, x_response OUT CLOB);
  /*==================================================
  Procedure Name :
      proc_prop_remove
  Description:
      删除属性
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2016-11-21  jianfeng.zheng  Creation
  Sample input:
      {
         "property_key": "xxxx"
     }
         property_key:         属性key
  Sample output:
         标准输出
  ==================================================*/
  PROCEDURE proc_prop_remove(p_request IN CLOB, x_response OUT CLOB);
  /*==================================================
  Procedure Name :
      proc_role_query_members
  Description:
      查询角色成员信息
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2016-11-21  jianfeng.zheng  Creation
  Sample input:
      {
         "fields": [
               {
                 "field": "property_key/property_value",
                 "op": "like/like",
                  "value": "xxxx"
                }],
          "page": 100,
          "size": 101,
          "order": "xxxx",
          "order_type": "xxxxx"
       }
  Sample output:
         [
         "property_key": "xxxx",
         "property_value": "xxxx",
         "description": "xxxx",
         "status": "xxx"
        ]
         property_key:         属性key
         property_value:       属性值
         description:          属性描述
         status:               状态Y/N
  ==================================================*/
  PROCEDURE proc_prop_query_properties(p_request  IN CLOB,
                                       x_response OUT CLOB);

  /*==================================================
  Procedure Name :
      proc_query_user_organizations
  Description:
      查询用户的组织信息
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2017-04-28  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_query_user_organizations(p_request  IN CLOB,
                                          x_response OUT CLOB);
END dfnd_foundation_api_pkg;

/

