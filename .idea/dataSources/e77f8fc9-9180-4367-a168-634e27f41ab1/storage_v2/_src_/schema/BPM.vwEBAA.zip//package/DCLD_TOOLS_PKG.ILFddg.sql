create package     DCLD_TOOLS_PKG is

  /*==================================================
  Procedure/Function Name :
      proc_is_null
  Description:
      This function perform:
      检查是否为空
  Argument:
     -入参
     arg varhcar2 要检查的参数
     -return
     boolean 是否为空
  History:
      1.00  2018-01-11  Echo.Zeng  Creation
  ==================================================*/
  function proc_is_null(arg in varchar2) return boolean;

  /*==================================================
  Procedure/Function Name :
      proc_add_user
  Description:
      This function perform:
      新增用户
  Argument:
     -入参
     p_user_code 工号(方法内统一转大写存入数据库)
     p_user_name 用户名
     p_org_id 组织ID
  History:
      1.00  2018-06-29  wlj  Creation
  ==================================================*/
  procedure proc_add_user(p_user_code varchar2,
                          p_user_name varchar2,
                          p_org_id    number);
end DCLD_TOOLS_PKG;

/

