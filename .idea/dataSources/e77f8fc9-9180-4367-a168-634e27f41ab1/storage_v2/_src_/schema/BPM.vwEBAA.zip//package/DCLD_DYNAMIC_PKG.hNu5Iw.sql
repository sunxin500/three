create PACKAGE     dcld_dynamic_pkg IS

  /*==================================================
  Procedure/Function Name :
      proc_query_dynamic_list
  Description:
      This function perform:
      查询所有动态（我的动态和我好友的动态）
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-03-13  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_query_dynamic_list(p_request CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_add_dynamic
  Description:
      This function perform:
      发起动态
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-03-13  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_add_dynamic(p_request CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_add_dynamic_comment
  Description:
      This function perform:
      发起动态评论
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-03-15  chenming  Creation
  ==================================================*/
  PROCEDURE proc_add_dynamic_comment(p_request CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_dynamic_praise
  Description:
      This function perform:
      给动态点赞
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-03-13  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_dynamic_praise(p_request CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_dynamic_collect
  Description:
      This function perform:
      收藏动态
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-03-13  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_dynamic_collect(p_request CLOB, x_response OUT CLOB);
END dcld_dynamic_pkg;

/

