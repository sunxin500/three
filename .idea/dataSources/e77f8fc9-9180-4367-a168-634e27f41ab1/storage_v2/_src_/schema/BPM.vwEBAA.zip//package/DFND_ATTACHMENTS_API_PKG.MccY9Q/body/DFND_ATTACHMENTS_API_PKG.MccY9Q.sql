create PACKAGE BODY     dfnd_attachments_api_pkg IS
  /*==================================================
  Procedure/Function Name :
      proc_query_attachments
  Description:
      This function perform:
      查询附件
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-10-25  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_query_attachments(p_request CLOB, x_response OUT CLOB) IS
    v_request         json;
    v_response        pl_json := pl_json;
    v_attachment_json pl_json;
    v_document_id     NUMBER;
    v_count           NUMBER;
    CURSOR v_attachments_cur(p_document_id NUMBER) IS
      SELECT *
        FROM dfnd_attachments da
       WHERE da.document_id = p_document_id;
  BEGIN
    v_request     := json(p_request, 'OBJECT');
    v_document_id := v_request.get('documentId').get_number;
    v_count       := 0;
    FOR v_attachment IN v_attachments_cur(v_document_id) LOOP
      v_attachment_json := pl_json;
      v_count           := v_count + 1;
      v_attachment_json.set_value('attachmentId',
                                  v_attachment.attachment_id);
      v_attachment_json.set_value('attachmentName',
                                  v_attachment.attachment_name);
      v_attachment_json.set_value('fileContentType', 'image/pjpeg');
      v_attachment_json.set_value('fileSuffix', v_attachment.suffix); --add by chenzhibin
      v_attachment_json.set_value('creatorName', v_attachment.created_by);
      v_attachment_json.set_value('createTime',
                                  to_char(v_attachment.creation_date,
                                          'YYYY-MM-DD HH24:MI'));
      v_attachment_json.set_value('downloadUrl', v_attachment.download_url);

      v_response.add_list_item('attachmentList', v_attachment_json);
    END LOOP;
    v_response.set_value('count', v_count);
    x_response := v_response.to_json;
  END proc_query_attachments;

  /*==================================================
  Procedure/Function Name :
      proc_add_attachments
  Description:
      This function perform:
      添加附件
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-10-25  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_add_attachments(p_request CLOB, x_response OUT CLOB) IS

  BEGIN
    NULL;
  END proc_add_attachments;

  /*==================================================
  Procedure/Function Name :
      proc_add_attachment
  Description:
      This function perform:
      添加附件
  History:
      1.00  2017-10-25  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_add_attachment(p_attachment_name VARCHAR2,
                                p_document_id     NUMBER,
                                p_creator         VARCHAR2,
                                p_download_url    VARCHAR2) IS
    v_fun_id       VARCHAR2(100);
    v_fun_name     VARCHAR2(100);
    v_creator_name VARCHAR2(100);
  BEGIN
    BEGIN
      SELECT dd.source_document_id, dd.process_code
        INTO v_fun_id, v_fun_name
        FROM dbpm_documents dd
       WHERE dd.document_id = p_document_id;
    EXCEPTION
      WHEN OTHERS THEN
        v_fun_id   := '';
        v_fun_name := '';
    END;

    BEGIN
      SELECT de.employee_name
        INTO v_creator_name
        FROM dfnd_employees de
       WHERE upper(de.employee_code) = upper(p_creator);
    EXCEPTION
      WHEN OTHERS THEN
        v_creator_name := '';
    END;

    INSERT INTO dfnd_attachments
      (attachment_id,
       attachment_name,
       document_id,
       download_url,
       creator_name,
       fun_id,
       fun_name,
       object_version_number,
       created_by,
       creation_date,
       last_updated_by,
       last_update_date)
    VALUES
      (dfnd_attachments_s.nextval,
       p_attachment_name,
       p_document_id,
       p_download_url,
       v_creator_name,
       v_fun_id,
       v_fun_name,
       1,
       p_creator,
       SYSDATE,
       p_creator,
       SYSDATE);
  END proc_add_attachment;

  /*==================================================
  Procedure/Function Name :
      proc_del_attachment
  Description:
      This function perform:
      删除附件
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-10-25  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_del_attachment(p_request CLOB, x_response OUT CLOB) IS

    v_request       json;
    v_response      pl_json := pl_json;
    v_attachment_id NUMBER;
  BEGIN
    v_request       := json(p_request, 'OBJECT');
    v_attachment_id := v_request.get('attachmentId').get_number;
    DELETE FROM dfnd_attachments da
     WHERE da.attachment_id = v_attachment_id;
    x_response := v_response.to_json;
    /* EXCEPTION
    WHEN OTHERS THEN
      v_response.fail('接口发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_del_attachment;

END dfnd_attachments_api_pkg;

/

