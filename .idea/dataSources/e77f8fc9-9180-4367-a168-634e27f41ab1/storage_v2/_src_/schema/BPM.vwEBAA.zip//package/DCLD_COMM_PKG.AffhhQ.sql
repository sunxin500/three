create PACKAGE dcld_comm_pkg IS

  -- Author  : ADOBE
  -- Created : 2016/12/10 19:00:40
  -- Purpose :

  FUNCTION get_string(p_field VARCHAR2, p_request json) RETURN VARCHAR2;

  --migrate by xiaowei.yao 20180411
  FUNCTION get_filter_value(p_field VARCHAR2, p_request json) RETURN VARCHAR2;
  --migrate by xiaowei.yao 20180411
  /*==================================================
  function Name :
      proc_get_menu
  Description:
      获取菜单
  Argument:
  History:
      1.00  2018-1-26  wlj  Creation
  ==================================================*/
  PROCEDURE proc_get_comm_menu(p_request IN CLOB, x_response OUT CLOB);
  --migrate by xiaowei.yao 20180411
  /*==================================================
  function Name :
      proc_get_components
  Description:
      获取组件
  Argument:
  History:
      1.00  2018-1-26  wlj  Creation
  ==================================================*/
  PROCEDURE proc_get_components(p_request IN CLOB, x_response OUT CLOB);
  --migrate by xiaowei.yao 20180411
  /*==================================================
  function Name :
      func_get_err_msg
  Description:
      获取错误信息
  Argument:
  History:
      1.00  2018-3-12  wlj  Creation
  ==================================================*/
  FUNCTION func_get_err_msg(p_err_code VARCHAR2,
                            p_locale   VARCHAR2,
                            p_params   VARCHAR2 default NULL) RETURN VARCHAR2;

  FUNCTION is_readed(p_source    VARCHAR2,
                     p_source_id VARCHAR2,
                     p_user      VARCHAR2) RETURN VARCHAR2;
  /*==================================================
  function Name :
      get_lookup_meaning
  Description:
      查询值列表含义
  Argument:
      p_lookup_type：  值列表类型
      p_lookup_code：  值列表编码
  History:
      1.00  2016-12-15  jianfeng.zheng  Creation
  ==================================================*/
  FUNCTION get_lookup_meaning(p_lookup_type VARCHAR2,
                              p_lookup_code VARCHAR2,
                              p_locale      varchar2 DEFAULT 'zh',
                              p_status      VARCHAR2 DEFAULT 'Y')
    RETURN VARCHAR2;

  /*==================================================
  function Name :
      get_data_source_value
  Description:
      查询数据字典的显示值
  Argument:
      p_lookup_type：  值列表类型
      p_lookup_code：  值列表编码
  History:
      1.00  2018-07-04  wlj  Creation
  ==================================================*/
  FUNCTION get_data_source_value(p_ds_code    VARCHAR2,
                                 p_value_code VARCHAR2,
                                 p_locale     varchar2 DEFAULT 'zh',
                                 p_status     VARCHAR2 DEFAULT 'Y')
    RETURN VARCHAR2;

  /*==================================================
  function Name :
      get_string
  Description:
     获取json_valued的值，以字符串形式返回
  History:
      1.00  2016-12-15  jianfeng.zheng  Creation
  ==================================================*/
  FUNCTION get_string_value(js_value json_value_cux) RETURN VARCHAR2;

  /*==================================================
  function Name :
      get_value_type
  Description:
      获取json_valued的值的类型，string，number，boolean，
  History:
      1.00  2016-12-15  jianfeng.zheng  Creation
  ==================================================*/
  FUNCTION get_value_type(js_value json_value_cux) RETURN VARCHAR2;

  /*==================================================
  function Name :
      proc_get_user_master_organization
  Description:
      获取用户主组织信息
  Argument:
  History:
      1.00  2016-12-15  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE get_user_master_organization(p_user_code         VARCHAR2,
                                         x_organization_id   OUT VARCHAR2,
                                         x_organization_name OUT VARCHAR2);

  /*==================================================
  function Name :
      func_get_err_msg
  Description:
      获取静态的系统国际化信息
  Argument:
  History:
      1.00  2018-5-29  wlj  Creation
  ==================================================*/
  FUNCTION func_get_sys_msg(p_msg_code VARCHAR2,
                            p_locale   VARCHAR2,
                            p_msg_type varchar2 default 'DCLD_SYS_TYPE',
                            p_params   VARCHAR2 default NULL) RETURN VARCHAR2;

  /*==================================================
  function Name :
      func_get_BPM_url
  Description:
      获取得云表单链接
  Argument:
  History:
      1.00  2018-5-29  wlj  Creation
  ==================================================*/
  FUNCTION func_get_BPM_url RETURN VARCHAR2;
END dcld_comm_pkg;

/

