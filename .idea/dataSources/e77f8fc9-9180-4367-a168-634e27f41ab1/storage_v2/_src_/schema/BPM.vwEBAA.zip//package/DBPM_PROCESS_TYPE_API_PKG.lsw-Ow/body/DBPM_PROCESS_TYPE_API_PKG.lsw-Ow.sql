create PACKAGE BODY     dbpm_process_type_api_pkg IS

  /*==================================================
  Procedure/Function Name :
      proc_query_process_types
  Description:
      This function perform:
      查询流分类
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-05-22  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_query_process_types(p_request CLOB, x_response OUT CLOB) IS
    v_request   json;
    v_response  pl_json := pl_json;
    v_type_json pl_json;
    --分页
    v_total NUMBER := 0;
    v_size  number := 20;
    v_page  number := 1;
    --查询条件
    v_filter   json;
    v_status   varchar2(1000);
    v_code     varchar2(100);
    v_name     varchar2(1000);
    v_sort_col varchar2(500);
    v_sort     json;
    v_lov      varchar2(5);
    CURSOR v_process_type_cur IS
      SELECT *
        FROM (SELECT v.*, rownum cnt
                FROM (SELECT COUNT(1) OVER(PARTITION BY 1) TOTAL, DPT.*
                        FROM dbpm_process_types dpt
                       WHERE dpt.status = decode(v_lov, 'Y', 'Y', dpt.status)
                         and INSTR(NVL(DPT.TYPE_CODE, 'NL'),
                                   NVL(v_code, NVL(DPT.TYPE_CODE, 'NL'))) > 0
                         AND INSTR(NVL(DPT.TYPE_NAME, 'NL'),
                                   NVL(v_name, NVL(DPT.TYPE_NAME, 'NL'))) > 0
                         AND INSTR(NVL(DPT.STATUS, 'NL'),
                                   NVL(v_status, NVL(DPT.STATUS, 'NL'))) > 0
                       ORDER BY decode(v_sort_col,
                                       'type_code_desc',
                                       dpt.type_code,
                                       'type_name_desc',
                                       dpt.type_name,
                                       'status_desc',
                                       dpt.status) DESC,
                                decode(v_sort_col,
                                       'type_code_asc',
                                       dpt.type_code,
                                       'type_name_asc',
                                       dpt.type_name,
                                       'status_asc',
                                       dpt.status) ASC,
                                dpt.type_id desc) v
               WHERE rownum <= v_page * v_size)
       WHERE cnt > (v_page - 1) * v_size;
  BEGIN
    v_request := json(p_request, 'OBJECT');
    if v_request.exist('page') then
      v_page := v_request.get_number('page');
    else
      v_lov := 'Y';
    end if;
    if v_request.exist('size') then
      v_size := v_request.get_number('size');
    end if;
    /* if v_request.exist('filter') then
      v_filter := json(v_request.get('filter'));
      v_code   := v_filter.get_string('typeCode');
      v_name   := v_filter.get_string('typeName');
      v_status := v_filter.get_string('statusMeaning');
      if v_status is not null then
      if v_status = '是' then
        v_status := 'Y';
      elsif v_status = '否' then
        v_status := 'N';
      else
        v_status := '-1';
      end if;
      end if;
    end if;*/
    v_code   := dcld_comm_pkg.get_filter_value('typeCode', v_request);
    v_name   := dcld_comm_pkg.get_filter_value('typeName', v_request);
    v_status := dcld_comm_pkg.get_filter_value('statusMeaning', v_request);
    if v_status is not null then
      if v_status = '是' then
        v_status := 'Y';
      elsif v_status = '否' then
        v_status := 'N';
      else
        v_status := '-1';
      end if;
    end if;
    if v_request.exist('sort') then
      v_sort     := json(v_request.get('sort'));
      v_sort_col := v_sort.get_string('value');
      v_sort_col := v_sort_col || '_' || v_sort.get_string('order');
    end if;
    FOR v_type IN v_process_type_cur LOOP
      v_total     := V_TYPE.TOTAL;
      v_type_json := pl_json;
      v_type_json.set_value('typeId', v_type.type_id);
      v_type_json.set_value('displayColor', v_type.display_color);
      v_type_json.set_value('status', v_type.status);
      v_type_json.set_value('typeCode', v_type.type_code);
      v_type_json.set_value('typeName', v_type.type_name);
      v_type_json.set_value('status',
                            (CASE WHEN v_type.status = 'Y' THEN TRUE ELSE
                             FALSE END));
      v_type_json.set_value('statusMeaning',
                            dcld_comm_pkg.func_get_sys_msg(v_type.status,v_request.locale));
      v_response.add_list_item('typeList', v_type_json);
    END LOOP;
    v_response.set_value('total', v_total);
    x_response := v_response.to_json;
  END proc_query_process_types;

  /*==================================================
  Procedure/Function Name :
      proc_save_process_node
  Description:
      This function perform:
      保存流程分类
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-05-17  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_save_process_type(p_request CLOB, x_response OUT CLOB) IS
    v_request      json;
    v_response     pl_json := pl_json;
    v_current_user VARCHAR2(50);
    v_type_id      NUMBER;
    v_status       VARCHAR2(10);
    v_count        NUMBER := 0;
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;

    IF v_request.get('typeId') IS NULL OR v_request.get('typeId')
      .get_number IS NULL THEN
      v_type_id := dbpm_process_types_s.nextval;
      v_count   := 0;
    ELSE
      v_type_id := v_request.get('typeId').get_number;
      v_count   := 1;
    END IF;
    IF v_request.get('status').get_bool THEN
      v_status := 'Y';
    ELSE
      v_status := 'N';
    END IF;
    IF v_count = 0 THEN
      begin
        INSERT INTO dbpm_process_types
          (type_id,
           type_name,
           type_code,
           status,
           display_color,
           created_by,
           last_updated_by)
        VALUES
          (v_type_id,
           v_request.get ('typeName' ).get_string,
           v_request.get ('typeCode' ).get_string,
           v_status,
           v_request.get ('displayColor' ).get_string,
           v_current_user,
           v_current_user);
      exception
        --xjl 修改唯一性报错
        when Dup_val_on_index then
          v_response.fail('分类编码不唯一，请检查！');
          x_response := v_response.to_json;
          return;
      end;
    ELSE
      UPDATE dbpm_process_types dpt
         SET dpt.type_code             = v_request.get('typeCode').get_string,
             dpt.type_name             = v_request.get('typeName').get_string,
             dpt.display_color         = v_request.get('displayColor')
                                         .get_string,
             dpt.status                = v_status,
             dpt.object_version_number = dpt.object_version_number + 1,
             dpt.created_by            = v_current_user,
             dpt.last_updated_by       = v_current_user
       WHERE dpt.type_id = v_type_id;
    END IF;
    x_response := v_response.to_json;
  END proc_save_process_type;

  /*==================================================
  Procedure/Function Name :
      proc_del_process_type
  Description:
      This function perform:
      删除流程分类
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-05-22  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_del_process_type(p_request CLOB, x_response OUT CLOB) IS
    v_request  json;
    v_response pl_json := pl_json;
    v_type_id  NUMBER;
  BEGIN
    v_request := json(p_request, 'OBJECT');
    v_type_id := v_request.get('typeId').get_number;
    DELETE FROM dbpm_process_types dpt WHERE dpt.type_id = v_type_id;
    x_response := v_response.to_json;
  END proc_del_process_type;
END dbpm_process_type_api_pkg;

/

