create package body DBPM_PROXY_API_PKG is

  /*==================================================
  Procedure/Function Name :
      proc_get_proxy_list
  Description:
      This function perform:
      查询授权列表
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-12-11  liangjun.wu  Creation
  ==================================================*/
  PROCEDURE proc_get_proxy_list(p_request CLOB, x_response OUT CLOB) as
    v_request      json;
    v_response     pl_json := pl_json;
    v_line         pl_json;
    v_filter       json;
    v_total        NUMBER := 0;
    v_size         NUMBER := 200;
    v_page         NUMBER := 1;
    v_current_user varchar2(30);
    --v_process_code  varchar2(100);
    v_proxy_to_user varchar2(100);
    v_process_node  varchar2(100);
    v_process_name  varchar2(4000);
    --排序参数
    v_sort_col varchar2(100);
    v_sort     json;
    v_platform varchar2(100); --平台码
    v_all      varchar2(4000); --查询条件

    cursor v_mob_proxy_cursor is
      SELECT *
        FROM (SELECT v.*, rownum cnt
                FROM (SELECT count(1) over(partition by 1) total, dpr.*
                        FROM (SELECT DP.PROCESS_NAME,
                                     (SELECT E.EMPLOYEE_NAME
                                        FROM DFND_EMPLOYEES E
                                       WHERE upper(E.EMPLOYEE_CODE) =
                                             upper(dpr.PROXY_FROM_USER)) FROM_USER_NAME,
                                     (SELECT E.EMPLOYEE_NAME
                                        FROM DFND_EMPLOYEES E
                                       WHERE upper(E.EMPLOYEE_CODE) =
                                             upper(dpr.PROXY_TO_USER)) TO_USER_NAME,
                                     dpr.*
                                FROM DBPM_PROX_RULES dpr, DBPM_PROCESS DP
                               WHERE dpr.PROCESS_ID = DP.PROCESS_ID
                                 AND upper(dpr.proxy_from_user) =
                                     v_current_user) dpr
                       WHERE INSTR(NVL(dpr.PROCESS_NAME, 'NL'),
                                   NVL(v_all,
                                       NVL(dpr.PROCESS_NAME, 'NL'))) > 0
                          OR INSTR(NVL(upper(dpr.TO_USER_NAME), 'NL'),
                                   NVL(upper(v_all),
                                       NVL(upper(dpr.TO_USER_NAME), 'NL'))) > 0
                          OR INSTR(NVL(dpr.process_node, 'NL'),
                                   NVL(v_all,
                                       NVL(dpr.process_node, 'NL'))) > 0
                       ORDER BY decode(v_sort_col,
                                       'process_name_desc',
                                       dpr.PROCESS_NAME,
                                       'process_node_desc',
                                       dpr.process_node,
                                       'proxy_from_user_desc',
                                       dpr.FROM_USER_NAME,
                                       'proxy_to_user_desc',
                                       dpr.TO_USER_NAME,
                                       'proxy_start_time_desc',
                                       to_char(dpr.proxy_start_time,
                                               'yyyy-mm-dd'),
                                       'proxy_end_time_desc',
                                       to_char(dpr.proxy_end_time,
                                               'yyyy-mm-dd')) DESC,
                                decode(v_sort_col,
                                       'process_name_asc',
                                       dpr.PROCESS_NAME,
                                       'process_node_asc',
                                       dpr.process_node,
                                       'proxy_from_user_asc',
                                       dpr.FROM_USER_NAME,
                                       'proxy_to_user_asc',
                                       dpr.TO_USER_NAME,
                                       'proxy_start_time_asc',
                                       to_char(dpr.proxy_start_time,
                                               'yyyy-mm-dd'),
                                       'proxy_end_time_asc',
                                       to_char(dpr.proxy_end_time,
                                               'yyyy-mm-dd')) ASC,
                                dpr.proxy_id desc) v
               WHERE rownum <= v_page * v_size)
       WHERE cnt > (v_page - 1) * v_size;

    cursor v_proxy_cursor is
      SELECT *
        FROM (SELECT v.*, rownum cnt
                FROM (SELECT count(1) over(partition by 1) total, dpr.*
                        FROM (SELECT DP.PROCESS_NAME,
                                     (SELECT E.EMPLOYEE_NAME
                                        FROM DFND_EMPLOYEES E
                                       WHERE upper(E.EMPLOYEE_CODE) =
                                             upper(dpr.PROXY_FROM_USER)) FROM_USER_NAME,
                                     (SELECT E.EMPLOYEE_NAME
                                        FROM DFND_EMPLOYEES E
                                       WHERE upper(E.EMPLOYEE_CODE) =
                                             upper(dpr.PROXY_TO_USER)) TO_USER_NAME,
                                     dpr.*
                                FROM DBPM_PROX_RULES dpr, DBPM_PROCESS DP
                               WHERE dpr.PROCESS_ID = DP.PROCESS_ID
                                 AND upper(dpr.proxy_from_user) =
                                     v_current_user) dpr
                       WHERE INSTR(NVL(dpr.PROCESS_NAME, 'NL'),
                                   NVL(v_process_name,
                                       NVL(dpr.PROCESS_NAME, 'NL'))) > 0
                         AND INSTR(NVL(upper(dpr.TO_USER_NAME), 'NL'),
                                   NVL(upper(v_proxy_to_user),
                                       NVL(upper(dpr.TO_USER_NAME), 'NL'))) > 0
                         AND INSTR(NVL(dpr.process_node, 'NL'),
                                   NVL(v_process_node,
                                       NVL(dpr.process_node, 'NL'))) > 0
                       ORDER BY decode(v_sort_col,
                                       'process_name_desc',
                                       dpr.PROCESS_NAME,
                                       'process_node_desc',
                                       dpr.process_node,
                                       'proxy_from_user_desc',
                                       dpr.FROM_USER_NAME,
                                       'proxy_to_user_desc',
                                       dpr.TO_USER_NAME,
                                       'proxy_start_time_desc',
                                       to_char(dpr.proxy_start_time,
                                               'yyyy-mm-dd'),
                                       'proxy_end_time_desc',
                                       to_char(dpr.proxy_end_time,
                                               'yyyy-mm-dd')) DESC,
                                decode(v_sort_col,
                                       'process_name_asc',
                                       dpr.PROCESS_NAME,
                                       'process_node_asc',
                                       dpr.process_node,
                                       'proxy_from_user_asc',
                                       dpr.FROM_USER_NAME,
                                       'proxy_to_user_asc',
                                       dpr.TO_USER_NAME,
                                       'proxy_start_time_asc',
                                       to_char(dpr.proxy_start_time,
                                               'yyyy-mm-dd'),
                                       'proxy_end_time_asc',
                                       to_char(dpr.proxy_end_time,
                                               'yyyy-mm-dd')) ASC,
                                dpr.proxy_id desc) v
               WHERE rownum <= v_page * v_size)
       WHERE cnt > (v_page - 1) * v_size;

  begin
    v_request      := json(p_request, 'OBJECT');
    v_current_user := upper(v_request.username);
    v_platform     := nvl(v_request.get_string('platform'), 'WEB');
    --v_space_id   := cux_comm_pkg.func_get_space_id(v_current_user);

    IF v_request.exist('page') THEN
      v_page := v_request.get_number('page');
    END IF;
    IF v_request.exist('size') THEN
      v_size := v_request.get_number('size');
    END IF;
    /*if v_request.exist('filter') then
      v_filter        := json(v_request.get('filter'));
      --v_process_code  := v_filter.get_string('processCode');
      v_proxy_to_user := upper(v_filter.get_string('proxyToUser'));
      v_process_node  := v_filter.get_string('processNode');
      v_process_name :=  v_filter.get_string('processName');
    end if;*/
    v_process_node  := dcld_comm_pkg.get_filter_value('processNode',
                                                      v_request);
    v_process_name  := dcld_comm_pkg.get_filter_value('processName',
                                                      v_request);
    v_proxy_to_user := dcld_comm_pkg.get_filter_value('proxyToUserName',
                                                      v_request);
    if v_request.exist('sort') then
      v_sort     := json(v_request.get('sort'));
      v_sort_col := v_sort.get_string('value');
      v_sort_col := v_sort_col || '_' || v_sort.get_string('order');
    end if;

    IF v_platform = 'WEB' THEN
      FOR v_proxy IN v_proxy_cursor LOOP
        v_total := v_proxy.total;
        v_line  := pl_json;
        v_line.set_value('proxyId', v_proxy.proxy_id);
        v_line.set_value('processCode', v_proxy.process_code);
        v_line.set_value('processName', v_proxy.process_name);
        v_line.set_value('processId', v_proxy.process_id);
        v_line.set_value('proxyFromUser', v_proxy.proxy_from_user);
        v_line.set_value('proxyFromUserName', v_proxy.from_user_name);
        v_line.set_value('proxyToUser', v_proxy.proxy_to_user);
        v_line.set_value('proxyToUserName', v_proxy.to_user_name);
        v_line.set_value('proxyStartTime',
                         to_char(v_proxy.proxy_start_time, 'yyyy-mm-dd'));
        v_line.set_value('proxyEndTime',
                         to_char(v_proxy.proxy_end_time, 'yyyy-mm-dd'));
        v_line.set_value('ruleIds', v_proxy.Rule_Ids);
        v_line.set_value('processNode', v_proxy.process_node);
        v_response.add_list_item('proxyList', v_line);
      END LOOP;
    ELSIF v_platform = 'MOB' THEN
      v_all := dcld_comm_pkg.get_filter_value('all', v_request);
      FOR v_proxy IN v_mob_proxy_cursor LOOP
        v_total := v_proxy.total;
        v_line  := pl_json;
        v_line.set_value('proxyId', v_proxy.proxy_id);
        v_line.set_value('processCode', v_proxy.process_code);
        v_line.set_value('processName', v_proxy.process_name);
        v_line.set_value('processId', v_proxy.process_id);
        v_line.set_value('proxyFromUser', v_proxy.proxy_from_user);
        v_line.set_value('proxyFromUserName', v_proxy.from_user_name);
        v_line.set_value('proxyToUser', v_proxy.proxy_to_user);
        v_line.set_value('proxyToUserName', v_proxy.to_user_name);
        v_line.set_value('proxyStartTime',
                         to_char(v_proxy.proxy_start_time, 'yyyy-mm-dd'));
        v_line.set_value('proxyEndTime',
                         to_char(v_proxy.proxy_end_time, 'yyyy-mm-dd'));
        v_line.set_value('ruleIds', v_proxy.Rule_Ids);
        v_line.set_value('processNode', v_proxy.process_node);
        v_response.add_list_item('proxyList', v_line);
      END LOOP;
    END IF;

    v_response.set_value('total', v_total);
    v_response.set_value('locale', v_request.locale);
    x_response := v_response.to_json;
  end;

  /*==================================================
  Procedure/Function Name :
      proc_save_proxy
  Description:
      This function perform:
      查询授权列表
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-12-11  liangjun.wu  Creation
  ==================================================*/
  PROCEDURE proc_save_proxy(p_request CLOB, x_response OUT CLOB) as
    v_request      json;
    v_response     pl_json := pl_json;
    v_current_user varchar2(30);

    v_proxy_id         number;
    v_proxy_to_user    varchar2(300);
    v_proxy_start_time date;
    v_proxy_end_time   date;
    v_process_code     varchar2(3000);
    v_process_id       number;
    v_process_node     varchar2(3000);
    v_rule_ids         varchar2(4000);
    v_uuid             varchar2(100);
    v_process_count    number; --流程存在标志
  begin
    v_request          := json(p_request, 'OBJECT');
    v_current_user     := v_request.username;
    v_proxy_id         := v_request.get_number('proxyId');
    v_proxy_to_user    := v_request.get_string('proxyToUser');
    v_proxy_start_time := v_request.get_date('proxyStartTime');
    v_proxy_end_time   := v_request.get_date('proxyEndTime');
    v_rule_ids         := v_request.get_string('ruleIds');
    v_process_code     := v_request.get_string('processCode');
    v_process_id       := v_request.get_number('processId');
    v_process_node     := v_request.get_string('processNode');
    v_uuid             := v_request.get_string('uuid');

    --判断流程是否存在
    select count(1)
      into v_process_count
      from dbpm_prox_rules dpr
     where upper(dpr.proxy_from_user) = upper(v_current_user)
       and dpr.process_id = v_process_id
       and dpr.process_node = v_process_node;

    if v_proxy_id is null and v_process_count > 0 then
      --v_response.fail('该流程已授权,不可重复授权');
      v_response.fail(DCLD_COMM_PKG.func_get_err_msg('DCLD-00014',
                                                     v_request.locale));
      x_response := v_response.to_json;
      return;
    end if;

    if v_proxy_id is null then
      v_proxy_id := DBPM_PROX_RULES_S.NEXTVAL;
    end if;

    MERGE INTO DBPM_PROX_RULES T
    USING (SELECT v_proxy_id proxy_id FROM DUAL) V
    ON (T.Proxy_Id = V.proxy_id)
    WHEN MATCHED THEN
      UPDATE
         Set t.proxy_to_user    = v_proxy_to_user,
             t.proxy_start_time = v_proxy_start_time,
             t.proxy_end_time   = v_proxy_end_time,
             t.process_code     = v_process_code,
             t.process_id       = v_process_id,
             t.process_node     = v_process_node,
             t.last_updated_by  = v_current_user,
             t.last_update_date = sysdate
    WHEN NOT MATCHED THEN
      insert
        (t.proxy_id,
         t.process_code,
         t.process_id,
         t.proxy_from_user,
         t.proxy_to_user,
         t.proxy_start_time,
         t.proxy_end_time,
         t.process_node,
         t.rule_ids,
         t.created_by,
         t.last_updated_by,
         t.uuid)
      values
        (v_proxy_id,
         v_process_code,
         v_process_id,
         v_current_user,
         v_proxy_to_user,
         v_proxy_start_time,
         v_proxy_end_time,
         v_process_node,
         v_rule_ids,
         v_current_user,
         v_current_user,
         v_uuid);
    v_response.set_value('proxyId', v_proxy_id);
    x_response := v_response.to_json;
  end;

  /*==================================================
  Procedure/Function Name :
      proc_delete_proxy
  Description:
      This function perform:
      查询授权列表
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-12-12  liangjun.wu  Creation
  ==================================================*/
  PROCEDURE proc_delete_proxy(p_request CLOB, x_response OUT CLOB) as
    v_request  json;
    v_response pl_json := pl_json;
    v_proxy_id number;
   
  begin
    v_request  := json(p_request, 'OBJECT');
    v_proxy_id := v_request.get_number('proxyId');
    delete from dbpm_prox_rules dpr where dpr.proxy_id = v_proxy_id;
   
    x_response := v_response.to_json;
  end;

end DBPM_PROXY_API_PKG;

/

