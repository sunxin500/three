create PACKAGE BODY dcld_comm_pkg IS

  --migrate by xiaowei.yao 20180509
  FUNCTION get_filter_value(p_field VARCHAR2, p_request json) RETURN VARCHAR2 IS
    v_fields json_list;
    v_field  json;
    v_result VARCHAR2(4000);
  BEGIN
    IF p_request.get('filter') IS NULL THEN
      RETURN NULL;
    END IF;
    v_fields := json_list(p_request.get('filter'));
    FOR v_index IN 1 .. v_fields.count LOOP
      v_field := json(v_fields.get(v_index));
      IF p_field = v_field.get_string('field') THEN
        v_result := v_field.get_string('value');
      END IF;
    END LOOP;
    RETURN v_result;
  END;

  FUNCTION get_string(p_field VARCHAR2, p_request json) RETURN VARCHAR2 IS
    v_fields json_list;
    v_field  json;
    v_result VARCHAR2(4000);
  BEGIN
    IF p_request.get('fields') IS NULL THEN
      RETURN NULL;
    END IF;
    v_fields := json_list(p_request.get('fields'));
    FOR v_index IN 1 .. v_fields.count LOOP
      v_field := json(v_fields.get(v_index));
      IF p_field = v_field.get('field').get_string THEN
        v_result := v_field.get('value').get_string;
      END IF;
    END LOOP;
    RETURN v_result;
  END;

  FUNCTION is_readed(p_source    VARCHAR2,
                     p_source_id VARCHAR2,
                     p_user      VARCHAR2) RETURN VARCHAR2 IS
    v_count NUMBER;
  BEGIN
    SELECT COUNT(1)
      INTO v_count
      FROM dcld_notice_history t
     WHERE t.from_source = p_source
       AND t.from_source_id = p_source_id
       AND t.user_code = p_user;
    IF v_count > 0 THEN
      RETURN 'Y';
    END IF;
    RETURN 'N';
  END;

  /*==================================================
  function Name :
      get_lookup_meaning
  Description:
      查询值列表含义
  Argument:
      p_lookup_type：  值列表类型
      p_lookup_code：  值列表编码
  History:
      1.00  2016-12-15  jianfeng.zheng  Creation
  ==================================================*/
  FUNCTION get_lookup_meaning(p_lookup_type VARCHAR2,
                              p_lookup_code VARCHAR2,
                              p_locale      varchar2 DEFAULT 'zh',
                              p_status      VARCHAR2 DEFAULT 'Y')
    RETURN VARCHAR2 IS
    v_meaning        VARCHAR2(4000);
    v_locale_meaning VARCHAR2(4000);
  BEGIN
    SELECT t.meaning,
           func_get_sys_msg(p_lookup_code, p_locale, p_lookup_type)
      INTO v_meaning, v_locale_meaning
      FROM dfnd_lookup_values t
     WHERE t.lookup_type = p_lookup_type
       AND t.lookup_code = p_lookup_code
       AND T.STATUS = p_status
       AND rownum = 1;
    RETURN nvl(v_locale_meaning,v_meaning);
  EXCEPTION
    WHEN OTHERS THEN
      RETURN v_meaning;
  END;
  /*==================================================
  function Name :
      get_data_source_value
  Description:
      查询数据字典的显示值
  Argument:
      p_lookup_type：  值列表类型
      p_lookup_code：  值列表编码
  History:
      1.00  2018-07-04  wlj  Creation
  ==================================================*/
  FUNCTION get_data_source_value(p_ds_code    VARCHAR2,
                                 p_value_code VARCHAR2,
                                 p_locale     varchar2 DEFAULT 'zh',
                                 p_status     VARCHAR2 DEFAULT 'Y')
    RETURN VARCHAR2 AS
    v_meaning        VARCHAR2(4000);
    v_locale_meaning VARCHAR2(4000);
  BEGIN
    SELECT t.value_name,
           func_get_sys_msg(p_value_code, p_locale, p_ds_code)
      INTO v_meaning, v_locale_meaning
      FROM dbpm_data_source_values t
     WHERE t.data_source_code = p_ds_code
       AND t.value_code = p_value_code
       AND T.STATUS = p_status
       AND rownum = 1;
    RETURN nvl(v_locale_meaning,v_meaning);
  EXCEPTION
    WHEN OTHERS THEN
      RETURN v_meaning;
  END;

  /*==================================================
  function Name :
      get_string_value
  Description:
      获取json_valued的值，以字符串形式返回
  Argument:
      p_lookup_type：  值列表类型
      p_lookup_code：  值列表编码
  History:
      1.00  2016-12-15  jianfeng.zheng  Creation
  ==================================================*/
  FUNCTION get_string_value(js_value json_value_cux) RETURN VARCHAR2 IS

  BEGIN
    IF js_value IS NOT NULL THEN
      IF js_value.get_number IS NOT NULL THEN
        RETURN to_char(js_value.get_number);
      ELSIF js_value.get_bool IS NOT NULL THEN
        IF js_value.get_bool THEN
          RETURN 'true';
        ELSE
          RETURN 'false';
        END IF;
      ELSE
        RETURN js_value.get_string;
      END IF;
    ELSE
      RETURN NULL;
    END IF;
  END get_string_value;

  /*==================================================
  function Name :
      get_value_type
  Description:
      获取json_valued的值的类型，string，number，boolean，
  Argument:
      p_lookup_type：  值列表类型
      p_lookup_code：  值列表编码
  History:
      1.00  2016-12-15  jianfeng.zheng  Creation
  ==================================================*/
  FUNCTION get_value_type(js_value json_value_cux) RETURN VARCHAR2 IS

  BEGIN
    IF js_value IS NOT NULL THEN
      IF js_value.get_number IS NOT NULL THEN
        RETURN 'number';
      ELSIF js_value.get_bool IS NOT NULL THEN
        RETURN 'boolean';
      ELSE
        RETURN 'string';
      END IF;
    ELSE
      RETURN 'string';
    END IF;
  END get_value_type;

  /*==================================================
  function Name :
      proc_get_user_master_organization
  Description:
      获取用户主组织信息
  Argument:
  History:
      1.00  2016-12-15  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE get_user_master_organization(p_user_code         VARCHAR2,
                                         x_organization_id   OUT VARCHAR2,
                                         x_organization_name OUT VARCHAR2) IS

  BEGIN
    SELECT doe.organization_id,
           (SELECT do.organization_name
              FROM dfnd_organizations do
             WHERE do.organization_id = doe.organization_id)
      INTO x_organization_id, x_organization_name
      FROM dfnd_org_employees doe
     WHERE upper(doe.employee_code) = upper(p_user_code)
       AND doe.is_master_organization = 'Y'
       AND rownum = 1;
  EXCEPTION
    WHEN OTHERS THEN
      x_organization_id   := 1000;
      x_organization_name := 'Haier Organization';
  END get_user_master_organization;

  /*==================================================
  function Name :
      proc_get_menu
  Description:
      获取菜单
  Argument:
  History:
      1.00  2018-1-26  wlj  Creation
  ==================================================*/
  PROCEDURE proc_get_comm_menu(p_request IN CLOB, x_response OUT CLOB) IS
    --v_api          VARCHAR2(30) := 'proc_get_menu';
    v_request      json;
    v_response     pl_json := pl_json;
    v_menu         pl_json;
    v_navMenus     pl_json := pl_json;
    v_tabs         pl_json := pl_json;
    v_current_user VARCHAR2(100);
    v_admin_type   varchar2(100);
    v_locale       varchar2(100);
    V_MENU_REGION  varchar2(100);
    V_CHILD_COUNT  NUMBER;
    v_platform     varchar2(10);

    CURSOR v_menu_cursor IS
      SELECT TL.MENU_NAME,
             T.MENU_ID,
             T.MENU_DESCRIPTION,
             T.MENU_CODE,
             T.MENU_ICON_CLASS,
             T.MENU_REGION,
             DECODE(INSTR(T.MENU_AUTH, 'USER'), 0, 'Y', 'N') IS_MANAGE_MENU

        FROM DCLD_MENU T, DCLD_MENU_TL TL
       WHERE T.MENU_ID = TL.MENU_ID(+)
         AND T.ENABLE_FLAG = 'Y'
         AND INSTR(TL.LOCALE, v_locale) > 0
         AND INSTR(T.MENU_AUTH, v_admin_type) > 0
         and t.menu_region = V_MENU_REGION
         AND T.WEB_FLAG = 'Y'
      /*   AND T.MENU_PARENT_ID IS NULL*/
       ORDER BY T.MENU_ORDER;

    --移动端菜单
    CURSOR v_mob_menu_cursor IS
      SELECT TL.MENU_NAME,
             T.MENU_ID,
             T.MENU_DESCRIPTION,
             T.MENU_CODE,
             T.MENU_ICON_CLASS,
             T.ICON,
             T.MENU_REGION,
             DECODE(INSTR(T.MENU_AUTH, 'USER'), 0, 'Y', 'N') IS_MANAGE_MENU

        FROM DCLD_MENU T, DCLD_MENU_TL TL
       WHERE T.MENU_ID = TL.MENU_ID(+)
         AND T.ENABLE_FLAG = 'Y'
         AND INSTR(TL.LOCALE, v_locale) > 0
         AND INSTR(T.MENU_AUTH, v_admin_type) > 0
         and t.menu_region = V_MENU_REGION
         AND T.MOBILE_FLAG = 'Y'
      /*   AND T.MENU_PARENT_ID IS NULL*/
       ORDER BY T.MENU_ORDER;

  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := upper(v_request.username);
    v_locale       := v_request.locale;
    v_locale       := nvl(v_locale, 'zh');
    V_MENU_REGION  := v_request.get_string('menuRegion');
    v_platform     := nvl(v_request.get_string('platform'), 'WEB');

    --查询用户角色 SUPER,ADMIN,USER
    select decode(max(da.admin_type),
                  'NormalAdmin',
                  'ADMIN',
                  'SuperAdmin',
                  'SUPER',
                  'USER')
      into v_admin_type
      from dbpm_administrators da
     where upper(da.user_code) = upper(v_current_user);
    -- 根据用户角色查询菜单
    if v_platform = 'WEB' then
      for v_menu_cur in v_menu_cursor loop
        --只有00575615，01465820，01147713，A0024975，A0017701，A0023610用户能看到KPI
        IF v_menu_cur.menu_code = 'MENU_08' AND
           v_current_user NOT IN ('00575615',
                                  '01514815',
                                  '01147713',
                                  'A0024975',
                                  'A0017701',
                                  'A0023610') THEN
          CONTINUE;
        END IF;
        v_menu := pl_json;
        v_menu.set_value('menuName', v_menu_cur.menu_name);
        v_menu.set_value('menuCode', v_menu_cur.menu_code);
        --v_menu.set_value('menuDescription', v_menu_cur.menu_description);
        v_menu.set_value('iconClass', v_menu_cur.menu_icon_class);
        v_menu.set_value('menuRegion', v_menu_cur.menu_region);
        --判断是否有子菜单
        SELECT COUNT(*)
          INTO V_CHILD_COUNT
          FROM DCLD_MENU DM
         WHERE DM.MENU_PARENT_ID = v_menu_cur.menu_id;
        IF V_CHILD_COUNT <> 0 THEN
          v_menu.set_value('isParent', 'Y');
        ELSE
          v_menu.set_value('isParent', 'N');
        END IF;
        V_CHILD_COUNT := null;
        v_response.add_list_item('menuList', v_menu);
      end loop;
    else
      --v_response.set_data_type('ARRAY');
      v_tabs.set_data_type('ARRAY');
      v_navMenus.set_data_type('ARRAY');
      for v_menu_cur in v_mob_menu_cursor loop
        v_menu := pl_json;
        v_menu.set_value('title', v_menu_cur.menu_name);
        v_menu.set_value('code', v_menu_cur.menu_code);
        --v_menu.set_value('menuDescription', v_menu_cur.menu_description);
        v_menu.set_value('iconClass', v_menu_cur.menu_icon_class);
        v_menu.set_value('icon', v_menu_cur.ICON);
        v_menu.set_value('menuRegion', v_menu_cur.menu_region);
        --判断是否有子菜单
        SELECT COUNT(*)
          INTO V_CHILD_COUNT
          FROM DCLD_MENU DM
         WHERE DM.MENU_PARENT_ID = v_menu_cur.menu_id;
        IF V_CHILD_COUNT <> 0 THEN
          v_menu.set_value('isParent', 'Y');
        ELSE
          v_menu.set_value('isParent', 'N');
        END IF;
        V_CHILD_COUNT := null;
        v_navMenus.add_list_item(v_menu);
      end loop;
      v_tabs.set_value('navMenus', v_navMenus);
      v_tabs.set_value('code', 'DYGZT');
      v_tabs.set_value('title', func_get_sys_msg('DYGZT',v_request.locale));
      v_response.add_list_item(v_tabs);
    end if;
    x_response := v_response.to_json;
  END proc_get_comm_menu;

  /*==================================================
  function Name :
      proc_get_components
  Description:
      获取组件
  Argument:
  History:
      1.00  2018-1-26  wlj  Creation
  ==================================================*/
  PROCEDURE proc_get_components(p_request IN CLOB, x_response OUT CLOB) IS
    v_request      json;
    v_response     pl_json := pl_json;
    v_component    pl_json;
    v_current_user VARCHAR2(100);
    v_locale       VARCHAR2(100);

    CURSOR V_COMPONENT_CURSOR IS
      SELECT T.COMPONENT_CODE,
             TL.COMPONENT_NAME,
             t.component_icon_class,
             t.icon_url,
             t.is_custom
        FROM DCLD_COMPONENT T, DCLD_COMPONENT_TL TL
       WHERE T.COMPONENT_ID = TL.COMPONENT_ID(+)
         AND T.ENABLE_FLAG = 'Y'
         AND INSTR(TL.LOCALE, v_locale) > 0
       ORDER BY T.COMPONENT_ORDER;

  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := upper(v_request.username);
    v_locale       := v_request.locale;
    v_locale       := nvl(v_locale, 'zh');

    for v_component_cur in v_component_cursor loop
      v_component := pl_json;
      v_component.set_value('code', v_component_cur.component_code);
      v_component.set_value('name', v_component_cur.component_name);
      v_component.set_value('iconClass',
                            v_component_cur.component_icon_class);
      v_component.set_value('iconUrl', v_component_cur.icon_url);
      if v_component_cur.is_custom = 'N' then
        v_component.set_value('isCustomComponent', FALSE);
      else
        v_component.set_value('isCustomComponent', TRUE);
      end if;
      v_response.add_list_item('componentList', v_component);
    end loop;
    x_response := v_response.to_json;
  END proc_get_components;

  /*==================================================
  function Name :
      func_get_err_msg
  Description:
      获取错误信息
  Argument:
  History:
      1.00  2018-3-12  wlj  Creation
  ==================================================*/
  FUNCTION func_get_err_msg(p_err_code VARCHAR2,
                            p_locale   VARCHAR2,
                            p_params   VARCHAR2 default NULL) RETURN VARCHAR2 AS
    v_err_msg VARCHAR2(4000);
    --v_dynamic_sql_str VARCHAR2(4000);
  BEGIN

    SELECT DEM.ERR_MSG
      INTO v_err_msg
      FROM DCLD_ERR_MSG DEM
     WHERE DEM.ERR_CODE = p_err_code
       AND DEM.LOCALE = p_locale;
    IF p_params IS NULL THEN
      NULL;
    ELSE
      select replace(v_err_msg, ':1', p_params) into v_err_msg from dual;
    END IF;
    return v_err_msg;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      return '';
    WHEN OTHERS THEN
      return 'ERROR';
  END;

  /*==================================================
  function Name :
      func_get_err_msg
  Description:
      获取静态的系统国际化信息
  Argument:
  History:
      1.00  2018-5-29  wlj  Creation
  ==================================================*/
  FUNCTION func_get_sys_msg(p_msg_code VARCHAR2,
                            p_locale   VARCHAR2,
                            p_msg_type varchar2 default 'DCLD_SYS_TYPE',
                            p_params   VARCHAR2 default NULL) RETURN VARCHAR2 AS
    v_locale_msg varchar2(4000);
  BEGIN
    select M.MSG
      into v_locale_msg
      from dfnd_msg_locale m
     where m.msg_type = p_msg_type
       AND m.msg_code = p_msg_code
       AND M.LOCALE = substr(p_locale, 0, 2);
    return v_locale_msg;
  exception
    when others then
      return null;
  END;

  /*==================================================
  function Name :
      func_get_BPM_url
  Description:
      获取得云表单链接
  Argument:
  History:
      1.00  2018-5-29  wlj  Creation
  ==================================================*/
  FUNCTION func_get_BPM_url RETURN VARCHAR2 AS
    v_url varchar2(4000);
  BEGIN
    v_url := 'http://ssosci.haier.net:88/OAMSsoLogin/BPMUITODO/?definesys=definesys';
    return v_url;
  END;

END dcld_comm_pkg;

/

