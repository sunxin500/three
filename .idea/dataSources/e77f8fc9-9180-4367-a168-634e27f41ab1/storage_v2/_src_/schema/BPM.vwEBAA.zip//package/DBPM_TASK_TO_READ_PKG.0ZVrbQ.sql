create PACKAGE     dbpm_task_to_read_pkg IS

  PROCEDURE create_task_read(p_document_id IN NUMBER);

  /*
  查询待阅记录
  Author  : XJL
  Created : 2017/11/29
  */
  PROCEDURE get_task_read(p_request IN CLOB, x_response OUT CLOB);
  /*
  更新已读状态
  Author  : XJL
  Created : 2017/11/29
  */
  PROCEDURE update_task_read(p_read_id IN NUMBER);

END dbpm_task_to_read_pkg;

/

