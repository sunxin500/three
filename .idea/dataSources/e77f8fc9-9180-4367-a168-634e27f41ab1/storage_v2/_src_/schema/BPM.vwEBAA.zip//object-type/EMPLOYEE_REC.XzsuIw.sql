create TYPE     "EMPLOYEE_REC" IS OBJECT
(
  employee_code  VARCHAR2(300),
  display_name   VARCHAR2(300),
  mail           VARCHAR2(300),
  manager        VARCHAR2(300)
)

/

