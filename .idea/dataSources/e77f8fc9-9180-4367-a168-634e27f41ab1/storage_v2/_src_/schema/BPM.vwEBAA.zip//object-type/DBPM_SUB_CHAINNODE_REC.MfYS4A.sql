create TYPE     "DBPM_SUB_CHAINNODE_REC" IS OBJECT
(
  node_id   NUMBER,
  chain_uuid varchar2(200)
)

/

