create package     DBPM_PROCESS_SERVICE_API is
 -- Author  : yxw
  -- Created : 2019/02/20 12:00
  -- Purpose : 流程服务功能



/*==================================================
  Procedure/Function Name :
      proc_save_service
  Description:
      This function perform:
      保存服务配置
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2019-02-20  yxw  Creation
  ==================================================*/
  procedure proc_save_service(p_request in clob,x_response out clob);
  /*==================================================
  Procedure/Function Name :
      proc_query_service
  Description:
      This function perform:
      查询服务配置
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2019-02-20  yxw  Creation
  ==================================================*/
  procedure proc_query_service(p_request in clob,x_response out clob);
/*==================================================
  Procedure/Function Name :
      proc_del_service
  Description:
      This function perform:
      删除服务配置
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2019-02-21  yxw  Creation
  ==================================================*/
  procedure proc_del_service(p_request in clob,x_response out clob);


end DBPM_PROCESS_SERVICE_API;

/

