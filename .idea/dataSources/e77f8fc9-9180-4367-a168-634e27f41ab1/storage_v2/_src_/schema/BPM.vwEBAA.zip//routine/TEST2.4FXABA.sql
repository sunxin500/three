create procedure     test2(v_sqlq     in varchar2,
                                  p_business in DBPM_BUSINESS_PARAM_REC,
                                  x_sql      out varchar2,
                                  x_flag     out varchar2) is
  v_rule_exs    varchar2(128);
  v_index       number;
  v_next_tmp    varchar2(2);
  v_Previou_tmp varchar2(2);
begin
  --循环传入的参数
  x_sql := v_sqlq;
  --循环sql语句，查询 paramkey在 sql语句中的位置，直到查询不到 paramkey
  for m in 1 .. length(v_sqlq) loop

    v_index := instr(v_sqlq, p_business.paramkey, 1, m);

    if v_index = 0 then
      --查询不到，退出本循环
      x_flag := 'F';
      exit;
    else
      --获取之后一个字符，和之前一个字符
      v_next_tmp    := substr(v_sqlq,
                              v_index + length(p_business.paramkey),
                              1);
      v_Previou_tmp := substr(v_sqlq, v_index - 1, 1);
      --如果为 之后一个字符为 = < > 或者空格  并且 之前一个字符 为 或者空格 说明为参数
      if ((v_next_tmp = '=' or v_next_tmp = '<' or v_next_tmp = ' ' or
         v_next_tmp = '>') and
         (v_Previou_tmp = ' ' or v_Previou_tmp is null or v_index = 1)) or
         ((v_Previou_tmp = '=' or v_Previou_tmp = '<' or
         v_Previou_tmp = ' ' or v_next_tmp = '>') and
         (v_next_tmp = ' ' or v_next_tmp is null)) then
        x_sql  := substr(v_sqlq, 1, v_index - 1) || '''' ||
                  p_business.paramvalue || '''' ||
                  substr(v_sqlq,
                         v_index + length(p_business.paramkey),
                         length(v_sqlq));
        x_flag := 'T';
        exit;
      end if;

    end if;

  end loop;
end test2;

/

