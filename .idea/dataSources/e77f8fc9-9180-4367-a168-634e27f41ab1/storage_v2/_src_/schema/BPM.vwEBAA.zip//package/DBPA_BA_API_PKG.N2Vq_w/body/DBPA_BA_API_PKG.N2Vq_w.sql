create package body     dbpa_ba_api_pkg is

  procedure proc_plat_processcountsbygroup(p_request  in clob,
                                           x_response out clob) is
    v_request                  json;
    v_response                 pl_json := pl_json;
    v_search_content_startdate varchar2(200);
    v_search_content_enddate   varchar2(200);
    v_page                     number;
    v_size                     number;
    v_sort_col                 varchar2(100);
    v_sort                     json;
    processcounts              pl_json;
    processnewaddcounts        pl_json;
    v_processcount             number := 0;
    v_processnewaddcount       number := 0;
    v_count                    pl_json;
    --v_total                    number := 0;
    --用来展示系统流程总数和过去三十天新增流程总数

    cursor v_processcountandnewadd_cur is
     select vvvv.* from (
     select vvv.*,rownum rn from (
      select vv.*, rownum isrn
        from (select v.*
                from (select v4.*, count(1) over(partition by 1) as total
                        from (select v2.*,
                                     nvl(v3.processnewaddcount, 0) processnewaddcount
                                from (select v1.*, da.system_name
                                        from (select max(system_code) system_code,
                                                     count(system_code) processcount
                                                from (select t.process_code,
                                                             t.system_code
                                                        from dbpm_ba_sync_process_v t
                                                         where t.creationdate between
                                                     to_date(v_search_content_startdate,
                                                             'yyyy-mm-dd') and
                                                     to_date(v_search_content_enddate,
                                                             'yyyy-mm-dd')+1
                                                       group by t.process_code,
                                                                t.system_code)
                                               group by system_code) v1,
                                             dbpm_ba_sync_app_v da
                                       where v1.system_code =
                                             da.system_code
                                             and da.status = 'Y') v2,
                                     (select max(system_code) system_code,
                                             count(system_code) processnewaddcount
                                        from (select t.process_code,
                                                     t.system_code
                                                from dbpm_ba_sync_process_v t
                                               where t.creationdate between
                                                     to_date(v_search_content_startdate,
                                                             'yyyy-mm-dd') and
                                                     to_date(v_search_content_enddate,
                                                             'yyyy-mm-dd')+1
                                               group by t.process_code,
                                                        t.system_code)
                                       group by system_code) v3
                               where v2.system_code = v3.system_code(+)) v4
                       order by decode(v_sort_col,
                                       'processCount_asc',
                                       processcount,
                                       'processNewAddCount_asc',
                                       processnewaddcount) asc,
                                decode(v_sort_col,
                                       'processCount_desc',
                                       processcount,
                                       'processNewAddCount_desc',
                                       processnewaddcount) desc) v) vv)vvv
       where isrn <= v_page * v_size
         and isrn > (v_page - 1) * v_size)vvvv;

  begin
    v_request                  := json(p_request, 'OBJECT');
    v_search_content_startdate := dcld_comm_pkg.get_filter_value('startDate',
                                                                 v_request);
    v_search_content_enddate   := dcld_comm_pkg.get_filter_value('endDate',
                                                                 v_request);
    if v_request.exist('sort') then
      v_sort     := json(v_request.get('sort'));
      v_sort_col := v_sort.get_string('value');
      v_sort_col := v_sort_col || '_' || v_sort.get_string('order');
      dbms_output.put_line(v_sort_col);
    end if;
    v_page := nvl(v_request.get('page').get_number, 1);
    v_size := nvl(v_request.get('size').get_number, 20);
    if to_date(v_search_content_startdate, 'yyyy-mm-dd hh24:mi:ss') <=
       to_date(v_search_content_enddate, 'yyyy-mm-dd hh24:mi:ss') then
      for v_processcountandnewadd_row in v_processcountandnewadd_cur loop
        -- v_line.set_value('systemCode',
        --                v_processcountandnewadd_row.system_code);
        processcounts       := pl_json;
        processnewaddcounts := pl_json;
        processcounts.set_value('name',
                                v_processcountandnewadd_row.system_name);
        processcounts.set_value('value',
                                v_processcountandnewadd_row.processcount);
        processnewaddcounts.set_value('name',
                                      v_processcountandnewadd_row.system_name);
        processnewaddcounts.set_value('value',
                                      v_processcountandnewadd_row.processnewaddcount);
        processcounts.set_value('systemCode',
                                v_processcountandnewadd_row.system_code);
        processnewaddcounts.set_value('systemCode',
                                      v_processcountandnewadd_row.system_code);
        v_processcount       := v_processcount +
                                v_processcountandnewadd_row.processcount;
        v_processnewaddcount := v_processnewaddcount +
                                v_processcountandnewadd_row.processnewaddcount;
        v_response.add_list_item('processCount', processcounts);
        v_response.add_list_item('processNewAddCount', processnewaddcounts);
        if v_processcountandnewadd_row.rn = 1 then
          v_response.set_value('total', v_processcountandnewadd_row.total);
        end if;
      end loop;
      v_count := pl_json;
      v_count.set_value('processCount', v_processcount);
      v_count.set_value('processNewAddCount', v_processnewaddcount);
      v_response.set_value('counts', v_count);
    else
      v_response.code   := 'FAILED';
      v_response.devmsg := '请求参数错误';
    end if;
    x_response := v_response.to_json;

  end proc_plat_processcountsbygroup;

  procedure proc_plat_insexceptioncounts(p_request  in clob,
                                         x_response out clob) is
    v_request                  json;
    v_response                 pl_json := pl_json;
    v_search_content_startdate varchar2(200);
    v_search_content_enddate   varchar2(200);
    v_system_exceptionnumber   number;
    v_syetem_disposeexception  number;
    v_exception_today          number;
    v_disposeexception_totay   number;
    --用来展示系统异常实例量

  begin

    v_request                  := json(p_request, 'OBJECT');
    v_search_content_startdate := dcld_comm_pkg.get_filter_value('startDate',
                                                                 v_request);
    v_search_content_enddate   := dcld_comm_pkg.get_filter_value('endDate',
                                                                 v_request);
    --平台内所有异常总数
    select count(1)
      into v_system_exceptionnumber
      from dbpm_ba_process_instance  t
     where t.state not in (1,5)
       and t.creation_date between
           to_date(v_search_content_startdate, 'yyyy-mm-dd') and
           to_date(v_search_content_enddate, 'yyyy-mm-dd');
    --已处理的异常
    select count(1)
      into v_syetem_disposeexception
      from dbpm_ba_process_instance t
     where t.state in (2, 4, 7)
       and t.creation_date between
           to_date(v_search_content_startdate, 'yyyy-mm-dd') and
           to_date(v_search_content_enddate, 'yyyy-mm-dd');
    --今日异常总数
    select count(1)
      into v_exception_today
      from dbpm_ba_process_instance t
     where t.state in (2, 4, 7)
      and  t.creation_date >  sysdate-1
      and   t.creation_date < sysdate;
    --今日已处理异常数
    select count(1)
      into v_disposeexception_totay
      from dbpm_ba_process_instance t
     where t.state in (2, 4, 7)
      and t.creation_date >  sysdate-1
       and   t.creation_date < sysdate;

    v_response.set_value('counts', v_system_exceptionnumber);
    v_response.set_value('countsDealed', v_syetem_disposeexception);
    v_response.set_value('todayCounts', v_exception_today);
    v_response.set_value('todaycountsDealed', v_disposeexception_totay);
    x_response := v_response.to_json;
  end proc_plat_insexceptioncounts;

  procedure proc_plat_processdetailbygroup(p_request  in clob,
                                           x_response out clob) is
    --用来展示各个系统的流程详情
    v_request                  json;
    v_response                 pl_json := pl_json;
    v_search_content_startdate varchar2(200);
    v_search_content_enddate   varchar2(200);
    v_page                     number;
    v_size                     number;
    v_sort_col                 varchar2(100);
    v_sort                     json;
    v_line                     pl_json;
    -- v_total                    number := 0;
    v_systemcode varchar2(200);
    cursor v_processdetails_cur is
      select vvv.* from (
      select vv.*,rownum rn from (
      select v.*,rownum isrn
        from (select v4.*
                from (select v3.*
                        from (select v2.*
                                     ,count(1) over(partition by 1) as total
                                from (select-- max(system_id) system_id,
                                             max(system_code) system_code,
                                             max(process_code) process_code,
                                             max(prcoess_name) process_name,
                                             max(system_name) system_name,
                                             max(createdate) createdate
                                        from (select --dp.,
                                                     dp.system_code,
                                                     da.system_name,
                                                     dp.process_code,
                                                     dp.prcoess_name,
                                                     to_char(dp.creationdate,
                                                             'yyyy-mm-dd') as createdate
                                                from dbpm_ba_sync_process_v dp,
                                                     dbpm_ba_sync_app_v        da
                                               where dp.system_code =
                                                     da.system_code(+)
                                                 and dp.system_code =
                                                       nvl(v_systemcode,dp.system_code)
                                                 and dp.creationdate between
                                                     to_date(v_search_content_startdate,
                                                             'yyyy-mm-dd') and
                                                     to_date(v_search_content_enddate,
                                                             'yyyy-mm-dd')+1) v1
                                       group by v1.process_code) v2) v3) v4
               order by decode(v_sort_col, 'createDate_desc', v4.createdate) desc,
                        decode(v_sort_col, 'createDate_asc', v4.createdate) asc) v
       )vv
       where isrn <= v_page * v_size
         and isrn > (v_page - 1) * v_size)vvv;

  begin
    v_request                  := json(p_request, 'OBJECT');
    v_search_content_startdate := dcld_comm_pkg.get_filter_value('startDate',
                                                                 v_request);
    v_search_content_enddate   := dcld_comm_pkg.get_filter_value('endDate',
                                                                 v_request);
    v_systemcode               := dcld_comm_pkg.get_filter_value('systemCode',
                                                                 v_request);

    v_page := nvl(v_request.get_number('page'), 1);
    v_size := nvl(v_request.get_number('size'), 20);

    if v_request.exist('sort') then
      v_sort     := json(v_request.get('sort'));
      v_sort_col := v_sort.get_string('value');
      v_sort_col := v_sort_col || '_' || v_sort.get_string('order');
    end if;
    for v_processdetails_row in v_processdetails_cur loop
      v_line := pl_json;
      --v_line.set_value('systemId', v_processdetails_row.system_id);
      v_line.set_value('systemCode', v_processdetails_row.system_code);
      v_line.set_value('systemName', v_processdetails_row.system_name);
      v_line.set_value('processCode', v_processdetails_row.process_code);
      v_line.set_value('processName', v_processdetails_row.process_name);
      v_line.set_value('createDate', v_processdetails_row.createdate);
      v_response.add_list_item('process', v_line);
      if v_processdetails_row.rn = 1 then
        v_response.set_value('total', v_processdetails_row.total);
      end if;
    end loop;

    v_response.set_value('pageNo', v_page);
    x_response := v_response.to_json;

  end proc_plat_processdetailbygroup;
  procedure proc_plat_inscountsbygroup(p_request  in clob,
                                       x_response out clob) is
    v_request                  json;
    v_response                 pl_json := pl_json;
    v_search_content_startdate varchar2(200);
    v_search_content_enddate   varchar2(200);
    v_page                     number;
    v_size                     number;
    v_sort_col                 varchar2(100);
    v_sort                     json;
    v_line                     pl_json;
    -- v_total                    number := 0;
    v_systemcode varchar2(200);

    --获取全部系统下面的实例或者某一个系统所有流程的数据
    cursor v_inscountbygroup_cur is
      select vvv.* from (
      select vv.* ,rownum rn from (
      select v.*, rownum isrn
        from (select v6.*
                from (select v5.*
                        from (select *
                                from (select v1.system_code system_code,
                                             v1.instancecounts,
                                             v1.process_code,
                                             fun_getname_bycode(v1.system_code,
                                                                'sys') system_name,
                                             fun_getname_bycode(v1.process_code,
                                                                'process') process_name,
                                             nvl(v2.instancecompletecounts,0) instancecompletecounts,
                                             count(1) over(partition by 1) total
                                        from (select max(system_code) system_code,
                                                     max(process_code) process_code,
                                                     nvl(count(1), 0) instancecounts
                                                from (select ddb.system_code system_code,
                                                             ddb.process_code
                                                        from dbpm_ba_sync_app_v                 da,
                                                             dbpm_ba_sync_process_ins_v ddb
                                                       where ddb.system_code =
                                                             da.system_code(+)
                                                         and ddb.system_code =
                                                             nvl(v_systemcode,
                                                                ddb.system_code)
                                                         and ddb.creation_date between
                                                             to_date(v_search_content_startdate,
                                                                     'yyyy-mm-dd hh24:mi:ss') and
                                                             to_date(v_search_content_enddate,
                                                                     'yyyy-mm-dd hh24:mi:ss'))
                                               group by decode(v_systemcode,
                                                               '',
                                                               system_code,
                                                               process_code)) v1,
                                             (select max(system_code) system_code,
                                                     max(process_code) process_code,
                                                     nvl(count(1), 0) instancecompletecounts
                                                from (select ddb.system_code system_code,
                                                             ddb.process_code,
                                                             ddb.creation_date create_date
                                                        from dbpm_ba_sync_app_v        da,
                                                             dbpm_ba_process_instance ddb
                                                       where ddb.state=5
                                                       and ddb.system_code =
                                                             da.system_code(+)
                                                         and ddb.system_code =
                                                             nvl(v_systemcode,
                                                                 ddb.system_code)
                                                         and ddb.creation_date between
                                                             to_date(v_search_content_startdate,
                                                                     'yyyy-mm-dd hh24:mi:ss') and
                                                             to_date(v_search_content_enddate,
                                                                     'yyyy-mm-dd hh24:mi:ss'))
                                               group by decode(v_systemcode,
                                                               '',
                                                               system_code,
                                                               process_code)) v2
                                       where decode(v_systemcode,
                                                    '',
                                                    v1.system_code,
                                                    v1.process_code) =
                                             decode(v_systemcode,
                                                    '',
                                                    v2.system_code(+),
                                                    v2.process_code(+))) v4
                               order by decode(v_sort_col,
                                               'instanceCounts_desc',
                                               v4.instancecounts,
                                               'instanceCompleteCounts_desc',
                                               v4.instancecompletecounts) desc,
                                        decode(v_sort_col,
                                               'instanceCounts_asc',
                                               v4.instancecounts,
                                               'instanceCompleteCounts_asc',
                                               v4.instancecompletecounts) asc) v5
                     ) v6) v)vv
                      where isrn > (v_page - 1) * v_size
                      and isrn <= v_page * v_size)vvv;

  begin

    v_request                  := json(p_request, 'OBJECT');
    v_search_content_startdate := dcld_comm_pkg.get_filter_value('startDate',
                                                                 v_request);
    v_search_content_enddate   := dcld_comm_pkg.get_filter_value('endDate',
                                                                 v_request);
    v_systemcode               := dcld_comm_pkg.get_filter_value('systemCode',
                                                                 v_request);
    v_page                     := nvl(v_request.get_number('page'), 1);
    v_size                     := nvl(v_request.get_number('size'), 20);
    if v_request.exist('sort') then
      v_sort     := json(v_request.get('sort'));
      v_sort_col := v_sort.get_string('value');
      v_sort_col := v_sort_col || '_' || v_sort.get_string('order');
    end if;
    for v_inscountbygroup_cur_row in v_inscountbygroup_cur loop
      v_line := pl_json();
      /* v_line.set_value('systemId', v_inscountbygroup_cur_row.system_id);*/
      v_line.set_value('systemCode', v_inscountbygroup_cur_row.system_code);
      v_line.set_value('systemName', v_inscountbygroup_cur_row.system_name);
      v_line.set_value('processName',
                       v_inscountbygroup_cur_row.process_name);
      v_line.set_value('process_code',
                       v_inscountbygroup_cur_row.process_code);
      v_line.set_value('instanceCounts',
                       v_inscountbygroup_cur_row.instancecounts);
      v_line.set_value('instanceCompleteCounts',
                       v_inscountbygroup_cur_row.instancecompletecounts);
      v_response.add_list_item('systems', v_line);
      if v_inscountbygroup_cur_row.rn = 1 then
        v_response.set_value('total', v_inscountbygroup_cur_row.total);
      end if;
    end loop;
    --dbms_output.put_line(v_inscountbygroup_cur);

    x_response := v_response.to_json;
  end proc_plat_inscountsbygroup;

  procedure proc_plat_processinsbysum(p_request  in clob,
                                      x_response out clob) is
    --获取各个流程下面的实例
    v_request                  json;
    v_response                 pl_json := pl_json;
    v_search_content_startdate varchar2(200);
    v_search_content_enddate   varchar2(200);
    v_page                     number;
    v_size                     number;
    v_sort_col                 varchar2(100);
    v_sort                     json;
    v_line                     pl_json;
    -- v_total                    number := 0;
    v_counts      pl_json;
    v_processcode varchar2(200);
    cursor v_processinstaces_cur is
    select vvv.* from (
    select vv.*,rownum rn from (
      select v.*, rownum isrn
        from (select *
                from (select v1.*,
                             v2.instancecompletecounts,
                             count(1) over(partition by 1) total
                        from (select max(process_id) process_id,
                                     max(process_code) process_code,
                                     max(process_name) process_name,
                                     count(1) instancecounts
                                from (select di.process_id,
                                             di.process_code,
                                             dp.process_name
                                        from dbpm_ba_process_instance di,
                                             dbpm_ba_process          dp
                                       where di.process_code = v_processcode
                                         and di.process_code =
                                             dp.process_code(+)
                                         and di.creation_date between
                                             to_date(v_search_content_startdate,
                                                     'yyyy-mm-dd') and
                                             to_date(v_search_content_enddate,
                                                     'yyyy-mm-dd'))
                               group by process_code) v1,
                             (select max(process_code) process_code,
                                     max(process_name) process_name,
                                     count(1) instancecompletecounts
                                from (select di.process_id,
                                             di.process_code,
                                             dp.process_name
                                        from dbpm_ba_process_instance di,
                                             dbpm_ba_process          dp
                                       where di.process_code = v_processcode
                                         and di.process_code =
                                             dp.process_code(+)
                                         and di.state = 5)
                               group by process_code) v2
                       where v1.process_code = v2.process_code(+))
               order by decode(v_sort_col,
                               'processId_desc',
                               nvl(process_id, '-'),
                               'processCode_desc',
                               nvl(process_code, '-'),
                               'processName_desc',
                               nvl(process_name, '-'),
                               'instanceCounts_desc',
                               nvl(instancecounts, '-'),
                               'instanceCompleteCounts_desc',
                               nvl(instancecompletecounts, '-')) desc,
                        decode(v_sort_col,
                               'processId_asc',
                               nvl(process_id, '-'),
                               'processCode_asc',
                               nvl(process_code, '-'),
                               'processName_asc',
                               nvl(process_name, '-'),
                               'instanceCounts_asc',
                               nvl(instancecounts, '-'),
                               'instanceCompleteCounts_asc',
                               nvl(instancecompletecounts, '-')) asc) v)vv
       where isrn <= v_page * v_size
         and isrn > (v_page - 1) * v_size) vvv;

  begin
    v_request                  := json(p_request, 'OBJECT');
    v_search_content_startdate := dcld_comm_pkg.get_filter_value('startDate',
                                                                 v_request);
    v_search_content_enddate   := dcld_comm_pkg.get_filter_value('endDate',
                                                                 v_request);
    v_processcode              := dcld_comm_pkg.get_filter_value('processCode',
                                                                 v_request);
    v_page                     := nvl(v_request.get_number('page'), 1);
    v_size                     := nvl(v_request.get_number('size'), 20);
    if v_request.exist('sort') then
      v_sort     := json(v_request.get('sort'));
      v_sort_col := v_sort.get_string('value');
      v_sort_col := v_sort_col || '_' || v_sort.get_string('order');
    end if;
    for v_processinstaces_row in v_processinstaces_cur loop
      v_line   := pl_json();
      v_counts := pl_json();
      v_line.set_value('processId', v_processinstaces_row.process_id);
      v_line.set_value('processCode', v_processinstaces_row.process_code);
      v_line.set_value('processName', v_processinstaces_row.process_name);
      v_line.set_value('instanceCounts',
                       v_processinstaces_row.instancecounts);
      v_line.set_value('instanceCompleteCounts',
                       v_processinstaces_row.instancecompletecounts);
      v_counts.set_value('instanceCounts',
                         v_processinstaces_row.instancecounts);
      v_counts.set_value('instanceCompleteCounts',
                         v_processinstaces_row.instancecompletecounts);
      v_response.set_value('counts', v_counts);
      v_response.add_list_item('systems', v_line);
      if v_processinstaces_row.rn = 1 then
        v_response.set_value('total', v_processinstaces_row.total);
      end if;
    end loop;

    x_response := v_response.to_json;
  end proc_plat_processinsbysum;
  /*==================================================
  procedure/function name :
      proc_plat_processexceptionnum
  description:
      this function perform:
     获取各个流程平均运行时间

  history:
      1.00  2018-08-25  xiaowei.yao
  ==================================================*/
  procedure proc_plat_processrunavgdura(p_request  in clob,
                                        x_response out clob) is
    v_request                     json;
    v_response                    pl_json := pl_json;
    v_search_content_startdateavg varchar2(200);
    v_search_content_enddateavg   varchar2(200);
    v_search_content_startdatecur varchar2(200);
    v_search_content_enddatecur   varchar2(200);
    v_page                        number;
    v_size                        number;
    v_sort_col                    varchar2(100);
    v_sort                        json;
    v_line                        pl_json;
    --v_total                       number := 0;
    v_search_content_systemcode varchar(200);
  cursor v_process_runavgdura_cur is
   select vvv.* from (
   select vv.*,rownum rn from (
      select v.*, rownum isrn
        from (select distinct v4.*,
                              count(1) over(partition by 1) total
                from (select v2.*, v3.curdura
                        from (select distinct v1.process_code process_code,
                                              max(v1.process_id) process_id,
                                              max(v1.system_code) system_code,
                                              max(system_name) system_name,
                                              max(process_name) process_name,
                                              round(avg(dura)) avgdura
                                from (select to_number(to_date(to_char(db.modify_date,
                                                                       'yyyy-mm-dd hh24:mi:ss'),
                                                               'yyyy-mm-dd hh24:mi:ss') -
                                                       to_date(to_char(db.creation_date,
                                                                       'yyyy-mm-dd hh24:mi:ss'),
                                                               'yyyy-mm-dd hh24:mi:ss')) *
                                             86400 as dura,
                                             db.process_id,
                                             db.process_code,
                                             db.system_code,
                                             nvl(da.system_name, db.system_code) system_name,
                                             nvl(dp.process_name,
                                                 dp.process_code) process_name,
                                             nvl(da.system_name, db.system_code)
                                        from dbpm_ba_process_instance db,
                                             dbpm_ba_process          dp,
                                             dfnd_app                 da
                                       where db.process_code =
                                             dp.process_code(+)
                                         and dp.system_code = da.system_code(+)
                                         and db.state = 5
                                         and db.creation_date between
                                             to_date(v_search_content_startdateavg,
                                                     'yyyy-mm-dd') and
                                             to_date(v_search_content_enddateavg,
                                                     'yyyy-mm-dd')
                                         and upper(db.system_code) =
                                             upper(v_search_content_systemcode)) v1
                               group by v1.process_code) v2,
                             (select distinct upper(v1.process_code) process_code,
                                              round(avg(dura)) curdura
                                from (select to_number(to_date(to_char(t.modify_date,
                                                                       'yyyy-mm-dd hh24:mi:ss'),
                                                               'yyyy-mm-dd hh24:mi:ss') -
                                                       to_date(to_char(t.creation_date,
                                                                       'yyyy-mm-dd hh24:mi:ss'),
                                                               'yyyy-mm-dd hh24:mi:ss')) *
                                             86400 as dura,
                                             t.process_code
                                        from dbpm_ba_process_instance t
                                       where t.state = 5
                                         and t.creation_date between
                                             to_date(v_search_content_startdatecur,
                                                     'yyyy-mm-dd') and
                                             to_date(v_search_content_enddatecur,
                                                     'yyyy-mm-dd')
                                         and t.system_code =v_search_content_systemcode
                                          ) v1
                               group by v1.process_code) v3
                       where v2.process_code = v3.process_code(+)) v4
               order by decode(v_sort_col,
                               'avgDura_desc',
                               avgdura,
                               'curDura_desc',
                               curdura) desc nulls last,
                        decode(v_sort_col,
                               'avgDura_asc',
                               avgdura,
                               'curDura_asc',
                               curdura) asc nulls last) v)vv
       where isrn > (v_page - 1) * v_size
         and isrn <= v_page * v_size)vvv;
  begin
    v_request                     := json(p_request, 'OBJECT');
    v_search_content_startdateavg := dcld_comm_pkg.get_filter_value('startDateAvg',
                                                                    v_request);
    v_search_content_enddateavg   := dcld_comm_pkg.get_filter_value('endDateAvg',
                                                                    v_request);
    v_search_content_startdatecur := dcld_comm_pkg.get_filter_value('startDateCur',
                                                                    v_request);
    v_search_content_enddatecur   := dcld_comm_pkg.get_filter_value('endDateCur',
                                                                    v_request);
    v_search_content_systemcode   := dcld_comm_pkg.get_filter_value('systemCode',
                                                                    v_request);

    v_page := nvl(v_request.get_number('page'), 1);
    v_size := nvl(v_request.get_number('size'), 20);

    if v_request.exist('sort') then
      v_sort     := json(v_request.get('sort'));
      v_sort_col := v_sort.get_string('value');
      v_sort_col := v_sort_col || '_' || v_sort.get_string('order');
    end if;
    for v_process_runavgdura_row in v_process_runavgdura_cur loop
      v_line := pl_json();
      v_line.set_value('processId', v_process_runavgdura_row.process_id);
      v_line.set_value('processCode',
                       v_process_runavgdura_row.process_code);
      v_line.set_value('processName',
                       v_process_runavgdura_row.process_name);
      v_line.set_value('systemCode', v_process_runavgdura_row.system_code);
      v_line.set_value('systemName', v_process_runavgdura_row.system_name);
      v_line.set_value('avgDura', v_process_runavgdura_row.avgdura);
      v_line.set_value('curDura', v_process_runavgdura_row.curdura);
      if v_process_runavgdura_row.rn = 1 then
        v_response.set_value('total', v_process_runavgdura_row.total);
      end if;
      v_response.add_list_item('efficiency', v_line);
    end loop;

    v_response.set_value('pageNo', v_page);
    x_response := v_response.to_json;
    return;
  end proc_plat_processrunavgdura;
  function fun_getname_bycode(p_code varchar2, p_type varchar2)
    return varchar2 as
    v_name varchar2(400);
  begin

    if (p_type = 'sys') then
      select nvl(df.system_name, p_code)
        into v_name
        from dfnd_app df
       where p_code = df.system_code;
    else
      select nvl(dp.process_name, p_code)
        into v_name
        from dbpm_ba_process dp
       where dp.process_code = p_code;
    end if;
    return v_name;
  end fun_getname_bycode;

  function comparedate(parameter_date varchar2, record_date varchar2)
    return varchar2 as
    --比较字符串类型的日期
    --parameter_date : 格式 2017-1-1
    --record_date：    格式 26-apr-17 09.15.11.000000 am
    --parameter_date > record_date 返回1，否则返回空
    v_date varchar2(100);
  begin
    v_date := substr(record_date, 1, 9);
    if to_date(parameter_date, 'yyyy-mm-dd') > to_date(v_date, 'dd-Mon-yy') then
      return '1';
    else
      return null;
    end if;
  end comparedate;

  procedure proc_plat_instanceexceptionnum(p_request  in clob,
                                           x_response out clob) is
    --获取系统流程异常实例量
    v_request                  json;
    v_response                 pl_json := pl_json;
    v_search_content_startdate varchar2(200);
    v_search_content_enddate   varchar2(200);
    v_line                     pl_json := pl_json;
    v_exceptioncount           number := 0;
    v_exceptiondealedcount     number := 0;

  begin
    v_request                  := json(p_request, 'OBJECT');
    v_search_content_startdate := dcld_comm_pkg.get_filter_value('startDate',
                                                                 v_request);
    v_search_content_enddate   := dcld_comm_pkg.get_filter_value('endDate',
                                                                 v_request);
    v_search_content_startdate := nvl(v_search_content_startdate,
                                      '1000-1-1');
    v_search_content_enddate   := nvl(v_search_content_enddate,
                                      '9000-12-30');

    select count(1)
      into v_exceptioncount
      from dbpm_ba_process_instance dbpi
     where dbpi.state in (5)
       and dbpi.creation_date between
           to_date(v_search_content_startdate, 'yyyy-mm-dd') and
           to_date(v_search_content_enddate, 'yyyy-mm-dd');

    select count(1)
      into v_exceptiondealedcount
      from dbpm_ba_process_instance dbpi
     where dbpi.state in (1)
       and dbpi.creation_date between
           to_date(v_search_content_startdate, 'yyyy-mm-dd') and
           to_date(v_search_content_enddate, 'yyyy-mm-dd');

    v_line.set_value('counts', v_exceptioncount);
    v_line.set_value('countsDealed', v_exceptiondealedcount);
    v_response.set_value('instancesError', v_line);
    x_response := v_response.to_json;
  end proc_plat_instanceexceptionnum;

  -----------------------------------------------------------------------------------

  procedure proc_plat_systemlist(p_request in clob, x_response out clob) is
    --获取全部系统信息
    v_request  json;
    v_response pl_json := pl_json;
    v_line     pl_json;
    v_page     number;
    v_size     number;
    v_total    number;
    /*    v_systemcode varchar(200);
    v_systemname varchar(200);*/
    /*  cursor v_platformsystem_cur is
        select max(system_code) system_code, max(system_name) system_name
          from (select nvl(db.system_code,da.system_name)system_code,
                       nvl(da.system_name, db.system_code) system_name
                  from dbpm_ba_process db, dfnd_app da
                 where db.system_code(+) = da.system_code)
         group by system_code;
    */
     v_search_content varchar2(1000);
    cursor v_platformsystem_cur is
      select *
        from (select da.system_code,
                     da.system_name,
                     count(1) over(partition by 1) total,
                     rownum rn
                from dfnd_app da
                where da.system_code like '%'||v_search_content||'%'
                or da.system_name like '%'||v_search_content||'%' )

       where rn <= v_page * v_size
         and rn > (v_page - 1) * v_size;

  begin
    v_request := json(p_request, 'OBJECT');
    v_page    := nvl(v_request.get_number('page'), 1);
    v_size    := nvl(v_request.get_number('size'), 10);
     v_search_content := dcld_comm_pkg.get_filter_value('all', v_request);

    for v_platformsystem_row in v_platformsystem_cur loop
      v_line := pl_json();
      v_line.set_value('systemCode', v_platformsystem_row.system_code);
      v_line.set_value('systemName', v_platformsystem_row.system_name);
      v_response.add_list_item('systems', v_line);
    end loop;
    --获取总条数
    select count(da.system_code) total into v_total from dfnd_app da
    where da.system_code like '%'||v_search_content||'%'
                or da.system_name like '%'||v_search_content||'%' ;
    v_response.set_value('total', v_total);
    v_response.set_value('page', v_page);

    x_response := v_response.to_json;
  end proc_plat_systemlist;

  ----------------------------------------------------------------------------------

  procedure proc_plat_processlist(p_request in clob, x_response out clob) is
    --获取全部流程信息
    v_request    json;
    v_response   pl_json := pl_json;
    v_line       pl_json;
    v_page       number;
    v_size       number;
    v_systemcode varchar(200);
     v_search_content varchar2(1000);
    -- v_total      number := 0;
    /*  cursor v_systeminproces_cur is
    select max(process_code) process_code, max(process_name) process_name
      from (select upper(t.process_code) process_code,
                   nvl(t.process_name, t.process_code) process_name
              from dbpm_ba_process t
             where upper(t.system_code) =
                 nvl(upper(v_systemcode), t.system_code))
                   --nvl(upper(v_systemcode), upper(t.system_code)))
     group by process_code;*/
    cursor v_systeminproces_cur is
      select v.*, rownum isrn
        from (select v1.*, count(1) over(partition by 1) total, rownum rn
                from (select distinct process_code,
                                      nvl(process_name, process_code) process_name
                        from dbpm_ba_process t
                       where upper(t.system_code) =
                             nvl(upper(v_systemcode), upper(t.system_code))
                              and t.process_code like '%'||v_search_content||'%'
                or t.process_name like '%'||v_search_content||'%') v1) v
       where v.rn <= v_page * v_size
         and v.rn > (v_page - 1) * v_size;

  begin
    v_request    := json(p_request, 'OBJECT');
    v_page       := nvl(v_request.get_number('page'), 1);
    v_size       := nvl(v_request.get_number('size'), 10);
    v_systemcode := dcld_comm_pkg.get_filter_value('systemCode', v_request);
     v_search_content := dcld_comm_pkg.get_filter_value('all', v_request);
    for v_systeminproces_row in v_systeminproces_cur loop
      v_line := pl_json();
      v_line.set_value('processCode', v_systeminproces_row.process_code);
      v_line.set_value('processName', v_systeminproces_row.process_name);
      if v_systeminproces_row.isrn = 1 then
        v_response.set_value('total', v_systeminproces_row.total);
      end if;
      v_response.add_list_item('systems', v_line);
    end loop;

    v_response.set_value('page', v_page);
    x_response := v_response.to_json;

  end proc_plat_processlist;

  procedure proc_plat_processnodeavgdura(p_request  in clob,
                                         x_response out clob) is
    v_request                     json;
    v_response                    pl_json := pl_json;
    v_search_content_startdateavg varchar2(200);
    v_search_content_enddateavg   varchar2(200);
    v_search_content_startdatecur varchar2(200);
    v_search_content_enddatecur   varchar2(200);
    v_search_content_processcode  varchar2(200);
    v_search_content_actcode      varchar2(200);
    v_sort                        json;
    v_sort_col                    varchar2(200);
    v_line                        pl_json;
    v_page                        number;
    v_size                        number;
    -- v_total                       number := 0;
    cursor v_processnoderunavgdura_cur is
      select vvvv.* from (
      select vvv.*,rownum rn  from (
      select vv.*, rownum isrn
        from (select process_id,
                     process_code,
                     process_name,
                     activity_code,
                     activity_name,
                     system_name,
                     system_code,
                     avgdura,
                     curdura,
                     count(1) over(partition by 1) total
                from (select v1.*, v2.curdura, rownum rn
                        from (select activity_code,
                                     max(process_id) process_id,
                                     max(system_name) system_name,
                                     max(system_code) system_code,
                                     max(process_code) process_code,
                                     max(process_name) process_name,
                                     max(activity_name) activity_name,
                                     nvl(round(avg(avgdura)), 0) avgdura
                                from (select db.process_id,
                                             dp.process_code,
                                             dp.process_name,
                                             dp.system_code,
                                             da.system_name,
                                             db.activity_code,
                                             db.activity_name,
                                             to_number(to_date(to_char(dia.end_time,
                                                                       'yyyy-mm-dd hh24:mi:ss'),
                                                               'yyyy-mm-dd hh24:mi:ss') -
                                                       to_date(to_char(dia.start_time,
                                                                       'yyyy-mm-dd hh24:mi:ss'),
                                                               'yyyy-mm-dd hh24:mi:ss')) *
                                             86400 avgdura
                                        from dbpm_ba_process_activity     db,
                                             dbpm_ba_process              dp,
                                             dfnd_app                     da,
                                             dbpm_ba_process_instance_act dia
                                       where dia.activity_code=db.activity_code(+)
                                         and db.process_code = dp.process_code(+)
                                         and dp.system_code = da.system_code(+)
                                         and dp.process_code =
                                             nvl(v_search_content_processcode,
                                                 dp.process_code)
                                         and db.creation_date between
                                             to_date(v_search_content_startdateavg,
                                                     'yyyy-mm-dd hh24:mi:ss') and
                                             to_date(v_search_content_enddateavg,
                                                     'yyyy-mm-dd hh24:mi:ss')
                                         and db.activity_code =
                                             nvl(v_search_content_actcode,
                                                 db.activity_code))
                               group by activity_code) v1,
                             (select *
                                from (select activity_code,
                                             nvl(round(avg(curdura)), 0) curdura
                                        from (select db.activity_code,
                                                     to_number(to_date(to_char(dia.end_time,
                                                                               'yyyy-mm-dd hh24:mi:ss'),
                                                                       'yyyy-mm-dd hh24:mi:ss') -
                                                               to_date(to_char(dia.start_time,
                                                                               'yyyy-mm-dd hh24:mi:ss'),
                                                                       'yyyy-mm-dd hh24:mi:ss')) *
                                                     86400 curdura
                                                from dbpm_ba_process_activity     db,
                                                     dbpm_ba_process              dp,
                                                     dfnd_app                     da,
                                                     dbpm_ba_process_instance_act dia
                                               where  dia.activity_code=db.activity_code(+)
                                                 and db.process_code = dp.process_code(+)
                                                 and dp.system_code = da.system_code(+)
                                                 and db.creation_date between
                                                     to_date(v_search_content_startdatecur,
                                                             'yyyy-mm-dd hh24:mi:ss')
                                                 and to_date(v_search_content_enddatecur,
                                                             'yyyy-mm-dd hh24:mi:ss')
                                                 and db.process_code =
                                                     nvl(v_search_content_processcode,
                                                         db.process_code))
                                       group by activity_code)) v2
                       where v1.activity_code = v2.activity_code(+)) v
               order by decode(v_sort_col,
                               'avgDura_desc',
                               v.avgdura,
                               'curDura_desc',
                               v.curdura) desc,
                        decode(v_sort_col,
                               'avgDura_asc',
                               v.avgdura,
                               'curDura_asc',
                               v.curdura) asc) vv)vvv
       where isrn <= v_page * v_size
         and isrn > (v_page - 1) * v_size)vvvv;

  begin
    v_request                     := json(p_request, 'OBJECT');
    v_search_content_startdateavg := dcld_comm_pkg.get_filter_value('startDateAvg',
                                                                    v_request);
    v_search_content_enddateavg   := dcld_comm_pkg.get_filter_value('endDateAvg',
                                                                    v_request);
    v_search_content_startdatecur := dcld_comm_pkg.get_filter_value('startDateCur',
                                                                    v_request);
    v_search_content_enddatecur   := dcld_comm_pkg.get_filter_value('endDateCur',
                                                                    v_request);
    v_search_content_processcode  := dcld_comm_pkg.get_filter_value('processCode',
                                                                    v_request);
    v_page                        := v_request.get_number('page');
    v_size                        := v_request.get_number('size');

    if v_request.exist('sort') then
      v_sort     := json(v_request.get('sort'));
      v_sort_col := v_sort.get_string('value');
      v_sort_col := v_sort_col || '_' || v_sort.get_string('order');
    end if;

    for v_processnoderunavgdura_row in v_processnoderunavgdura_cur loop
      v_line := pl_json();
      v_line.set_value('processId', v_processnoderunavgdura_row.process_id);
      v_line.set_value('processCode',
                       v_processnoderunavgdura_row.process_code);
      v_line.set_value('processName',
                       v_processnoderunavgdura_row.process_name);
      v_line.set_value('systemCode',
                       v_processnoderunavgdura_row.system_code);
      v_line.set_value('systemName',
                       v_processnoderunavgdura_row.system_name);
      v_line.set_value('actName',
                       v_processnoderunavgdura_row.activity_name);
      v_line.set_value('actCode',
                       v_processnoderunavgdura_row.activity_code);
      v_line.set_value('avgDura', v_processnoderunavgdura_row.avgdura);
      v_line.set_value('curDura', v_processnoderunavgdura_row.curdura);
      v_response.add_list_item('efficiency', v_line);
      if v_processnoderunavgdura_row.rn = 1 then
        v_response.set_value('total', v_processnoderunavgdura_row.total);
      end if;
    end loop;
    x_response := v_response.to_json;
  end proc_plat_processnodeavgdura;
  procedure proc_plat_nodelist(p_request in clob, x_response out clob) is
    v_request     json;
    v_response    pl_json := pl_json;
    v_line        pl_json;
    v_page        number;
    v_size        number;
    v_processcode varchar(200);
    --v_total       number := 0;
    --获取流程下面的所有节点
    cursor v_processinnodes_cur is
      select vv.* ,rownum isrn from (
      select v.*, rownum rn
        from (select   db.activity_code,
                   max(db.activity_name) activity_name,
                     count(1) over(partition by 1) total
                from dbpm_ba_process_activity db
               where db.process_code = v_processcode
               group by activity_code) v )vv
       where rn <= v_page * v_size
         and rn > (v_page - 1) * v_size;

  begin
    v_request     := json(p_request, 'OBJECT');
    v_processcode := dcld_comm_pkg.get_filter_value('processCode',
                                                    v_request);
    v_page        := nvl(v_request.get_number('page'), 1);
    v_size        := nvl(v_request.get_number('size'), 10);
    for v_processinnodes_row in v_processinnodes_cur loop
      v_line := pl_json();
      v_line.set_value('actCode', v_processinnodes_row.activity_code);
      v_line.set_value('actName', v_processinnodes_row.activity_name);
      if v_processinnodes_row.isrn = 1 then
        v_response.set_value('total', v_processinnodes_row.total);
      end if;
      v_response.add_list_item('systems', v_line);
    end loop;

    v_response.set_value('page', v_page);
    x_response := v_response.to_json;
  end proc_plat_nodelist;
  procedure proc_plat_processactivitavgrun(p_request  in clob,
                                           x_response out clob) is
    v_request                     json;
    v_response                    pl_json := pl_json;
    v_search_content_startdateavg varchar2(200);
    v_search_content_enddateavg   varchar2(200);
    v_search_content_startdatecur varchar2(200);
    v_search_content_enddatecur   varchar2(200);
    v_search_content_systemcode   varchar2(200);
    v_search_content_processcode  varchar2(200);
    v_search_content_activticode  varchar2(200);
    v_sort                        json;
    v_sort_col                    varchar2(200);
    v_line                        pl_json;
    v_page                        number;
    v_size                        number;
    --v_total                       number := 0;
    --获取流程审批人平均运行时间
    cursor v_activitavg_cur is
      select vvvv.* from (
      select vvv.*,rownum rn from (
      select vv.*, rownum isrn
        from (select v.*
                from (select v1.*,
                             v2.curdura,
                             count(1) over(partition by 1) total
                        from (select  approvercode,
                                     max(approvername) approvername,
                                     avg(avgdura) avgdura
                                from (select db.updatedby approvercode,
                                             de.employee_name approvername,
                                             to_number(to_date(to_char(db.end_time,
                                                                       'yyyy-mm-dd hh24:mi:ss'),
                                                               'yyyy-mm-dd hh24:mi:ss') -
                                                       to_date(to_char(db.start_time,
                                                                       'yyyy-mm-dd hh24:mi:ss'),
                                                               'yyyy-mm-dd hh24:mi:ss')) *
                                             86400 avgdura
                                        from dbpm_ba_process_instance     di,
                                             dbpm_ba_process_instance_act db,
                                             dbpm_ba_process_activity     da,
                                             dfnd_employees               de
                                       where di.process_code =
                                             da.process_code(+)
                                         and da.activity_code =
                                             db.activity_code(+)
                                         and db.updatedby =
                                             lower(de.employee_code)
                                         and db.updatedby is not null
                                         and da.creation_date between
                                             to_date(v_search_content_startdateavg,
                                                     'yyyy-mm-dd') and
                                             to_date(v_search_content_enddateavg,
                                                     'yyyy-mm-dd')
                                         and db.activity_code =
                                             v_search_content_activticode
                                         and da.process_code =
                                             v_search_content_processcode
                                         and di.system_code =v_search_content_systemcode)
                               group by approvercode) v1,
                             (select  approvercode,
                                      avg(curdura) curdura
                                from (select db.updatedby approvercode,
                                             to_number(to_date(to_char(db.end_time,
                                                                       'yyyy-mm-dd hh24:mi:ss'),
                                                               'yyyy-mm-dd hh24:mi:ss') -
                                                       to_date(to_char(db.start_time,
                                                                       'yyyy-mm-dd hh24:mi:ss'),
                                                               'yyyy-mm-dd hh24:mi:ss')) *
                                             86400 curdura
                                        from dbpm_ba_process_instance     di,
                                             dbpm_ba_process_instance_act db,
                                             dbpm_ba_process_activity     da,
                                             dfnd_employees               de
                                       where di.process_code =
                                             da.process_code(+)
                                         and da.activity_code =
                                             db.activity_code(+)
                                         and upper(db.updatedby) =
                                             upper(de.employee_code)
                                         and da.creation_date between
                                             to_date(v_search_content_startdatecur,
                                                     'yyyy-mm-dd') and
                                             to_date(v_search_content_enddatecur,
                                                     'yyyy-mm-dd')
                                         and db.updatedby is not null
                                         and db.activity_code =
                                             v_search_content_activticode
                                         and da.process_code =
                                             v_search_content_processcode
                                         and di.system_code =
                                             v_search_content_systemcode)
                               group by approvercode) v2
                       where v1.approvercode = v2.approvercode) v
               order by decode(v_sort_col,
                               'avgDura_desc',
                               v.avgdura,
                               'curDura_desc',
                               v.curdura) desc,
                        decode(v_sort_col,
                               'avgDura_asc',
                               v.avgdura,
                               'curDura_asc',
                               v.curdura) asc) vv)vvv
       where isrn <= v_page * v_size
         and isrn > (v_page - 1) * v_size)vvvv;
  begin
    v_request                     := json(p_request, 'OBJECT');
    v_search_content_startdateavg := dcld_comm_pkg.get_filter_value('startDateAvg',
                                                                    v_request);
    v_search_content_enddateavg   := dcld_comm_pkg.get_filter_value('endDateAvg',
                                                                    v_request);
    v_search_content_startdatecur := dcld_comm_pkg.get_filter_value('startDateCur',
                                                                    v_request);
    v_search_content_enddatecur   := dcld_comm_pkg.get_filter_value('endDateCur',
                                                                    v_request);
    v_search_content_systemcode   := dcld_comm_pkg.get_filter_value('systemCode',
                                                                    v_request);
    v_search_content_processcode  := dcld_comm_pkg.get_filter_value('processCode',
                                                                    v_request);
    v_search_content_activticode  := dcld_comm_pkg.get_filter_value('actCode',
                                                                    v_request);
    v_page := v_request.get_number('page');
    v_size := v_request.get_number('size');

    if v_request.exist('sort') then
      v_sort     := json(v_request.get('sort'));
      v_sort_col := v_sort.get_string('value');
      v_sort_col := v_sort_col || '_' || v_sort.get_string('order');
    end if;
    for v_activitavg_row in v_activitavg_cur loop
      v_line := pl_json();
      v_line.set_value('approverCode', v_activitavg_row.approvercode);
      v_line.set_value('approverName', v_activitavg_row.approvername);
      v_line.set_value('avgDura', v_activitavg_row.avgdura);
      v_line.set_value('curDura', v_activitavg_row.curdura);
      if v_activitavg_row.rn = 1 then
        v_response.set_value('total', v_activitavg_row.total);
      end if;
      v_response.add_list_item('efficiency', v_line);
    end loop;

    v_response.set_value('page', v_page);
    x_response := v_response.to_json;

  end proc_plat_processactivitavgrun;

  procedure proc_plat_processupandlowcount(p_request  in clob,
                                           x_response out clob) is
    v_response                 pl_json := pl_json;
    v_request                  json;
    v_search_content_startdate varchar2(200);
    v_search_content_enddate   varchar2(200);
    v_upefficiency             number;
    v_lowefficiency            number;
    v_eqefficiency             number;
   cursor v_avg_cur is  Select count(qq.aa) processCount, qq.aaa processType
  From (Select v1.process_id aa,
               (Case
                 When v1.s - v2.s > 0 Then
                  -1
                 When v1.s - v2.s = 0 Then
                  0
                 When v1.s - v2.s < 0 Then
                  1
               End) aaa
          From (Select w.process_id,
                       Avg(to_date(to_char(w.modify_date,
                                           'yyyy-mm-dd hh24-mi-ss'),
                                   'yyyy-mm-dd hh24-mi-ss') -
                           to_date(to_char(w.creation_date,
                                           'yyyy-mm-dd hh24-mi-ss'),
                                   'yyyy-mm-dd hh24-mi-ss')) * 24 * 60 * 60 s
                  From dbpm_ba_process_instance w
                 Where w.state = 5 And w.modify_date < Sysdate
                 Group By w.process_id) v1,
               (Select w.process_id,
                       Avg(to_date(to_char(w.modify_date,
                                           'yyyy-mm-dd hh24-mi-ss'),
                                   'yyyy-mm-dd hh24-mi-ss') -
                           to_date(to_char(w.creation_date,
                                           'yyyy-mm-dd hh24-mi-ss'),
                                   'yyyy-mm-dd hh24-mi-ss')) * 24 * 60 * 60 s
                  From dbpm_ba_process_instance w
                 Where w.state = 5 And
                       w.modify_date < add_months(Sysdate, -1)
                 Group By w.process_id) v2
         Where v1.process_id = v2.process_id) qq
 Group By qq.aaa;
  begin
    --获取到系统的年月份
    -- select extract(year from sysdate) into v_year from dual;
    -- select extract(month from sysdate) into v_month from dual;
    v_request                  := json(p_request, 'OBJECT');
   /* v_search_content_startdate := dcld_comm_pkg.get_filter_value('startDate',
                                                                 v_request);
    v_search_content_enddate   := dcld_comm_pkg.get_filter_value('endDate',
                                                                 v_request);
    v_search_content_enddate :=sysdate+1;
    v_search_content_startdate :=sysdate-26;

    --效率升高的流程数据
    select count(process_code)
      into v_upefficiency
      from (select max(process_code) process_code,
                   round(avg(upavgcur)) upavgcur,
                   round(avg(blavgcur)) blavgcur
              from (select t1.process_code process_code,
                           to_number(to_date(to_char(t1.modify_date,
                                                     'yyyy-mm-dd hh24:mi:ss'),
                                             'yyyy-mm-dd hh24:mi:ss') -
                                     to_date(to_char(t1.creation_date,
                                                     'yyyy-mm-dd hh24:mi:ss'),
                                             'yyyy-mm-dd hh24:mi:ss')) *
                           86400 upavgcur,
                           to_number(to_date(to_char(t2.modify_date,
                                                     'yyyy-mm-dd hh24:mi:ss'),
                                             'yyyy-mm-dd hh24:mi:ss') -
                                     to_date(to_char(t2.creation_date,
                                                     'yyyy-mm-dd hh24:mi:ss'),
                                             'yyyy-mm-dd hh24:mi:ss')) *
                           86400 blavgcur
                      from dbpm_ba_process_instance t1,
                           dbpm_ba_process_instance t2
                     where t1.process_code = t2.process_code(+)
                       and t1.state = 5
                       and t2.state = 5
                       and t1.modify_date between
                           to_date(v_search_content_startdate-30, 'yyyy-mm-dd') and
                           to_date(v_search_content_startdate, 'yyyy-mm-dd')
                       and t2.modify_date between
                           to_date(v_search_content_startdate,
                                              'yyyy-mm-dd') and
                           to_date(v_search_content_enddate,
                                              'yyyy-mm-dd'))
             group by process_code)
     where upavgcur > blavgcur;
    ---效率降低的流程数据
    select count(process_code)
      into v_lowefficiency
      from (select max(process_code) process_code,
                   round(avg(upavgcur)) upavgcur,
                   round(avg(blavgcur)) blavgcur
              from (select t1.process_code process_code,
                           to_number(to_date(to_char(t1.modify_date,
                                                     'yyyy-mm-dd hh24:mi:ss'),
                                             'yyyy-mm-dd hh24:mi:ss') -
                                     to_date(to_char(t1.creation_date,
                                                     'yyyy-mm-dd hh24:mi:ss'),
                                             'yyyy-mm-dd hh24:mi:ss')) *
                           86400 upavgcur,
                           to_number(to_date(to_char(t2.modify_date,
                                                     'yyyy-mm-dd hh24:mi:ss'),
                                             'yyyy-mm-dd hh24:mi:ss') -
                                     to_date(to_char(t2.creation_date,
                                                     'yyyy-mm-dd hh24:mi:ss'),
                                             'yyyy-mm-dd hh24:mi:ss')) *
                           86400 blavgcur
                      from dbpm_ba_process_instance t1,
                           dbpm_ba_process_instance t2
                     where t1.process_code = t2.process_code(+)
                       and t1.state = 5
                       and t2.state = 5
                       and t1.creation_date between
                           to_date(v_search_content_startdate, 'yyyy-mm-dd') and
                           to_date(v_search_content_enddate, 'yyyy-mm-dd')
                       and t2.creation_date between
                           add_months(to_date(v_search_content_startdate,
                                              'yyyy-mm-dd'),
                                      -1) and
                           add_months(to_date(v_search_content_enddate,
                                              'yyyy-mm-dd'),
                                      -1))
             group by process_code)
     where upavgcur < blavgcur;
     --效率持平
    select count(process_code)
      into v_eqefficiency
      from (select max(process_code) process_code,
                   round(avg(upavgcur)) upavgcur,
                   round(avg(blavgcur)) blavgcur
              from (select t1.process_code process_code,
                           to_number(to_date(to_char(t1.modify_date,
                                                     'yyyy-mm-dd hh24:mi:ss'),
                                             'yyyy-mm-dd hh24:mi:ss') -
                                     to_date(to_char(t1.creation_date,
                                                     'yyyy-mm-dd hh24:mi:ss'),
                                             'yyyy-mm-dd hh24:mi:ss')) *
                           86400 upavgcur,
                           to_number(to_date(to_char(t2.modify_date,
                                                     'yyyy-mm-dd hh24:mi:ss'),
                                             'yyyy-mm-dd hh24:mi:ss') -
                                     to_date(to_char(t2.creation_date,
                                                     'yyyy-mm-dd hh24:mi:ss'),
                                             'yyyy-mm-dd hh24:mi:ss')) *
                           86400 blavgcur
                      from dbpm_ba_process_instance t1,
                           dbpm_ba_process_instance t2
                     where t1.process_code = t2.process_code(+)
                       and t1.state = 5
                       and t2.state = 5
                       and t1.creation_date between
                           to_date(v_search_content_startdate, 'yyyy-mm-dd') and
                           to_date(v_search_content_enddate, 'yyyy-mm-dd')
                       and t2.creation_date between
                           add_months(to_date(v_search_content_startdate,
                                              'yyyy-mm-dd'),
                                      -1) and
                           add_months(to_date(v_search_content_enddate,
                                              'yyyy-mm-dd'),
                                      -1))
             group by process_code)
     where upavgcur = blavgcur;*/
    for v_avg in v_avg_cur loop
      if v_avg.processtype=0 then
        v_eqefficiency :=v_avg.processcount;
        elsif v_avg.processtype=-1  then
         v_upefficiency:= v_avg.processcount;
          elsif v_avg.processtype=1  then
         v_lowefficiency:= v_avg.processcount;
         end if;
      end loop;
    v_response.set_value('upefficiency', v_upefficiency);
    v_response.set_value('lowefficiency', v_lowefficiency);
    v_response.set_value('eqefficiency', v_eqefficiency);
    x_response := v_response.to_json;

  end proc_plat_processupandlowcount;
end dbpa_ba_api_pkg;

/

