create package body     DKPI_BA_SYNC_PKG is
  /*==================================================
  Procedure/Function Name :
      proc_sync_ba_apps
  Description:
      This function perform:
      同步应用信息到BA应用表
      1、soa分区信息
      2、一期客户化应用表BPM_PROCESS_APP_CONF
  Argument:
     p_last_sync_date：   上一次同步时间
  History:
      1.00  2018-01-08    Echo.Zeng
        2.00  2018-10-24  xw.yao
  ==================================================*/
  procedure proc_sync_ba_apps(p_last_sync_date in date) is
    v_last_sync_date date;
    cursor v_ba_sync_app_cur is
      select v.*
        from dbpm_ba_sync_app_v v
       where v.last_update_date > v_last_sync_date;
    v_count number;
  begin
    --如果输入的时间为空，取当前全量数据
    if p_last_sync_date is null then
      v_last_sync_date := sysdate - 1000 * 365; --默认1000年前
    else
      v_last_sync_date := p_last_sync_date;
    end if;
    --同步soa分区信息
    for v_ba_sync_app_cur_row in v_ba_sync_app_cur loop
      select count(1)
        into v_count
        from dfnd_app t
       where upper(t.system_code) = upper(v_ba_sync_app_cur_row.app_code);
      --已经存在了，更新
      if v_count > 0 then
        update dfnd_app t
           set t.system_name   = v_ba_sync_app_cur_row.app_name,
               t.system_desc   = v_ba_sync_app_cur_row.app_desc,
               t.status        = v_ba_sync_app_cur_row.status,
               t.creation_date = v_ba_sync_app_cur_row.create_date,
               t.created_by    = v_ba_sync_app_cur_row.create_by,
               t.update_date   = v_ba_sync_app_cur_row.last_update_date,
               t.updated_by    = v_ba_sync_app_cur_row.last_update_by
        --   t.partition_date = v_ba_sync_app_cur_row.last_update_date 分区关键字不可更改
         where upper(t.system_code) = upper(v_ba_sync_app_cur_row.app_code);
      else
        --不存在，新增
        insert into dfnd_app t
          (t.system_id,
           t.system_code,
           t.system_name,
           t.system_desc,
           t.status,
           t.version,
           t.creation_date,
           t.created_by,
           t.update_date,
           t.updated_by,
           t.partition_date)
        values
          (dfnd_app_s.nextval,
           v_ba_sync_app_cur_row.app_code,
           v_ba_sync_app_cur_row.app_name,
           v_ba_sync_app_cur_row.app_desc,
           v_ba_sync_app_cur_row.status,
           1,
           v_ba_sync_app_cur_row.create_date,
           v_ba_sync_app_cur_row.create_by,
           v_ba_sync_app_cur_row.last_update_date,
           v_ba_sync_app_cur_row.last_update_by,
           v_ba_sync_app_cur_row.last_update_date);
      end if;
    end loop;
    /* --插入新增系统
    insert into dfnd_app t
      (t.system_id,
       t.system_code,
       t.system_name,
       t.system_desc,
       t.status,
       t.version,
       t.creation_date,
       t.created_by,
       t.update_date,
       t.updated_by,
       t.partition_date)
      select dfnd_app_s.nextval,
             v.APP_CODE,
             v.APP_NAME,
             v.APP_DESC,
             v.STATUS,
             1,
             v.CREATE_DATE,
             v.CREATE_BY,
             sysdate,
             v.LAST_UPDATE_BY,
             sysdate
        from dbpm_ba_sync_app_new_v v;

    --where v.LAST_UPDATE_DATE > v_last_sync_date;
    --更新已经存在的 系统
    update dfnd_app da
       set (da.status,
            da.system_name,
            da.system_desc,
            da.version,
            da.update_date,
            da.updated_by) =
           (select v.STATUS,
                   v.APP_NAME,
                   v.APP_DESC,
                   v.OBJECT_VERSION_NUMBER,
                   sysdate,
                   v.LAST_UPDATE_BY
              from dbpm_ba_sync_app_update_v v
             where v.APP_CODE = da.system_code
               and v.LAST_UPDATE_DATE > v_last_sync_date)
     where exists (select 1
              from dbpm_ba_sync_app_update_v vv
             where vv.APP_CODE = da.system_code);*/

  end proc_sync_ba_apps;

  /*==================================================
  Procedure/Function Name :
      proc_sync_ba_process
  Description:
      This function perform:
      同步流程信息到BA流程表
      1、bpm官方流程表关联CUX_BPM_ALL_INSTANC表
      2、得云流程表
      3、一期配置平台流程表
  Argument:
     p_last_sync_date：   上一次同步时间
  History:
      1.00  2018-01-08    Echo.Zeng
        2.00  2018-10-24  xw.yao
  ==================================================*/
  procedure proc_sync_ba_process(p_last_sync_date in date) is
    v_last_sync_date date;
    cursor v_ba_sync_process_cur is
      select v.*
        from dbpm_ba_sync_process_v v
       where v.lastupdated > v_last_sync_date;
    v_count     number;
    v_system_id number;
  begin
    --如果输入的时间为空，取当前全量数据
    if p_last_sync_date is null then
      v_last_sync_date := sysdate - 1000 * 365; --默认1000年前
    else
      v_last_sync_date := p_last_sync_date;
    end if;
    /*  --同步流程信息
    for v_ba_sync_process_cur_row in v_ba_sync_process_cur loop
      --根据系统编号查询系统id
      select max(t.system_id)
        into v_system_id
        from dfnd_app t
       where upper(t.system_code) =
             upper(v_ba_sync_process_cur_row.system_code);
      select count(1)
        into v_count
        from dbpm_ba_process t
       where t.process_code = v_ba_sync_process_cur_row.process_code
         and t.process_version = v_ba_sync_process_cur_row.revision;
      --已经存在了，更新
      if v_count > 0 then
        update dbpm_ba_process t
           set t.domain_name    = v_ba_sync_process_cur_row.domainname,
               t.composite_name = v_ba_sync_process_cur_row.compositename,
               t.process_name   = v_ba_sync_process_cur_row.prcoess_name,
               t.system_id      = v_system_id,
               t.system_code    = v_ba_sync_process_cur_row.system_code,
               t.attribute1     = v_ba_sync_process_cur_row.bpm_process_id,
               t.update_date    = v_ba_sync_process_cur_row.lastupdated,
               t.updated_by     = v_ba_sync_process_cur_row.updated_by
        --  t.partition_date = v_ba_sync_process_cur_row.lastupdated 分区关键字不可更新
         where t.process_code = v_ba_sync_process_cur_row.process_code
           and t.process_version = v_ba_sync_process_cur_row.revision;
      else
        --不存在，新增
        insert into dbpm_ba_process t
          (t.process_id,
           t.domain_name,
           t.composite_name,
           t.process_code,
           t.process_name,
           t.system_id,
           t.system_code,
           t.process_version,
           t.version,
           t.creation_date,
           t.created_by,
           t.update_date,
           t.updated_by,
           t.partition_date,
           t.attribute1)
        values
          (dbpm_ba_process_s.nextval,
           v_ba_sync_process_cur_row.domainname,
           v_ba_sync_process_cur_row.compositename,
           v_ba_sync_process_cur_row.process_code,
           v_ba_sync_process_cur_row.prcoess_name,
           v_system_id,
           v_ba_sync_process_cur_row.system_code,
           v_ba_sync_process_cur_row.revision,
           1,
           v_ba_sync_process_cur_row.creationdate,
           v_ba_sync_process_cur_row.created_by,
           v_ba_sync_process_cur_row.lastupdated,
           v_ba_sync_process_cur_row.updated_by,
           v_ba_sync_process_cur_row.lastupdated,
           v_ba_sync_process_cur_row.bpm_process_id);
      end if;
    end loop;*/
    --插入新增的流程
    insert into dbpm_ba_process t
      (t.process_id,
       t.domain_name,
       t.composite_name,
       t.process_code,
       t.process_name,
       t.system_id,
       t.system_code,
       t.process_version,
       t.version,
       t.creation_date,
       t.created_by,
       t.update_date,
       t.updated_by,
       t.partition_date,
       t.attribute1)
      select dbpm_ba_process_s.nextval,
             dpn.DOMAINNAME,
             dpn.COMPOSITENAME,
             dpn.PROCESS_CODE,
             dpn.PRCOESS_NAME,
             (select tt.system_id
                from dfnd_app tt
               where tt.system_code = dpn.SYSTEM_CODE),
             dpn.SYSTEM_CODE,
             dpn.REVISION,
             1,
             sysdate,
             dpn.CREATED_BY,
             sysdate,
             dpn.UPDATED_BY,
             sysdate,
             dpn.BPM_PROCESS_ID
        from dbpm_ba_sync_process_new_v dpn;

    -- where nvl(dpn.LASTUPDATED, sysdate) > v_last_sync_date;
    --修改
    /*  update dbpm_ba_process t
      set (t.domain_name,
           t.composite_name,
           t.process_name,
           t.system_id,
           t.system_code,
           t.attribute1,
           t.update_date,
           t.updated_by) =
          (select v.DOMAINNAME,
                  v.COMPOSITENAME,
                  v.PRCOESS_NAME,
                  (select tt.system_id
                     from dfnd_app tt
                    where tt.system_code = v.SYSTEM_CODE),
                  v.SYSTEM_CODE,
                  v.BPM_PROCESS_ID,
                  sysdate,
                  v.UPDATED_BY
             from dbpm_ba_sync_process_update_v v
            where nvl(v.LASTUPDATED, sysdate) > v_last_sync_date
              and v.COMPOSITENAME = t.composite_name
              and v.PROCESS_CODE = t.process_code
              and v.REVISION = t.version
              and t.system_code = v.SYSTEM_CODE)
    where exists (select 1
             from dbpm_ba_sync_process_update_v vv
            where vv.COMPOSITENAME = t.composite_name
              and vv.PROCESS_CODE = t.process_code
              and vv.REVISION = t.version
              and t.system_code = vv.SYSTEM_CODE);*/
  end proc_sync_ba_process;

  /*==================================================
  Procedure/Function Name :
      proc_sync_ba_process_activity
  Description:
      This function perform:
      同步流程活动信息到BA流程活动表
      1、bpm官方活动表关联BPM_CUBE_PROCESS表
      2、得云流程节点表关联流程表
      3、一期配置平台流程节点表关联流程表
  Argument:
     p_last_sync_date：   上一次同步时间
  History:
      1.00  2018-01-08    Echo.Zeng
        2.00  2018-10-24  xw.yao
  ==================================================*/
  procedure proc_sync_ba_process_activity(p_last_sync_date in date) is
    v_last_sync_date date;
    cursor v_ba_sync_process_act_cur is
      select v.*
        from dbpm_ba_sync_process_act_v v
       where v.update_date > v_last_sync_date;
    v_count number;
  begin
    --如果输入的时间为空，取当前全量数据
    if p_last_sync_date is null then
      v_last_sync_date := sysdate - 1000 * 365; --默认1000年前
    else
      v_last_sync_date := p_last_sync_date;
    end if;
    --同步流程活动信息
    /*for v_ba_sync_process_act_cur_row in v_ba_sync_process_act_cur loop
      select count(1)
        into v_count
        from dbpm_ba_process_activity t
       where t.activity_code = v_ba_sync_process_act_cur_row.activity_code
         and t.process_id = v_ba_sync_process_act_cur_row.process_id;
      --已经存在了，更新
      if v_count > 0 then
        update dbpm_ba_process_activity t
           set t.activity_type  = v_ba_sync_process_act_cur_row.activity_type,
               t.activity_name  = v_ba_sync_process_act_cur_row.activity_name,
               t.activity_desc  = v_ba_sync_process_act_cur_row.activity_desc,
               t.order_num      = v_ba_sync_process_act_cur_row.order_num,
               t.update_date    = v_ba_sync_process_act_cur_row.update_date,
               t.update_by      = v_ba_sync_process_act_cur_row.updated_by,
               t.partition_date = v_ba_sync_process_act_cur_row.update_date,
               t.attribute1     = v_ba_sync_process_act_cur_row.bpm_act_id
         where t.activity_code =
               v_ba_sync_process_act_cur_row.activity_code
           and t.process_id = v_ba_sync_process_act_cur_row.process_id;
      else
        --不存在，新增
        insert into dbpm_ba_process_activity t
          (t.activity_id,
           t.activity_type,
           t.activity_code,
           t.activity_name,
           t.activity_desc,
           t.process_code,
           t.process_id,
           t.order_num,
           t.version,
           t.creation_date,
           t.create_by,
           t.update_date,
           t.update_by,
           t.partition_date,
           t.attribute1)
        values
          (dbpm_ba_process_activity_s.nextval,
           v_ba_sync_process_act_cur_row.activity_type,
           v_ba_sync_process_act_cur_row.activity_code,
           v_ba_sync_process_act_cur_row.activity_name,
           v_ba_sync_process_act_cur_row.activity_desc,
           v_ba_sync_process_act_cur_row.process_code,
           v_ba_sync_process_act_cur_row.process_id,
           v_ba_sync_process_act_cur_row.order_num,
           1,
           v_ba_sync_process_act_cur_row.creation_date,
           v_ba_sync_process_act_cur_row.created_by,
           v_ba_sync_process_act_cur_row.update_date,
           v_ba_sync_process_act_cur_row.updated_by,
           v_ba_sync_process_act_cur_row.update_date,
           v_ba_sync_process_act_cur_row.bpm_act_id);
      end if;
    end loop;*/

    --新增流程活动
    insert into dbpm_ba_process_activity t
      (t.activity_id,
       t.activity_type,
       t.activity_code,
       t.activity_name,
       t.activity_desc,
       t.process_code,
       t.process_id,
       t.order_num,
       t.version,
       t.creation_date,
       t.create_by,
       t.update_date,
       t.update_by,
       t.partition_date,
       t.attribute1)
      select dbpm_ba_process_activity_s.nextval,
             v.ACTIVITY_TYPe,
             v.ACTIVITY_CODE,
             v.ACTIVITY_NAME,
             v.ACTIVITY_DESC,
             v.PROCESS_CODE,
             v.PROCESS_ID,
             v.ORDER_NUM,
             1,
             sysdate,
             v.CREATED_BY,
             sysdate,
             v.UPDATED_BY,
             sysdate,
             v.BPM_ACT_ID
        from dbpm_ba_sync_process_act_new_v v;
    -- 更新
    update dbpm_ba_process_activity t
       set (t.activity_type,
            t.activity_name,
            t.activity_desc,
            t.order_num,
            t.update_date,
            t.update_by,
            t.attribute1) =
           (select v.ACTIVITY_TYPE,
                   v.ACTIVITY_NAME,
                   v.ACTIVITY_DESC,
                   v.order_num,
                   sysdate,
                   sysdate,
                   v.BPM_ACT_ID
              from dbpm_ba_sync_process_act_ud_v v
             where v.ACTIVITY_CODE = t.activity_code
               and v.PROCESS_ID = t.process_id)
     where exists (select 1
              from dbpm_ba_sync_process_act_ud_v v
             where v.ACTIVITY_CODE = t.activity_code
               and v.PROCESS_ID = t.process_id
               and v.UPDATE_DATE > t.update_date);
  end proc_sync_ba_process_activity;

  /*==================================================
  Procedure/Function Name :
      proc_sync_ba_process_instance
  Description:
      This function perform:
      同步流程实例信息到BA流程实例表
      1、得云流程的流程实例
      2、一期配置平台流程的流程实例
      3、bpm官方的流程实例（没有配置的）
  Argument:
     p_last_sync_date：   上一次同步时间
  History:
      1.00  2018-01-08    Echo.Zeng
        2.00  2018-10-24  xw.yao
  ==================================================*/
  procedure proc_sync_ba_process_instance(p_last_sync_date in date) is
    v_last_sync_date date;
    cursor v_ba_sync_process_ins_cur is
      select v.*
        from dbpm_ba_sync_process_ins_v v
       where nvl(v.modify_date, v.creation_date) > v_last_sync_date;
    v_count number;
  begin
    --如果输入的时间为空，取当前全量数据
    if p_last_sync_date is null then
      v_last_sync_date := sysdate - 1000 * 365; --默认1000年前
    else
      v_last_sync_date := p_last_sync_date;
    end if;
    --同步流程实例信息
    /*for v_ba_sync_process_ins_cur_row in v_ba_sync_process_ins_cur loop
      select count(1)
        into v_count
        from dbpm_ba_process_instance t
       where t.instance_id = v_ba_sync_process_ins_cur_row.instance_id;

      --已经存在了，更新
      if v_count > 0 then
        update dbpm_ba_process_instance t
           set t.process_id      = v_ba_sync_process_ins_cur_row.process_id,
               t.process_code    = v_ba_sync_process_ins_cur_row.Process_Code,
               t.system_code     = v_ba_sync_process_ins_cur_row.system_code,
               t.creator         = v_ba_sync_process_ins_cur_row.creator,
               t.process_form_id = v_ba_sync_process_ins_cur_row.process_form_id,
               t.state           = v_ba_sync_process_ins_cur_row.state,
               t.creation_date   = v_ba_sync_process_ins_cur_row.creation_date,
               t.modify_date     = v_ba_sync_process_ins_cur_row.modify_date,
               t.partition_date  = v_ba_sync_process_ins_cur_row.creation_date
         where t.instance_id = v_ba_sync_process_ins_cur_row.instance_id;

      else
        --不存在，新增

        insert into dbpm_ba_process_instance t
          (t.instance_id,
           t.process_id,
           t.process_code,
           t.system_code,
           t.creator,
           t.process_form_id,
           t.state,
           t.version,
           t.creation_date,
           t.modify_date,
           t.partition_date)
        values
          (v_ba_sync_process_ins_cur_row.instance_id,
           v_ba_sync_process_ins_cur_row.process_id,
           v_ba_sync_process_ins_cur_row.process_code,
           v_ba_sync_process_ins_cur_row.system_code,
           v_ba_sync_process_ins_cur_row.creator,
           v_ba_sync_process_ins_cur_row.process_form_id,
           v_ba_sync_process_ins_cur_row.state,
           1,
           v_ba_sync_process_ins_cur_row.creation_date,
           v_ba_sync_process_ins_cur_row.modify_date,
           v_ba_sync_process_ins_cur_row.creation_date);
      end if;
    end loop;*/
    --插入新增系统
    insert into dbpm_ba_process_instance t
      (t.instance_id,

       t.process_code,
       t.system_code,
       t.creator,
       t.process_form_id,
       t.state,
       t.version,
       t.creation_date,
       t.modify_date,
       t.partition_date)
      select v.INSTANCE_ID,

             v.process_code,
             v.system_code,
             v.creator,
             nvl(v.process_form_id, 'null'),
             v.state,
             1,
             sysdate,
             sysdate,
             sysdate
        from dbpm_ba_sync_process_ins_new_v v;

    update dbpm_ba_process_instance t
       set (t.state, t.creation_date, t.modify_date) =
           (select v.state, sysdate, sysdate
              from dbpm_ba_sync_process_ins_ud_v v
             where t.instance_id = v.instance_id)
     where exists (select 1
              from dbpm_ba_sync_process_ins_ud_v vv
             where vv.INSTANCE_ID = t.instance_id
               and vv.MODIFY_DATE > t.modify_date);

  end proc_sync_ba_process_instance;
  /*==================================================
  Procedure/Function Name :
      proc_sync_ba_process_ins_act
  Description:
      This function perform:
      同步流程实例活动信息到BA流程实例活动表
      1、得云流程的流程实例活动（人工节点）
      2、一期配置平台流程的流程实例活动（人工节点）
      3、bpm官方的流程实例活动（没有配置的）
  Argument:
     p_last_sync_date：   上一次同步时间
  History:
      1.00  2018-01-08    Echo.Zeng
        2.00  2018-10-24  xw.yao
  ==================================================*/
  procedure proc_sync_ba_process_ins_act(p_last_sync_date in date) is
    v_last_sync_date date;
    cursor v_ba_sync_ins_act_cur is
      select v.*
        from dbpm_ba_sync_process_ins_act_v v
       where v.start_time > v_last_sync_date;
    v_count    number;
    v_act_type dbpm_ba_process_activity.activity_type%TYPE;
  begin

    --如果输入的时间为空，取当前全量数据
    if p_last_sync_date is null then
      v_last_sync_date := sysdate - 1000 * 365; --默认1000年前
    else
      v_last_sync_date := p_last_sync_date;
    end if;
    --同步流程实例信息
    for v_ba_sync_ins_act_cur_row in v_ba_sync_ins_act_cur loop
      select t.activity_type
        into v_act_type
        from dbpm_ba_process_activity t
       where t.activity_id = v_ba_sync_ins_act_cur_row.activity_id;
      --如果是人工节点
      if v_act_type = 'USER_TASK' then
        select count(1)
          into v_count
          from dbpm_ba_process_instance_act t
         where t.instance_id = v_ba_sync_ins_act_cur_row.instance_id
           and t.activity_id = v_ba_sync_ins_act_cur_row.activity_id
           and t.task_id = v_ba_sync_ins_act_cur_row.taskid
           and t.process_id = v_ba_sync_ins_act_cur_row.process_id;
        --已经存在了，更新
        if v_count > 0 then
          update dbpm_ba_process_instance_act t
             set t.fault_type    = v_ba_sync_ins_act_cur_row.fault_type,
                 t.activity_name = v_ba_sync_ins_act_cur_row.activity_name,
                 t.updatedby     = v_ba_sync_ins_act_cur_row.updatedby,
                 t.end_time      = v_ba_sync_ins_act_cur_row.end_time
           where t.instance_id = v_ba_sync_ins_act_cur_row.instance_id
             and t.activity_id = v_ba_sync_ins_act_cur_row.activity_id
             and t.task_id = v_ba_sync_ins_act_cur_row.taskid
             and t.process_id = v_ba_sync_ins_act_cur_row.process_id;
        else
          --不存在，新增
          insert into dbpm_ba_process_instance_act t
            (t.instance_act_id,
             t.start_query_id,
             t.end_query_id,
             t.activity_id,
             t.activity_code,
             t.activity_name,
             t.fault_type,
             t.task_id,
             t.updatedby,
             t.version,
             t.instance_id,
             t.flow_id,
             t.start_time,
             t.end_time,
             t.process_id,
             t.partition_date,
             t.attribute1)
          values
            (dbpm_ba_process_instance_act_s.nextval,
             v_ba_sync_ins_act_cur_row.start_query_id,
             v_ba_sync_ins_act_cur_row.end_query_id,
             v_ba_sync_ins_act_cur_row.activity_id,
             v_ba_sync_ins_act_cur_row.activity_code,
             v_ba_sync_ins_act_cur_row.activity_name,
             v_ba_sync_ins_act_cur_row.fault_type,
             v_ba_sync_ins_act_cur_row.taskid,
             v_ba_sync_ins_act_cur_row.updatedby,
             1,
             v_ba_sync_ins_act_cur_row.instance_id,
             v_ba_sync_ins_act_cur_row.flow_id,
             v_ba_sync_ins_act_cur_row.start_time,
             v_ba_sync_ins_act_cur_row.end_time,
             v_ba_sync_ins_act_cur_row.process_id,
             v_ba_sync_ins_act_cur_row.start_time,
             v_ba_sync_ins_act_cur_row.data_source);
        end if;
      else
        --不是人工节点
        select count(1)
          into v_count
          from dbpm_ba_process_instance_act t
         where t.instance_id = v_ba_sync_ins_act_cur_row.instance_id
           and t.activity_id = v_ba_sync_ins_act_cur_row.activity_id
           and t.process_id = v_ba_sync_ins_act_cur_row.process_id;
        --已经存在了，更新
        if v_count > 0 then
          update dbpm_ba_process_instance_act t
             set t.fault_type    = v_ba_sync_ins_act_cur_row.fault_type,
                 t.activity_name = v_ba_sync_ins_act_cur_row.activity_name,
                 t.updatedby     = v_ba_sync_ins_act_cur_row.updatedby,
                 t.end_time      = v_ba_sync_ins_act_cur_row.end_time
           where t.instance_id = v_ba_sync_ins_act_cur_row.instance_id
             and t.activity_id = v_ba_sync_ins_act_cur_row.activity_id
             and t.process_id = v_ba_sync_ins_act_cur_row.process_id;
        else
          --不存在，新增
          insert into dbpm_ba_process_instance_act t
            (t.instance_act_id,
             t.start_query_id,
             t.end_query_id,
             t.activity_id,
             t.activity_code,
             t.activity_name,
             t.fault_type,
             t.task_id,
             t.updatedby,
             t.version,
             t.instance_id,
             t.flow_id,
             t.start_time,
             t.end_time,
             t.process_id,
             t.partition_date,
             t.attribute1)
          values
            (dbpm_ba_process_instance_act_s.nextval,
             v_ba_sync_ins_act_cur_row.start_query_id,
             v_ba_sync_ins_act_cur_row.end_query_id,
             v_ba_sync_ins_act_cur_row.activity_id,
             v_ba_sync_ins_act_cur_row.activity_code,
             v_ba_sync_ins_act_cur_row.activity_name,
             v_ba_sync_ins_act_cur_row.fault_type,
             v_ba_sync_ins_act_cur_row.taskid,
             v_ba_sync_ins_act_cur_row.updatedby,
             1,
             v_ba_sync_ins_act_cur_row.instance_id,
             v_ba_sync_ins_act_cur_row.flow_id,
             v_ba_sync_ins_act_cur_row.start_time,
             v_ba_sync_ins_act_cur_row.end_time,
             v_ba_sync_ins_act_cur_row.process_id,
             v_ba_sync_ins_act_cur_row.start_time,
             v_ba_sync_ins_act_cur_row.data_source);
        end if;
      end if;
      commit;
    end loop;

  end proc_sync_ba_process_ins_act;
end DKPI_BA_SYNC_PKG;

/

