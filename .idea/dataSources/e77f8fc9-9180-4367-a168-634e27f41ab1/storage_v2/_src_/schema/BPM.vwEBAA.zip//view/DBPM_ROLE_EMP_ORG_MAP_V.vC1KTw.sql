create view DBPM_ROLE_EMP_ORG_MAP_V as
SELECT dr.role_code,
       dr.role_name,
       drm.member_code,
       drmp.param_value,
       drmp.param_id,
       drmp.member_id
  FROM dbpm_role_member_params drmp,
       dbpm_role_members       drm,
       dbpm_role_params        drp,
       dbpm_roles              dr
 WHERE drmp.member_id = drm.member_id
   AND drmp.param_id = drp.param_id
   AND drm.role_id = dr.role_id
   AND drp.role_id = dr.role_id
/

