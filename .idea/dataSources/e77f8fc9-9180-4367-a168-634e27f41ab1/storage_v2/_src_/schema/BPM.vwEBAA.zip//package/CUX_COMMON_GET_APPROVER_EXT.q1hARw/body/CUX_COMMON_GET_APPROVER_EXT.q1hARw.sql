create package body cux_common_get_approver_ext is

  /*==================================================
  Procedure/Function Name :
      proc_get_manager_ext
  Description:
      This function perform:
      通过申请人查找IDM直线经理
  Argument:
     p_business_param： 流程业务参数
  History:
      1.00  2019-3-01  xiaower.yao  Creation
  ==================================================*/
  PROCEDURE proc_get_manager_ext(p_node_id        NUMBER,
                                 p_document_id    VARCHAR2,
                                 p_process_param  dbpm_process_param_rec,
                                 p_business_param dbpm_business_param_tbl,
                                 x_approvers      OUT VARCHAR2,
                                 x_result_flag    OUT VARCHAR2,
                                 x_error_msg      OUT VARCHAR2) is
    v_appliercode varchar2(200);

  begin
    -- 获取参数值
    BEGIN
      FOR i IN 1 .. p_business_param.count LOOP
        IF 'APPLYER' = p_business_param(i).paramkey THEN
          v_appliercode := p_business_param(i).paramvalue;
        END IF;
      END LOOP;
      if v_appliercode is null then
        v_appliercode := p_process_param.processApplier;
      end if;
    EXCEPTION
      WHEN no_data_found THEN
        x_result_flag := 'N';
        x_error_msg   := '查找参数异常，审批节点node_id=' || p_node_id;
        raise_application_error(-20001, x_error_msg);
        RETURN;
    END;
    BEGIN
   /*   select de.haieruserfirstlineid
        into x_approvers
        from t_idm_user de
       where upper(de.usercode) = upper(v_appliercode);*/
       null;
    EXCEPTION
      WHEN OTHERS THEN
        x_result_flag := 'N';
        x_error_msg   := '查找申请人直线经理异常，申请人v_appliercode=' || v_appliercode;
        raise_application_error(-20001,
                                '根据申请人' || v_appliercode || '查询直线经理为空！');
    END;
    IF x_approvers IS NULL THEN
      raise_application_error(-20001,
                              '根据申请人' || v_appliercode || '查询直线经理为空！');
    END IF;
  end proc_get_manager_ext;
  /*==================================================
  Procedure/Function Name :
      proc_get_sec_manager_ext
  Description:
      This function perform:
      通过申请人查找IDM二线经理
  Argument:
     p_business_param： 流程业务参数
  History:
      1.00  2019-3-01  xiaower.yao  Creation
  ==================================================*/
  PROCEDURE proc_get_sec_manager_ext(p_node_id        NUMBER,
                                     p_document_id    VARCHAR2,
                                     p_process_param  dbpm_process_param_rec,
                                     p_business_param dbpm_business_param_tbl,
                                     x_approvers      OUT VARCHAR2,
                                     x_result_flag    OUT VARCHAR2,
                                     x_error_msg      OUT VARCHAR2) is
    v_appliercode varchar2(200);
  begin
    -- 获取参数值
    BEGIN
      FOR i IN 1 .. p_business_param.count LOOP
        IF 'APPLYER' = p_business_param(i).paramkey THEN
          v_appliercode := p_business_param(i).paramvalue;
        END IF;
      END LOOP;
      if v_appliercode is null then
        v_appliercode := p_process_param.processApplier;
      end if;
    EXCEPTION
      WHEN no_data_found THEN
        x_result_flag := 'N';
        x_error_msg   := '查找参数异常，审批节点node_id=' || p_node_id;
        raise_application_error(-20001, x_error_msg);
        RETURN;
    END;
    BEGIN
     /* select de.haierusersecondlineid
        into x_approvers
        from t_idm_user de
       where upper(de.usercode) = (v_appliercode);*/
       null;
    EXCEPTION
      WHEN OTHERS THEN
        x_result_flag := 'N';
        x_error_msg   := '查找申请人二线经理异常，申请人v_appliercode=' || v_appliercode;
        raise_application_error(-20001,
                                '根据申请人' || v_appliercode || '查询二线经理为空！');
    END;
    IF x_approvers IS NULL THEN
      raise_application_error(-20001,
                              '根据申请人' || v_appliercode || '查询二线经理为空！');
    END IF;

  end proc_get_sec_manager_ext;
  /*==================================================
  Procedure/Function Name :
      proc_get_xwmaster_ext
  Description:
      This function perform:
      通过申请人查找小微自注册小微主(来源于EDW)
  Argument:
     p_business_param： 流程业务参数
  History:
      1.00  2019-3-01  xiaower.yao  Creation
  ==================================================*/
  PROCEDURE proc_get_xwmaster_ext(p_node_id        NUMBER,
                                  p_document_id    VARCHAR2,
                                  p_process_param  dbpm_process_param_rec,
                                  p_business_param dbpm_business_param_tbl,
                                  x_approvers      OUT VARCHAR2,
                                  x_result_flag    OUT VARCHAR2,
                                  x_error_msg      OUT VARCHAR2) is
    v_appliercode varchar2(200);
  begin
    -- 获取参数值
    BEGIN
      FOR i IN 1 .. p_business_param.count LOOP
        IF 'APPLYER' = p_business_param(i).paramkey THEN
          v_appliercode := p_business_param(i).paramvalue;
        END IF;
      END LOOP;
      if v_appliercode is null then
        v_appliercode := p_process_param.processApplier;
      end if;
    EXCEPTION
      WHEN no_data_found THEN
        x_result_flag := 'N';
        x_error_msg   := '查找参数异常，审批节点node_id=' || p_node_id;
        raise_application_error(-20001, x_error_msg);
        RETURN;
    END;
    BEGIN
    /*  select tf.xw_master_code
        into x_approvers
        from t_edw_xwinfo tf, t_edw_xwemp te
       where te.xw_code = tf.xwpt_code
         and te.empsn = v_appliercode;*/
         null;
    EXCEPTION
      WHEN OTHERS THEN
        x_result_flag := 'N';
        x_error_msg   := '查找申请人小微主异常，申请人v_appliercode=' || v_appliercode;
        raise_application_error(-20001,
                                '根据申请人' || v_appliercode || '查询小微主为空！');
    END;
    IF x_approvers IS NULL THEN
      raise_application_error(-20001,
                              '根据申请人' || v_appliercode || '查询小微主为空！');
    END IF;
  end proc_get_xwmaster_ext;
  /*==================================================
  Procedure/Function Name :
      proc_get_ptmaster_ext
  Description:
      This function perform:
      通过申请人查找小微自注册平台主(来源于EDW)
  Argument:
     p_business_param： 流程业务参数
  History:
      1.00  2019-3-01  xiaower.yao  Creation
  ==================================================*/
  PROCEDURE proc_get_ptmaster_ext(p_node_id        NUMBER,
                                  p_document_id    VARCHAR2,
                                  p_process_param  dbpm_process_param_rec,
                                  p_business_param dbpm_business_param_tbl,
                                  x_approvers      OUT VARCHAR2,
                                  x_result_flag    OUT VARCHAR2,
                                  x_error_msg      OUT VARCHAR2) is
    v_appliercode varchar2(200);
  begin
    -- 获取参数值
    BEGIN
      FOR i IN 1 .. p_business_param.count LOOP
        IF 'APPLYER' = p_business_param(i).paramkey THEN
          v_appliercode := p_business_param(i).paramvalue;
        END IF;
      END LOOP;
      if v_appliercode is null then
        v_appliercode := p_process_param.processApplier;
      end if;
    EXCEPTION
      WHEN no_data_found THEN
        x_result_flag := 'N';
        x_error_msg   := '查找参数异常，审批节点node_id=' || p_node_id;
        raise_application_error(-20001, x_error_msg);
        RETURN;
    END;
    BEGIN
     /* select tf.pt_master_code
        into x_approvers
        from t_edw_xwinfo tf, t_edw_xwemp te
       where te.xw_code = tf.xwpt_code
         and te.empsn = v_appliercode;*/
         null;
    EXCEPTION
      WHEN OTHERS THEN
        x_result_flag := 'N';
        x_error_msg   := '查找申请人平台主异常，申请人v_appliercode=' || v_appliercode;
        raise_application_error(-20001,
                                '根据申请人' || v_appliercode || '查询平台主为空！');
    END;
    IF x_approvers IS NULL THEN
      raise_application_error(-20001,
                              '根据申请人' || v_appliercode || '查询平台主为空！');
    END IF;
  end proc_get_ptmaster_ext;
end cux_common_get_approver_ext;

/

