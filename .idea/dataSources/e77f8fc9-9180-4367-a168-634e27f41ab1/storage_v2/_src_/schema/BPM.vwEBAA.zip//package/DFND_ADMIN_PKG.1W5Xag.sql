create package     DFND_ADMIN_PKG is

  -- Author  : liangjun.wu
  -- Created : 2017/12/4 14:42:13

  /*==================================================
  Procedure/Function Name :
      proc_get_admin_list
  Description:
      This function perform:
      获取管理员列表
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-12-04  liangjun.wu  Creation
  ==================================================*/
  procedure proc_get_admin_list(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_save_admin
  Description:
      This function perform:
      维护管理员
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-12-04  liangjun.wu  Creation
  ==================================================*/
  procedure proc_save_admin(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_delete_admin
  Description:
      This function perform:
      删除管理员
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-12-04  liangjun.wu  Creation
  ==================================================*/
  procedure proc_delete_admin(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_get_space_list
  Description:
      This function perform:
      获取空间列表
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-12-05  liangjun.wu  Creation
  ==================================================*/
  procedure proc_get_space_list(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_save_space
  Description:
      This function perform:
      维护空间
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-12-05  liangjun.wu  Creation
  ==================================================*/
  procedure proc_save_space(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_delete_space
  Description:
      This function perform:
      删除管理员
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-12-04  liangjun.wu  Creation
  ==================================================*/
  procedure proc_delete_space(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_get_space_personal
  Description:
      This function perform:
      切换空间接口
        Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-12-14  jinglun.xu  Creation
  ==================================================*/
  procedure proc_get_space_personal(p_request IN CLOB, x_response OUT CLOB);


  /*==================================================
  Procedure/Function Name :
      func_get_space_id
  Description:
      This function perform:
      查询space空间
  Argument:
     p_user_code： 员工编号
  History:
      1.00  2017-12-06  liangjun.wu  Creation
  ==================================================*/
  function func_get_space_id(p_user_code varchar2) return varchar2;
end DFND_ADMIN_PKG;

/

