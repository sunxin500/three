create package     cux_dfnd_signature_manage is

  -- Author  : XUEYOU.XU
  -- Created : 2018/3/16 13:37:46
  -- Purpose : 个性签名管理

  /*
  查询该空间下所有签名
  */
  procedure proc_get_signatures(p_request in clob, x_response out clob);

  /*
  删除签名信息及图片
  */
  procedure proc_del_signatures(p_request in clob, x_response out clob);
  /*
  上传签名
  */
  procedure proc_upload_emp_signature(v_user_code in varchar2,
                  original in blob, thumbnail in blob, space_id in varchar2,
                  var_response out varchar2, var_status out varchar2);

end cux_dfnd_signature_manage;

/

