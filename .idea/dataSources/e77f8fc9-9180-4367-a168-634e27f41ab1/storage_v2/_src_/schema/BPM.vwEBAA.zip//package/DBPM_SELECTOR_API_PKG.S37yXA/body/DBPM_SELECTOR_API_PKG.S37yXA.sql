create PACKAGE BODY     dbpm_selector_api_pkg IS

  /*==================================================
  Procedure/Function Name :
      proc_query_selector_employees
  Description:
      This function perform:
      获取人员信息
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-09-27  zhiheng.wei  Creation
  ==================================================*/
  PROCEDURE proc_query_selector_employees(p_request  CLOB,
                                          x_response OUT CLOB) IS
    v_request  json;
    v_response pl_json := pl_json;
    v_employee pl_json;
    v_count    NUMBER := 0;
    v_page     NUMBER;
    v_size     NUMBER;
    v_keyword  VARCHAR2(4000);
    CURSOR v_emp_cur IS
      SELECT *
        FROM (SELECT v.*, rownum cnt
                FROM (SELECT de.employee_code,
                             de.employee_name,
                             do.organization_name
                        FROM dfnd_employees     de,
                             dfnd_org_employees doe,
                             dfnd_organizations do
                       WHERE upper(de.employee_code) = upper(doe.employee_code)
                         AND doe.organization_id = do.organization_id
                         AND (de.employee_code LIKE '%' || v_keyword || '%' OR
                             de.employee_name LIKE '%' || v_keyword || '%' OR
                             do.organization_name LIKE
                             '%' || v_keyword || '%')) v
               WHERE rownum <= v_page * v_size)
       WHERE cnt > (v_page - 1) * v_size;
  BEGIN
    v_request := json(p_request, 'OBJECT');
    v_page    := nvl(v_request.get('page').get_number, 1);
    v_size    := nvl(v_request.get('size').get_number, 5);
    IF v_request.get('keyword') IS NOT NULL THEN
      v_keyword := v_request.get('keyword').get_string;
    END IF;

    SELECT COUNT(1)
      INTO v_count
      FROM (SELECT de.employee_code, de.employee_name, do.organization_name
              FROM dfnd_employees     de,
                   dfnd_org_employees doe,
                   dfnd_organizations do
             WHERE upper(de.employee_code) = upper(doe.employee_code)
               AND doe.organization_id = do.organization_id
               AND (de.employee_code LIKE '%' || v_keyword || '%' OR
                   de.employee_name LIKE '%' || v_keyword || '%' OR
                   do.organization_name LIKE '%' || v_keyword || '%'));

    FOR v_emp IN v_emp_cur LOOP
      v_employee := pl_json;
      v_employee.set_value('userCode', v_emp.employee_code);
      v_employee.set_value('userName', v_emp.employee_name);
      v_employee.set_value('departmentName', v_emp.organization_name);
      v_response.add_list_item('employeeList', v_employee);
    END LOOP;
    v_response.set_value('count', v_count);
    x_response := v_response.to_json;
 /* EXCEPTION
    WHEN OTHERS THEN
      v_response.fail('获取人员信息出错');
      x_response := v_response.to_json;
      RETURN;*/

  END proc_query_selector_employees;
END dbpm_selector_api_pkg;

/

