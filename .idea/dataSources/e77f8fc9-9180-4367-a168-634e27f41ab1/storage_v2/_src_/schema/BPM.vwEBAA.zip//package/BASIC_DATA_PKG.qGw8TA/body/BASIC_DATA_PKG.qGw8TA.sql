create PACKAGE BODY     "BASIC_DATA_PKG" is

  PROCEDURE proc_process_tl_correct(p_process_code IN VARCHAR2,
                                    p_locale       IN VARCHAR2) IS
    v_tl_data    VARCHAR2(2000);
    v_process_id NUMBER;
    v_count      NUMBER;
  BEGIN
    --获取流程名称国际化值
    SELECT t.lang_data
      INTO v_tl_data
      FROM cux_lang t
     WHERE t.process_code = p_process_code
       AND t.lang_code = p_locale
       AND t.using_type = '流程名';
    --获取流程id
    SELECT dp.process_id
      INTO v_process_id
      FROM dbpm_process dp
     WHERE dp.process_code = p_process_code;
    IF v_process_id IS NOT NULL AND v_tl_data IS NOT NULL THEN
      SELECT COUNT(1)
        INTO v_count
        FROM dbpm_process_tl dpt
       WHERE dpt.process_id = v_process_id
         AND dpt.locale = p_locale;
      --是否已经存在国际化值
      IF v_count > 0 THEN
        UPDATE dbpm_process_tl dpt
           SET dpt.process_name = v_tl_data, dpt.description = v_tl_data
         WHERE dpt.process_id = v_process_id
           AND dpt.locale = p_locale;
      ELSE
        INSERT INTO dbpm_process_tl
          (PROCESS_ID,
           LOCALE,
           PROCESS_NAME,
           DESCRIPTION,
           OBJECT_VERSION_NUMBER,
           CREATION_DATE,
           CREATED_BY,
           LAST_UPDATED_BY,
           LAST_UPDATE_DATE)
        VALUES
          (v_process_id,
           p_locale,
           v_tl_data,
           v_tl_data,
           1,
           SYSDATE,
           'weblogic',
           'weblogic',
           SYSDATE);

      END IF;
    END IF;
  END proc_process_tl_correct;

  PROCEDURE proc_node_tl_correct(p_process_code IN VARCHAR2,
                                 p_locale       IN VARCHAR2) IS
    CURSOR v_node_tl_cur IS
      SELECT *
        FROM dbpm_chain_node_tl_v v
       WHERE v.process_code = p_process_code;
    -- AND v.locale = 'zh_CN';
    v_count   NUMBER;
    v_tl_data VARCHAR2(2000);
  BEGIN
    --循环审批链节点
    FOR v_node_tl_cur_row IN v_node_tl_cur LOOP
      SELECT MAX(cl.lang_data)
        INTO v_tl_data
        FROM cux_lang cl
       WHERE cl.process_code = p_process_code
         AND cl.lang_code = p_locale
         AND cl.node_name = v_node_tl_cur_row.node_name
         AND cl.using_type = '节点名';
      SELECT COUNT(1)
        INTO v_count
        FROM dbpm_chain_nodes_tl t
       WHERE t.node_id = v_node_tl_cur_row.node_id
         AND t.locale = p_locale;
      IF v_count > 0 THEN
        --更新国际化值
        UPDATE dbpm_chain_nodes_tl dcnt
           SET dcnt.node_name = v_tl_data, dcnt.last_update_date = sysdate
         WHERE dcnt.node_id = v_node_tl_cur_row.node_id
           AND dcnt.locale = p_locale;
      ELSE
        --新增国际化值
        insert into DBPM_CHAIN_NODES_TL
          (NODE_ID,
           LOCALE,
           NODE_NAME,
           OBJECT_VERSION_NUMBER,
           CREATION_DATE,
           CREATED_BY,
           LAST_UPDATED_BY,
           LAST_UPDATE_DATE)
        values
          (v_node_tl_cur_row.node_id,
           p_locale,
           v_tl_data,
           1,
           sysdate,
           'weblogic',
           'weblogic',
           sysdate);
      END IF;
    END LOOP;
  END proc_node_tl_correct;
  PROCEDURE proc_node_param_correct(p_process_code IN VARCHAR2) IS
    CURSOR v_chain_node_cur IS
      SELECT *
        FROM DBPM_CHAIN_NODE_V v
       WHERE v.process_code = p_process_code;
    v_node_status VARCHAR2(2000);
    v_count       NUMBER;
  BEGIN
    FOR v_chain_node_cur_row IN v_chain_node_cur LOOP
      --查询节点对应的参数
      SELECT MAX(t.node_status)
        INTO v_node_status
        FROM cux_gems_node_status_tmp t
       WHERE t.process_code = p_process_code
         AND t.node_name = v_chain_node_cur_row.node_name;
      --是否已经配置参数
      SELECT COUNT(1)
        INTO v_count
        FROM cux_gems_node_params cgnp
       WHERE cgnp.node_id = v_chain_node_cur_row.node_id
         AND cgnp.param_key = 'step_status';
      --已经配置则更新
      IF v_count > 0 THEN
        UPDATE cux_gems_node_params t
           SET t.param_value = v_node_status
         WHERE t.node_id = v_chain_node_cur_row.node_id
           AND t.param_key = 'step_status';
      ELSE
        --没有配置则新增
        INSERT INTO CUX_GEMS_NODE_PARAMS
          (NODE_ID, PARAM_KEY, PARAM_VALUE)
        VALUES
          (v_chain_node_cur_row.node_id, 'step_status', v_node_status);
      END IF;
    END LOOP;
  END proc_node_param_correct;

  PROCEDURE proc_itl_param_correct(p_process_code IN VARCHAR2) IS
    CURSOR v_process_itl_cur IS
      SELECT t.lang_code
        FROM cux_lang t
       WHERE t.process_code = p_process_code
         AND t.using_type = '流程名';
  BEGIN
    FOR v_process_itl_cur_row IN v_process_itl_cur LOOP
      proc_process_tl_correct(p_process_code,
                              v_process_itl_cur_row.lang_code);
      proc_node_tl_correct(p_process_code, v_process_itl_cur_row.lang_code);
    END LOOP;
    proc_node_param_correct(p_process_code);
  END proc_itl_param_correct;

  PROCEDURE proc_purge_process(p_process_code IN VARCHAR2) IS
    CURSOR v_chain_node_cur(p_chain_id NUMBER) IS
      SELECT dac.chain_id, dcn.node_id
        FROM dbpm_approval_chain dac, dbpm_chain_nodes dcn
       WHERE dac.chain_id = dcn.chain_id
         AND dac.chain_id = p_chain_id;
    CURSOR v_chain_cur(p_process_id NUMBER) IS
      SELECT dp.process_id, dp.process_code, dac.chain_id
        FROM dbpm_process dp, dbpm_approval_chain dac
       WHERE dp.process_id = dac.process_id
         AND dp.process_id = p_process_id;
    v_node_role_id NUMBER;
    CURSOR v_process_node_cur IS
      SELECT dp.process_id, t.node_id
        FROM dbpm_process_nodes t, dbpm_process dp
       WHERE t.process_id = dp.process_id
         AND dp.process_code = p_process_code;
    CURSOR v_procss_cur IS
      SELECT dp.process_id
        FROM dbpm_process dp
       WHERE dp.process_code = p_process_code;
  BEGIN
    --多条流程
    FOR v_procss_cur_row IN v_procss_cur LOOP
      --清除审批链数据
      FOR v_chain_cur_row IN v_chain_cur(v_procss_cur_row.process_id) LOOP
        FOR v_chain_node_cur_row IN v_chain_node_cur(v_chain_cur_row.chain_id) LOOP
          --清除审批链节点国际化
          DELETE FROM dbpm_chain_nodes_tl t
           WHERE t.node_id = v_chain_node_cur_row.node_id;
          --清除审批链节点角色参数
          SELECT MAX(t.node_role_id)
            INTO v_node_role_id
            FROM dbpm_node_roles t
           WHERE t.node_id = v_chain_node_cur_row.node_id
             AND t.node_from_type = 'ChainNode';
          DELETE FROM dbpm_node_role_param_value t
           WHERE t.node_role_id = v_node_role_id;
          --清除审批链节点角色
          DELETE FROM dbpm_node_roles t
           WHERE t.node_role_id = v_node_role_id;
          --清除审批链节点
          DELETE FROM dbpm_chain_nodes t
           WHERE t.node_id = v_chain_node_cur_row.node_id;
        END LOOP;
        --审批链规则
        DELETE FROM dbpm_chain_rules t
         WHERE t.chain_id = v_chain_cur_row.chain_id;
        DELETE FROM dbpm_approval_chain t
         WHERE t.chain_id = v_chain_cur_row.chain_id;
      END LOOP;
      --清除流程节点
      FOR v_process_node_cur_row IN v_process_node_cur LOOP
        --清除流程节点国际化
        DELETE FROM dbpm_process_nodes_tl t
         WHERE t.node_id = v_process_node_cur_row.node_id;
        --清除流程节点角色参数
        SELECT MAX(t.node_role_id)
          INTO v_node_role_id
          FROM dbpm_node_roles t
         WHERE t.node_id = v_process_node_cur_row.node_id
           AND t.node_from_type = 'ProcessNode';
        --清除流程节点状态
        delete from dbpm_nodes_businessdata dnb
         where dnb.node_id = v_process_node_cur_row.node_id;
        ---清除流程节点绑定邮件
        delete from dbpm_nodes_email_map dmp
         where dmp.node_id = v_process_node_cur_row.node_id;
        --清除流程节点绑定服务
        delete from dbpm_nodes_service_map dsm
         where dsm.node_id = v_process_node_cur_row.node_id;
        DELETE FROM dbpm_node_role_param_value t
         WHERE t.node_role_id = v_node_role_id;
        --清除流程节点角色
        DELETE FROM dbpm_node_roles t
         WHERE t.node_role_id = v_node_role_id;
        --清除流程节点
        DELETE FROM dbpm_process_nodes t
         WHERE t.node_id = v_process_node_cur_row.node_id;
      END LOOP;
      --清除流程参数
      DELETE FROM dbpm_process_params t
       WHERE t.process_id = v_procss_cur_row.process_id;
      --清除流程国际化
      delete from dbpm_process_tl t
       WHERE t.process_id = v_procss_cur_row.process_id;
      --清除流程
      DELETE FROM dbpm_process t
       WHERE t.process_id = v_procss_cur_row.process_id;
      -- 清除流程绑定邮件
      delete from dbpm_process_email_map t
       where t.process_id = v_procss_cur_row.process_id;
      --清除流程绑定服务
      delete from dbpm_process_service_map t
       where t.process_id = v_procss_cur_row.process_id;
      --清除动态找人表
      DELETE FROM dbpm_dynamic_approvers t
       where t.node_id in

             (select dpn.node_id
                from dbpm_process_nodes dpn
               where dpn.process_id = v_procss_cur_row.process_id
              union
              select dcn.node_id
                from dbpm_approval_chain dac, dbpm_chain_nodes dcn
               where dac.chain_id = dcn.chain_id
                 and dac.process_id = v_procss_cur_row.process_id);
      --清除特殊规则配置表
      DELETE FROM cux_bpm_common_rule t
       where t.node_id in
             (select dpn.node_id
                from dbpm_process_nodes dpn
               where dpn.process_id = v_procss_cur_row.process_id
              union
              select dcn.node_id
                from dbpm_approval_chain dac, dbpm_chain_nodes dcn
               where dac.chain_id = dcn.chain_id
                 and dac.process_id = v_procss_cur_row.process_id);
    END LOOP;
    --清除中间表配置
    delete from cux_lang t where t.process_code = p_process_code;
    delete from cux_gems_node_status_tmp t
     where t.process_code = p_process_code;
  END proc_purge_process;

  --同步流程迁移信息

  ---绑定关系，审批链节点和流程节点绑定关系
  PROCEDURE proc_processNode_map_chainnode is

    cursor v_chain_node_cur(p_processid number) is
      select dn.node_id, dn.parent_id, dn.node_name
        from dbpm_approval_chain t, dbpm_chain_nodes dn
       where t.chain_id = dn.chain_id
         and t.process_id = p_processid;
    cursor v_process_node_cur(p_processid number) is

      select dn.node_id, dn.node_name
        from dbpm_process_nodes dn
       where dn.process_id = p_processid;
    v_process_id number;
    cursor v_process_cur is
      select * from dbpm_process t;
  begin

    for v_process in v_process_cur loop
      v_process_id := v_process.process_id;
      for v_chain_node in v_chain_node_cur(v_process_id) loop

        for v_process_node in v_process_node_cur(v_process_id) loop
          if v_chain_node.node_name = v_process_node.node_name then
            update dbpm_chain_nodes dns
               set dns.parent_id = v_process_node.node_id
             where dns.node_id = v_chain_node.node_id
               and dns.parent_id is null;
          end if;
        end loop;
      end loop;
    end loop;
  end proc_processNode_map_chainnode;

  PROCEDURE proc_sync_node_status is
    cursor v_node_status_cur is
      select dn.*
        from cux_gems_node_params dn, dbpm_chain_nodes cp
       where cp.node_id = dn.node_id;

    v_node_id   number;
    v_busine_id number;
    v_count     number;
  begin
    for v_params in v_node_status_cur loop
      select dn.parent_id
        into v_node_id
        from dbpm_chain_nodes dn
       where dn.node_id = v_params.node_id;
      select count(1)
        into v_count
        from dbpm_nodes_businessdata y
       where y.node_id = v_node_id
         and y.business_code = 'STEP_STATUS';
      if v_count = 0 and v_node_id is not null then
        insert into dbpm_nodes_businessdata
          (id,
           node_id,
           business_code,
           business_name,
           business_content,
           creation_date,
           created_by,
           last_updated_by,
           last_update_date)
        values
          (dbpm_nodes_businessdata_s.nextval,
           v_node_id,
           'STEP_STATUS',
           '节点状态',
           v_params.param_value,
           sysdate,
           'A0023610',
           'A0023610',
           sysdate);
      end if;
    end loop;
    null;
  end proc_sync_node_status;

  PROCEDURE proc_sync_node_itl is
    cursor v_node_itl is
      select d.*, dn.parent_id
        from dbpm_chain_nodes_tl d, dbpm_chain_nodes dn
       where dn.node_id = d.node_id
         and dn.parent_id is not null;
    v_count number;
  begin
    for v_it in v_node_itl loop
      select count(1)
        into v_count
        from dbpm_process_nodes_tl t
       where t.node_id = v_it.parent_id
         and t.locale = v_it.locale;
      --  and t.node_name=v_it.node_name;
      if v_count = 0 then
        insert into dbpm_process_nodes_tl
          (node_id,
           locale,
           node_name,
           creation_date,
           created_by,
           last_updated_by,
           last_update_date)
        values
          (v_it.parent_id,
           v_it.locale,
           v_it.node_name,
           sysdate,
           'A0023610',
           'A0023610',
           sysdate);
      end if;
    end loop;
    null;
  end proc_sync_node_itl;

  --复制审批链规则
  PROCEDURE proc_sync_chain_rule is
    v_chain_id number := 24021;
    cursor v_cur_rules is
      select * from dbpm_chain_rules t where t.chain_id = 23565;
  begin
    delete from dbpm_chain_rules t where t.chain_id = v_chain_id;
    for v_cur in v_cur_rules loop
      if v_cur.param_name = 'DEPARTMENTS' then
        insert into dbpm_chain_rules
          (rule_id,
           chain_id,
           param_name,
           param_meaning,
           param_type,
           operation_type,
           param_value,
           object_version_number,
           last_updated_by,
           creation_date,
           created_by,
           last_update_date,
           get_value_type,
           rule_uuid)
        values
          (dbpm_chain_rules_s.nextval,
           v_chain_id,
           v_cur.param_name,
           v_cur.param_meaning,
           v_cur.param_type,
           'IN',
           '0N30003',
           1,
           'A0023610',
           sysdate,
           'A0023610',
           sysdate,
           v_cur.get_value_type,
           v_cur.rule_uuid);
      else
        insert into dbpm_chain_rules
          (rule_id,
           chain_id,
           param_name,
           param_meaning,
           param_type,
           operation_type,
           param_value,
           object_version_number,
           last_updated_by,
           creation_date,
           created_by,
           last_update_date,
           get_value_type,
           rule_uuid)
        values
          (dbpm_chain_rules_s.nextval,
           v_chain_id,
           v_cur.param_name,
           v_cur.param_meaning,
           v_cur.param_type,
           v_cur.operation_type,
           v_cur.param_value,
           1,
           'A0023610',
           sysdate,
           'A0023610',
           sysdate,
           v_cur.get_value_type,
           v_cur.rule_uuid);

      end if;
    end loop;
  end proc_sync_chain_rule;

end BASIC_DATA_PKG;

/

