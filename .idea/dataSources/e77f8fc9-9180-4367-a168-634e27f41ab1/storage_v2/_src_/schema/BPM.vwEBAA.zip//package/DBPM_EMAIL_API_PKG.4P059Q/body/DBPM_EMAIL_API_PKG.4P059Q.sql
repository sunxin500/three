create PACKAGE BODY     "DBPM_EMAIL_API_PKG" is

  /*==================================================
  Procedure/Function Name :
      proc_get_data_set
  Description:
      This function perform:
       获取流程信息和单据信息
  Argument:
     p_document_id： 单据号
     x_single_line_cursor： 单行的cursor
     x_muti_line_cursor :  多行的cursor
  History:
      1.00  2018-05-10  wlj  Creation
  ==================================================*/
  PROCEDURE proc_get_data_set(p_instance_id        varchar2,
                              p_task_id            varchar2,
                              p_outcome            varchar2,
                              p_locale             varchar2,
                              p_process_param      dbpm_process_param_rec,
                              p_sql                varchar2,
                              x_single_line_cursor out sys_refcursor,
                              x_muti_line_cursor   out sys_refcursor) AS
    v_sql    varchar2(30000);
    v_doc_id number;
  BEGIN
    --获取单据号
    select d.document_id
      into v_doc_id
      from dbpm_documents d
     where d.bpm_instance_id = p_instance_id;

    if p_sql is null then
      open x_single_line_cursor for
        select d.document_id,
               d.doc_number,
               d.title,
               d.doc_creator,
               d.doc_creator_name,
               d.doc_create_time,
               d.status,
               d.organization_id,
               d.process_id,
               d.form_id,
               '模拟供应商' VENDORNAME,
               '9999' AMOUNT,
               --'6666' CURRENCY,
               '模拟业务类型' BUSINESSTYPE
          from dbpm_documents d
         where d.document_id = v_doc_id
           and rownum = 1;

      open x_muti_line_cursor for
        select 'custom_key' custom_key, 'custom_value' custom_value
          from dual;
    else
      open x_muti_line_cursor for p_sql;
      open x_single_line_cursor for p_sql;
    end if;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;

  /*==================================================
  Procedure/Function Name :
      proc_get_email_template
  Description:
      This function perform:
       获取邮件模板
  Argument:
     p_document_id： 表单ID
     p_task_id： 待办ID
     p_outcome : 邮件的类型（待办提醒邮件/拒绝邮件/完成邮件等）
     p_process_param ：流程参数
     p_business_param ：业务参数
  History:
      1.00  2018-05-23  wlj  Creation
  ==================================================*/
  PROCEDURE proc_get_email_template(p_instance_id   varchar2,
                                    p_task_id       varchar2,
                                    p_outcome       varchar2,
                                    p_locale        varchar2,
                                    p_process_param dbpm_process_param_rec,
                                    x_email_title   OUT CLOB,
                                    x_email_body    OUT CLOB,
                                    x_result_flag   OUT VARCHAR2,
                                    x_error_msg     OUT VARCHAR2) AS
    v_process_id number;
    v_nodeid     number;
    v_doc_id     number;
    v_is_find    varchar2(10) := 'Y';
    v_locale     varchar2(20) := nvl(p_locale, 'zh');
  BEGIN
    --根据taskId获取节点
    begin
      select wf.protectednumberattribute1
        into v_nodeid
        from wftask wf
       where wf.taskid = p_task_id;
    exception
      when no_data_found then
        v_nodeid := null;
    end;

    --获取单据id
    begin
      select d.document_id
        into v_doc_id
        from dbpm_documents d
       where d.bpm_instance_id = p_instance_id;
    exception
      when others then
        v_doc_id := null;
    end;

    --获取流程的ID
    --如果根据单据id找到流程则使用该流程
    begin
      SELECT D.PROCESS_ID
        INTO v_process_id
        FROM DBPM_DOCUMENTS D
       WHERE D.DOCUMENT_ID = v_doc_id;
    exception
      when others then
        v_process_id := null;
    end;

    --如果未找到，则根据task_id找到节点id，通过节点id找到流程
    if v_process_id is null then
      begin
        SELECT AC.PROCESS_ID
          INTO v_process_id
          FROM DBPM_CHAIN_NODES CN, DBPM_APPROVAL_CHAIN AC
         WHERE CN.NODE_ID = v_nodeid
           AND CN.CHAIN_ID = AC.CHAIN_ID;
      exception
        when no_data_found then
          v_process_id := null;
      end;
    end if;

    --如果未找到，则通过process_param获取流程编码找，找流程
    if v_process_id is null then
      begin
        select dp.process_id
          into v_process_id
          from dbpm_process dp
         where dp.process_code = p_process_param.processCode;
      exception
        when others then
          v_process_id := null;
      end;
    end if;

    --仍未找到，则报错
    if v_process_id is null then
      x_result_flag := 'N';
      x_error_msg   := '流程查找失败';
      return;
    end if;

    --根据节点，流程和邮件种类来获取邮件模板
    begin
      select et.email_subject, et.email_content
        into x_email_title, x_email_body
        from dbpm_process_email_template et
       where et.process_id = v_process_id
         and nvl(et.node_id, 0) = nvl(v_nodeid, 0)
         and et.email_catalog = p_outcome
         and et.locale = v_locale
         and et.enabled_flag = 'Y'
         and rownum = 1;
      v_is_find := 'Y';
    exception
      when others then
        v_is_find := 'N';
    end;
    --如果没找到，则再通过流程和邮件种类获取邮件模板
    begin
      select et.email_subject, et.email_content
        into x_email_title, x_email_body
        from dbpm_process_email_template et
       where et.process_id = v_process_id
         and et.email_catalog = p_outcome
         and et.locale = v_locale
         and et.enabled_flag = 'Y'
         and rownum = 1;
      v_is_find := 'Y';
    exception
      when others then
        v_is_find := 'N';
    end;
    --仍未找到，则报错
    if v_is_find = 'N' then
      x_result_flag := 'N';
      x_error_msg   := '邮件模板获取失败';
      return;
    end if;

    --获取默认的邮件模板
    --TODO
  END;
  /*==================================================
  Procedure/Function Name :
      proc_save_email
  Description:
      This function perform:
      保存邮件模板
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2019-02-25  yxw  Creation
  ==================================================*/
  procedure proc_save_email(p_request in clob, x_response out clob) is
    v_subject_clob clob;
    v_content_clob clob;
    v_request      json;
    v_response     pl_json := pl_json;
    v_email_id     number;
    v_email_type   varchar2(100);
    v_locale       varchar2(100);
    v_enable       varchar2(100);
    v_email_name   varchar2(100);

  begin
    v_request    := json(p_request, 'OBJECT');
    v_email_id   := v_request.get_number('emailId');
    v_email_type := v_request.get_string('emailType');
    v_enable     := v_request.get_string('enable');
    v_locale     := v_request.get_string('locale');
    v_email_name := v_request.get_string('emailName');
    IF v_request.path('subject') IS NOT NULL THEN
      dbms_lob.createtemporary(v_subject_clob, false);
      json(v_request.get('subject')).to_clob(v_subject_clob);
    END IF;
    IF v_request.path('content') IS NOT NULL THEN
      dbms_lob.createtemporary(v_content_clob, false);
      json(v_request.get('content')).to_clob(v_content_clob);
    END IF;
    if v_email_id is not null then
      update dbpm_email_teamplate dt
         set dt.email_catalog         = v_email_type,
             dt.email_content         = v_content_clob,
             dt.enabled_flag          = v_enable,
             dt.last_updated_by       = v_request.username,
             dt.last_update_date      = sysdate,
             dt.object_version_number = dt.object_version_number + 1,
             dt.email_name            = v_email_name
       where dt.id = v_email_id;
    else
      v_email_id :=dbpm_email_teamplate_s.nextval;
      insert into dbpm_email_teamplate
        (id,
         email_catalog,
         email_content,
         enabled_flag,
         object_version_number,
         creation_date,
         created_by,
         last_updated_by,
         last_update_date,
         email_name)
      values
        (v_email_id,
         v_email_type,
         v_content_clob,
         v_enable,
         1,
         sysdate,
         v_request.username,
         v_request.username,
         sysdate,
         v_email_name);
    end if;
    v_response.set_value('emailId',v_email_id);
    x_response := v_response.to_json;
  end proc_save_email;
  /*==================================================
  Procedure/Function Name :
      proc_query_email
  Description:
      This function perform:
      查询邮件模板
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2019-02-25  yxw  Creation
  ==================================================*/
  procedure proc_query_email(p_request in clob, x_response out clob) is
    v_enable   varchar2(100);
    v_page     number;
    v_size     number;
    v_email_id number;
    cursor v_email_cur is
      select *
        from (select v.*, rownum cnt
                from (select count(1) over(partition by 1) total,
                             dt.id,
                             dt.email_name,
                             dt.email_catalog,
                             dt.email_content,
                             dt.created_by,
                             dt.enabled_flag,
                             dt.creation_date

                        from dbpm_email_teamplate dt
                       where dt.deleted_flag = 'N'
                         and instr(nvl(dt.enabled_flag, 'NL'),
                                   nvl(v_enable, nvl(dt.enabled_flag, 'NL'))) > 0
                         and nvl(v_email_id, dt.id) = dt.id
                       order by dt.last_update_date desc) v
               where rownum <= v_page * v_size)
       where cnt > (v_page - 1) * v_size;
    v_request      json;
    v_response     pl_json := pl_json;
    v_line         pl_json;
    v_email_clob   clob;
    v_createByName varchar2(100);
  begin
    v_request := json(p_request, 'OBJECT');
    v_page    := nvl(v_request.get_number('page'), 1);
    v_size    := nvl(v_request.get_number('size'), 20);
    --  v_enable   := v_request.get_string('enable');
    v_email_id := v_request.get_number('emailId');
    for v_row in v_email_cur loop
      v_response.set_value('total', v_row.total);
      v_line := pl_json;
      select de.english_name
        into v_createByName
        from dfnd_employees de
       where upper(de.employee_code) = upper(v_row.created_by);
      v_line.set_value('emailType', v_row.email_catalog);
      v_line.set_value('emailId', v_row.id);
      v_line.set_value('emailName', v_row.email_name);
      v_line.set_value('content', json(v_row.email_content));
      v_line.set_value('enable', v_row.enabled_flag);
      v_line.set_value('createdBy', v_row.created_by);
      v_line.set_value('createdByName', v_createByName);
      v_line.set_value('createDate',to_char( v_row.creation_date,'yyyy-mm-dd'));
      v_response.add_list_item('emails', v_line);
    end loop;

    x_response := v_response.to_json;
  end proc_query_email;
  /*==================================================
  Procedure/Function Name :
      proc_del_email
  Description:
      This function perform:
      删除邮件模板（逻辑删除）
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2019-02-21  yxw  Creation
  ==================================================*/
  procedure proc_del_email(p_request in clob, x_response out clob) is
    v_request  json;
    v_ids      json_list;
    v_id       json := json;
    v_response pl_json := pl_json;
  begin
    v_request := json(p_request, 'OBJECT');

    v_ids := json_list(v_request.get('emailIds'));
    for i in 1 .. v_ids.count loop
      v_id := json(v_ids.get(i));
      update dbpm_email_teamplate ds
         set ds.deleted_flag = 'Y'
       where ds.id = v_id.get_number('emailId');
    end loop;
    x_response := v_response.to_json;
  end proc_del_email;

end DBPM_EMAIL_API_PKG;

/

