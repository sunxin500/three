create view DBPM_TASK_READ_QUERY_V as
SELECT
       dd.document_id,
       dd.doc_number,
       dd.form_id,
       dd.process_id,
       --dd.doc_number || '' task_number,
       dd.doc_number task_number,
       dd.title,
       --dd.status,
       dd.status,
       dpt.process_name,
       dp.process_code,
       dp.process_type,
       dd.doc_create_time creation_date,
       dd.doc_creator created_user_code,
       FE1.EMPLOYEE_NAME created_user_name
  FROM
  dbpm_process dp, dbpm_process_tl dpt,dbpm_documents dd,dfnd_employees fe1
 WHERE DD.process_code = dp.process_code
   AND dp.process_id = dpt.process_id
   AND DD.DOC_CREATOR = FE1.EMPLOYEE_CODE
   AND dpt.locale = dbpm_comm_pkg.get_current_locale

/

