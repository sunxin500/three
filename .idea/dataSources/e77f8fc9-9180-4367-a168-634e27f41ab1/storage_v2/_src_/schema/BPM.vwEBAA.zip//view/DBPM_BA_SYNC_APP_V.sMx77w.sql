create view DBPM_BA_SYNC_APP_V as
select t.space_code system_code,
       t.space_name  system_name,
       t.space_description system_desc,
       decode(t.space_code,'DF','N','Y') status,
       t.object_version_number,
       t.created_by create_by,
       t.creation_date create_date,
       t.last_updated_by last_update_by,
       t.last_update_date last_update_date
  from dbpm_spaces t
/

