create package     BASIC_DATA_PKG is
  PROCEDURE proc_process_tl_correct(p_process_code IN VARCHAR2,
                                    p_locale       IN VARCHAR2);

  PROCEDURE proc_node_tl_correct(p_process_code IN VARCHAR2,
                                 p_locale       IN VARCHAR2);
  PROCEDURE proc_node_param_correct(p_process_code IN VARCHAR2);

  PROCEDURE proc_itl_param_correct(p_process_code IN VARCHAR2);

  PROCEDURE proc_purge_process(p_process_code IN VARCHAR2);

  ---绑定关系，审批链节点和流程节点绑定关系
  PROCEDURE proc_processNode_map_chainnode;

   PROCEDURE proc_sync_node_status;

    ---同步节点国际化值到标准表
  PROCEDURE proc_sync_node_itl;

  --复制审批链规则
   PROCEDURE proc_sync_chain_rule;

end BASIC_DATA_PKG;

/

