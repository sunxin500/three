create PACKAGE BODY     "DBPA_BA_SYNC_PKG" is
  /*==================================================
  Procedure/Function Name :
      proc_sync_ba_apps
  Description:
      This function perform:
      同步应用信息到BA应用表
      1、soa分区信息
      2、一期客户化应用表BPM_PROCESS_APP_CONF
  Argument:
     p_last_sync_date：   上一次同步时间
  History:
      1.00  2018-01-08    Echo.Zeng
      updated by xiaowei.yao : 2019-04-23 09:50:00
  ==================================================*/
  procedure proc_sync_ba_apps(p_last_sync_date in date) is
    v_last_sync_date date;
    cursor v_ba_sync_app_cur is
      select v.*
        from dbpm_ba_sync_app_v v
       where v.last_update_date > v_last_sync_date;
    v_count number;
  begin

    --如果输入的时间为空，取当前全量数据
    if p_last_sync_date is null then
      v_last_sync_date := sysdate - 1000 * 365; --默认1000年前
    else
      v_last_sync_date := p_last_sync_date;
    end if;
    --同步soa分区信息
    for v_ba_sync_app_cur_row in v_ba_sync_app_cur loop
      select count(1)
        into v_count
        from dfnd_app t
       where t.system_code = v_ba_sync_app_cur_row.system_code;
      --已经存在了，更新
      if v_count > 0 then
        update dfnd_app t
           set t.system_name   = v_ba_sync_app_cur_row.system_name,
               t.system_desc   = v_ba_sync_app_cur_row.system_desc,
               t.status        = v_ba_sync_app_cur_row.status,
               t.creation_date = v_ba_sync_app_cur_row.create_date,
               t.created_by    = v_ba_sync_app_cur_row.create_by,
               t.update_date   = v_ba_sync_app_cur_row.last_update_date,
               t.updated_by    = v_ba_sync_app_cur_row.last_update_by
         where t.system_code = v_ba_sync_app_cur_row.system_code;
      else
        --不存在，新增
        insert into dfnd_app t
          (t.system_id,
           t.system_code,
           t.system_name,
           t.system_desc,
           t.status,
           t.version,
           t.creation_date,
           t.created_by,
           t.update_date,
           t.updated_by,
           t.partition_date)
        values
          (dfnd_app_s.nextval,
           v_ba_sync_app_cur_row.system_code,
           v_ba_sync_app_cur_row.system_name,
           v_ba_sync_app_cur_row.system_desc,
           v_ba_sync_app_cur_row.status,
           1,
           v_ba_sync_app_cur_row.create_date,
           v_ba_sync_app_cur_row.create_by,
           v_ba_sync_app_cur_row.last_update_date,
           v_ba_sync_app_cur_row.last_update_by,
           v_ba_sync_app_cur_row.last_update_date);
      end if;

    end loop;

  end proc_sync_ba_apps;

  /*==================================================
  Procedure/Function Name :
      proc_sync_ba_process
  Description:
      This function perform:
      同步流程信息到BA流程表
      1、bpm官方流程表关联CUX_BPM_ALL_INSTANC表
      2、得云流程表
      3、一期配置平台流程表
  Argument:
     p_last_sync_date：   上一次同步时间
  History:
      1.00  2018-01-08    Echo.Zeng
      updated by xiaowei.yao : 2019-04-23 09:50:00
  ==================================================*/
  procedure proc_sync_ba_process(p_last_sync_date in date) is
    v_last_sync_date date;
    cursor v_ba_sync_process_cur is
      select v.*
        from dbpm_ba_sync_process_v v
       where v.lastupdated > v_last_sync_date;
    v_count     number;
    v_system_id number;
  begin

    --如果输入的时间为空，取当前全量数据
    if p_last_sync_date is null then
      v_last_sync_date := sysdate - 1000 * 365; --默认1000年前
    else
      v_last_sync_date := p_last_sync_date;
    end if;
    --同步流程信息
    for v_ba_sync_process_cur_row in v_ba_sync_process_cur loop
      --根据系统编号查询系统id
      select t.system_id
        into v_system_id
        from dfnd_app t
       where t.system_code = v_ba_sync_process_cur_row.system_code;
      select count(1)
        into v_count
        from dbpm_ba_process t
       where t.process_code = v_ba_sync_process_cur_row.process_code;
      --  and t.process_version = v_ba_sync_process_cur_row.revision;
      --已经存在了，更新
      if v_count > 0 then
        update dbpm_ba_process t
           set t.update_date = v_ba_sync_process_cur_row.lastupdated
         where t.process_code = v_ba_sync_process_cur_row.process_code;

      else
        --不存在，新增
        insert into dbpm_ba_process t
          (t.process_id,
           t.domain_name,
           t.composite_name,
           t.process_code,
           t.process_name,
           t.system_id,
           t.system_code,
           t.process_version,
           t.version,
           t.creation_date,
           t.created_by,
           t.update_date,
           t.updated_by,
           t.partition_date,
           t.attribute1)
        values
          (dbpm_ba_process_s.nextval,
           v_ba_sync_process_cur_row.domainname,
           v_ba_sync_process_cur_row.compositename,
           v_ba_sync_process_cur_row.process_code,
           v_ba_sync_process_cur_row.prcoess_name,
           v_system_id,
           v_ba_sync_process_cur_row.system_code,
           v_ba_sync_process_cur_row.revision,
           1,
           v_ba_sync_process_cur_row.creationdate,
           v_ba_sync_process_cur_row.created_by,
           v_ba_sync_process_cur_row.lastupdated,
           v_ba_sync_process_cur_row.updated_by,
           v_ba_sync_process_cur_row.lastupdated,
           v_ba_sync_process_cur_row.bpm_process_id);
      end if;
      -- commit;

    end loop;

  end proc_sync_ba_process;

  /*==================================================
  Procedure/Function Name :
      proc_sync_ba_process_activity
  Description:
      This function perform:
      同步流程活动信息到BA流程活动表
      1、bpm官方活动表关联BPM_CUBE_PROCESS表
      2、得云流程节点表关联流程表
      3、一期配置平台流程节点表关联流程表
  Argument:
     p_last_sync_date：   上一次同步时间
  History:
      1.00  2018-01-08    Echo.Zeng
      updated by xiaowei.yao : 2019-04-23 09:50:00
  ==================================================*/
  procedure proc_sync_ba_process_activity(p_last_sync_date in date) is
    v_last_sync_date date;
    cursor v_ba_sync_process_act_cur is
      select v.*
        from dbpm_ba_sync_process_act_v v
       where v.update_date > v_last_sync_date
       and rownum<100000;
    v_count number;
  begin

    --如果输入的时间为空，取当前全量数据
    if p_last_sync_date is null then
      v_last_sync_date := sysdate - 1000 * 365; --默认1000年前
    else
      v_last_sync_date := p_last_sync_date;
    end if;
    --同步流程活动信息
    for v_ba_sync_process_act_cur_row in v_ba_sync_process_act_cur loop
      select count(1)
        into v_count
        from dbpm_ba_process_activity t
       where t.process_id = v_ba_sync_process_act_cur_row.process_id
         and t.activity_code = v_ba_sync_process_act_cur_row.activity_code;
      --已经存在了，更新
      if v_count > 0 then
        update dbpm_ba_process_activity t
           set t.activity_name = v_ba_sync_process_act_cur_row.activity_name,
               t.update_date   = v_ba_sync_process_act_cur_row.update_date,
               t.update_by     = v_ba_sync_process_act_cur_row.updated_by
         where t.activity_code =
               v_ba_sync_process_act_cur_row.activity_code
           and t.process_id = v_ba_sync_process_act_cur_row.process_id;
      end if;
    end loop;
    --不存在，新增
    insert into dbpm_ba_process_activity t
      (t.activity_id,
       t.activity_type,
       t.activity_code,
       t.activity_name,
       t.activity_desc,
       t.process_code,
       t.process_id,
       t.order_num,
       t.version,
       t.creation_date,
       t.create_by,
       t.update_date,
       t.update_by,
       t.partition_date)
      select dbpm_ba_process_activity_s.nextval,
             v.activity_type,
             v.activity_code,
             v.activity_name,
             v.activity_desc,
             v.process_code,
             v.process_id,
             v.order_num,
             1,
             v.creation_date,
             v.created_by,
             v.update_date,
             v.updated_by,
             sysdate
        from dbpm_ba_sync_process_act_v v
       where not exists (select 1
                from dbpm_ba_process_activity da
               where da.process_id = v.process_id
                 and da.activity_code = v.activity_code);

  end proc_sync_ba_process_activity;

  /*==================================================
  Procedure/Function Name :
      proc_sync_ba_process_instance
  Description:
      This function perform:
      同步流程实例信息到BA流程实例表
      1、得云流程的流程实例
      2、一期配置平台流程的流程实例
      3、bpm官方的流程实例（没有配置的）
  Argument:
     p_last_sync_date：   上一次同步时间
  History:
      1.00  2018-01-08    Echo.Zeng
      updated by xiaowei.yao : 2019-04-23 09:50:00
  ==================================================*/
  procedure proc_sync_ba_process_instance(p_last_sync_date in date) is
    v_last_sync_date date;
    cursor v_ba_sync_process_ins_cur is
      select v.*
        from dbpm_ba_sync_process_ins_v v
       where nvl(v.modify_date, v.creation_date) > v_last_sync_date
       and rownum<100000;

    v_count number;
  begin
    --如果输入的时间为空，取当前全量数据
    if p_last_sync_date is null then
      v_last_sync_date := sysdate - 1000 * 365; --默认1000年前
    else
      v_last_sync_date := p_last_sync_date;
    end if;

    update dbpm_ba_process_instance di
       set (di.state, di.modify_date) =
           (select v.state, v.modify_date
              from dbpm_ba_sync_process_ins_v v
             where di.instance_id = v.instance_id)
     where exists (select 1
              from dbpm_ba_sync_process_ins_v t
             where di.instance_id = t.instance_id
               and t.modify_date > v_last_sync_date);
    --同步流程实例信息
    --不存在，新增
    insert into dbpm_ba_process_instance t
      (t.instance_id,
       t.process_id,
       t.process_code,
       t.system_code,
       t.creator,
       t.process_form_id,
       t.state,
       t.version,
       t.creation_date,
       t.modify_date,
       t.partition_date)
      select v.instance_id,
             v.process_id,
             v.process_code,
             v.system_code,
             v.creator,
             v.process_form_id,
             v.state,
             1,
             v.creation_date,
             v.modify_date,
             sysdate
        from dbpm_ba_sync_process_ins_v v
       where not exists (select 1
                from dbpm_ba_process_instance dv
               where v.instance_id = dv.instance_id
                )
       and  v.modify_date > v_last_sync_date;
  end proc_sync_ba_process_instance;
  /*==================================================
  Procedure/Function Name :
      proc_sync_ba_process_ins_act
  Description:
      This function perform:
      同步流程实例活动信息到BA流程实例活动表
      1、得云流程的流程实例活动（人工节点）
      2、一期配置平台流程的流程实例活动（人工节点）
      3、bpm官方的流程实例活动（没有配置的）
  Argument:
     p_last_sync_date：   上一次同步时间
  History:
      1.00  2018-01-08    Echo.Zeng
      updated by xiaowei.yao : 2019-04-23 09:50:00
  ==================================================*/
  procedure proc_sync_ba_process_ins_act(p_last_sync_date in date) is
    v_last_sync_date date;
    cursor v_ba_sync_ins_act_cur is
      select v.*
        from dbpm_ba_sync_process_ins_act_v v
       where v.start_time > v_last_sync_date
       and rownum<100000;
    v_count    number;
    v_act_type dbpm_ba_process_activity.activity_type%TYPE;
  begin

    --如果输入的时间为空，取当前全量数据
    if p_last_sync_date is null then
      v_last_sync_date := sysdate - 1000 * 365; --默认1000年前
    else
      v_last_sync_date := p_last_sync_date;
    end if;
    --同步流程实例信息

    insert into dbpm_ba_process_instance_act t
      (t.instance_act_id,
       t.start_query_id,
       t.end_query_id,
       t.activity_id,
       t.activity_code,
       t.activity_name,
       t.fault_type,
       t.task_id,
       t.updatedby,
       t.version,
       t.instance_id,
       t.flow_id,
       t.start_time,
       t.end_time,
       t.process_id,
       t.partition_date,
       t.attribute1)
      select dbpm_ba_process_instance_act_s.nextval,
             v.start_query_id,
             v.end_query_id,
             v.activity_id,
             v.activity_code,
             v.activity_name,
             v.fault_type,
             v.taskid,
             v.updatedby,
             1,
             v.instance_id,
             v.flow_id,
             v.start_time,
             v.end_time,
             v.process_id,
             sysdate,
             v.data_source
        from dbpm_ba_sync_process_ins_act_v v
       where not exists (select 1
                from dbpm_ba_process_instance_act da
               where da.task_id = v.taskid)
         and v.end_time > v_last_sync_date;

  end proc_sync_ba_process_ins_act;

  /*==================================================
  Procedure/Function Name :
      proc_sync_to_ba
  Description:
      This function perform:
      同步所有数据到流程分析平台
      用于job调度
  Argument:
  History:
      1.00  2018-01-08    Echo.Zeng
      updated by xiaowei.yao : 2019-04-23 09:50:00
  ==================================================*/
  procedure proc_sync_to_ba is
    v_last_sync_date date;
    v_seq            number;
  begin
    select max(t.start_time) into v_last_sync_date from cux_sync_log t;
    --同步开始，写入同步日志
    v_seq := cux_sync_log_s.nextval;
    insert into cux_sync_log t
      (t.log_id, t.start_time, t.end_time)
    values
      (v_seq, sysdate, null);
    proc_sync_ba_apps(v_last_sync_date);

    proc_sync_ba_process(v_last_sync_date);

    proc_sync_ba_process_activity(v_last_sync_date);

    proc_sync_ba_process_instance(v_last_sync_date);

    proc_sync_ba_process_ins_act(v_last_sync_date);
    --同步结束,更新同步日志
    update cux_sync_log t set t.end_time = sysdate where t.log_id = v_seq;
    commit;

  exception
    when others then
     rollback;
      cux_BPM_logger.ERROR('proc_sync_to_ba', SQLERRM);

  end proc_sync_to_ba;

  procedure proc_sync_ba_ins_act(p_start_date in date, p_end_date in date) is
    v_start_date date;

    v_end_date date;
    --非自开发的流程实例活动
    cursor v_ba_sync_ins_act_cur is
      select v.*
        from dbpm_ba_sync_process_ins_act_v v
       where (v.start_time >= p_start_date and v.start_time < v_end_date);
    --自开发的审计记录
    cursor v_ba_sync_audit_cur(p_instance_id VARCHAR2) is
      select tmp.start_query_id,
             tmp.end_query_id,
             baq.component_instance_id,
             baq.component_type,
             baq.step,
             baq.component_name,
             baq.composite_instance_id,
             baq.composite_dn,
             baq.composite_name,
             baq.process_name,
             baq.activity_name,
             baq.activity_id,
             baq.activity_type,
             baq.flow_element_type,
             tmp.fault_type,
             baq.scope_id,
             baq.source_activity,
             tmp.target_activity,
             baq.title,
             baq.label,
             baq.role_id,
             baq.loop_count,
             baq.instance_count,
             baq.audit_level,
             baq.ecid,
             baq.flow_id,
             baq.process_title,
             tmp.start_time,
             tmp.end_time
        from (select min(decode(t.audit_instance_type,
                                'START',
                                t.query_id,
                                null)) as start_query_id,
                     min(decode(t.audit_instance_type,
                                'START',
                                t.create_time,
                                null)) as start_time,
                     max(decode(t.audit_instance_type,
                                'END',
                                t.query_id,
                                null)) as end_query_id,
                     max(decode(t.audit_instance_type,
                                'END',
                                t.create_time,
                                null)) as end_time,
                     max(decode(t.audit_instance_type,
                                'END',
                                t.target_activity,
                                null)) as target_activity,
                     max(case
                           when t.fault_type is not null then
                            t.fault_type
                           else
                            null
                         end) as fault_type
                from BPM_AUDIT_QUERY t
               where t.component_type = 'BPMN'
                 and t.component_instance_id = p_instance_id
               group by t.scope_id) tmp,
             BPM_AUDIT_QUERY baq
       where tmp.start_query_id = baq.query_id;
    --流程实例
    cursor v_ba_instance_cur is
      select ci.cikey instance_id
        from cube_instance ci
       where ci.CREATION_DATE >= p_start_date
         and ci.creation_date < p_end_date;

    v_count         number;
    v_act_type      dbpm_ba_process_activity.activity_type%TYPE;
    v_activity_id   dbpm_ba_process_activity.activity_id%TYPE;
    v_activity_code dbpm_ba_process_activity.activity_code%TYPE;
    v_activity_name dbpm_ba_process_activity.activity_name%TYPE;
    v_process_id    dbpm_ba_process.process_id%TYPE;
    v_task_id       wftask.taskid%TYPE;
    v_updated_by    wftask.updatedby%TYPE;
  begin
    Dbms_Output.put_line('----processInstanceAct同步开始');
    --循环所有实例
    for v_instance_row in v_ba_instance_cur loop
      --循环每一条实例的审计
      for v_ba_sync_audit_row in v_ba_sync_audit_cur(to_char(v_instance_row.instance_id)) loop
        --查询其他信息
        select dbpa.activity_id,
               dbpa.activity_code,
               dbpa.activity_name,
               dbp.process_id
          into v_activity_id,
               v_activity_code,
               v_activity_name,
               v_process_id
          from bpm_cube_process         bcp,
               bpm_cube_activity        bca,
               dbpm_ba_process_activity dbpa,
               dbpm_ba_process          dbp
         where bcp.compositedn = v_ba_sync_audit_row.composite_dn
           and bcp.processname = v_ba_sync_audit_row.component_name
           and bcp.processid = bca.processid
           and v_ba_sync_audit_row.activity_id = bca.activityname
           and dbp.attribute1 = 'obpm' || bcp.processid
           and dbpa.attribute1 = 'obpm' || bca.activityid;
        --查询审批人信息
        select wt.taskid, wt.updatedby
          into v_task_id, v_updated_by
          from wftask wt
         where wt.hassubtask = 'F'
           and wt.parentcomponentinstrefid = v_ba_sync_audit_row.scope_id;

        select t.activity_type
          into v_act_type
          from dbpm_ba_process_activity t
         where t.activity_id = v_activity_id;
        --如果是人工节点
        if v_act_type = 'USER_TASK' then
          select count(1)
            into v_count
            from dbpm_ba_process_instance_act t
           where t.instance_id = v_ba_sync_audit_row.component_instance_id
             and t.activity_id = v_activity_id
             and t.task_id = v_task_id
             and t.process_id = v_process_id;
          --已经存在了，更新
          if v_count > 0 then
            update dbpm_ba_process_instance_act t
               set t.fault_type    = v_ba_sync_audit_row.fault_type,
                   t.activity_name = v_activity_name,
                   t.updatedby     = v_updated_by,
                   t.end_time      = v_ba_sync_audit_row.end_time
             where t.instance_id =
                   v_ba_sync_audit_row.component_instance_id
               and t.activity_id = v_activity_id
               and t.task_id = v_task_id
               and t.process_id = v_process_id;
          else
            --不存在，新增
            insert into dbpm_ba_process_instance_act t
              (t.instance_act_id,
               t.start_query_id,
               t.end_query_id,
               t.activity_id,
               t.activity_code,
               t.activity_name,
               t.fault_type,
               t.task_id,
               t.updatedby,
               t.version,
               t.instance_id,
               t.flow_id,
               t.start_time,
               t.end_time,
               t.process_id,
               t.partition_date,
               t.attribute1)
            values
              (dbpm_ba_process_instance_act_s.nextval,
               v_ba_sync_audit_row.start_query_id,
               v_ba_sync_audit_row.end_query_id,
               v_activity_id,
               v_activity_code,
               v_activity_name,
               v_ba_sync_audit_row.fault_type,
               v_task_id,
               v_updated_by,
               1,
               v_ba_sync_audit_row.component_instance_id,
               v_ba_sync_audit_row.flow_id,
               v_ba_sync_audit_row.start_time,
               v_ba_sync_audit_row.end_time,
               v_process_id,
               v_ba_sync_audit_row.start_time,
               'custom');
          end if;
        else
          --不是人工节点
          select count(1)
            into v_count
            from dbpm_ba_process_instance_act t
           where t.instance_id = v_ba_sync_audit_row.component_instance_id
             and t.activity_id = v_activity_id
             and t.process_id = v_process_id;
          --已经存在了，更新
          if v_count > 0 then
            update dbpm_ba_process_instance_act t
               set t.fault_type    = v_ba_sync_audit_row.fault_type,
                   t.activity_name = v_activity_name,
                   t.updatedby     = v_updated_by,
                   t.end_time      = v_ba_sync_audit_row.end_time
             where t.instance_id =
                   v_ba_sync_audit_row.component_instance_id
               and t.activity_id = v_activity_id
               and t.process_id = v_process_id;
          else
            --不存在，新增
            insert into dbpm_ba_process_instance_act t
              (t.instance_act_id,
               t.start_query_id,
               t.end_query_id,
               t.activity_id,
               t.activity_code,
               t.activity_name,
               t.fault_type,
               t.task_id,
               t.updatedby,
               t.version,
               t.instance_id,
               t.flow_id,
               t.start_time,
               t.end_time,
               t.process_id,
               t.partition_date,
               t.attribute1)
            values
              (dbpm_ba_process_instance_act_s.nextval,
               v_ba_sync_audit_row.start_query_id,
               v_ba_sync_audit_row.end_query_id,
               v_activity_id,
               v_activity_code,
               v_activity_name,
               v_ba_sync_audit_row.fault_type,
               v_task_id,
               v_updated_by,
               1,
               v_ba_sync_audit_row.component_instance_id,
               v_ba_sync_audit_row.flow_id,
               v_ba_sync_audit_row.start_time,
               v_ba_sync_audit_row.end_time,
               v_process_id,
               v_ba_sync_audit_row.start_time,
               'custom');
          end if;
        end if;
        -- commit;
        Dbms_Output.put_line('----***startQueryId:' ||
                             v_ba_sync_audit_row.start_query_id ||
                             ',endQueryId:' ||
                             v_ba_sync_audit_row.end_query_id || '同步完成');
      end loop;
    end loop;

    --同步流程实例信息
    for v_ba_sync_ins_act_cur_row in v_ba_sync_ins_act_cur loop
      select t.activity_type
        into v_act_type
        from dbpm_ba_process_activity t
       where t.activity_id = v_ba_sync_ins_act_cur_row.activity_id;
      --如果是人工节点
      if v_act_type = 'USER_TASK' then
        select count(1)
          into v_count
          from dbpm_ba_process_instance_act t
         where t.instance_id = v_ba_sync_ins_act_cur_row.instance_id
           and t.activity_id = v_ba_sync_ins_act_cur_row.activity_id
           and t.task_id = v_ba_sync_ins_act_cur_row.taskid
           and t.process_id = v_ba_sync_ins_act_cur_row.process_id;
        --已经存在了，更新
        if v_count > 0 then
          update dbpm_ba_process_instance_act t
             set t.fault_type    = v_ba_sync_ins_act_cur_row.fault_type,
                 t.activity_name = v_ba_sync_ins_act_cur_row.activity_name,
                 t.updatedby     = v_ba_sync_ins_act_cur_row.updatedby,
                 t.end_time      = v_ba_sync_ins_act_cur_row.end_time
           where t.instance_id = v_ba_sync_ins_act_cur_row.instance_id
             and t.activity_id = v_ba_sync_ins_act_cur_row.activity_id
             and t.task_id = v_ba_sync_ins_act_cur_row.taskid
             and t.process_id = v_ba_sync_ins_act_cur_row.process_id;
        else
          --不存在，新增
          insert into dbpm_ba_process_instance_act t
            (t.instance_act_id,
             t.start_query_id,
             t.end_query_id,
             t.activity_id,
             t.activity_code,
             t.activity_name,
             t.fault_type,
             t.task_id,
             t.updatedby,
             t.version,
             t.instance_id,
             t.flow_id,
             t.start_time,
             t.end_time,
             t.process_id,
             t.partition_date,
             t.attribute1)
          values
            (dbpm_ba_process_instance_act_s.nextval,
             v_ba_sync_ins_act_cur_row.start_query_id,
             v_ba_sync_ins_act_cur_row.end_query_id,
             v_ba_sync_ins_act_cur_row.activity_id,
             v_ba_sync_ins_act_cur_row.activity_code,
             v_ba_sync_ins_act_cur_row.activity_name,
             v_ba_sync_ins_act_cur_row.fault_type,
             v_ba_sync_ins_act_cur_row.taskid,
             v_ba_sync_ins_act_cur_row.updatedby,
             1,
             v_ba_sync_ins_act_cur_row.instance_id,
             v_ba_sync_ins_act_cur_row.flow_id,
             v_ba_sync_ins_act_cur_row.start_time,
             v_ba_sync_ins_act_cur_row.end_time,
             v_ba_sync_ins_act_cur_row.process_id,
             v_ba_sync_ins_act_cur_row.start_time,
             v_ba_sync_ins_act_cur_row.data_source);
        end if;
      else
        --不是人工节点
        select count(1)
          into v_count
          from dbpm_ba_process_instance_act t
         where t.instance_id = v_ba_sync_ins_act_cur_row.instance_id
           and t.activity_id = v_ba_sync_ins_act_cur_row.activity_id
           and t.process_id = v_ba_sync_ins_act_cur_row.process_id;
        --已经存在了，更新
        if v_count > 0 then
          update dbpm_ba_process_instance_act t
             set t.fault_type    = v_ba_sync_ins_act_cur_row.fault_type,
                 t.activity_name = v_ba_sync_ins_act_cur_row.activity_name,
                 t.updatedby     = v_ba_sync_ins_act_cur_row.updatedby,
                 t.end_time      = v_ba_sync_ins_act_cur_row.end_time
           where t.instance_id = v_ba_sync_ins_act_cur_row.instance_id
             and t.activity_id = v_ba_sync_ins_act_cur_row.activity_id
             and t.process_id = v_ba_sync_ins_act_cur_row.process_id;
        else
          --不存在，新增
          insert into dbpm_ba_process_instance_act t
            (t.instance_act_id,
             t.start_query_id,
             t.end_query_id,
             t.activity_id,
             t.activity_code,
             t.activity_name,
             t.fault_type,
             t.task_id,
             t.updatedby,
             t.version,
             t.instance_id,
             t.flow_id,
             t.start_time,
             t.end_time,
             t.process_id,
             t.partition_date,
             t.attribute1)
          values
            (dbpm_ba_process_instance_act_s.nextval,
             v_ba_sync_ins_act_cur_row.start_query_id,
             v_ba_sync_ins_act_cur_row.end_query_id,
             v_ba_sync_ins_act_cur_row.activity_id,
             v_ba_sync_ins_act_cur_row.activity_code,
             v_ba_sync_ins_act_cur_row.activity_name,
             v_ba_sync_ins_act_cur_row.fault_type,
             v_ba_sync_ins_act_cur_row.taskid,
             v_ba_sync_ins_act_cur_row.updatedby,
             1,
             v_ba_sync_ins_act_cur_row.instance_id,
             v_ba_sync_ins_act_cur_row.flow_id,
             v_ba_sync_ins_act_cur_row.start_time,
             v_ba_sync_ins_act_cur_row.end_time,
             v_ba_sync_ins_act_cur_row.process_id,
             v_ba_sync_ins_act_cur_row.start_time,
             v_ba_sync_ins_act_cur_row.data_source);
        end if;
      end if;

    end loop;

  end proc_sync_ba_ins_act;
end DBPA_BA_SYNC_PKG;

/

