create TYPE     "JSON_ATOM" FORCE as object
(
-- Author  : ADOBE
-- Created : 2016/10/31 12:58:53
-- Purpose :
  obj_name  varchar2(100),
  obj_value varchar2(32767),
  obj_clob  clob,
  obj_type  varchar2(20),
  constructor function json_atom(p_obj_name varchar2, p_obj_value varchar2)
    return self as result,
  constructor function json_atom(p_obj_name varchar2, p_obj_value number)
    return self as result,
  constructor function json_atom(p_obj_name varchar2, p_obj_value BOOLEAN)
    return self as RESULT,
  constructor function json_atom(p_obj_name varchar2, p_obj_value date)
    return self as result,
  constructor function json_atom(p_obj_name varchar2, p_obj_clob clob)
    return self as result,
  constructor function json_atom(p_obj_name varchar2,
                                 p_obj_clob clob,
                                 p_obj_type varchar2) return self as result,
  constructor function json_atom(p_obj_name  varchar2,
                                 p_obj_value varchar2,
                                 p_obj_type  varchar2)
    return self as result,
  member procedure append(p_obj_value varchar2),
  member procedure append(p_obj_clob clob)
)

/

