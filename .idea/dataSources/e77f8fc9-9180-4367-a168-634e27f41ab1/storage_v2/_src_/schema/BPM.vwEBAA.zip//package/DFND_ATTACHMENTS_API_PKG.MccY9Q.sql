create PACKAGE     dfnd_attachments_api_pkg IS
  ---migrate by xiaowei.yao 20180411
  /*==================================================
  Procedure/Function Name :
      proc_query_attachments
  Description:
      This function perform:
      查询附件
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-10-25  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_query_attachments(p_request CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_add_attachments
  Description:
      This function perform:
      添加附件
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-10-25  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_add_attachments(p_request CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_add_attachment
  Description:
      This function perform:
      添加附件
  History:
      1.00  2017-10-25  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_add_attachment(p_attachment_name VARCHAR2,
                                p_document_id     NUMBER,
                                p_creator         VARCHAR2,
                                p_download_url    VARCHAR2);

  /*==================================================
  Procedure/Function Name :
      proc_del_attachment
  Description:
      This function perform:
      删除附件
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-10-25  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_del_attachment(p_request CLOB, x_response OUT CLOB);

END dfnd_attachments_api_pkg;

/

