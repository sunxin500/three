create function     func_string_split(p_list VARCHAR2, p_sep VARCHAR2)
    RETURN type_split AS
    l_idx         PLS_INTEGER;
    v_list        VARCHAR2(4000) := p_list; --长度多给点
    v_spilt_array type_split;
  BEGIN
    v_spilt_array := type_split();
    --循环递归
    LOOP
      l_idx := instr(v_list, p_sep); --获取位置
      v_spilt_array.extend;
      IF l_idx > 0 THEN
        v_spilt_array(v_spilt_array.count) := substr(v_list, 1, l_idx - 1);
        v_list := substr(v_list, l_idx + length(p_sep)); --递归
      ELSE
        v_spilt_array(v_spilt_array.count) := v_list;
        EXIT;
      END IF;
    END LOOP;
    RETURN v_spilt_array;
  END func_string_split;

/

