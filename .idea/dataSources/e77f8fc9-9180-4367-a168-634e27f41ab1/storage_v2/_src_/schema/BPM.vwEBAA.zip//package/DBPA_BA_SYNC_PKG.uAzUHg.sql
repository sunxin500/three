create PACKAGE     "DBPA_BA_SYNC_PKG" is

  -- Author  : Echo.Zeng
  -- Created : 2018-01-08 09:50:00
  -- updated by xiaowei.yao : 2019-04-23 09:50:00

  /*==================================================
  Procedure/Function Name :
      proc_sync_ba_apps
  Description:
      This function perform:
      同步应用信息到BA应用表
      1、soa分区信息
      2、一期客户化应用表BPM_PROCESS_APP_CONF
  Argument:
     p_last_sync_date：   上一次同步时间
  History:
      1.00  2018-01-08    Echo.Zeng
      updated by xiaowei.yao : 2019-04-23 09:50:00
  ==================================================*/
  procedure proc_sync_ba_apps(p_last_sync_date in date);

  /*==================================================
  Procedure/Function Name :
      proc_sync_ba_process
  Description:
      This function perform:
      同步流程信息到BA流程表
      1、bpm官方流程表关联CUX_BPM_ALL_INSTANC表
      2、得云流程表
      3、一期配置平台流程表
  Argument:
     p_last_sync_date：   上一次同步时间
  History:
      1.00  2018-01-08    Echo.Zeng
      updated by xiaowei.yao : 2019-04-23 09:50:00
  ==================================================*/
  procedure proc_sync_ba_process(p_last_sync_date in date);

  /*==================================================
  Procedure/Function Name :
      proc_sync_ba_process_activity
  Description:
      This function perform:
      同步流程活动信息到BA流程活动表
      1、bpm官方活动表关联BPM_CUBE_PROCESS表
      2、得云流程节点表关联流程表
      3、一期配置平台流程节点表关联流程表
  Argument:
     p_last_sync_date：   上一次同步时间
  History:
      1.00  2018-01-08    Echo.Zeng
      updated by xiaowei.yao : 2019-04-23 09:50:00
  ==================================================*/
  procedure proc_sync_ba_process_activity(p_last_sync_date in date);

  /*==================================================
  Procedure/Function Name :
      proc_sync_ba_process_instance
  Description:
      This function perform:
      同步流程实例信息到BA流程实例表
      1、得云流程的流程实例
      2、一期配置平台流程的流程实例
      3、bpm官方的流程实例（没有配置的）
  Argument:
     p_last_sync_date：   上一次同步时间
  History:
      1.00  2018-01-08    Echo.Zeng
      updated by xiaowei.yao : 2019-04-23 09:50:00
  ==================================================*/
  procedure proc_sync_ba_process_instance(p_last_sync_date in date);

  /*==================================================
  Procedure/Function Name :
      proc_sync_ba_process_ins_act
  Description:
      This function perform:
      同步流程实例活动信息到BA流程实例活动表
      1、得云流程的流程实例活动（人工节点）
      2、一期配置平台流程的流程实例活动（人工节点）
      3、bpm官方的流程实例活动（没有配置的）
  Argument:
     p_last_sync_date：   上一次同步时间
  History:
      1.00  2018-01-08    Echo.Zeng
      updated by xiaowei.yao : 2019-04-23 09:50:00
  ==================================================*/
  procedure proc_sync_ba_process_ins_act(p_last_sync_date in date);

  /*==================================================
  Procedure/Function Name :
      proc_sync_to_ba
  Description:
      This function perform:
      同步所有数据到流程分析平台
      用于job调度
  Argument:
  History:
      1.00  2018-01-08    Echo.Zeng
      updated by xiaowei.yao : 2019-04-23 09:50:00
  ==================================================*/
  procedure proc_sync_to_ba;
  procedure proc_sync_ba_ins_act(p_start_date in date,p_end_date in date);
end DBPA_BA_SYNC_PKG;

/

