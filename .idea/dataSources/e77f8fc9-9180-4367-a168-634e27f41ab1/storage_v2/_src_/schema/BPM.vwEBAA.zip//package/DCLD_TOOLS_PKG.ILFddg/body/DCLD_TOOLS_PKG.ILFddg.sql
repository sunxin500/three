create package body     DCLD_TOOLS_PKG is

  /*==================================================
  Procedure/Function Name :
      proc_is_null
  Description:
      This function perform:
      检查是否为空
  Argument:
     -入参
     arg varhcar2 要检查的参数
     -return
     boolean 是否为空
  History:
      1.00  2018-01-11  Echo.Zeng  Creation
  ==================================================*/
  function proc_is_null(arg in varchar2) return boolean is
    bool boolean := false;
  begin
    return bool;
  end proc_is_null;

  /*==================================================
  Procedure/Function Name :
      proc_add_user
  Description:
      This function perform:
      新增用户
  Argument:
     -入参
     p_user_code 用户名
     p_org_id 组织ID
  History:
      1.00  2018-06-29  wlj  Creation
  ==================================================*/
  procedure proc_add_user(p_user_code varchar2,
                          p_user_name varchar2,
                          p_org_id    number) as
    v_user_code varchar2(100);
  begin
    v_user_code := upper(p_user_code);
    INSERT INTO DFND_EMPLOYEES
      (EMPLOYEE_ID,
       EMPLOYEE_CODE,
       ENGLISH_NAME,
       STATUS,
       EMPLOYEE_NAME,
       Created_By,
       Creation_Date,
       Last_Updated_By,
       Last_Update_Date)
    VALUES
      (DFND_EMPLOYEES_S.NEXTVAL,
       v_user_code,
       p_user_name,
       'Y',
       p_user_name,
       'weblogic',
       sysdate,
       'weblogic',
       sysdate);
    INSERT INTO DFND_ORG_EMPLOYEES
      (ORG_EMPLOYEE_ID,
       EMPLOYEE_CODE,
       ORGANIZATION_ID,
       IS_MASTER_ORGANIZATION,
       ENABLED_FLAG)
    VALUES
      (DFND_ORG_EMPLOYEES_S.NEXTVAL, v_user_code, p_org_id, 'Y', 'Y');
  end;

end DCLD_TOOLS_PKG;

/

