create package body     cux_dfnd_signature_manage is
   /*==================================================
  Procedure/Function Name :
      proc_get_signatures
  Description:
      This function perform:
      获取当前空间下签名
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-02-28  xueyou.xu  Creation
  ==================================================*/
  procedure proc_get_signatures(p_request in clob, x_response out clob) is
    v_request       json;
    v_response      pl_json := pl_json;
    v_data          pl_json := pl_json;
    v_signature_item pl_json;
    --查询参数
    --v_search_fields json;
    v_total number := 0;
    v_size  number := 10;
    v_page  number := 1;
    v_space_id     number;


    v_filter        json;
    v_user_name varchar2(100);
    v_user_code     varchar2(100);
    v_user_all      varchar2(200);

    --排序参数
    v_sort_col varchar2(100);
    v_sort     json;
    cursor v_signature_cursor is
      SELECT *
        FROM (SELECT v.*, rownum cnt
                FROM (select COUNT(1) OVER(PARTITION BY 1) TOTAL,
                                  des.signature_id,
                                  des.user_code,
                                  emp.employee_name,
                                  des.image_id,
                                  des.base_url ||des.image_id||'&'||'original=false' as url
                             from BPM_emp_signature des,
                             dfnd_employees emp
                             where upper(des.user_code) = upper(emp.employee_code)
                             --and des.space_id = v_space_id
                         /*
                         AND (des.user_code  like '%'||v_user_code||'%'
                         OR emp.employee_name like '%'||v_user_name||'%')
                         */
                         AND INSTR(NVL(des.user_code, 'NL'),NVL(v_user_code,NVL(des.user_code, 'NL'))) > 0
                         AND INSTR(NVL(emp.employee_name, 'NL'),
                                   NVL(v_user_name, NVL(emp.employee_name, 'NL'))) > 0
                         ORDER BY decode(v_sort_col,
                                       'userCode_desc',
                                       des.user_code,
                                       'userName_desc',
                                       emp.employee_name) DESC,
                                decode(v_sort_col,
                                       'userCode_asc',
                                       des.user_code,
                                       'userName_asc',
                                       emp.employee_name) ASC,
                                des.creation_date) v
               WHERE rownum <= v_page * v_size)
       WHERE cnt > (v_page - 1) * v_size;
  begin
    --测试数据
    --v_request := json('{"page":1,"size":10,"spaceId":10026}');
    -- 获取参数

    v_request := json(p_request, 'OBJECT');

    --v_current_user := v_request.username;

    if v_request.exist('page') then
      v_page := v_request.get_number('page');
    end if;
    if v_request.exist('spaceId') then
      v_space_id := v_request.get_number('spaceId');
    end if;
    if v_request.exist('size') then
      v_size := v_request.get_number('size');
    end if;
    if v_request.exist('sort') then
      v_sort     := json(v_request.get('sort'));
      v_sort_col := v_sort.get_string('value');
      v_sort_col := v_sort_col || '_' || v_sort.get_string('order');
    end if;
    /*
   if v_request.exist('filter') then
      v_filter        := json(v_request.get('filter'));
      v_user_code     := v_filter.get_string('userCode');
      v_user_name     := v_filter.get_string('userName');
    end if;
    */

    v_user_code :=dcld_comm_pkg.get_filter_value('userCode',v_request);
    v_user_name :=dcld_comm_pkg.get_filter_value('userName',v_request);
    /*
    v_user_all :=  dcld_comm_pkg.get_filter_value('all', v_request);
    v_user_code := v_user_code || v_user_all;
    v_user_name := v_user_name || v_user_all;
    */
    v_data.set_data_type('ARRAY');
    for v_signature_cur in v_signature_cursor loop
      v_signature_item := pl_json;
      v_total         := v_signature_cur.total;
      v_signature_item.set_value('signatureId', v_signature_cur.signature_id);
      v_signature_item.set_value('userCode',v_signature_cur.user_code);
      v_signature_item.set_value('userName', v_signature_cur.employee_name);
      v_signature_item.set_value('imageId', v_signature_cur.image_id);
      v_signature_item.set_value('imageUrl', v_signature_cur.url);

      v_data.add_list_item(v_signature_item);
    end loop;
    v_response.set_value('signatureList', v_data);
    v_response.set_value('total', v_total);
    x_response := v_response.to_json;
  end;
  /*==================================================
  Procedure/Function Name :
      proc_del_signatures
  Description:
      This function perform:
      删除签名信息
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-03-19  xueyou.xu  Creation
  ==================================================*/
  procedure proc_del_signatures(p_request in clob, x_response out clob) is
    v_request       json;
    v_response      pl_json := pl_json;
    v_data          pl_json := pl_json;
    v_signature_id  number;
    v_image_id      number;
    v_user_code     varchar2(80);
    v_temp_count    number;
  begin
    --获取参数
    v_request := json(p_request, 'OBJECT');

    --测试数据
    --v_request := json('{"signatureId":1207}');
    if v_request.exist('signatureId') then
      v_signature_id := v_request.get_number('signatureId');
      --v_image_id     := v_request.get_number('imageId');
      --删除数据
      select des.image_id, des.user_code into v_image_id, v_user_code
             from BPM.BPM_emp_signature des where des.signature_id = v_signature_id;
      delete from BPM.BPM_emp_signature des where des.signature_id = v_signature_id;
      delete from BPM.BPM_signature_image dsi where dsi.image_id = v_image_id;
      v_response.set_value('code', 'SUCCESS');
      v_response.set_value('usrMsg', '用户 '||v_user_code||' 个性签名删除成功！');
    else
      v_response.set_value('code', 'ERROR');
    end if;

    x_response := v_response.to_data_json;
  end;


    /*==================================================
  Procedure/Function Name :
      proc_upload_emp_signature
  Description:
      This function perform:
      上传签名
  Argument:
     v_user_code： 请求参数 员工编号
     original：  请求参数 原图
     thumbnail： 请求参数 缩略图
     space_id    请求参数 空间ID

     x_response： 响应结果
  History:
      1.00  2018-03-19  xueyou.xu  Creation
  ==================================================*/
  procedure proc_upload_emp_signature(v_user_code in varchar2,
                  original in blob, thumbnail in blob, space_id in varchar2,
                  var_response out varchar2, var_status out varchar2) is
    var_token_val          number;
    var_image_id           number;
    v_temp_count           number;
   begin
  select count(1) into v_temp_count from BPM.BPM_emp_signature des where des.user_code = v_user_code;
      if v_temp_count >= 1 then

         --删除签名信息图片数据

        delete from BPM.BPM_signature_image dsi
               where dsi.image_id in (
                     select des.image_id from BPM.BPM_emp_signature des
                     where des.user_code = v_user_code);

        --删除关联表数据
        delete from BPM.BPM_emp_signature des
         where des.user_code = v_user_code;

       end if;
     insert into BPM.BPM_signature_image(image_id, original,thumbnail, created_by, creation_date)
            values(BPM.signature_image_seq.nextval, original, thumbnail, 'weblogic', sysdate);

     insert into BPM.BPM_emp_signature(signature_id,
                                      user_code,
                                      base_url,
                                      image_id,
                                      space_id,
                                      created_by,
                                      creation_date ) values (BPM.signature_seq.nextval,
                                      v_user_code,
                                      (select t.property_value from BPM.dfnd_properties t where t.property_key = 'SIGNATURE_IMAGE_URL'),
                                      BPM.signature_image_seq.currval,
                                      space_id,
                                      'weblogic',
                                      sysdate);

       var_response := '个性签名图片上传成功';
       var_status := 'SUCCESS';
       commit;
      exception
      when others then
         var_response := '个性签名图片上传失败';
         var_status := 'ERROR';
end proc_upload_emp_signature;

end cux_dfnd_signature_manage;

/

