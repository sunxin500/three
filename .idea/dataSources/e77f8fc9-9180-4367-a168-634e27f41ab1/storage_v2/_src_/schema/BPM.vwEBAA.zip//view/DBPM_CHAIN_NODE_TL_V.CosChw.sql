create view DBPM_CHAIN_NODE_TL_V as
SELECT dp.process_code,
       dac.chain_id,
       dac.chain_name,
       dcn.node_id,
       dcn.node_name,
       dcnt.locale,
       dcnt.node_name tl_name
  FROM dbpm_process        dp,
       dbpm_approval_chain dac,
       dbpm_chain_nodes    dcn,
       dbpm_chain_nodes_tl dcnt
 WHERE dac.process_id = dp.process_id
   AND dcn.chain_id = dac.chain_id
   AND dcn.node_id = dcnt.node_id(+)
   -- panzexiang 2018-6-27日修改
   AND dcn.is_deleted ='N'
   -- panzexiang 2018-9-26日修改
   AND dac.is_deleted='N'
   ORDER BY dp.process_code,dac.chain_id,dcn.node_id

/

