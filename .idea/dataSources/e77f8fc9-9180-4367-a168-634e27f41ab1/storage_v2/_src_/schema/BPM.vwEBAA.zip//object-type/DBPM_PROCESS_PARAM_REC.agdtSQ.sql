create TYPE     "DBPM_PROCESS_PARAM_REC" IS OBJECT
(
  processFormNo   VARCHAR2(2000),
  processApplier  VARCHAR2(2000),
  processParam    VARCHAR2(2000),
  processKeyword  VARCHAR2(2000),
  processTitle    VARCHAR2(4000),
  processCode     VARCHAR2(2000),
  businessSysCode VARCHAR2(2000)
)

/

