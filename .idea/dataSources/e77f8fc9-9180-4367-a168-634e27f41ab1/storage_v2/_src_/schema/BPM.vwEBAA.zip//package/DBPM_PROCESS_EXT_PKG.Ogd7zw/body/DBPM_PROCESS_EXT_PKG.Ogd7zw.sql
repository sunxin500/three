create package body DBPM_PROCESS_EXT_PKG is

  /*==================================================
  Procedure/Function Name :
      proc_query_external_process
  Description:
      This function perform:
      查询外部流程列表
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-03-21  jinglun.xu   Creation
  ==================================================*/
  PROCEDURE proc_query_external_process(p_request  CLOB,
                                        x_response OUT clob) is
    v_request      json;
    v_response     pl_json := pl_json;
    v_process      pl_json := pl_json;
    v_array        pl_json := pl_json;
    v_total        NUMBER := 0;
    v_size         NUMBER := 20;
    v_page         NUMBER := 1;
    v_process_name varchar2(500);
    cursor v_external_process_cur is
      SELECT *
        FROM (SELECT v.*, rownum cnt
                FROM (SELECT *
                        FROM dbpm_process_registry BCP
                       WHERE BCP.ENABLED_FLAG = 'Y'
                         AND BCP.PROCESS_MODEL_TYPE = 'OBPM'
                         AND INSTR(NVL(BCP.PROCESS_NAME, 'NL'),
                                   NVL(v_process_name,
                                       NVL(BCP.PROCESS_NAME, 'NL'))) > 0
                       order by BCP.PROCESS_ID desc) v
               WHERE rownum <= v_page * v_size)
       WHERE cnt > (v_page - 1) * v_size;
  begin
    v_request := json(p_request, 'OBJECT');
    IF v_request.exist('page') THEN
      v_page := v_request.get_number('page');
    END IF;
    IF v_request.exist('size') THEN
      v_size := v_request.get_number('size');
    END IF;
    v_process_name := dcld_comm_pkg.get_filter_value('all', v_request);
    for c_external_process_cur in v_external_process_cur loop
      v_process := pl_json;
      v_process.set_value('externalProcessId',
                          c_external_process_cur.Process_Id);
      v_process.set_value('externalProcessCode',
                          c_external_process_cur.process_code);
      v_process.set_value('externalProcessName',
                          c_external_process_cur.Process_Name);
      v_process.set_value('externalProcessDesc',
                          c_external_process_cur.description);
      v_process.set_value('revision', '-');

      v_total := c_external_process_cur.cnt;
      v_array.add_list_item(v_process);
    end loop;
    v_array.set_data_type('ARRAY');
    v_response.set_value('total', v_total);
    v_response.set_value('externalProcessList', v_array);
    x_response := v_response.to_json;
  end proc_query_external_process;
  /*==================================================
  Procedure/Function Name :
      proc_update_external_node
  Description:
      This function perform:
      查询外部流程节点
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-03-21  jinglun.xu   Creation
  ==================================================*/
  /*  PROCEDURE proc_update_external_node(p_process_id number,
                                      x_code       out varchar2) is
    v_request             json;
    v_response            pl_json := pl_json;
    v_external_process_id number;
    v_process_id          number;
    cursor v_external_node_cur is
      select T.ACTIVITYID, T.LABEL, T.PROCESSID
        from BPM_CUBE_ACTIVITY T
       WHERE T.PROCESSID = v_external_process_id
         AND T.ACTIVITYTYPE = 'USER_TASK'
       ORDER BY T.ACTIVITYID;
  begin

    select dp.bpm_process_id
      into v_external_process_id
      from dbpm_process dp
     where dp.process_id = p_process_id;
    if p_process_id is not null then
      delete from dbpm_process_nodes t where t.process_id = p_process_id;
      for c_external_node_cur in v_external_node_cur loop
        insert into dbpm_process_nodes
          (process_id, node_id, node_name, node_type)
        values
          (p_process_id,
           dbpm_process_nodes_s.nextval,
           c_external_node_cur.label,
           'Single');
      end loop;
    end if;
  exception
    when others then
      x_code := sqlerrm;
  end proc_update_external_node;*/
  /*==================================================
  Procedure/Function Name :
      proc_get_external_process_info
  Description:
      This function perform:
      铲鲟外部流程信息
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-03-21  jinglun.xu   Creation
  ==================================================*/
  PROCEDURE proc_get_external_process_info(p_process_id     number,
                                           p_domain_name    out varchar2,
                                           p_composite_name out varchar2) is
    v_external_process_id number;
  begin
    begin
      select dp.bpm_process_id
        into v_external_process_id
        from dbpm_process dp
       where dp.process_id = p_process_id;
    exception
      when no_data_found then
        return;
    end;
    SELECT BCP.COMPOSITENAME, bcp.domainname
      into p_composite_name, p_domain_name
      FROM BPM_CUBE_PROCESS BCP,
           (select t.compositename, max(t.revision) revision
              from BPM_CUBE_PROCESS t
             where t.processname = 'DBPMCoreProcess'
               and t.compositename != 'DbpmCoreProcess'
             group by t.compositename) TMP
     WHERE BCP.COMPOSITENAME = TMP.compositename
       AND BCP.REVISION = TMP.revision
       and bcp.processid = v_external_process_id;
  exception
    when others then
      return;
  end proc_get_external_process_info;
  /*==================================================
  Procedure/Function Name :
      proc_get_external_process_parm
  Description:
      This function perform:
      铲鲟外部流程接口参数
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-03-23  jinglun.xu   Creation
  ==================================================*/
  PROCEDURE proc_get_external_process_parm(p_process_id  number,
                                           p_xml_varchar out varchar2) is
    p_xml xmltype;
  begin
    /*p_xml         := df_stage.json_xml.json_to_xml(json('{"processName":"流程1"}'));
    p_xml_varchar := p_xml.extract('/').getstringval();*/
    null;
  end proc_get_external_process_parm;

  /*==================================================
  Procedure/Function Name :
      proc_save_ext_process
  Description:
      This function perform:
      维护外部流程
  Argument:
     p_process_id： 流程id
     x_result_flag： Y/N
     x_err_msg：
  History:
      1.00  2018-05-11  wlj   Creation
  ==================================================*/
  PROCEDURE proc_save_ext_process(p_process_id  number,
                                  p_bpm_id      number,
                                  p_locale      varchar2,
                                  x_result_flag out varchar2,
                                  x_err_msg     out varchar2) as
    v_domain_name     varchar2(100);
    v_composite_name  varchar2(1000);
    v_ext_process_id  number;
    v_process_name    varchar2(1000);
    v_exist_count     number;
    v_process_version number;
    v_process_code    varchar2(300);
    v_chain_id        number;
    v_composite_dn    varchar2(500);
    v_enable_flag     varchar2(10);
    v_count           number;
    cursor v_external_node_cur is
      select T.ACTIVITYID, T.LABEL, T.PROCESSID
        from BPM_CUBE_ACTIVITY T
       WHERE T.PROCESSID = v_ext_process_id
         AND T.ACTIVITYTYPE = 'USER_TASK'
       ORDER BY T.ACTIVITYID;
  BEGIN
    BEGIN
      select dp.process_code, dp.enabled_flag
        into v_process_code, v_enable_flag
        from dbpm_process dp
       where dp.process_id = p_process_id;
      if p_bpm_id is null then
        --查询外部流程的版本信息
        SELECT R.Object_Version_Number,
               r.compositerdn,
               regexp_substr(r.compositerdn, '[^/]+', 1, 1),
               regexp_substr(r.compositerdn, '[^/]+', 1, 2),
               regexp_substr(r.compositerdn, '[^/]+', 1, 3)
          INTO v_process_version,
               v_composite_dn,
               v_domain_name,
               v_composite_name,
               v_process_name
          FROM DBPM_PROCESS_REGISTRY R
         WHERE R.PROCESS_CODE = v_process_code;
      else
        --查询外部流程的版本信息
        SELECT

         r.domainname, r.compositename, r.processname
          INTO v_domain_name, v_composite_name, v_process_name
          FROM BPM_CUBE_PROCESS R
         WHERE R.PROCESSID = p_bpm_id;

      end if;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        x_result_flag := 'N';
        x_err_msg     := dcld_comm_pkg.func_get_err_msg('DCLD-00025',
                                                        p_locale);
        --x_err_msg     := '流程不存在';--DCLD-00025
        return;
    END;
    --判断编码是否存在bpm官方表
    select count(1)
      INTO v_exist_count
      from BPM_CUBE_PROCESS dcp
     where dcp.domainname = v_domain_name
       and dcp.compositename = v_composite_name
       and dcp.processname = v_process_name;

    IF v_exist_count = 0 THEN
      --若不存在返回错误
      x_result_flag := 'N';
      x_err_msg     := dcld_comm_pkg.func_get_err_msg('DCLD-00026',
                                                      p_locale); --DCLD-00026
      --x_err_msg     := '编码不存在';--DCLD-00026
      return;
    END IF;

    --若存在
    --根据编码查询默认的修订，查找对应的节点信息
    v_ext_process_id := func_get_default_process(v_process_name,
                                                 v_composite_name,
                                                 v_domain_name);
    --若查询报错则返回
    IF v_ext_process_id IS NULL THEN
      x_result_flag := 'N';
      x_err_msg     := dcld_comm_pkg.func_get_err_msg('DCLD-00027',
                                                      p_locale); --DCLD-00027
      --x_err_msg     := '查询节点失败';
      return;
    END IF;
    --更新流程信息
    update dbpm_process dp
       set dp.bpm_process_id = v_ext_process_id,
           --dp.last_update_date      = sysdate,
           DP.OBJECT_VERSION_NUMBER = DP.OBJECT_VERSION_NUMBER + 1
     where dp.process_id = p_process_id;
    /*  --更新注册表信息
    update dbpm_process_registry dp
       set dp.enabled_flag     = nvl(v_enable_flag, 'N'),
           dp.last_update_date = sysdate
     where dp.process_code = v_process_code;*/

    --覆盖式维护节点信息
    --delete from dbpm_process_nodes t where t.process_id = p_process_id;
    --融合式维护节点信息
    for c_external_node_cur in v_external_node_cur loop
      select count(1)
        into v_count
        from dbpm_process_nodes dns
       where dns.process_id = p_process_id
         and dns.node_name = c_external_node_cur.label;
      if v_count = 0 then
        insert into dbpm_process_nodes
          (process_id, node_id, node_name, node_type)
        values
          (p_process_id,
           dbpm_process_nodes_s.nextval,
           c_external_node_cur.label,
           'Single');
      else
        update dbpm_process_nodes dns
           set dns.last_update_date = sysdate
         where dns.process_id = p_process_id
           and dns.node_name = c_external_node_cur.label;
      end if;
    end loop;

    --维护一条默认的审批链
    /*  begin
      select dac.chain_id
        INTO v_chain_id
        from dbpm_approval_chain dac
       where dac.process_id = p_process_id
         and dac.is_deleted = 'N';
    exception
      when no_data_found then
        v_chain_id := dbpm_approval_chain_s.nextval;
        INSERT INTO dbpm_approval_chain
          (chain_id, chain_name, process_id, organization_id)
        VALUES
          (v_chain_id, 'OBPM默认审批链', p_process_id, '-999');
    end;*/
    --维护审批链节点信息
    --先删除对应审批链id的所有节点（自开发流程的节点信息只用于展示，所以进行物理删除）
    /* delete from dbpm_chain_nodes cn where cn.chain_id = v_chain_id;
    insert into dbpm_chain_nodes
      (node_id, chain_id, node_name, node_type)
      select dbpm_chain_nodes_s.nextval,
             v_chain_id,
             dpn.node_name,
             dpn.node_type
        from dbpm_process_nodes dpn
       where dpn.process_id = p_process_id;*/
    --否则插入审批链的节点
  END;

  /*==================================================
  Procedure/Function Name :
      func_get_default_process
  Description:
      This function perform:
      查询默认版本的流程ID
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-05-10  wlj   Creation
  ==================================================*/
  FUNCTION func_get_default_process(p_process_name   varchar2,
                                    p_composite_name varchar2,
                                    p_domain_name    varchar2) return number as
    v_composite_dn              varchar2(1000);
    v_latest_content_id         number;
    v_att_comp_seq              number;
    v_default_composite_version varchar2(4000);
    v_location                  varchar2(4000);
    v_dn                        varchar2(1000);
    v_process_id                number;
  begin
    --生成compositeDN
    v_composite_dn := p_domain_name || '/' || p_composite_name;
    --查询DN
    --1.查询最新的contentId
    select max(t.att_contentid) latest_content_id
      into v_latest_content_id
      from mds_attributes t
     where t.att_value = v_composite_dn;
    --1.1查询最新的comp_seq
    select max(t.att_comp_seq)
      into v_att_comp_seq
      from mds_attributes t
     where t.att_value = v_composite_dn
       and t.att_contentid = v_latest_content_id;
    --2.查询默认的版本
    select t.att_value
      into v_default_composite_version
      from mds_attributes t
     where t.att_comp_seq = v_att_comp_seq
       and t.att_contentid = v_latest_content_id
       and t.att_localname = 'default';
    --3.查询location
    select t.att_value
      into v_location
      from mds_attributes t
     where t.att_contentid = v_latest_content_id
       and t.att_comp_seq =
           (select t.att_comp_seq
              from mds_attributes t
             where t.att_contentid = v_latest_content_id
               and t.att_localname = 'dn'
               and t.att_value = v_default_composite_version)
       and t.att_localname = 'location';
    --生成DN
    v_dn := v_default_composite_version || '*' || substr(v_location, 4);
    --查询流程ID
    select d.processid
      into v_process_id
      from BPM_CUBE_PROCESS d
     where d.compositedn = v_dn
       and d.processname = p_process_name
       and d.domainname = p_domain_name
       and d.compositename = p_composite_name;
    return v_process_id;
  exception
    when others then
      return null;
  end;

  /*==================================================
  Procedure/Function Name :
      proc_process_register
  Description:
      This function perform:
      注册流程
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-05-14  wlj   Creation
  ==================================================*/
  PROCEDURE proc_process_register(p_request CLOB, x_response OUT CLOB) as
    v_request          json;
    v_response         pl_json := pl_json;
    v_process_code     dbpm_process_registry.process_code%type;
    v_sys_code         dbpm_process_registry.sys_code%type;
    v_process_name     dbpm_process_registry.process_name%type;
    v_process_id       varchar2(300);
    v_domain_name      varchar2(100);
    v_composite_name   varchar2(100);
    v_bpm_process_name varchar2(100);
    v_composite_dn     dbpm_process_registry.process_code%type;
  begin
    v_request := json(p_request, 'OBJECT');
    --v_request      := json('{"compositerDn":"Sample/BpmFaultEjbTimeOutProcess/BpmFaultEjbTimeOutProcess","processName":"OBPM-test流程","sysCode":"TEST"}');
    v_process_code := v_request.get_string('processCode');
    v_process_name := v_request.get_string('processName');
    v_sys_code     := v_request.get_string('sysCode');
    v_composite_dn := v_request.get_string('compositerDn');
    select regexp_substr(v_composite_dn, '[^/]+', 1, 1),
           regexp_substr(v_composite_dn, '[^/]+', 1, 2),
           regexp_substr(v_composite_dn, '[^/]+', 1, 3)
      INTO v_domain_name, v_composite_name, v_bpm_process_name
      from dual;

    v_process_id := sys_guid();
    INSERT INTO dbpm_process_registry
      (process_id,
       process_code,
       process_name,
       sys_code,
       process_model_type,
       processname,
       domainname,
       compositename,
       compositerdn)
    VALUES
      (v_process_id,
       v_process_code,
       v_process_name,
       v_sys_code,
       'OBPM',
       v_bpm_process_name,
       v_domain_name,
       v_composite_name,
       v_composite_dn);
  end;

  /*==================================================
  Procedure/Function Name :
      func_get_process_node
  Description:
      This function perform:
      获取流程审批链对应的nodeId
  Argument:
     p_process_id： 流程id
     p_node_name：  节点名称
  History:
      1.00  2018-05-15  wlj   Creation
  ==================================================*/
  FUNCTION func_get_process_node(p_process_id varchar2,
                                 p_node_name  varchar2) return number as
    v_node_id number;

  begin
    select cn.node_id
      into v_node_id
      from dbpm_approval_chain c, dbpm_chain_nodes cn
     where c.chain_id = cn.chain_id
       and c.process_id = p_process_id
       and cn.node_name = p_node_name;
    return v_node_id;
  exception
    when others then
      return null;
  end;
  procedure proc_sync_process is
    cursor v_proce_cur is
      select * from cux_process_coustom t;
    v_compositename varchar2(200);
    v_processname   varchar2(200);
    v_count         number;
  begin
    for v_row in v_proce_cur loop
      select count(1)
        into v_count
        from dbpm_process_registry dr
       where dr.processname = v_row.processname
         and dr.compositename = v_row.compositename
         and dr.process_code = v_row.process_code;
      if v_count = 0 then
        dbms_output.put_line('processname：' || v_row.processname);
        dbms_output.put_line('compositename：' || v_row.compositename);
        insert into dbpm_process_registry
          (process_id,
           process_code,
           process_name,
           sys_code,
           enabled_flag,
           object_version_number,
           creation_date,
           created_by,
           last_updated_by,
           last_update_date,
           process_model_type,
           processname,
           domainname,
           compositename,
           compositerdn)
        values
          (1,
           v_row.process_code,
           v_row.processname,
           v_row.domainname,
           'Y',
           1,
           sysdate,
           'A0023610',
           'A0023610',
           sysdate,
           'OBPM',
           v_row.processname,
           v_row.domainname,
           v_row.compositename,
           v_row.domainname || '/' || v_row.compositename || '/' ||
           v_row.processname);

      end if;
    end loop;

  end;

  procedure proc_sync_BPMprocess is
    cursor v_cur is
      select *
        from dbpm_process_registry t
       where t.process_code in ('HOOMS_CGSQ_PV','OEA_KT');

    v_process_code varchar2(200);
    v_count        number;
    v_processid    number;
    v_space_id     number;
    v_processbpmid number;
    x_result_flag  varchar2(200);
    x_err_msg      varchar2(200);
    v_create       timestamp;
    v_lastdate     timestamp;
  begin

    for v_row in v_cur loop
      select count(1)
        into v_count
        from dbpm_process dp
       where dp.process_code = v_row.process_code;
      select max(t.processid)
        into v_processbpmid
        from bpm_cube_process t
       where t.processname = v_row.processname
         and t.domainname = v_row.domainname
         and t.compositename = v_row.compositename;
      dbms_output.put_line(v_row.processname);
      dbms_output.put_line(v_row.domainname);
      dbms_output.put_line(v_row.compositename);
     -- dbms_output.put_line(v_row.process_code);
      if v_processbpmid is not null then
        if v_count = 0 then
          v_processid := dbpm_process_s.nextval;
          begin
            select ds.space_id
              into v_space_id
              from dbpm_spaces ds
             where ds.space_code = upper(v_row.sys_code);
          exception
            when no_data_found then
              v_space_id := 0;
          end;

          INSERT INTO dbpm_process
            (process_id,
             process_code,
             process_name,
             process_type,
             description,
             enabled_flag,
             created_by,
             last_updated_by,
             space_id,
             is_shared,
             bpm_process_id,
             process_class,
             form_url,
             doc_sys_code,
             cux_org_type,
             cux_auto_approve_flag,
             creation_date,
             last_update_date)
          values
            (v_processid,
             v_row.process_code,
             v_row.process_name,
             'RT',
             v_row.process_name,
             'Y',
             'A0023610',
             'A0023610',
             v_space_id,
             'N',
             v_processbpmid,
             'EXTERNAL',
             '',
             'SCI',
             'HR',
             'Y',
             v_row.creation_date,
             v_row.last_update_date);
          DBPM_PROCESS_EXT_PKG.proc_save_ext_process(v_processid,
                                                     v_processbpmid,
                                                     'zh_CN',
                                                     x_result_flag,
                                                     x_err_msg);
        else

          select dp.process_id
            into v_processid
            from dbpm_process dp
           where dp.process_code = v_row.process_code;
          DBPM_PROCESS_EXT_PKG.proc_save_ext_process(v_processid,
                                                     v_processbpmid,
                                                     'zh_CN',
                                                     x_result_flag,
                                                     x_err_msg);

        end if;
      end if;
    end loop;

  end proc_sync_BPMprocess;

  procedure proc_purge_process is
    cursor v_purge_process is
      select *
        from dbpm_process t
       where t.process_id > 12739
         and t.process_class = 'EXTERNAL'
         and 1 = 0;
  begin
    for v_row in v_purge_process loop
      dbms_output.put_line(v_row.process_code);
      dbms_output.put_line(v_row.process_name);
      basic_data_pkg.proc_purge_process(v_row.process_code);
    end loop;
  end;
 
end DBPM_PROCESS_EXT_PKG;

/

