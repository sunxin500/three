create PACKAGE     dbpm_data_source_api_pkg IS

  /*==================================================
  Procedure/Function Name :
      proc_query_data_source
  Description:
      This function perform:
      查询数据字典
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-05-03  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_query_data_sources(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_save_datasource
  Description:
      This function perform:
      保存数据字典，需要判断是新增还是修改
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-20  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_save_data_source(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_del_datasource
  Description:
      This function perform:
      删除数据字典
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-20  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_del_data_source(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_query_datasource_values
  Description:
      This function perform:
      查询数据字典明细
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-20  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_query_data_source_values(p_request  IN CLOB,
                                          x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_save_datasource_value
  Description:
      This function perform:
      保存数据字典值信息，需要判断是新增还是修改
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-20  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_save_data_source_value(p_request  IN CLOB,
                                        x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_del_datasource_value
  Description:
      This function perform:
      删除数据字典的值明细
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-20  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_del_data_source_value(p_request  IN CLOB,
                                       x_response OUT CLOB);

  /*
  * 根据value_code获取value_name
  */
  function get_data_value_name(p_data_source_code varchar2,
                               p_data_value_code  varchar2) return varchar2;
  /*==================================================
  Procedure/Function Name :
      func_get_all_data_source_value
  Description:
      This function perform: migrate by xiaowei.yao 20180411
      获取数据源的值
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-02-06  wlj  Creation
  ==================================================*/
  function func_get_all_data_source_value(p_data_source_code varchar2)
    return varchar2;
END dbpm_data_source_api_pkg;

/

