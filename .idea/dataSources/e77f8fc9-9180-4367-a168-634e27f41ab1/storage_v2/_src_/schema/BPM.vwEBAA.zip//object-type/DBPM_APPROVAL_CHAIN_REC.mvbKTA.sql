create TYPE     "DBPM_APPROVAL_CHAIN_REC" IS OBJECT
(
  chain_id   NUMBER, -- 审批链ID
  chain_name VARCHAR2(2000), -- 审批链名称
  chain_type VARCHAR2(2000), -- 审批连类型
  process_id VARCHAR2(2000), -- 所属流程
-- organization_id NUMBER, -- 所属组织--migrate by xiaowei.yao 20180413
  organization_id VARCHAR2(2000), -- 所属组织--migrate by xiaowei.yao 20180413
  chain_nodes     dbpm_chain_node_tbl
)

/

