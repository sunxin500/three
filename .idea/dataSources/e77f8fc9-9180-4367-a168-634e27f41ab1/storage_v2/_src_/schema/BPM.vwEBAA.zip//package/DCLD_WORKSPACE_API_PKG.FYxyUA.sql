create PACKAGE     dcld_workspace_api_pkg IS

  -- Author  : ADOBE
  -- Created : 2016/12/4 14:56:11
  -- Purpose :

  /*==================================================
  Procedure Name :
      proc_notice_publish
  Description:
      发布通知公告
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2016-11-25  Kerry.Wu  Creation
  Sample input:
    {
    "title": "xxx",
    "content": "xxxx",
    "notice_type": "xxxx",
    "scopes": [
      {
            "scope": "ROLE",
            "assigner": [
                "DEMO_ROLE1",
                "DEMO_ROLE2"
        ]
      },
      {
            "scope": "USER",
            "assigner": [
                "user1",
                "user2"
            ]
      },
      {
            "scope": "ALL"
      }
    ]
  }
         title:         标题
         content:       内容
         notice_type:   类型
         scope:         发送范围
         assignee_type: 分配人类型
         assignee:      分配人
  Sample output:
         标准输出
  ==================================================*/
  PROCEDURE proc_notice_publish(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure Name :
      proc_notice_query
  Description:
      自己能看到的所有通知公告
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2016-11-25  Kerry.Wu  Creation
  Sample input:
        {
    "title": "xxx",
    "content": "xxxx",
    "notice_type": "xxxx",
    "scopes": [
        {
            "scope": "ROLE",
            "assigner": [
                "DEMO_ROLE1",
                "DEMO_ROLE2"
            ]
        },
        {
            "scope": "USER",
            "assigner": [
                "user1",
                "user2"
            ]
        },
        {
            "scope": "ALL"
        }
    ]
    }
  Sample output:
      [{
         "title": "xxx",
         "content": "xxxx",
         "notice_type": "xxxx",
         "notice_id": "xxxx",
         "create_date":"xxxx",
         "create_by":"xxxx",
         "new":"Y/N"
         }]
         title:         标题
         content:       内容
         notice_type:   类型
         scope:         发送范围,用于区分“仅@我的通知”
         create_date:   创建时间
         create_by:     发起人
         new:           是否新建的显示
  ==================================================*/
  PROCEDURE proc_notice_query(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure Name :
      proc_set_doc_readead
  Description:
      设置 消息公共/系统消息/待办 是否已读
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2016-11-25  Kerry.Wu  Creation
  Sample input:
       {
         "source": "NOTICE/SYSTEM_MESSAGE/PROCESS_CODE",
         "source_id": 1234
       }
       source：公告(NOTICE)/系统消息(SYSTEM_MESSAGE)/待办(待办对应的PROCESS_CODE)
  Sample output:
      标准输出
  ==================================================*/
  PROCEDURE proc_set_doc_readead(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure Name :
      proc_query_all_process
  Description:
      查询流程信息
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2016-12-09  Kerry.Wu  Creation
  Sample input:
      {
         "fields": [
               {
                 "field": "process_type",
                 "op": "=",
                  "value": "xxxx"
                },{
                 "field": "process_name",
                 "op": "like",
                  "value": "xxxx"
                }],
          "page": 100,
          "size": 101

       }
  Sample output:
         [
         "process_code": "xxxx",
         "process_type": "xxxx",
         "process_name": "xxxx",
         "description": "xxxx",
          "enabled_flag":""
       ]
  ==================================================*/
  PROCEDURE proc_query_all_process(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure Name :
      proc_user_favorite_process_query
  Description:
      查询用户常用的 常用业务,或常用导航
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2016-12-09  Kerry.Wu  Creation
  Sample input:
      {
          "space_type":"xxxx",
          "page": 100,
          "size": 101
       }
  Sample output:
         [
         "weight"      : 0.258,
         "process_code": "xxxx",
         "process_type": "xxxx",
         "process_name": "xxxx",
         "description": "xxxx",
         "enabled_flag": "Y/N",
         "business_url":"xxxx"
       ]

       space_type:   BUSINESS(常用业务)/NAVIGATION(常用导航)
  ==================================================*/
  PROCEDURE proc_query_favorite_business(p_request  IN CLOB,
                                         x_response OUT CLOB);

  /*
  *{
    "content": "xxx",
    "message_type": "xxxx",
    "module":"xxx",
    "function":"xxx",
    "scopes": [
      {
            "scope": "ROLE",
            "assigner": [
                "DEMO_ROLE1",
                "DEMO_ROLE2"
               ]
      },
      {
            "scope": "USER",
            "assigner": [
                "user1",
                "user2"
            ]
      },
      {
            "scope": "ALL"
      }
    ]
  }
  */
  /*PROCEDURE proc_system_message_publish(p_request  IN CLOB,
  x_response OUT CLOB);*/

  /*==================================================
  Procedure Name :
      proc_system_message_query
  Description:
      用户查看系统通知
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  Table：
      DCLD_SYSTEM_MESSAGE
      DCLD_SYSTEM_MESSAGE_ASSIGN
  History:
      1.00  2016-11-29  haochi.xu  Creation
  Sample input:
     {
          "page": xxx,
          "size": xxx
     }


         user_code:        用户code
         message_id


  Sample output:
       [
         "message_id": "xxxx",
         "content": "xxxx",
         "message_type": "xxxx",
         "creation_date": "xxxx",
         "is_new": "xxxx",
       ]
  ==================================================*/
  /*PROCEDURE proc_system_message_query(p_request  IN CLOB,
  x_response OUT CLOB);*/

  PROCEDURE proc_get_user_workspace_data(p_request  IN CLOB,
                                         x_response OUT CLOB);
  PROCEDURE proc_add_quick_navigation(p_request  IN CLOB,
                                      x_response OUT CLOB);

  PROCEDURE proc_delete_quick_navigation(p_request  IN CLOB,
                                         x_response OUT CLOB);
END dcld_workspace_api_pkg;

/

