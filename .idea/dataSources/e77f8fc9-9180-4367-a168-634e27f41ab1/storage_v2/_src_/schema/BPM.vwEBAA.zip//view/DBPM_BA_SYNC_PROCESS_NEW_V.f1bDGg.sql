create view DBPM_BA_SYNC_PROCESS_NEW_V as
select "DOMAINNAME","COMPOSITENAME","SYSTEM_CODE","PRCOESS_NAME","REVISION","CREATIONDATE","LASTUPDATED","PROCESS_CODE","CREATED_BY","UPDATED_BY","BPM_PROCESS_ID" from (
select distinct bcp.domainname,
                bcp.compositename,
                bcp.domainname system_code,
                '' prcoess_name,
                bcp.revision,
                bcp.creationdate,
                bcp.lastupdated,
                ins.process_code,
                'bpm_cube_process' created_by,
                'bpm_cube_process' updated_by,
                ('obpm' || bcp.processid) bpm_process_id
  from bpm_cube_process bcp, cux_bpm_all_instance ins, cube_instance ci
 where ins.instance_id = ci.cikey
   and bcp.domainname = ci.domain_name
   and bcp.compositename = ci.composite_name
   and bcp.revision = ci.composite_revision
   and bcp.scalabel = ci.composite_label
   and bcp.status = 1
   and bcp.migrationstatus = 'LATEST'
   and bcp.compositename not in
       ('GpmsOverseaBpmProcess', 'DbpmCoreProcess')
union
select 'SCI' domainname,
       'DbpmCoreProcess' compositename,
       'GEMS' system_code,
       dp.process_name,
       '1.0' revision,
       dp.creation_date creationdate,
       dp.last_update_date lastupdated,
       dp.process_code,
       'dbpm_process' created_by,
       'dbpm_process' updated_by,
       ('BPM' || dp.process_id) bpm_process_id
  from dbpm_process dp
  where  dp.process_class ='INTERNAL'
union
select 'GPMS' domainname,
       'GpmsOverseaBpmProcess' compositename,
       bp.sys_code system_code,
       bp.process_name,
       '1.0' revision,
       bp.create_date creationdate,
       bp.last_update_date lastupdated,
       bp.process_code,
       'bpm_process_def_conf' created_by,
       'bpm_process_def_conf' updated_by,
       ('dbpm' || bp.id) bpm_process_id
  from bpm_process_def_conf bp) v
  where not exists (
  select 1 from dbpm_ba_process bp where  bp.process_code=v.process_code and bp.process_version=v.revision and bp.system_code=v.system_code and bp.composite_name = v.compositename
  )
/

