create PACKAGE BODY     dbpm_process_start_param_pkg IS

  /*==================================================
  procedure name :
      proc_add_instance_param
  description:
      记录流程发起参数
  argument:
     p_instanceid：       实例号
     p_request_date:      请求时间
     p_request_content:   请求内容
     p_response_date:     响应时间
     p_response_content:  响应内容
     p_result:            接口调用接口（success/failure)
     p_error_log:         p_result='FAILURE'的错误日志
     x_msg:               调用结果
  history:
      1.00  2019-6-12  xiaowei.yao  creation
  ==================================================*/

    PROCEDURE proc_add_instance_param (
        p_instanceid         IN    VARCHAR2,
        p_request_date       IN    DATE,
        p_request_content    IN    CLOB,
        p_response_date      IN    DATE,
        p_response_content   IN    CLOB,
        p_result             IN    VARCHAR2,
        p_error_log          IN    CLOB,
        x_msg                OUT   VARCHAR2,
        x_flag               OUT   VARCHAR2
    ) IS
    BEGIN
        BEGIN
            INSERT INTO dbpm_process_start_param (
                instanceid,
                request_date,
                request_content,
                response_date,
                response_content,
                result,
                error_log,
                create_date,
                update_date
            ) VALUES (
                p_instanceid,
                p_request_date,
                p_request_content,
                p_response_date,
                p_response_content,
         p_result,
                p_error_log,
                SYSDATE,
                SYSDATE
            );

            x_flag := 'success';
            x_msg := 'start bpm process success';
        EXCEPTION
            WHEN OTHERS then
                x_flag := 'fail';
                x_msg := 'error log :  ' || sqlerrm;
        END;
    END proc_add_instance_param;
  /*==================================================
  procedure name :
      proc_update_instance_param
  description:
     更新流程参数
  argument:
     p_instanceid：     实例号
     p_new_param:       要更新的流程参数
     x_flag:            接口调用接口（success/failure)
     x_msg:             异常信息
  history:
      1.00  2019-6-14  xiaowei.yao  creation
  ==================================================*/

    PROCEDURE proc_update_instance_param (
        p_new_param   IN    CLOB,
        x_msg         OUT   VARCHAR2,
        x_flag        OUT   VARCHAR2
    ) IS

        v_new_bussin_param       json;
        v_new_bussin_params      json_list;
        v_old_bussin_param       json;
        v_old_bussin_params      json_list;
        v_new_process_start      json;
        v_old_process_start      json;
        v_update_process_start   pl_json;
        v_update_sub_param       pl_json;
        v_temp                   CLOB;
        v_new_param              json;
        v_old_param              json;
        v_new_subparam           json;
        v_old_subparam           json;
        v_old_subchainparams     json_list;
        v_new_subchainparams     json_list;
        v_new_sub_param          json_list;
        v_old_sub_param          json_list;
        v_update_sub_param       pl_json;
        v_instanceid             VARCHAR2(100);
        v_tempjson               json;
        v_update_type            VARCHAR2(200);
    BEGIN
        BEGIN
            v_new_process_start := json(p_new_param);
            v_instanceid := v_new_process_start.get_string('instanceId');
            v_update_type := v_new_process_start.get_string('updateType');
            INSERT INTO dbpm_start_param_reversion
                SELECT
                    dp.*
                FROM
                    dbpm_process_start_param dp
                WHERE
                    dp.instanceid = v_instanceid;

            SELECT
                dp.request_content
            INTO v_temp
            FROM
                dbpm_process_start_param dp
            WHERE
                dp.instanceid = v_instanceid;

            v_old_process_start := json(v_temp);
            v_old_bussin_param := json(v_old_process_start.get('businessParam'));
            v_old_bussin_params := json_list(v_old_bussin_param.get('param'));
            v_old_subchainparams := json_list(v_old_process_start.get('subChainParams'));
      --基本参数不允许修改
            v_update_process_start := pl_json;
            v_update_process_start.set_value('processParam', json(v_old_process_start.get('processParam')));

      --判断是覆盖更新还是部分更新
            IF v_update_type = 'PART' THEN
        --修改主流程业务参数
                IF v_new_process_start.path('businessParam') IS NOT NULL THEN
                    v_new_bussin_param := json(v_new_process_start.get('businessParam'));
                    v_new_bussin_params := json_list(v_new_bussin_param.get('param'));
                    FOR i IN 1..v_old_bussin_params.count LOOP
                        v_old_param := json(v_old_bussin_params.get(i));
                        FOR j IN 1..v_new_bussin_params.count LOOP
                            v_new_param := json(v_new_bussin_params.get(j));
                            IF v_new_param.get_string('key') = v_old_param.get_string('key') THEN
                                v_old_bussin_params.replace(i, v_new_param.to_json_value);
                            END IF;

                        END LOOP;

                    END LOOP;

                END IF;

                v_tempjson := json;
                v_tempjson.put('param', v_old_bussin_params);
                v_update_process_start.set_value('businessParam', v_tempjson);
        --修改子流程参数
                IF v_old_process_start.path('subChainParams') IS NOT NULL THEN
                    v_old_subchainparams := json_list(v_old_process_start.get('subChainParams'));
                    IF v_new_process_start.path('subChainParams') IS NOT NULL THEN
                        v_new_subchainparams := json_list(v_new_process_start.get('subChainParams'));
                        FOR k IN 1..v_old_subchainparams.count LOOP
                            v_old_param := json(v_old_subchainparams.get(k));
                            FOR l IN 1..v_new_subchainparams.count LOOP
                                v_new_param := json(v_new_subchainparams.get(l));
                                IF v_old_param.get_string('subChainId') = v_new_param.get_string('subChainId') THEN
                                    v_new_sub_param := json_list(v_new_param.get('subParam'));
                                    v_old_sub_param := json_list(v_old_param.get('subParam'));
                                    FOR a IN 1..v_old_sub_param.count LOOP
                                        v_old_subparam := json(v_old_sub_param.get(a));
                                        FOR b IN 1..v_new_sub_param.count LOOP
                                            v_new_subparam := json(v_new_sub_param.get(b));
                                            IF v_new_subparam.get_string('key') = v_old_subparam.get_string('key') THEN
                                                v_old_sub_param.replace(a, v_new_subparam.to_json_value);
                                            END IF;

                                        END LOOP;

                                    END LOOP;

                                    v_tempjson := json;
                                    v_tempjson.put('subParam', v_old_sub_param);
                                    v_tempjson.put('subChainId', v_old_param.get_string('subChainId'));
                                    v_tempjson.put('subProcessTitle', v_old_param.get_string('subProcessTitle'));
                                    v_tempjson.put('subProcessKeyWord', v_old_param.get_string('subProcessKeyWord'));
                                    v_old_subchainparams.replace(k, v_tempjson.to_json_value);
                                END IF;

                            END LOOP;

                        END LOOP;

                    END IF;

                END IF;

                v_update_process_start.set_value('subChainParams', v_old_subchainparams);
            ELSE
                v_update_process_start.set_value('businessParam', json(v_new_process_start.get('businessParam')));
                v_update_process_start.set_value('subChainParams', json_list(v_new_process_start.get('subChainParams')));
            END IF;

            UPDATE dbpm_process_start_param dsp
            SET
                dsp.request_content = v_update_process_start.to_data_json,
                dsp.update_date = SYSDATE
            WHERE
                dsp.instanceid = v_instanceid;

            x_flag := 'success';
            x_msg := 'update process param success';
        EXCEPTION
            WHEN OTHERS THEN
                ROLLBACK;
                x_msg := sqlerrm;
                x_flag := 'fail';
        END;
    END proc_update_instance_param;
  /*==================================================
  procedure name :
      proc_check_instance_param
  description:
     校验流程参数
  argument:
     p_instance_param:       要校验的流程参数
     x_flag:          接口调用接口（success/failure)
     x_msg:             异常信息
  history:
      1.00  2019-6-24  xiaowei.yao  creation
  ==================================================*/

    PROCEDURE proc_check_instance_param (
        p_instance_param   IN    CLOB,
        x_msg              OUT   VARCHAR2,
        x_flag             OUT   VARCHAR2
    ) IS

        v_re                json;
        v_processapplier    VARCHAR2(100);
        v_processcode       VARCHAR2(100);
        v_businesssyscode   VARCHAR2(100);
        v_count             NUMBER := 0;
        v_subchainparams    json_list;
        v_subchain          json;
        v_subchainid        type_array := type_array();
        v_processparam      json;
      
        
    BEGIN
        v_re := json(p_instance_param);
        v_processparam := json(v_re.get('processParam'));
        BEGIN
            IF v_processparam.path('processApplier') IS NOT NULL THEN
                v_processapplier := v_processparam.get_string('processApplier');
                IF v_processapplier IS NULL THEN
                    x_flag := 'fail';
                    x_msg := 'processApplier不可为空';
                    return;
                END IF;

            END IF;
            
            IF v_processparam.path('processParam') IS NOT NULL THEN
               
                IF v_processparam.get_string('processParam') IS NULL THEN
                    x_flag := 'fail';
                    x_msg := 'processParam不可为空';
                    return;
                END IF;

            END IF;
            
             IF v_processparam.path('processTitle') IS NOT NULL THEN
              
                IF v_processparam.get_string('processTitle') IS NULL THEN
                    x_flag := 'fail';
                    x_msg := 'processTitle不可为空';
                    return;
                END IF;

            END IF;
            
             IF v_processparam.path('processFormNo') IS NOT NULL THEN
               
                IF v_processparam.get_string('processFormNo') IS NULL THEN
                    x_flag := 'fail';
                    x_msg := 'processFormNo不可为空';
                    return;
                END IF;

            END IF;
            
             IF v_processparam.path('processKeyword') IS NOT NULL THEN
              
                IF v_processparam.get_string('processKeyword') IS NULL THEN
                    x_flag := 'fail';
                    x_msg := 'processKeyword不可为空';
                    return;
                END IF;

            END IF;
             IF v_processparam.path('documentId') IS NOT NULL THEN
              
                IF v_processparam.get_string('documentId') IS NULL THEN
                    x_flag := 'fail';
                    x_msg := 'documentId不可为空';
                    return;
                END IF;

            END IF;

            SELECT
                COUNT(1)
            INTO v_count
            FROM
                dfnd_employees em
            WHERE
                lower(em.employee_code) = lower(v_processapplier);

            IF v_count = 0 THEN
                x_flag := 'fail';
                x_msg := 'processApplier:'
                         || v_processapplier
                         || '不存在';
                return;
            END IF;

            IF v_processparam.path('processCode') IS NOT NULL THEN
                v_processcode := v_processparam.get_string('processCode');
            END IF;

            SELECT
                COUNT(1)
            INTO v_count
            FROM
                dbpm_process pr
            WHERE
                pr.process_code = v_processcode
                and pr.process_class='INTERNAL';

            IF v_count = 0 THEN
                x_flag := 'fail';
                x_msg := 'processCode:'
                         || v_processcode
                         || '不存在';
                return;
            END IF;

            IF v_processparam.path('businessSysCode') IS NOT NULL THEN
                v_businesssyscode := v_processparam.get_string('businessSysCode');
            END IF;

            SELECT
                COUNT(1)
            INTO v_count
            FROM
                dbpm_spaces sp
            WHERE
                sp.space_code = v_businesssyscode;

            IF v_count = 0 THEN
                x_flag := 'fail';
                x_msg := 'businessSysCode:'
                         || v_businesssyscode
                         || '不存在';
                return;
            END IF;

            SELECT
                COUNT(1)
            INTO v_count
            FROM
                dbpm_process   dp,
                dbpm_spaces    ds
            WHERE
                dp.space_id = ds.space_id
                AND dp.process_code = v_processcode
                AND ds.space_code = v_businesssyscode;

            IF v_count = 0 THEN
                x_flag := 'fail';
                x_msg := '流程编码和空间编码不对应';
                return;
            END IF;

            IF v_re.path('subChainParams') IS NOT NULL THEN
                v_subchainparams := json_list(v_re.get('subChainParams'));
                FOR i IN 1..v_subchainparams.count LOOP
                    v_subchain := json(v_subchainparams.get(i));
                    IF v_subchain.path('subChainId') IS NOT NULL THEN
                        v_subchainid.extend();
                        v_subchainid(i) := v_subchain.get_string('subChainId');
                    END IF;

                END LOOP;

                FOR j IN 1..( v_subchainid.count - 1 ) LOOP FOR k IN ( j + 1 )..v_subchainid.count LOOP
                    IF v_subchainid(j) = v_subchainid(k) THEN
                        x_flag := 'fail';
                        x_msg := '第'
                                 || j
                                 || '个和第'
                                 || k
                                 || '个subChainId:'
                                 || v_subchainid(j)
                                 || '重复';

                        return;
                    END IF;
                END LOOP;
                END LOOP;

            END IF;

            x_flag := 'success';
        EXCEPTION
            WHEN OTHERS THEN
                x_flag := 'fail';
                x_msg := 'error log :  ' || sqlerrm;
        END;

    END proc_check_instance_param;
  /*==================================================
  procedure name :
      proc_get_error_email
  description:
     校验流程参数
  argument:
     p_instance_param:       要校验的流程参数
     x_flag:          接口调用接口（success/failure)
     x_msg:             异常信息
  history:
      1.00  2019-6-25  xiaowei.yao  creation
  ==================================================*/

    PROCEDURE proc_get_error_email (
        p_instance_param   IN    CLOB,
        x_subject          OUT   VARCHAR2,
        x_content          OUT   VARCHAR2,
        x_reply            OUT   VARCHAR2,
        x_cc               OUT   VARCHAR2,
        x_tt               OUT   VARCHAR2
    ) IS
    BEGIN
        x_subject := '出问题了';
        x_content := '发起参数为：' || p_instance_param;
        x_cc := 'A0023610';
        x_tt := 'A0017701';
    END proc_get_error_email;

END dbpm_process_start_param_pkg;
/

