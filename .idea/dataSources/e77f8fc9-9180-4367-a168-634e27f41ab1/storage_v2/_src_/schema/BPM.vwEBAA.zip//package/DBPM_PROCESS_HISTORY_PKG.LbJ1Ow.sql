create package     DBPM_PROCESS_HISTORY_PKG is

  -- Author  : WOLF
  -- Created : 2018/5/25 14:17:28
  -- Purpose : 审批历史功能

  /*==================================================
  Procedure/Function Name :
      proc_query_history_graph
  Description:
      This function perform:
       查询审批历史流程图
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-05-08  wlj  Creation
  ==================================================*/
  PROCEDURE proc_query_history_graph(p_request  IN CLOB,
                                     x_response OUT CLOB);
  /*==================================================
  Procedure/Function Name :
      proc_query_official_history
  Description:
      This function perform:
       查询流程官方的审批历史
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-05-17  wlj  Creation
  ==================================================*/
  PROCEDURE proc_query_official_history(p_request  IN CLOB,
                                        x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      func_get_reassign_user
  Description:
      This function perform:
       获取授权信息
  Argument:
     p_instance_id: 流程实例ID
     return : 重新分配的员工
  History:
      1.00  2018-05-25  wlj  Creation
  ==================================================*/
  PROCEDURE proc_get_reassign_user(p_task_id   varchar2,
                                   p_task_type varchar2,
                                   x_user      out varchar2,
                                   x_user_name out varchar2);

end DBPM_PROCESS_HISTORY_PKG;

/

