create view CHAIN_NODE_PARAM_V as
SELECT dp.process_id,
       dp.process_code,
       dac.chain_id,
       dac.chain_name,
       dcn.node_id,
       dcn.node_name,
       cgnp.param_key,
       cgnp.param_value
  FROM dbpm_process         dp,
       dbpm_approval_chain  dac,
       dbpm_chain_nodes     dcn,
       cux_gems_node_params cgnp
 WHERE dp.process_id = dac.process_id
   AND dac.chain_id = dcn.chain_id
   AND dcn.node_id = cgnp.node_id(+)
   --panzexiang 2018-6-27日修改
   AND dcn.is_deleted= 'N'
   --panzexiang 2018-9-26日修改
   AND dac.is_deleted='N'
 ORDER BY dp.process_id,dac.chain_id,dcn.node_id

/

