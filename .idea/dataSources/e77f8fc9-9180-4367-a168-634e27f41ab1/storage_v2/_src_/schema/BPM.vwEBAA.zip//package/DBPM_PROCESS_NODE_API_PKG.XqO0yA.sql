create PACKAGE     dbpm_process_node_api_pkg IS

  /*==================================================
  Procedure/Function Name :
      proc_query_process_nodes
  Description:
      This function perform:
      查询流程节点
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-05-17  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_query_process_nodes(p_request CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_save_process_nodes
  Description:
      This function perform:
      保存流程节点
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-05-17  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_save_process_nodes(p_request CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_del_process_node
  Description:
      This function perform:
      删除流程节点
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-05-17  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_del_process_node(p_request CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_save_process_node
  Description:
      This function perform:
      保存流程节点
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-05-17  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_save_process_node(p_request CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_save_process_nodes_ex
  Description:
      This function perform:
      保存流程节点，支持批量
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-11-02  Echo.Zeng  Creation
  ==================================================*/
  PROCEDURE proc_save_process_nodes_ex(p_request CLOB, x_response OUT CLOB);
  /*==================================================
   --migrate by xiaowei.yao 20180416
  Procedure/Function Name :
      proc_query_next_nodes
  Description:
      This function perform:
      获取下级审批节点及审批人
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-09-15  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_query_next_node_approvers(p_request  CLOB,
                                           x_response OUT CLOB);
  /*==================================================
   migrate by xiaowei.yao20180416
   ------------
  Procedure/Function Name :
      proc_save_process_all_node
  Description:
      This function perform:
      保存流程全部节点
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-11-20  jinglun.xu   Creation
  ==================================================*/
  PROCEDURE proc_save_process_all_node(p_request CLOB, x_response OUT CLOB);

END dbpm_process_node_api_pkg;

/

