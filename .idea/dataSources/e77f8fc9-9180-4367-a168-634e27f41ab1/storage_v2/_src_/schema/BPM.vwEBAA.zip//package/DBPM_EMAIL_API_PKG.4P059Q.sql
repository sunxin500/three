create package     DBPM_EMAIL_API_PKG is

  -- Author  : WLJ
  -- Created : 2018/5/23 0:31:02
  -- Purpose : 邮件功能

  /*==================================================
  Procedure/Function Name :
      proc_get_data_set
  Description:
      This function perform:
       获取流程信息和单据信息
  Argument:

  History:
      1.00  2018-05-10  wlj  Creation
  ==================================================*/
  PROCEDURE proc_get_data_set(p_instance_id        varchar2,
                              p_task_id            varchar2,
                              p_outcome            varchar2,
                              p_locale             varchar2,
                              p_process_param      dbpm_process_param_rec,
                              p_sql                varchar2,
                              x_single_line_cursor out sys_refcursor,
                              x_muti_line_cursor   out sys_refcursor);

  /*==================================================
  Procedure/Function Name :
      proc_get_email_template
  Description:
      This function perform:
       获取邮件模板
  Argument:
     p_instance_id： 流程实例ID
     p_task_id： 待办ID
     p_outcome : 邮件的类型（待办提醒邮件/拒绝邮件/完成邮件等）
     p_process_param ：流程参数
     p_business_param ：业务参数
  History:
      1.00  2018-05-23  wlj  Creation
  ==================================================*/
  PROCEDURE proc_get_email_template(p_instance_id   varchar2,
                                    p_task_id       varchar2,
                                    p_outcome       varchar2,
                                    p_locale        varchar2,
                                    p_process_param dbpm_process_param_rec,
                                    x_email_title   OUT CLOB,
                                    x_email_body    OUT CLOB,
                                    x_result_flag   OUT VARCHAR2,
                                    x_error_msg     OUT VARCHAR2);
 /*==================================================
  Procedure/Function Name :
      proc_save_email
  Description:
      This function perform:
      保存邮件模板
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2019-02-25  yxw  Creation
  ==================================================*/
  procedure proc_save_email(p_request in clob,x_response out clob);
  /*==================================================
  Procedure/Function Name :
      proc_query_email
  Description:
      This function perform:
      查询邮件模板
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2019-02-25  yxw  Creation
  ==================================================*/
  procedure proc_query_email(p_request in clob,x_response out clob);
/*==================================================
  Procedure/Function Name :
      proc_del_email
  Description:
      This function perform:
      删除邮件模板（逻辑删除）
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2019-02-21  yxw  Creation
  ==================================================*/
  procedure proc_del_email(p_request in clob,x_response out clob);


end DBPM_EMAIL_API_PKG;

/

