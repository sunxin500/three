create PACKAGE dbpm_comm_pkg IS

  TYPE type_split IS TABLE OF VARCHAR2(2000);

  /*
  * 根据流程ID获取表单ID
  */
  FUNCTION func_get_process_form(p_process_id NUMBER) RETURN NUMBER;

  /*
  * 根据表单ID获取流程ID
  */
  FUNCTION func_get_form_process(p_form_id NUMBER) RETURN NUMBER;

  /*
  * 判断组件类型是否是否是数字类型组件
  */
  FUNCTION is_number_component(p_type varchar2) return varchar2;
  /*
  * 判断是否映射到标准字段的组件
  */
  function is_standard_component(p_type varchar2) return varchar2;
  /*
  * 判断是否映射文本域的组件--migrate by xiaowei.yao 20180411
  */
  FUNCTION is_textarea_component(p_type VARCHAR2) RETURN VARCHAR2;
  /*
  * 获取数据字典值名称
  */
  FUNCTION get_datasource_value_name(p_datasource_code VARCHAR2,
                                     p_value_code      VARCHAR2)
    RETURN VARCHAR2;

  /*
  * 获取当前语言
  */
  FUNCTION get_current_locale RETURN VARCHAR2;
  /*
  * 根据当前节点ID获取下级节点ID
  */
  FUNCTION get_next_node_id(p_node_id NUMBER) RETURN NUMBER; --migrate by xiaowei.yao 20180411
  /*
  * 更新文本域组件更新clob字段
  */
  procedure update_clob_component(code out varchar2); --migrate by xiaowei.yao 20180411

  /*==================================================
  Procedure/Function Name :
      func_get_task_url
  Description:
      This function perform:
      获取表单连接
  Argument:

  History:
      1.00  2018-06-07  wlj  Creation
  ==================================================*/
  function func_get_task_url(p_domain_url  varchar2,
                             p_instance_id varchar2,
                             p_form_key    varchar2,
                             p_task_id     varchar2,
                             p_params      varchar2,
                             p_sys_code    varchar2) return varchar2;
  /*==================================================
  Procedure/Function Name :
      func_instance_live_day
  Description:
      This function perform:
      获取流程执行的天数
  Argument:

  History:
      1.00  2018-06-25  wlj  Creation
  ==================================================*/
  function func_instance_live_day(p_instance_id varchar2) return number;

  /*==================================================
  Procedure/Function Name :
      func_string_split
  Description:
      This function perform:
      按照特殊分隔符拆分字符串为数组
      如：1234,234,321 --> [1234,234,321]
  Argument:
     p_list： 要拆分的字符串
     p_sep：  分隔符
  History:
      1.00  2018-08-31  xiaowei.yao  Creation
  ==================================================*/
  FUNCTION func_string_split(p_list VARCHAR2, p_sep VARCHAR2)
    RETURN type_split;
    /*==================================================
  Procedure/Function Name :
      proc_get_email_address
  Description:
      This function perform:
     根据工号查询邮件地址
  Argument:
       p_userCode   2018-10-13 12.00
     x_email_address 邮件地址


  History:
      1.00  2018-10-13 12.00  xiaowei.yao  Creation
  ==================================================*/
  procedure proc_get_email_address(p_userCode      in varchar,
                                   x_email_address out varchar,
                                   x_outadd        out varchar);

END dbpm_comm_pkg;

/

