create package dbpm_subprocess_pkg is

  -- author  : yaoshallwe
  -- created : 2019/6/14 10:23:54
  -- purpose : 子流程逻辑包
type type_string_list is table of varchar2(2000);

  /*==================================================
  procedure/function name :
      proc_get_sub_processid
  description:
      this function perform:
       查询子流程标志
  argument:
     p_instanceid：实例号
     x_processids： 子流程标志数组
  history:
      1.00  2019-06-14  xiaowei.yao  creation
  ==================================================*/

  procedure proc_get_sub_processid(p_instanceid in varchar2,
                                  x_chainuuids out type_array);
  /*==================================================
  procedure/function name :
      proc_get_subchain_nodes
  description:
      this function perform:
       查询子审批链详情
  argument:
     p_processid： 子流程id
     p_instanceid  流程实例
     x_nodeids： 审批节点数组
  history:
      1.00  2019-06-14  xiaowei.yao  creation
  ==================================================*/

  procedure proc_get_subchain_nodes(p_chainuuid  in varchar2,
                                   p_instanceid in varchar2,
                                   p_nodeid     in number,
                                   x_nodeids    out dbpm_sub_chainnode_tbl);
  /*==================================================
  procedure/function name :
      proc_get_node_detail
  description:
      this function perform:
       查询节点详情
  argument:
     p_nodeid： 审批节点id
     p_instanceid: 实例号
     x_nodeids： 审批节点数组
  history:
      1.00  2019-06-14  xiaowei.yao  creation
  ==================================================*/

  procedure proc_get_node_detail(p_nodeid          in number,
                                p_instanceid      in varchar2,
                                p_chainuuid       in varchar2,
                                x_node_id         out number,
                                x_node_type       out varchar2,
                                x_nodename        out varchar2,
                                x_node_formurl    out varchar2,
                                x_approvers       out varchar2,
                                x_proxy_rule      out varchar2,
                                x_proxy_approvers out varchar2,
                                x_process_param   out dbpm_process_param_rec,
                                x_business_param  out dbpm_business_param_tbl);
  /*
  * 获取审批链id
  */
  procedure proc_get_chain_id(p_node_id        number,
                              p_document_id    number,
                              p_process_param  dbpm_process_param_rec,
                              p_business_param dbpm_business_param_tbl,
                              x_chain_id       out number,
                              x_result_flag    out varchar2,
                              x_error_msg      out varchar2);


	procedure test_lsg(p_processid in String, x_chain out String);
end dbpm_subprocess_pkg;

/

