create PACKAGE BODY     dbpm_process_admins_pkg IS

  /*==================================================
  Procedure/Function Name :
      proc_query_emp_org
  Description:
      This function perform:
      查询员工信息（用户名，用户Code，部门名，部门ID）
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-09-29  张俊强~  Creation
  ==================================================*/
  PROCEDURE proc_query_emp_org(p_request  IN CLOB,
                               x_response OUT CLOB) IS
    v_api          VARCHAR2(100) := 'proc_query_emp_org';
    v_response     pl_json := pl_json;
    v_emp_org_json pl_json;
    CURSOR v_emp_org_cur IS
      SELECT df_emp.employee_code,
             df_emp.employee_name,
             df_org.organization_id,
             df_org.organization_name
        FROM dfnd_employees     df_emp,
             dfnd_organizations df_org,
             dfnd_org_employees df_org_emp
       WHERE upper(df_emp.employee_code) = upper(df_org_emp.employee_code)
         AND df_org_emp.organization_id = df_org.organization_code;
    v_total NUMBER := 0;
  BEGIN
    FOR v_emp_org IN v_emp_org_cur
    LOOP
      v_total        := v_total + 1;
      v_emp_org_json := pl_json;
      v_emp_org_json.set_value('employeeCode', v_emp_org.employee_code);
      v_emp_org_json.set_value('employeeName', v_emp_org.employee_name);
      v_emp_org_json.set_value('organizationId', v_emp_org.organization_id);
      v_emp_org_json.set_value('organizationName', v_emp_org.organization_name);
      v_response.add_list_item('emporg', v_emp_org_json);
    END LOOP;
    v_response.set_value('total', v_total);
    x_response := v_response.to_json;

/*  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_query_emp_org;

  /*==================================================
  Procedure/Function Name :
      proc_query_admins
  Description:
      This function perform:
      查询Admins信息
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-09-29  张俊强~  Creation
  ==================================================*/
  PROCEDURE proc_query_admins(p_request  IN CLOB,
                              x_response OUT CLOB) IS
    v_api        VARCHAR2(100) := 'proc_query_admins';
    v_response   pl_json := pl_json;
    v_admin_json pl_json;
    CURSOR v_admin_cur IS
      SELECT db_admin.administrator_id,
             db_admin.user_code,
             df_emp.employee_name,
             db_admin.organization_id,
             df_org.organization_name
        FROM dbpm_administrators db_admin,
             dfnd_employees      df_emp,
             dfnd_organizations  df_org
       WHERE upper(db_admin.user_code) = upper(df_emp.employee_code)
         AND db_admin.organization_id = df_org.organization_id;
    v_total NUMBER := 0;
  BEGIN
    FOR v_admin IN v_admin_cur
    LOOP
      v_total      := v_total + 1;
      v_admin_json := pl_json;
      v_admin_json.set_value('administratorId', v_admin.administrator_id);
      v_admin_json.set_value('employeeCode', v_admin.user_code);
      v_admin_json.set_value('employeeName', v_admin.employee_name);
      v_admin_json.set_value('organizationId', v_admin.organization_id);
      v_admin_json.set_value('organizationName', v_admin.organization_name);
      v_response.add_list_item('admins', v_admin_json);
    END LOOP;
    v_response.set_value('total', v_total);
    x_response := v_response.to_json;

/*  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_query_admins;

  /*==================================================
  Procedure/Function Name :
      proc_insert_admins
  Description:
      This function perform:
      插入员工信息到管理员表
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-09-29  张俊强~  Creation
  ==================================================*/
  PROCEDURE proc_insert_admins(p_request  IN CLOB,
                               x_response OUT CLOB) IS
    v_api      VARCHAR2(100) := 'proc_insert_admins';
    v_request  json;
    v_response pl_json := pl_json;
    emp_code   VARCHAR2(50);
    org_id     VARCHAR2(50);
  BEGIN
    -- 得到传入的参数
    v_request := json(p_request, 'OBJECT');
    emp_code  := v_request.get('employeeCode').get_string;
    org_id    := v_request.get('organizationId').get_string;

    INSERT INTO dbpm_administrators
      (administrator_id,
       user_code,
       organization_id,
       object_version_number,
       creation_date,
       created_by,
       last_updated_by,
       last_update_date)
    VALUES
      (dbpm_administrators_s.nextval, emp_code, org_id, '1', SYSDATE, 'weblogic', 'weblogic', SYSDATE);
    x_response := v_response.to_json;
    COMMIT;
/*  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_insert_admins;

  /*==================================================
  Procedure/Function Name :
      proc_delete_admins
  Description:
      This function perform:
      删除一条管理员信息
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-09-29  张俊强~  Creation
  ==================================================*/
  PROCEDURE proc_delete_admins(p_request  IN CLOB,
                               x_response OUT CLOB) IS
    v_api      VARCHAR2(100) := 'proc_delete_admins';
    v_request  json;
    v_response pl_json := pl_json;
    admin_id   NUMBER;
  BEGIN
    -- 得到传入的参数
    v_request := json(p_request, 'OBJECT');
    admin_id  := v_request.get('administratorId').get_number;

    DELETE FROM dbpm_administrators db_admin
     WHERE db_admin.administrator_id = admin_id;
    x_response := v_response.to_json;
    --COMMIT;
/*  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/

  END proc_delete_admins;

END dbpm_process_admins_pkg;

/

