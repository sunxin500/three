create PACKAGE     "DBPA_BA_CORE_PKG" is

  -- Author  : Echo.Zeng
  -- Created : 2018-01-11 09:00:00
  --TYPE
  type refcur is ref cursor;

  /*==================================================
  Procedure/Function Name :
      proc_plat_query_poc_counts
  Description:
      This function perform:
      获取各个系统的流程数量

  Argument:
     p_request      请求json
      {
          "user": "weblogic",
          "data":
          {
              "systemCode": ["HMQM", "GEMS"],
              "startDate": "2017-12-01 00:00:00",
              "endDate": "2018-01-01 00:00:00"
          }
      }
     x_response     响应json
      {
          "code": "SUCCESS",
          "data":
          {
              "systems": [
              {
                  "systemId": 1001,
                  "systemCode": "HMQM",
                  "systemName": "HMQM",
                  "processCount": 5000
              },
              {
                  "systemId": 1002,
                  "systemCode": "GEMS",
                  "systemName": "全球费用管理系统",
                  "processCount": 12000
              }]
          }
      }
  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  procedure proc_plat_query_poc_counts(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_plat_ins_counts
  Description:
      This function perform:
      获取各个系统的实例数量

  Argument:
     p_request      请求json
      {
          "user": "weblogic",
          "data":
          {
              "systemCode": ["HMQM", "GEMS"],
              "state": ["completed", "runing", "error"]
              "startDate": "2017-12-01",
              "endDate": "2018-01-01"
          }
      }
     x_response     响应json
        {
          "code": "SUCCESS",
          "data": {
            "systems": [{
                "systemId": 1001,
                "systemCode": "HMQM",
                "systemName": "HMQM",
                "instanceCount": [{
                    "code": "completed",
                    "count": 1000
                  }, {
                    "code": "runing",
                    "count": 1000
                  }, {
                    "code": "error",
                    "count": 1000
                  }
                ]
              }, {
                "systemId": 1002,
                "systemCode": "GEMS",
                "systemName": "全球费用管理系统",
                "instanceCount": [{
                    "code": "completed",
                    "count": 1000
                  }, {
                    "code": "runing",
                    "count": 1000
                  }, {
                    "code": "error",
                    "count": 1000
                  }
                ]
              }
            ]
          }
        }

  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  procedure proc_plat_ins_counts(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_plat_ins_counts_group
  Description:
      This function perform:
      获取单个系统在时间区间内的实例数量
      1. 如果选择小时，则维度取小时，传入时间段是某一天
      2. 如果选择天，则维度取天，传入时间段是多少天
      3. 如果选择周，则维度按周，传入时间段是多少天，每周一到周日算一周
      4、如果选择月，则按月统计，每月1号到月底

  Argument:
     p_request      请求json
      {
          "user": "weblogic",
          "data":
          {
              "systemCode": "HMQM",
              "state": ["completed", "runing", "error"],
              "group": "day",
              "startDate": "2017-12-01",
              "endDate": "2018-12-01"
          }

      }
     x_response     响应json
          {
            "code": "SUCCESS",
            "data": {
              "dimensionName": "月",
              "dimensionCode": "mon",
              "dimensionValues": [{
                  "dimensionValue": "1",
                  "instanceCount": [{
                      "code": "completed",
                      "count": 1000
                    }, {
                      "code": "runing",
                      "count": 1000
                    }, {
                      "code": "error",
                      "count": 1000
                    }
                  ]
                }, {
                  "dimensionValue": "2",
                  "instanceCount": [{
                      "code": "completed",
                      "count": 1000
                    }, {
                      "code": "runing",
                      "count": 1000
                    }, {
                      "code": "error",
                      "count": 1000
                    }
                  ]
                }
              ]
            }
          }
  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  procedure proc_plat_ins_counts_group(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_plat_systems
  Description:
      This function perform:
      获取系统的详细信息
      1. 如果传空，表示获取所有的系统
      2.支持批量查询

  Argument:
     p_request      请求json
        {
            "user": "weblogic",
            "data":
            {
                "systemCode": ["HMQM"],
                "status": "Y",
                "pageNo": 1,
                "size": 10
            }

        }
     x_response     响应json
        {
          "code": "SUCCESS",
          "data": {
            "systems": [{
                "systemId": 1001,
                "systemCode": "HMQM",
                "systemName": "HMQM",
                "industry": "690",
                "systemDesc": "",
                "status": "N",
                "creationDate": "2017-12-29",
                "createdBy": "weblogic",
                "updateDate": "2017-12-29",
                "updatedBy": "weblogic",
              }, {
                "systemId": 1001,
                "systemCode": "HMQM",
                "systemName": "HMQM",
                "industry": "690",
                "systemDesc": "",
                "status": "Y",
                "creationDate": "2017-12-29",
                "createdBy": "weblogic",
                "updateDate": "2017-12-29",
                "updatedBy": "weblogic",
              }
            ],
            "total": "10",
            "pageNo": "-1"
          }
        }
  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  procedure proc_plat_systems(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_index_ins_counts_group
  Description:
      This function perform:
      主界面获取实例趋势

  Argument:
     p_request      请求json
      {
          "user": "weblogic",
          "data":
          {
              "systemCode": "",
              "state": ["completed", "runing", "error"]
              "startDate": "2017-12-01",
              "endDate": "2018-01-01"
          }
      }
     x_response     响应json

  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  procedure proc_index_ins_counts_group(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_system_ins_counts
  Description:
      This function perform:
      获取单个系统的实例数量

  Argument:
     p_request      请求json
          {
              "user": "weblogic",
              "data":
              {
                  "systemCode": "HMQM",
                  "state": ["completed", "runing", "error"],
                  "startDate": "2017-12-29",
                  "endDate": "2017-12-31"

              }
          }
     x_response     响应json
                {
                  "code": "SUCCESS",
                  "data": {
                      "systemId": 12,
                      "systemCode": "SCI",
                      "systemName": "SCI",
                      "processes": [
                          {
                              "processCode": "王子",
                              "processName": "null",
                              "instanceCount": [
                                  {
                                      "code": "completed",
                                      "count": 0
                                  },
                                  {
                                      "code": "runing",
                                      "count": 0
                                  },
                                  {
                                      "code": "error",
                                      "count": 0
                                  }
                              ]
                          },
                          {
                              "processCode": "FQRP_KT",
                              "processName": "null",
                              "instanceCount": [
                                  {
                                      "code": "completed",
                                      "count": 0
                                  },
                                  {
                                      "code": "runing",
                                      "count": 18
                                  },
                                  {
                                      "code": "error",
                                      "count": 1
                                  }
                              ]
                          }
                      ]
                  }
              }

  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  procedure proc_system_ins_counts(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_system_ins_counts_group
  Description:
      This function perform:
      获取单个系统的实例数量

  Argument:
     p_request      请求json
          {
              "user": "weblogic",
              "data":
              {
                  "systemCode": "HMQM",
                  "state": ["completed", "runing", "error"],
                  "startDate": "2017-12-29",
                  "endDate": "2017-12-31"

              }
          }
     x_response     响应json
                {
                  "code": "SUCCESS",
                  "data": {
                      "systemId": 12,
                      "systemCode": "SCI",
                      "systemName": "SCI",
                      "processes": [
                          {
                              "processCode": "王子",
                              "processName": "null",
                              "instanceCount": [
                                  {
                                      "code": "completed",
                                      "count": 0
                                  },
                                  {
                                      "code": "runing",
                                      "count": 0
                                  },
                                  {
                                      "code": "error",
                                      "count": 0
                                  }
                              ]
                          },
                          {
                              "processCode": "FQRP_KT",
                              "processName": "null",
                              "instanceCount": [
                                  {
                                      "code": "completed",
                                      "count": 0
                                  },
                                  {
                                      "code": "runing",
                                      "count": 18
                                  },
                                  {
                                      "code": "error",
                                      "count": 1
                                  }
                              ]
                          }
                      ]
                  }
              }

  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  procedure proc_system_ins_counts_group(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_system_process_durtime
  Description:
      This function perform:
      获取单个系统的实例数量

  Argument:
     p_request      请求json
          {
              "user": "weblogic",
              "data":
                  {
                      "systemCode": "HMQM",
                      "startDate": "2017-12-01",
                      "endDate": "2017-12-01"
                  }
          }
     x_response     响应json
                {
                    "code": "SUCCESS",
                    "data":
                    {
                        "process": [
                        {
                            "processId": 1001,
                            "processCode": "BI_KT",
                            "processName": "DMC报表权限申请流程",
                            "duringTime": [
                            {
                                "code": "avg",
                                "count": 500
                            },
                            {
                                "code": "max",
                                "count": 1000
                            }]
                        },
                        {
                            "processId": 1001,
                            "processCode": "BI_KT",
                            "processName": "DMC报表权限申请流程",
                            "duringTime": [
                            {
                                "code": "avg",
                                "count": 500
                            },
                            {
                                "code": "max",
                                "count": 1000
                            }]
                        }]
                    }
                }
  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  procedure proc_system_process_durtime(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_system_duringtime_group
  Description:
      This function perform:
      获取单个系统的实例数量

  Argument:
     p_request      请求json
          {
              "user": "weblogic",
              "data":
                {
                  "processCode":"WEB-KT",
                  "group":"year",
                  "startDate":"2017-12-01",
                  "endDate":"2018-01-25"
                }

          }
     x_response     响应json
              {
                  "code": "SUCCESS",
                  "data": {
                      "processCode": "WEB-KT",
                      "systemId": 12,
                      "systemCode": "SCI",
                      "systemName": "SCI",
                      "dimensionName": "年",
                      "dimensionCode": "year",
                      "dimensionValues": [
                          {
                              "dimensionValue": "2017",
                              "duringTime": [
                                  {
                                      "code": "max",
                                      "name": "最大时间",
                                      "count": 4.99
                                  },
                                  {
                                      "code": "avg",
                                      "name": "平均时间",
                                      "count": 0.15
                                  }
                              ]
                          },
                          {
                              "dimensionValue": "2018",
                              "duringTime": [
                                  {
                                      "code": "max",
                                      "name": "最大时间",
                                      "count": 19.73
                                  },
                                  {
                                      "code": "avg",
                                      "name": "平均时间",
                                      "count": 2.99
                                  }
                              ]
                          }
                      ]
                  }
              }
  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  procedure proc_system_duringtime_group(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_system_duringtime_group
  Description:
      This function perform:
      获取流程信息

  Argument:
     p_request      请求json
          {
              "user": "weblogic",
              "data":
                {
                    "systemCode":"GEMS",
                    "queryKey":"dada",
                    "pageNo":1,
                    "size":10
                }

          }
     x_response     响应json

  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  procedure proc_system_query_process(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_process_act_ins_counts
  Description:
      This function perform:
      获取单个系统的实例数量

  Argument:
     p_request      请求json
        {
          "processCode":"BI_KT",
          "startDate":"2017-12-29",
          "endDate":"2017-12-31"
        }
    p_response      响应json
          {
            "code": "SUCCESS",
            "data": {
              "processCode": "BI_KT",
              "processName": "DMC报表分析平台",
              "activities": [{
                  "activityCode": "file_up",
                  "activityName": "审核文件上传",
                  "activityType": "task",
                  "instanceCounts": [{
                      "code": "completed",
                      "name": "已完成",
                      "count": 1000
                    }, {
                      "code": "runing",
                      "name": "已完成",
                      "count": 1000
                    }, {
                      "code": "error",
                      "name": "已完成",
                      "count": 1000
                    }
                  ]
                }, {
                  "activityCode": "file_up",
                  "activityName": "审核文件上传",
                  "activityType": "task",
                  "instanceCounts": [{
                      "code": "completed",
                      "name": "已完成",
                      "count": 1000
                    }, {
                      "code": "runing",
                      "name": "已完成",
                      "count": 1000
                    }, {
                      "code": "error",
                      "name": "已完成",
                      "count": 1000
                    }
                  ]
                }
              ]
            }
          }

  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  procedure proc_process_act_ins_counts(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_process_act_ins_counts
  Description:
      This function perform:
      获取单个系统的实例数量

  Argument:
     p_request      请求json
            {
                "user": "a0017702",
                "data":
                  {
                      "processCode": "BI_KT"
                      "activityCode": "fileUp",
                      "state": ["completed", "runing", "error"],
                      "group": "day",
                      "startDate": "2017-12-01",
                      "endDate": "2018-12-01"
                  }
            }
    p_response      响应json
                {
                  "code": "SUCCESS",
                  "data": {
                    "activityCode": "BI_KT",
                    "activityName": "",
                    "activityType": "DMC",
                    "processCode": "process",
                    "processName": "DMC报表权限申请流程",
                    "dimensionName": "月",
                    "dimensionCode": "mon",
                    "dimensionValues": [{
                      "dimensionValue": "1",
                      "instanceCounts": [{
                        "code": "completed",
                        "name": "已完成",
                        "count": 1000
                      }, {
                        "code": "runing",
                        "name": "进行中",
                        "count": 1000
                      }, {
                        "code": "error",
                        "name": "异常",
                        "count": 1000
                      }]
                    }, {
                      "dimensionValue": "2",
                      "instanceCounts": [{
                        "code": "completed",
                        "name": "已完成",
                        "count": 1000
                      }, {
                        "code": "runing",
                        "name": "进行中",
                        "count": 1000
                      }, {
                        "code": "error",
                        "name": "异常",
                        "count": 1000
                      }]
                    }]
                  }
                }
  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  procedure proc_proact_ins_counts_group(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_process_act_duringtime
  Description:
      This function perform:
      获取单个系统的实例数量

  Argument:
     p_request      请求json
            {
                "user": "a0017702",
                "data":
                  {
                      "processCode": "BI_KT",
                      "startDate": "2017-12-29",
                      "endDate": "2017-12-31"
                  }
            }
    p_response      响应json
              {
                "code": "SUCCESS",
                "data": {
                  "processCode": "test",
                  "processName": "dada",
                  "activities": [{
                      "activityName": "审批文件上传",
                      "activityType": "task",
                      "duringTime": [{
                          "code": "avg",
                          "count": 1000
                        },
                        {
                          "code": "max",
                          "count": 1000
                        }
                      ]
                    },
                    {
                      "activityName": "审批文件上传",
                      "activityType": "task",
                      "duringTime": [{
                          "code": "avg",
                          "count": 1000
                        },
                        {
                          "code": "max",
                          "count": 1000
                        }
                      ]
                    }
                  ]
                }
              }
  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  procedure proc_process_act_duringtime(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_process_act_dur_group
  Description:
      This function perform:
      获取单个系统的实例数量

  Argument:
     p_request      请求json
                    {
                        "user": "a0017702",
                        "data":
                          {
                              "systemCode": "cccc"
                              "processCode": "BI_KT"
                              "activityCode": "fileUp",
                              "group": "day",
                              "startDate": "2017-12-01",
                              "endDate": "2018-12-01"
                          }
                    }
    p_response      响应json
              {
                "code": "SUCCESS",
                "data": {
                  "activityCode": "BI_KT",
                  "activityName": "",
                  "activityType": "DMC",
                  "processCode": "process",
                  "processName": "DMC报表权限申请流程",
                  "dimensionName": "月",
                  "dimensionCode": "mon",
                  "dimensionValues": [{
                    "dimensionValue": "1",
                    "duringTimes": [{
                      "code": "max",
                      "name": "最大时间",
                      "count": 1000
                    }, {
                      "code": "avg",
                      "name": "平均时间",
                      "count": 1000
                    }]
                  }, {
                    "dimensionValue": "2",
                    "instanceCounts": [{
                      "code": "max",
                      "name": "最大时间",
                      "count": 1000
                    }, {
                      "code": "avg",
                      "name": "平均时间",
                      "count": 1000
                    }]
                  }]
                }
              }
  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  procedure proc_process_act_dur_group(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_process_query_acts
  Description:
      This function perform:
      获取流程信息

  Argument:
     p_request      请求json
          {
              "user": "weblogic",
              "data":
                {
                    "queryKey": "",
                    "processCode": "",
                    "systemCode": ""
                }
          }
     x_response     响应json
          {
              "code": "SUCCESS",
              "data":
              {
                  "processCode": "BI_KT",
                  "processName": "流程名称",
                  "activities": [
                  {
                      "activityCode": "file_up",
                      "activityName": "审核文件上传",
                      "activityType": "task"
                  },
                  {
                      "activityCode": "file_up",
                      "activityName": "审核文件上传",
                      "activityType": "task"
                  }]
              }
          }
  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  procedure proc_process_query_acts(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_task_duringtime
  Description:
      This function perform:
      获取单个系统的实例数量

  Argument:
     p_request      请求json
                    {
                        "user": "a0017702",
                        "data":
                          {
                            "systemCode":"DMC",
                            "processCode":"",
                            "startDate":"2017-12-29",
                            "endDate":"2017-12-31",
                            "orderType":"desc",
                            "size":100
                          }
                    }
    p_response      响应json
                    {
                        "code": "SUCCESS",
                        "data":
                        {
                            "processCode": "JYBZ",
                            "processName": "JYBZ",
                            "activities": [
                            {
                                "activityCode":"",
                                "activityName": "审批文件上传",
                                "approver": "09810938",
                                "approverName": "",
                                "avgDuringtime": "201"
                            },
                            {
                                "activityCode":"",
                                "activityName": "审批文件上传",
                                "approver": "09810938",
                                "approverName": "",
                                "avgDuringtime": "201"
                            }]
                        }
                    }

  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  procedure proc_task_duringtime(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_task_user_duringtime
  Description:
      This function perform:
      获取流程任务节点某个用户审批时间最长/最短的TOP10任务

  Argument:
     p_request      请求json
                    {
                        "user": "a0017702",
                        "data":
                            {
                              "systemCode":"DMC",
                              "processCode":"",
                              "activityCode":"",
                              "startDate":"2017-12-29",
                              "endDate":"2017-12-31",
                              "orderType":"desc",
                              "approver":"",
                              "size":100
                            }
                    }
    p_response      响应json
                    {
                        "code": "SUCCESS",
                        "data":
                        {
                            "processCode":"",
                            "processName":"",
                            "activities": [
                            {
                                "activityName": "审批文件上传",
                                "activityType": "task",
                                "approver": "09810938",
                                "approverName": "",
                                "taskId": "",
                                "instanceId": "",
                                "formNo":"",
                                "approveTime":"2017-06-05 16:00:00",
                                "duringTime": "201"
                            },
                            {
                                "activityName": "审批文件上传",
                                "activityType": "task",
                                "approver": "09810938",
                                "approverName": "",
                                "taskId": "",
                                "instanceId": "",
                                "formNo":"",
                                "approveTime":"2017-06-05 16:00:00",
                                "duringTime": "201"
                            }]
                        }
                    }
  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  procedure proc_task_user_duringtime(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_query_data_source_values
  Description:
      This function perform:
      动态查询数据源的值
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-02-01  Echo.Zeng  Creation
  ==================================================*/
  PROCEDURE proc_query_data_source_values(p_request  CLOB,
                                          x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      func_get_data_value
  Description:
      This function perform:
      获取数据字典中的值

  Argument:
     --入参
     p_data_source_code 数据源编号
     p_value_code       值编号
     --出参

  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  function func_get_data_value(p_data_source_code in varchar2,p_value_code in varchar2) return varchar2;

  /*==================================================
  Procedure/Function Name :
      func_check_date
  Description:
      This function perform:
      检查日期：
      1、日期格式
      2、结束日期必须大于开始日期
  Argument:
     --入参
     p_start_date   开始日期
     p_end_date     结束日期
     p_date_format  日期格式
     --出参
     boolean 是否正确
  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  function func_check_date(p_start_date in varchar2,p_end_date in varchar2,p_date_format in varchar2) return boolean;

  /*==================================================
  Procedure/Function Name :
      func_get_date_group
  Description:
      This function perform:
      获取日期组


  Argument:
     --入参
     p_group_code       组编号
     --出参
     组format值
  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  function func_get_date_group(p_group_code in varchar2,p_start_date in varchar2,p_end_date in varchar2,p_date_fmt in varchar2) return json_list;
end DBPA_BA_CORE_PKG;

/

