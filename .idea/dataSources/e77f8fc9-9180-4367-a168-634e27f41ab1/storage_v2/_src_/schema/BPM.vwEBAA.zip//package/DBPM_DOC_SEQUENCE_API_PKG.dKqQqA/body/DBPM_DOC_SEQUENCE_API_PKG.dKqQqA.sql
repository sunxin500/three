create PACKAGE BODY     dbpm_doc_sequence_api_pkg IS

  /*==================================================
  Procedure/Function Name :
      proc_query_doc_sequences
  Description:
      This function perform:
      查询流水码管理
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-05-13  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_query_doc_sequences(p_request CLOB, x_response OUT CLOB) IS
    v_response          pl_json := pl_json;
    v_request           json;
    v_sequence_json     pl_json;
    v_space_id          varchar2(100);
    v_current_user      varchar2(30);
    v_super_admin_count number;
    --分页
    v_total NUMBER := 0;
    v_size  number := 20;
    v_page  number := 1;
    --查询条件
    v_filter json;
    --V_documentType   varchar2(500);
    V_documentName   varchar2(4000);
    V_description    varchar2(500);
    v_prefix         varchar2(500);
    v_suffix         varchar2(500);
    v_startSequence  varchar2(500);
    v_sequenceLength varchar2(500);
    v_sort_col       varchar2(500);
    v_sort           json;
    CURSOR v_sequences_cur IS
      SELECT *
        FROM (SELECT v.*, rownum cnt
                FROM (SELECT COUNT(1) OVER(PARTITION BY 1) TOTAL, dds.*
                        FROM (select dp.process_name,
                                     t.*,
                                     dcld_comm_pkg.get_lookup_meaning('SEQUENCE_CLEAR_FLAG',T.CLEAR_FLAG,v_request.locale) clear_meaning
                                from DBPM_DOCUMENT_SEQUENCES t,
                                     dbpm_process            dp
                               where t.document_type = dp.process_code(+)) dds
                       WHERE NVL(DDS.SPACE_ID, 'NL') =
                             NVL(v_space_id, NVL(DDS.SPACE_ID, 'NL'))
                         and INSTR(NVL(DDS.process_name, 'NL'),
                                   NVL(V_documentName,
                                       NVL(DDS.process_name, 'NL'))) > 0
                         AND INSTR(NVL(DDS.DESCRIPTION, 'NL'),
                                   NVL(V_description,
                                       NVL(DDS.DESCRIPTION, 'NL'))) > 0
                         AND INSTR(NVL(DDS.Prefix, 'NL'),
                                   NVL(v_prefix, NVL(DDS.Prefix, 'NL'))) > 0
                         and INSTR(NVL(DDS.Suffix, 'NL'),
                                   NVL(v_suffix, NVL(DDS.Suffix, 'NL'))) > 0
                         AND INSTR(NVL(to_char(DDS.NEXT_SEQUENCE), 'NL'),
                                   NVL(v_startSequence,
                                       NVL(to_char(DDS.NEXT_SEQUENCE), 'NL'))) > 0
                         AND INSTR(NVL(to_char(DDS.SEQUENCE_LENGTH), 'NL'),
                                   NVL(v_sequenceLength,
                                       NVL(to_char(DDS.SEQUENCE_LENGTH), 'NL'))) > 0
                       ORDER BY decode(v_sort_col,
                                       'document_name_desc',
                                       dds.process_name,
                                       'description_desc',
                                       dds.description) DESC,
                                decode(v_sort_col,
                                       'document_name_asc',
                                       dds.process_name,
                                       'description_asc',
                                       dds.description) ASC,
                                dds.creation_date desc) v
               WHERE rownum <= v_page * v_size)
       WHERE cnt > (v_page - 1) * v_size;
  BEGIN
    v_request := json(p_request, 'OBJECT');
    if v_request.exist('page') then
      v_page := v_request.get_number('page');
    end if;
    if v_request.exist('size') then
      v_size := v_request.get_number('size');
    end if;
    /*   if v_request.exist('filter') then
      v_filter := json(v_request.get('filter'));
      --V_documentType   := v_filter.get_string('documentType');
      V_documentName   := v_filter.get_string('documentName');
      V_description    := v_filter.get_string('description');
      v_prefix         := v_filter.get_string('prefix');
      v_suffix         := v_filter.get_string('suffix');
      v_startSequence  := v_filter.get_string('nextSequence');
      v_sequenceLength := v_filter.get_string('sequenceLength');
    end if;*/
    V_documentName   := dcld_comm_pkg.get_filter_value('documentName',
                                                       v_request);
    V_description    := dcld_comm_pkg.get_filter_value('description',
                                                       v_request);
    v_prefix         := dcld_comm_pkg.get_filter_value('prefix', v_request);
    v_suffix         := dcld_comm_pkg.get_filter_value('suffix', v_request);
    v_startSequence  := dcld_comm_pkg.get_filter_value('nextSequence',
                                                       v_request);
    v_sequenceLength := dcld_comm_pkg.get_filter_value('sequenceLength',
                                                       v_request);
    if v_request.exist('sort') then
      v_sort     := json(v_request.get('sort'));
      v_sort_col := v_sort.get_string('value');
      v_sort_col := v_sort_col || '_' || v_sort.get_string('order');
    end if;
    v_current_user := v_request.username;
    v_space_id     := v_request.get_string('spaceId');
    if v_space_id is null then
      v_space_id := DFND_ADMIN_PKG.func_get_space_id(v_current_user);
    end if;
    --如果未找到company_id,设置company_id为-1
    --如果是超级管理员,设置company_id为null
    select count(1)
      into v_super_admin_count
      from dbpm_administrators t
     where t.user_code = v_current_user
       and t.admin_type = 'SuperAdmin';
    if v_space_id is null then
      v_space_id := '-';
    end if;
    if v_super_admin_count > 0 then
      v_space_id := null;
    end if;

    FOR v_sequence IN v_sequences_cur LOOP
      v_sequence_json := pl_json;
      v_sequence_json.set_value('documentType', v_sequence.document_type);
      v_sequence_json.set_value('documentName', v_sequence.process_name);
      v_sequence_json.set_value('description', v_sequence.description);
      v_sequence_json.set_value('prefix', v_sequence.prefix);
      v_sequence_json.set_value('suffix', v_sequence.suffix);
      v_sequence_json.set_value('startSequence', v_sequence.start_sequence);
      v_sequence_json.set_value('endSequence', v_sequence.end_sequence);
      v_sequence_json.set_value('nextSequence', v_sequence.next_sequence);
      v_sequence_json.set_value('sequenceLength',
                                v_sequence.sequence_length);
      v_total := v_sequence.total;
      v_sequence_json.set_value('clearFlag', v_sequence.clear_flag);
      v_sequence_json.set_value('clearFlagMeaning',
                                v_sequence.clear_meaning);
      /*      IF v_sequence.is_clear_day = 'Y' THEN
        v_sequence_json.set_value('isClearDay', TRUE);
      ELSE
        v_sequence_json.set_value('isClearDay', FALSE);
      END IF;
      IF v_sequence.is_clear_month = 'Y' THEN
        v_sequence_json.set_value('isClearMonth', TRUE);
      ELSE
        v_sequence_json.set_value('isClearMonth', FALSE);
      END IF;
      IF v_sequence.is_clear_year = 'Y' THEN
        v_sequence_json.set_value('isClearYear', TRUE);
      ELSE
        v_sequence_json.set_value('isClearYear', FALSE);
      END IF;*/

      v_response.add_list_item('docSequeceList', v_sequence_json);
    END LOOP;
    v_response.set_value('total', v_total);
    x_response := v_response.to_json;
  END proc_query_doc_sequences;

  /*==================================================
  Procedure/Function Name :
      proc_save_doc_sequence
  Description:
      This function perform:
      保存流水码，需要判断是新增还是修改
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-20  skycloud.wang  Creation
      2.00  2018-02-08  wlj  modified  更改清零实现的方式
  ==================================================*/
  PROCEDURE proc_save_doc_sequence(p_request IN CLOB, x_response OUT CLOB) IS
    v_api           VARCHAR2(30) := 'proc_save_doc_sequence';
    v_request       json;
    v_response      pl_json := pl_json;
    v_document_type VARCHAR2(100);
    v_current_user  VARCHAR2(50);
    --v_is_clear_day   VARCHAR2(10);
    --v_is_clear_month VARCHAR2(10);
    --v_is_clear_year  VARCHAR2(10);
    v_date_code  VARCHAR2(30);
    v_count      NUMBER;
    v_space_id   number; --所属space
    v_clear_flag varchar2(100); --清零标志(DAY/MONTH/YEAR/NONE) add by wlj
  BEGIN
    v_request       := json(p_request, 'OBJECT');
    v_current_user  := v_request.username;
    v_document_type := v_request.get('documentType').get_string;
    v_space_id      := v_request.get_string('spaceId');
    v_clear_flag    := v_request.get_string('clearFlag');
    v_date_code     := '';
    if v_space_id is null then
      v_space_id := DFND_ADMIN_PKG.func_get_space_id(v_current_user);
    end if;

    /*IF v_request.get('isClearYear').get_bool THEN
      v_is_clear_year := 'Y';
      v_date_code     := to_char(SYSDATE, 'YYYY');
    ELSE
      v_is_clear_year := 'N';
    END IF;

    IF v_request.get('isClearMonth').get_bool THEN
      v_is_clear_month := 'Y';
      v_date_code      := to_char(SYSDATE, 'YYYYMM');
    ELSE
      v_is_clear_month := 'N';
    END IF;

    IF v_request.get('isClearDay').get_bool THEN
      v_is_clear_day := 'Y';
      v_date_code    := to_char(SYSDATE, 'YYYYMMDD');
    ELSE
      v_is_clear_day := 'N';
    END IF;*/

    SELECT DECODE(v_clear_flag,
                  'DAY',
                  'DAY',
                  'MONTH',
                  'MONTH',
                  'YEAR',
                  'YEAR',
                  'NONE')
      INTO v_clear_flag
      FROM DUAL;

    --查询是否存在该角色
    SELECT COUNT(1)
      INTO v_count
      FROM dbpm_document_sequences dds
     WHERE dds.document_type = v_document_type;

    IF v_count = 0 THEN
      INSERT INTO dbpm_document_sequences
        (document_type,
         description,
         prefix,
         suffix,
         start_sequence,
         end_sequence,
         next_sequence,
         sequence_length,
         /* is_clear_day,
         is_clear_month,
         is_clear_year,*/
         date_code,
         created_by,
         last_updated_by,
         SPACE_ID,
         clear_flag)
      VALUES
        (v_document_type,
         v_request.get  ('description'  ).get_string,
         v_request.get  ('prefix'  ).get_string,
         v_request.get  ('suffix'  ).get_string,
         v_request.get  ('startSequence'  ).get_number,
         v_request.get  ('endSequence'  ).get_number,
         v_request.get  ('nextSequence'  ).get_number,
         v_request.get  ('sequenceLength'  ).get_number,
         /*v_is_clear_day,
         v_is_clear_month,
         v_is_clear_year,*/
         v_date_code,
         v_current_user,
         v_current_user,
         v_space_id,
         v_clear_flag);
    ELSE
      UPDATE dbpm_document_sequences dds
         SET dds.description     = v_request.get('description').get_string,
             dds.prefix          = v_request.get('prefix').get_string,
             dds.suffix          = v_request.get('suffix').get_string,
             dds.start_sequence  = v_request.get('startSequence').get_number,
             dds.end_sequence    = v_request.get('endSequence').get_number,
             dds.next_sequence   = v_request.get('nextSequence').get_number,
             dds.sequence_length = v_request.get('sequenceLength').get_number,
             /*dds.is_clear_day          = v_is_clear_day,
             dds.is_clear_month        = v_is_clear_month,
             dds.is_clear_year         = v_is_clear_year,*/
             dds.clear_flag            = v_clear_flag,
             dds.object_version_number = dds.object_version_number + 1,
             dds.last_updated_by       = v_current_user
       WHERE dds.document_type = v_document_type;
    END IF;

    x_response := v_response.to_json;
    /* EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_save_doc_sequence;

  /*==================================================
  Procedure/Function Name :
      proc_del_doc_sequence
  Description:
      This function perform:
      删除流水码
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-05-13  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_del_doc_sequence(p_request IN CLOB, x_response OUT CLOB) IS
    v_api           VARCHAR2(30) := 'proc_del_doc_sequence';
    v_request       json;
    v_response      pl_json := pl_json;
    v_document_type VARCHAR2(100);
  BEGIN
    v_request       := json(p_request, 'OBJECT');
    v_document_type := v_request.get('documentType').get_string;

    DELETE FROM dbpm_document_sequences dds
     WHERE dds.document_type = v_document_type;
    x_response := v_response.to_json;
    /* EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_del_doc_sequence;

END dbpm_doc_sequence_api_pkg;

/

