create PACKAGE BODY     "DBPM_PROCESS_NODE_API_PKG" IS

  /*==================================================
  Procedure/Function Name :
      proc_query_process_nodes
  Description:
      This function perform:
      查询流程节点
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-05-17  skycloud.wang  Creation
      2.00 2019-02-18   xiaowei.yao update
  ==================================================*/
  PROCEDURE proc_query_process_nodes(p_request CLOB, x_response OUT CLOB) IS
    v_request          json;
    v_response         pl_json := pl_json;
    v_process_id       NUMBER;
    v_node_json        pl_json;
    v_businessroles    pl_json;
    v_item             pl_json;
    v_paramlist        pl_json;
    v_node_chain       pl_json;
     v_row pl_json;
    v_data_source_code varchar2(300) := 'DbpmGetApproversType'; --update by Echo.Zeng 2017-12-07
    CURSOR v_process_node_cur(p_process_id NUMBER) IS
      SELECT dpn.*,
             (SELECT dcld_comm_pkg.get_data_source_value('DbpmNodeType',
                                                         ddsv.value_code,
                                                         v_request.locale) value_name
                FROM dbpm_data_source_values ddsv
               WHERE ddsv.value_code = dpn.node_type
                 AND ddsv.data_source_code = 'DbpmNodeType') node_type_name
        FROM dbpm_process_nodes dpn
       WHERE dpn.process_id = p_process_id
       ORDER BY dpn.order_num ASC; --Add by xuy 20170913
    --节点国际化值
    cursor v_itl_cur(p_node_id NUMBER) is
      select *
        from dbpm_process_nodes_tl dnt
       where dnt.node_id = p_node_id;
    --节点服务
    cursor v_service_cur(p_node_id NUMBER) is
      select dm.invoke_stage,
             ds.service_name,
             dm.invoke_order,
             dm.service_id,
             dm.service_req
        from dbpm_nodes_service_map dm, dbpm_service ds
       where ds.id = dm.service_id
         and dm.node_id = p_node_id;
    ---节点邮件
    cursor v_email_cur(p_node_id NUMBER) is
      select dm.send_stage,
             dm.email_name,
             dm.content,
             dm.email_id,
             dm.recipients,
             dm.recipients_type
        from dbpm_nodes_email_map dm
       where dm.node_id = p_node_id;

    --节点超期规则
    cursor v_expires_cur(p_node_id number) is
      select *
        from dbpm_process_expire_rule dr
       where dr.node_id = p_node_id
       and dr.rule_type='TASK';

    --节点业务数据
    cursor v_businessdata_cur(p_node_id NUMBER) is
      select db.business_code, db.business_name, db.business_content
        from dbpm_nodes_businessdata db
       where db.node_id = p_node_id;
    CURSOR v_role_cur(p_node_id NUMBER) IS
      SELECT dnr.business_role,
             dnr.node_role_id,
             dr.role_id,
             dr.role_name,
             dnr.custom_role_name
        FROM dbpm_node_roles dnr, dbpm_roles dr
       WHERE dnr.node_id = p_node_id
         AND dnr.business_role = dr.role_code
         AND dnr.node_from_type = 'ProcessNode';
    CURSOR v_param_cur(p_node_role_id NUMBER) IS
      SELECT dnrp.param_id,
             dnrp.param_value,
             drp.param_name,
             dnrp.operation_type, --migrate by xiaowei.yao 20180512
             dnrp.get_value_type
        FROM dbpm_node_role_param_value dnrp,
             dbpm_node_roles            dnr,
             dbpm_role_params           drp
       WHERE dnrp.node_role_id = dnr.node_role_id
         AND dnrp.param_id = drp.param_id
         AND dnrp.node_role_id = p_node_role_id;
    --migrate by xiaowei.yao begin 子审批链逻辑
    CURSOR v_chain_cur(p_node_id NUMBER, p_process_id NUMBER) IS
      SELECT dac.chain_id,
             dac.chain_name,
             (CASE
               WHEN dnc.chain_id IS NULL THEN
                'N'
               ELSE
                'Y'
             END) is_checked
        FROM dbpm_node_chains dnc, dbpm_approval_chain dac
       WHERE dnc.node_id = p_node_id
         AND dnc.chain_id = dac.chain_id
         AND dac.process_id = p_process_id
         AND dnc.node_from_type = 'ProcessNode'
         AND dac.chain_type = 'SubProcess';
    --migrate by xiaowei.yao end
    --add by echo.zeng begin
    CURSOR v_static_user_cur(p_node_id NUMBER) IS
      SELECT t.dynamic_value, t.get_value_type
        FROM dbpm_dynamic_approvers t
       where t.node_id = p_node_id
         and t.get_value_type = 'STATIC';
    v_approver_users varchar2(3000);
    v_dynamic_value  varchar2(3000);
    CURSOR v_user_list_cur(p_node_id NUMBER) IS
      select * from cux_bpm_common_rule t where t.node_id = p_node_id;
    v_sql_user   pl_json;
    v_type_split type_split;
    v_approves   json_list;
    --add by echo.zeng end
    --add by chenzhibin begin
    cursor v_dynamic_user_cur(p_node_id number) is
      select t.dynamic_value, t.get_value_type
        from DBPM_DYNAMIC_APPROVERS t
       where t.node_id = p_node_id
         and t.get_value_type <> 'STATIC';
    v_dynamic_user pl_json;
    v_static_user  pl_json;
    --add by chenzhibin end
  BEGIN
    v_request    := json(p_request, 'OBJECT');
    v_process_id := v_request.get('processId').get_number;
    v_response.set_value('processId', v_process_id);
    FOR v_node IN v_process_node_cur(v_process_id) LOOP
      v_node_json := pl_json;
      v_node_json.set_value('nodeId', v_node.node_id);
      v_node_json.set_value('nodeName', v_node.node_name);
      v_node_json.set_value('nodeType', v_node.node_type);
      v_node_json.set_value('nodeTypeName', v_node.node_type_name);
      v_node_json.set_value('approverType', v_node.approver_type);
      v_node_json.set_value('nodeFormUrl', v_node.node_formurl);
      v_node_json.set_value('orderNum', v_node.order_num);
      v_node_json.set_value('backNodeId', v_node.back_node_id);
      --migrate by  xiaowei.yao 20180512 begin
      IF v_node.is_required = 'Y' THEN
        --add by wlj
        v_node_json.set_value('isRequired', TRUE);
      ELSE
        v_node_json.set_value('isRequired', FALSE);
      END IF;
      IF v_node.is_auto_approve = 'Y' THEN
        --add by wlj
        v_node_json.set_value('isAutoApprove', TRUE);
      ELSE
        v_node_json.set_value('isAutoApprove', FALSE);
      END IF;
      IF v_node.email_flag = 'Y' THEN
        --add by yxw
        v_node_json.set_value('isSendMail', TRUE);
      ELSE
        v_node_json.set_value('isSendMail', FALSE);
      END IF;

      FOR v_role IN v_role_cur(v_node.node_id) LOOP
        v_businessroles := pl_json;
        v_businessroles.set_value('roleId', v_role.role_id);
        v_businessroles.set_value('roleCode', v_role.business_role);
        v_businessroles.set_value('roleName', v_role.role_name);
        v_businessroles.set_value('customRoleName',
                                  v_role.custom_role_name); --migrate by xiaowei.yao 20180512
        FOR v_param IN v_param_cur(v_role.node_role_id) LOOP
          v_paramlist := pl_json;
          v_paramlist.set_value('getValueType', v_param.get_value_type);
          v_paramlist.set_value('paramId', v_param.param_id);
          v_paramlist.set_value('paramName', v_param.param_name);
          v_paramlist.set_value('paramValue', v_param.param_value);
          v_paramlist.set_value('operationType', v_param.operation_type); --migrate by xiaowei.yao 20180512
          v_businessroles.add_list_item('paramList', v_paramlist);
        END LOOP;

        v_node_json.add_list_item('businessRoles', v_businessroles);
      END LOOP;
      --节点国际化值 add by xiaowei
      FOR v_it IN v_itl_cur(v_node.node_id) LOOP
        v_item := pl_json;
        v_item.set_value('lang', v_it.node_name);
        v_item.set_value('locale', v_it.locale);
        -- v_itls.add_list_item('nodeNametl', v_item);
        v_node_json.add_list_item('nodeNametl', v_item);
      END LOOP;
      ---节点服务 add by xiaowei
      for v_ser_row in v_service_cur(v_node.node_id) loop
        v_item := pl_json;
        v_item.set_value('serviceName', v_ser_row.service_name);
        v_item.set_value('serviceId', v_ser_row.service_id);
        v_item.set_value('invokeStage', v_ser_row.invoke_stage);
        v_item.set_value('invokeOrder', v_ser_row.invoke_order);
        v_item.set_value('serviceReq', json(v_ser_row.service_req));
        v_node_json.add_list_item('services', v_item);
      end loop;
      ---节点邮件 add by xiaowei
      for v_email_row in v_email_cur(v_node.node_id) loop
        v_item := pl_json;
        v_item.set_value('emailName', v_email_row.email_name);
        v_item.set_value('sendStage', v_email_row.send_stage);
        v_item.set_value('content', json(v_email_row.content));
        v_item.set_value('emailId', v_email_row.email_id);
        v_item.set_value('recipients', v_email_row.recipients);
        v_item.set_value('recipientsType', v_email_row.recipients_type);
        v_node_json.add_list_item('emails', v_item);
      end loop;
      ---节点业务数据 add by xiaowei
      for v_business_row in v_businessdata_cur(v_node.node_id) loop
        v_item := pl_json;
        v_item.set_value('businessCode', v_business_row.business_code);
        v_item.set_value('businessName', v_business_row.business_name);
        v_item.set_value('businessContent',
                         v_business_row.business_content);
        v_node_json.add_list_item('bussinessDatas', v_item);
      end loop;
       --节点超期规则
     for v_expire_row in v_expires_cur(v_node.node_id) loop
      v_row := pl_json;
      v_row.set_value('ruleUuid', v_expire_row.rule_uuid);
      v_row.set_value('paramName', v_expire_row.param_name);
      v_row.set_value('paramMeaning', v_expire_row.param_meaning);
      v_row.set_value('deloyDay', v_expire_row.deloy_day);
      v_row.set_value('paramValue', v_expire_row.param_value);
      v_row.set_value('startTime', v_expire_row.start_time);
      v_row.set_value('endTime', v_expire_row.end_time);
      v_row.set_value('warningDur', v_expire_row.warning_dur);
      v_row.set_value('warningNum', v_expire_row.warning_num);
      v_node_json.add_list_item('expires', v_row);
       end loop;
      --add by chenzhibin begin
      for v_dynamic In v_dynamic_user_cur(v_node.node_id) loop
        v_dynamic_user := pl_json;
        v_dynamic_user.set_value('getValueType', v_dynamic.get_value_type);
        if v_dynamic.get_value_type = 'SQL' then
          for v_row in v_user_list_cur(v_node.node_id) loop
            v_sql_user := pl_json;
            v_sql_user.set_value('rule', v_row.rule_expression);
            v_sql_user.set_value('getValueType', v_row.get_value_type);
            v_type_split := func_string_split(v_row.rule_value, ',');
            v_approves   := json_list;
            for i in 1 .. v_type_split.count loop
              v_approves.append(v_type_split(i));
            end loop;
            v_sql_user.set_value('approverList', v_approves);
            v_dynamic_user.add_list_item('sqlUsers', v_sql_user);
          end loop;
        else
          v_dynamic_user.set_value('dynamicValue', v_dynamic.dynamic_value);
        end if;
        v_node_json.set_object('dynamicUser', v_dynamic_user);
      end loop;
      --add by chenzhibin end
      --add by echo.zeng begin
      for v_static In v_static_user_cur(v_node.node_id) loop
        v_node_json.set_value('approverUsers', v_static.dynamic_value);
      end loop;
      --add by echo.zeng end
      --migrate by xiaowei.yao 20180416 begin
      FOR v_chain IN v_chain_cur(v_node.node_id, v_process_id) LOOP
        v_node_chain := pl_json;
        v_node_chain.set_value('chainId', v_chain.chain_id);
        v_node_chain.set_value('chainName', v_chain.chain_name);
        IF v_chain.is_checked = 'Y' THEN
          v_node_chain.set_value('isChecked', TRUE);
        ELSE
          v_node_chain.set_value('isChecked', FALSE);
          --migrate by xiaowei.yao 20180416 end
        END IF;
        v_node_json.add_list_item('nodeChains', v_node_chain);
      END LOOP;
      v_response.add_list_item('nodeList', v_node_json);
    END LOOP;

    x_response := v_response.to_json;
  END proc_query_process_nodes;

  /*==================================================
  Procedure/Function Name :
      proc_save_process_nodes
  Description:
      This function perform:
      保存流程节点
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-05-17  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_save_process_nodes(p_request CLOB, x_response OUT CLOB) IS
    v_request         json;
    v_response        pl_json := pl_json;
    v_current_user    VARCHAR2(50);
    v_process_nodes   VARCHAR2(4000);
    v_process_id      NUMBER;
    v_index           NUMBER := 1;
    v_node_name       VARCHAR2(100);
    v_count           NUMBER := 0;
    v_process_node_id NUMBER;
    v_countNode       NUMBER := 0;
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;

    v_process_nodes := TRIM(v_request.get('processNodes').get_string);
    IF v_process_nodes IS NULL THEN
      x_response := v_response.to_json;
      RETURN;
    END IF;
    v_process_id    := v_request.get('processId').get_number;
    v_process_nodes := REPLACE(TRIM(v_process_nodes), '，', ',');
    select count(1)
      into v_countNode
      from dbpm_process_nodes dns
     where dns.process_id = v_process_id;
    if v_countNode = 0 then
      --初始化申请节点
      v_process_node_id := dbpm_process_nodes_s.nextval;
      INSERT INTO dbpm_process_nodes
        (node_id,
         process_id,
         node_name,
         node_type,
         order_num,
         created_by,
         last_updated_by,
         back_node_id,
         approver_Type)
      VALUES
        (v_process_node_id,
         v_process_id,
         '申请人',
         'Single',
         1,
         v_current_user,
         v_current_user,
         -1,
         'Creator');
      -- 插入多语言表
      INSERT INTO dbpm_process_nodes_tl
        (node_id, locale, node_name, created_by, last_updated_by)
      VALUES
        (v_process_node_id,
         dbpm_comm_pkg.get_current_locale,
         '申请人',
         v_current_user,
         v_current_user);
    end if;
    FOR v_node IN (SELECT regexp_substr(v_process_nodes, '[^,]+', 1, rownum) node_name
                     FROM dual
                   CONNECT BY rownum <=
                              length(v_process_nodes) -
                              length(REPLACE(v_process_nodes, ',', '')) + 1) LOOP
      v_node_name := v_node.node_name;
      v_index     := v_index + 1;

      IF v_node_name IS NOT NULL THEN
        SELECT COUNT(1)
          INTO v_count
          FROM dbpm_process_nodes dpn
         WHERE dpn.process_id = v_process_id
           AND dpn.node_name = v_node_name;
        IF v_count = 0 THEN
          -- 插入流程节点表

          v_process_node_id := dbpm_process_nodes_s.nextval;
          INSERT INTO dbpm_process_nodes
            (node_id,
             process_id,
             node_name,
             node_type,
             order_num,
             created_by,
             last_updated_by,
             back_node_id)
          VALUES
            (v_process_node_id,
             v_process_id,
             v_node_name,
             'Single',
             v_index,
             v_current_user,
             v_current_user,
             -1);
          -- 插入多语言表
          INSERT INTO dbpm_process_nodes_tl
            (node_id, locale, node_name, created_by, last_updated_by)
          VALUES
            (v_process_node_id,
             dbpm_comm_pkg.get_current_locale,
             v_node_name,
             v_current_user,
             v_current_user);
        END IF;
      END IF;
    END LOOP;

    x_response := v_response.to_json;
  END proc_save_process_nodes;

  /*==================================================
  Procedure/Function Name :
      proc_del_process_node
  Description:
      This function perform:
      删除流程节点
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-05-17  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_del_process_node(p_request CLOB, x_response OUT CLOB) IS
    v_request  json;
    v_response pl_json := pl_json;
    v_node_id  NUMBER;
  BEGIN
    v_request := json(p_request, 'OBJECT');
    v_node_id := v_request.get('nodeId').get_number;
    -- 删除审批角色 migrate by xiaowei.yao 20180512 begin
    FOR v_role_del IN (SELECT *
                         FROM dbpm_node_roles dnr
                        WHERE dnr.node_id = v_node_id
                          AND dnr.node_from_type = 'ProcessNode') LOOP
      DELETE FROM dbpm_node_role_param_value dnrp
       WHERE dnrp.node_role_id = v_role_del.node_role_id;
      DELETE FROM dbpm_node_roles dnr
       WHERE dnr.node_role_id = v_role_del.node_role_id
         AND dnr.node_from_type = 'ProcessNode';
    END LOOP;
    -- 删除角色审批链
    DELETE FROM dbpm_node_chains dnc
     WHERE dnc.node_id = v_node_id
       AND dnc.node_from_type = 'ProcessNode';
    -- migrate by xiaowei.yao 20180512 end
    DELETE FROM dbpm_process_nodes dpn WHERE dpn.node_id = v_node_id;
    ---DELETE FROM dbpm_process_nodes_tl dpnt WHERE dpnt.node_id = v_node_id;
    x_response := v_response.to_json;
  END proc_del_process_node;

  /*==================================================
  Procedure/Function Name :
      proc_save_process_node
  Description:
      This function perform:
      保存流程节点
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-05-17  skycloud.wang  Creation
      1.1   2018-02-26  echo.zeng      updated
  ==================================================*/
  PROCEDURE proc_save_process_node(p_request CLOB, x_response OUT CLOB) IS
    v_request       json;
    v_response      pl_json := pl_json;
    v_current_user  VARCHAR2(50);
    v_node_id       NUMBER;
    v_node_type     VARCHAR2(100);
    v_node_name     VARCHAR2(100);
    v_approver_type VARCHAR2(100);
    v_role_list     json_list;
    v_param_list    json_list;
    v_chain_list    json_list;
    v_role          json;
    v_node_chain    json;
    v_param         json;
    v_node_role_id  NUMBER;
    v_process_id    NUMBER;
    v_order_num     number; --updated by Echo.Zeng 2018-01-08
    v_node_chain_id NUMBER; --migrate by xiaowei.yao 2015
    --add by chenzhibin begin
    v_dynamic_value_type varchar2(100);
    v_dynamic_value      varchar2(100);
    v_dynamic_user       json;
    v_sql_user           json;
    v_sql_users          json_list;
    v_rule               varchar2(1000);
    v_user_list          json_list;
    v_approvers          varchar2(4000);
    v_static_user        json;
    v_approver_users     varchar2(1000);
    v_is_auto_approve    varchar2(10) := 'N'; --是否自动审批
    v_is_required        varchar2(10) := 'N'; --是否可跳过
    v_isSendMail         varchar2(10) := 'N'; --是否发送待办邮件
    v_nodeFormUrl        varchar2(200); --审批页面地址
    v_node_itl_list      json_list;
    v_itl_item           json;
    v_lang               varchar2(200);
    v_locale             varchar2(200);
    v_count              number;
    --add by chenzhibin end
    --add by xiaowei.yao 2019-2-27
    v_emails          json_list;
    v_services        json_list;
    v_bussiness_datas json_list;
    v_row             json;
    -- v_subject_clob    clob;
    v_content_clob clob;
    v_service_req  clob;
    --add by xiaowei.yao
    v_back_node_id number;
    --
    v_expires json_list;
    v_expire  json;
    CURSOR v_chain_node_cur(p_process_id NUMBER, p_node_name VARCHAR) IS
      SELECT dac.process_id,
             dac.chain_id,
             dac.chain_name,
             dcn.node_id,
             dcn.node_name,
             dcn.node_type,
             dcn.object_version_number
      -- dcn.node_formurl
        FROM dbpm_chain_nodes dcn, dbpm_approval_chain dac
       WHERE dcn.chain_id = dac.chain_id
         AND dcn.node_name = p_node_name
         AND dac.process_id = p_process_id;

    v_getValue_type varchar2(20);
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;

    v_node_id       := v_request.get('nodeId').get_number;
    v_node_type     := v_request.get('nodeType').get_string;
    v_node_name     := v_request.get('nodeName').get_string;
    v_approver_type := v_request.get('approverType').get_string;
    v_order_num     := v_request.get('orderNum').get_number;
    v_nodeFormUrl   := v_request.get_string('nodeFormUrl');
    v_back_node_id  := v_request.get_number('backNodeId');
    IF v_request.get('isAutoApprove') IS NOT NULL AND v_request.get('isAutoApprove')
      .get_bool = TRUE THEN
      v_is_auto_approve := 'Y';
    END IF;
    IF v_request.get('isRequired') IS NOT NULL AND v_request.get('isRequired')
      .get_bool = TRUE THEN
      v_is_required := 'Y';
    END IF;
    IF v_request.get('isSendMail') IS NOT NULL AND v_request.get('isSendMail')
      .get_bool = TRUE THEN
      v_isSendMail := 'Y';
    END IF;
    UPDATE dbpm_process_nodes dpn
       SET dpn.node_name             = v_node_name,
           dpn.node_type             = v_node_type,
           dpn.approver_type         = v_approver_type,
           dpn.object_version_number = dpn.object_version_number + 1,
           dpn.order_num             = v_order_num,
           dpn.last_updated_by       = v_current_user,
           dpn.is_required           = v_is_required,
           dpn.is_auto_approve       = v_is_auto_approve,
           dpn.node_formurl          = v_nodeFormUrl,
           dpn.email_flag            = v_isSendMail,
           dpn.last_update_date      = sysdate,
           dpn.back_node_id          = v_back_node_id
     WHERE dpn.node_id = v_node_id;
    -- 更新多语言表
    /*  UPDATE dbpm_process_nodes_tl dpnt
      SET dpnt.node_name             = v_node_name,
          dpnt.object_version_number = dpnt.object_version_number + 1,
          dpnt.created_by            = v_current_user,
          dpnt.last_updated_by       = v_current_user
    WHERE dpnt.node_id = v_node_id
      AND dpnt.locale = dbpm_comm_pkg.get_current_locale;*/
    ---保存节点国际化数据
    if v_request.path('nodeNametl') is not null then
      v_node_itl_list := json_list(v_request.path('nodeNametl'));
      delete from dbpm_process_nodes_tl dn where dn.node_id = v_node_id;
      for v_index in 1 .. v_node_itl_list.count loop
        v_itl_item := json(v_node_itl_list.get(v_index));
        v_lang     := v_itl_item.get_string('lang');
        v_locale   := v_itl_item.get_string('locale');
        insert into dbpm_process_nodes_tl
          (node_id,
           locale,
           node_name,
           object_version_number,
           created_by,
           creation_date,
           last_updated_by,
           last_update_date)
        values
          (v_node_id,
           v_locale,
           v_lang,
           1,
           v_current_user,
           sysdate,
           v_current_user,
           sysdate);
      end loop;
    end if;
    --保存节点邮件数据
    if v_request.path('emails') is not null then
      delete from dbpm_nodes_email_map de where de.node_id = v_node_id;
      v_emails := json_list(v_request.path('emails'));
      for i in 1 .. v_emails.count loop
        v_row    := json(v_emails.get(i));
        v_emails := json_list(v_request.path('emails'));
        dbms_lob.createtemporary(v_content_clob, false);
        json(v_row.get('content')).to_clob(v_content_clob);
        insert into dbpm_nodes_email_map
          (map_id,
           NODE_ID,
           EMAIL_ID,
           send_stage,
           OBJECT_VERSION_NUMBER,
           CREATION_DATE,
           CREATED_BY,
           LAST_UPDATED_BY,
           LAST_UPDATE_DATE,
           content,
           email_name,
           recipients,
           recipients_type)
        values
          (dbpm_nodes_email_map_s.nextval,
           v_node_id,
           v_row.get_number('emailId'),
           v_row.get_string('sendStage'),
           1,
           sysdate,
           v_request.username,
           v_request.username,
           sysdate,
           v_content_clob,
           v_row.get_string('emailName'),
           v_row.get_string('recipients'),
           v_row.get_string('recipientsType'));
      end loop;
    end if;
    --保存节点服务数据
    if v_request.path('services') is not null then
      delete from dbpm_nodes_service_map de where de.node_id = v_node_id;
      v_services := json_list(v_request.path('services'));
      for i in 1 .. v_services.count loop
        v_row := json(v_services.get(i));
        dbms_lob.createtemporary(v_service_req, false);
        json(v_row.get('serviceReq')).to_clob(v_service_req);
        insert into dbpm_nodes_service_map
          (map_id,
           node_id,
           service_id,
           invoke_stage,
           OBJECT_VERSION_NUMBER,
           CREATION_DATE,
           CREATED_BY,
           LAST_UPDATED_BY,
           LAST_UPDATE_DATE， invoke_order， service_req)
        values
          (dbpm_nodes_service_map_s.nextval,
           v_node_id,
           v_row.get_number('serviceId'),
           v_row.get_string('invokeStage'),
           1,
           sysdate,
           v_request.username,
           v_request.username,
           sysdate,
           v_row.get_number('invokeOrder'),
           v_service_req);
      end loop;
    end if;

    --保存节点业务数据
    if v_request.path('bussinessDatas') is not null then
      delete from dbpm_nodes_businessdata de where de.node_id = v_node_id;
      v_bussiness_datas := json_list(v_request.path('bussinessDatas'));
      for i in 1 .. v_bussiness_datas.count loop
        v_row := json(v_bussiness_datas.get(i));
        insert into dbpm_nodes_businessdata
          (id,
           node_id,
           business_code,
           business_name,
           business_content,
           object_version_number,
           CREATION_DATE,
           CREATED_BY,
           LAST_UPDATED_BY,
           LAST_UPDATE_DATE)
        values
          (dbpm_nodes_businessdata_s.nextval,
           v_node_id,
           v_row.get_string('businessCode'),
           v_row.get_string('businessName'),
           v_row.get_string('businessContent'),
           1,
           sysdate,
           v_request.username,
           v_request.username,
           sysdate);
      end loop;
    end if;
    --关联流程和超期信息
    if v_request.path('expires') is not null then
      null;
      delete from dbpm_process_expire_rule dr where dr.node_id = v_node_id;
      v_expires := json_list(v_request.get('expires'));
      for i in 1 .. v_expires.count loop
        v_expire := json(v_expires.get(i));

        insert into dbpm_process_expire_rule
          (id,
           rule_uuid,
           rule_type,
           node_id,
           param_name,
           param_meaning,
           status,
           param_value,
           start_time,
           end_time,
           creation_date,
           created_by,
           deloy_day,
           warning_dur,
           warning_num)
        values
          (dbpm_process_expire_rule_s.nextval,
           v_expire.get_string('ruleUuid'),
           'TASK',
           v_node_id,
           v_expire.get_string('paramName'),
           v_expire.get_string('paramMeaning'),
           'Y',
           v_expire.get_number('paramValue'),
           v_expire.get_date('startTime'),
           v_expire.get_date('endTime'),
           sysdate,
           v_current_user,
           v_expire.get_number('deloyDay'),
           v_expire.get_number('warningDur'),
           v_expire.get_number('warningNum'));
      end loop;
    end if;

    -- 删除角色及角色参数
    DELETE FROM dbpm_node_role_param_value dnrp
     WHERE dnrp.node_role_id IN
           (SELECT dnr.node_role_id
              FROM dbpm_node_roles dnr
             WHERE dnr.node_id = v_node_id
               AND dnr.node_from_type = 'ProcessNode');
    DELETE FROM dbpm_node_roles dnr
     WHERE dnr.node_id = v_node_id
       AND dnr.node_from_type = 'ProcessNode';

    -- 保存审批节点角色
    IF v_request.path('businessRoles') IS NOT NULL THEN
      v_role_list := json_list(v_request.path('businessRoles'));
      FOR j IN 1 .. v_role_list.count LOOP
        v_role         := json(v_role_list.get(j));
        v_node_role_id := dbpm_node_roles_s.nextval;
        INSERT INTO dbpm_node_roles
          (node_role_id,
           node_id,
           business_role,
           node_from_type,
           created_by,
           last_updated_by,
           custom_role_name)
        VALUES
          (v_node_role_id,
           v_node_id,
           v_role.get('roleCode').get_string,
           'ProcessNode',
           v_current_user,
           v_current_user,
           v_role.get_string('customRoleName'));
        -- 保存角色参数
        IF v_role.path('paramList') IS NOT NULL THEN
          v_param_list := json_list(v_role.path('paramList'));
          FOR k IN 1 .. v_param_list.count LOOP
            v_param := json(v_param_list.get(k));
            INSERT INTO dbpm_node_role_param_value
              (node_role_id,
               param_id,
               param_value,
               operation_type,
               get_value_type)
            VALUES
              (v_node_role_id,
               v_param.get   ('paramId'   ).get_number,
               v_param.get   ('paramValue'   ).get_string,
               v_param.get   ('operationType'   ).get_string,
               v_param.get   ('getValueType'   ).get_string);
          END LOOP;
        END IF;
      END LOOP;
    END IF;
    -- 2017-11-07  Echo.Zeng  Updated
    --根据流程节点id查询当前流程id
    /*SELECT MAX(dpn.process_id)
      INTO v_process_id
      FROM dbpm_process_nodes dpn
     WHERE dpn.node_id = v_node_id;
    IF v_process_id IS NOT NULL THEN
      FOR v_chain_node_cur_row IN v_chain_node_cur(v_process_id,
                                                   v_node_name) LOOP
        --更新审批链节点
        UPDATE dbpm_chain_nodes dcn
           SET dcn.node_name             = v_node_name,
               dcn.node_type             = v_node_type,
               dcn.approver_type         = v_approver_type,
               dcn.object_version_number = dcn.object_version_number + 1,
               dcn.last_updated_by       = v_current_user,
               dcn.last_update_date      = sysdate
         WHERE dcn.node_id = v_chain_node_cur_row.node_id;
        -- 更新多语言表
        UPDATE dbpm_chain_nodes_tl dcnt
           SET dcnt.node_name             = v_node_name,
               dcnt.object_version_number = dcnt.object_version_number + 1,
               dcnt.last_updated_by       = v_current_user
         WHERE dcnt.node_id = v_chain_node_cur_row.node_id
           AND dcnt.locale = dbpm_comm_pkg.get_current_locale;

        -- 删除审批链角色及角色参数
        DELETE FROM dbpm_node_role_param_value dnrp
         WHERE dnrp.node_role_id IN
               (SELECT dnr.node_role_id
                  FROM dbpm_node_roles dnr
                 WHERE dnr.node_id = v_chain_node_cur_row.node_id
                   AND dnr.node_from_type = 'ChainNode');
        DELETE FROM dbpm_node_roles dnr
         WHERE dnr.node_id = v_chain_node_cur_row.node_id
           AND dnr.node_from_type = 'ChainNode';

        -- 保存审批节点角色
        IF v_request.path('businessRoles') IS NOT NULL THEN
          v_role_list := json_list(v_request.path('businessRoles'));
          FOR j IN 1 .. v_role_list.count LOOP
            v_role         := json(v_role_list.get(j));
            v_node_role_id := dbpm_node_roles_s.nextval;
            INSERT INTO dbpm_node_roles
              (node_role_id,
               node_id,
               business_role,
               node_from_type,
               created_by,
               last_updated_by)
            VALUES
              (v_node_role_id,
               v_chain_node_cur_row.node_id,
               v_role.get('roleCode').get_string,
               'ChainNode',
               v_current_user,
               v_current_user);
            -- 保存角色参数
            IF v_role.path('paramList') IS NOT NULL THEN
              v_param_list := json_list(v_role.path('paramList'));
              FOR k IN 1 .. v_param_list.count LOOP
                v_param := json(v_param_list.get(k));
                INSERT INTO dbpm_node_role_param_value
                  (node_role_id, param_id, param_value, get_value_type)
                VALUES
                  (v_node_role_id,
                   v_param.get   ('paramId'   ).get_number,
                   v_param.get   ('paramValue'   ).get_string,
                   v_param.get   ('getValueType'   ).get_string);
              END LOOP;
            END IF;
          END LOOP;
        END IF;
        --add by chenzhibin begin
        -- 增加动态参数取人设置值
        delete from DBPM_DYNAMIC_APPROVERS t
         where t.node_id = v_chain_node_cur_row.node_id;
        delete from cux_bpm_common_rule t
         where t.node_id = v_chain_node_cur_row.node_id;
        if v_approver_type = 'DynamicUser' then
          if v_request.path('dynamicUser') IS NOT NULL then

            v_dynamic_user       := json(v_request.path('dynamicUser'));
            v_dynamic_value_type := v_dynamic_user.get_string('getValueType');
            --update by echo.zeng 2018-02-26 begin
            if v_dynamic_value_type = 'SQL' then
              v_sql_users := json_list(v_dynamic_user.get('sqlUsers'));
              for i in 1 .. v_sql_users.count loop
                v_sql_user  := json(v_sql_users.get(i));
                v_rule      := v_sql_user.get_string('rule');
                v_approvers := '';
                v_user_list := json_list(v_sql_user.get('approverList'));
                for j in 1 .. v_user_list.count loop
                  if v_approvers is null then
                    v_approvers := v_user_list.get(j).get_string;
                  else
                    v_approvers := v_approvers || ',' || v_user_list.get(j)
                                  .get_string;
                  end if;
                end loop;
                insert into cux_bpm_common_rule t
                  (common_rule_id, node_id, rule_expression, rule_value)
                values
                  (cux_bpm_common_rule_s.nextval,
                   v_chain_node_cur_row.node_id,
                   v_rule,
                   v_approvers);
              end loop;
            end if;
            --update by echo.zeng 2018-02-26 end
            v_dynamic_value := v_dynamic_user.get_string('dynamicValue');
          end if;
          insert into DBPM_DYNAMIC_APPROVERS
            (APPROVER_ID,
             NODE_ID,
             DYNAMIC_VALUE,
             GET_VALUE_TYPE,
             OPERATION_TYPE)
          values
            (DBPM_DYNAMIC_APPROVERs_s.Nextval,
             v_chain_node_cur_row.node_id,
             nvl(v_dynamic_value, 'null'),
             v_dynamic_value_type,
             null);
        elsif v_approver_type = 'StaticUser' then
          insert into DBPM_DYNAMIC_APPROVERS
            (APPROVER_ID,
             NODE_ID,
             DYNAMIC_VALUE,
             GET_VALUE_TYPE,
             OPERATION_TYPE)
          values
            (DBPM_DYNAMIC_APPROVERs_s.Nextval,
             v_chain_node_cur_row.node_id,
             v_request.get_string('approverUsers'),
             'STATIC',
             null);
        end if;
        --add by chenzhibin end
      END LOOP;
    END IF;*/
    --migrate by xiaowei.yao 20180512 begin
    -- 删除审批节点审批链
    DELETE FROM dbpm_node_chains dnc
     WHERE dnc.node_id = v_node_id
       AND dnc.node_from_type = 'ProcessNode';
    -- 保存审批节点子审批链
    IF v_request.path('nodeChains') IS NOT NULL THEN
      v_chain_list := json_list(v_request.path('nodeChains'));
      FOR k IN 1 .. v_chain_list.count LOOP
        v_node_chain := json(v_chain_list.get(k));
        IF v_node_chain.get('isChecked').get_bool THEN
          v_node_chain_id := dbpm_node_chains_s.nextval;
          INSERT INTO dbpm_node_chains
            (node_chain_id,
             node_id,
             chain_id,
             node_from_type,
             created_by,
             last_updated_by)
          VALUES
            (v_node_chain_id,
             v_node_id,
             v_node_chain.get('chainId').get_number,
             'ProcessNode',
             v_current_user,
             v_current_user);
        END IF;
      END LOOP;
    END IF;
    --migrate by xiaowei.yao 20180512 end
    -- 2017-11-07  Echo.Zeng  Updated
    --add by chenzhibin begin
    -- 增加动态参数取人设置值
    delete from DBPM_DYNAMIC_APPROVERS t where t.node_id = v_node_id;
    delete from cux_bpm_common_rule t where t.node_id = v_node_id;
    if v_approver_type = 'DynamicUser' then
      if v_request.path('dynamicUser') IS NOT NULL then

        v_dynamic_user       := json(v_request.path('dynamicUser'));
        v_dynamic_value_type := v_dynamic_user.get_string('getValueType');
        --update by echo.zeng 2018-02-26 begin
        if v_dynamic_value_type = 'SQL' then
          v_sql_users := json_list(v_dynamic_user.get('sqlUsers'));
          for i in 1 .. v_sql_users.count loop
            v_sql_user      := json(v_sql_users.get(i));
            v_rule          := v_sql_user.get_string('rule');
            v_getValue_type := v_sql_user.get_string('getValueType');
            v_approvers     := '';
            v_user_list     := json_list(v_sql_user.get('approverList'));
            for j in 1 .. v_user_list.count loop
              if v_approvers is null then
                v_approvers := v_user_list.get(j).get_string;
              else
                v_approvers := v_approvers || ',' || v_user_list.get(j)
                              .get_string;
              end if;
            end loop;
            insert into cux_bpm_common_rule t
              (common_rule_id,
               node_id,
               rule_expression,
               rule_value,
               get_value_type)
            values
              (cux_bpm_common_rule_s.nextval,
               v_node_id,
               v_rule,
               v_approvers,
               v_getValue_type);
          end loop;
        end if;
        --update by echo.zeng 2018-02-26 end
        v_dynamic_value := v_dynamic_user.get_string('dynamicValue');
      end if;
      insert into DBPM_DYNAMIC_APPROVERS
        (APPROVER_ID,
         NODE_ID,
         DYNAMIC_VALUE,
         GET_VALUE_TYPE,
         OPERATION_TYPE)
      values
        (DBPM_DYNAMIC_APPROVERs_s.Nextval,
         v_node_id,
         nvl(v_dynamic_value, 'null'),
         v_dynamic_value_type,
         null);
    elsif v_approver_type = 'StaticUser' then
      insert into DBPM_DYNAMIC_APPROVERS
        (APPROVER_ID,
         NODE_ID,
         DYNAMIC_VALUE,
         GET_VALUE_TYPE,
         OPERATION_TYPE)
      values
        (DBPM_DYNAMIC_APPROVERs_s.Nextval,
         v_node_id,
         v_request.get_string('approverUsers'),
         'STATIC',
         null);
    end if;
    --add by chenzhibin end
    x_response := v_response.to_json;
  END proc_save_process_node;

  PROCEDURE proc_save_process_node_bak(p_request CLOB, x_response OUT CLOB) IS
    v_request       json;
    v_response      pl_json := pl_json;
    v_current_user  VARCHAR2(50);
    v_node_id       NUMBER;
    v_node_type     VARCHAR2(100);
    v_node_name     VARCHAR2(100);
    v_approver_type VARCHAR2(100);
    v_role_list     json_list;
    v_param_list    json_list;
    v_role          json;
    v_param         json;
    v_node_role_id  NUMBER;
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;

    v_node_id       := v_request.get('nodeId').get_number;
    v_node_type     := v_request.get('nodeType').get_string;
    v_node_name     := v_request.get('nodeName').get_string;
    v_approver_type := v_request.get('approverType').get_string;
    UPDATE dbpm_process_nodes dpn
       SET dpn.node_name             = v_node_name,
           dpn.node_type             = v_node_type,
           dpn.approver_type         = v_approver_type,
           dpn.object_version_number = dpn.object_version_number + 1,
           dpn.created_by            = v_current_user,
           dpn.last_updated_by       = v_current_user
     WHERE dpn.node_id = v_node_id;
    -- 更新多语言表
    UPDATE dbpm_process_nodes_tl dpnt
       SET dpnt.node_name             = v_node_name,
           dpnt.object_version_number = dpnt.object_version_number + 1,
           dpnt.created_by            = v_current_user,
           dpnt.last_updated_by       = v_current_user
     WHERE dpnt.node_id = v_node_id
       AND dpnt.locale = dbpm_comm_pkg.get_current_locale;
    -- 删除角色及角色参数
    DELETE FROM dbpm_node_role_param_value dnrp
     WHERE dnrp.node_role_id IN
           (SELECT dnr.node_role_id
              FROM dbpm_node_roles dnr
             WHERE dnr.node_id = v_node_id
               AND dnr.node_from_type = 'ProcessNode');
    DELETE FROM dbpm_node_roles dnr
     WHERE dnr.node_id = v_node_id
       AND dnr.node_from_type = 'ProcessNode';

    -- 保存审批节点角色
    IF v_request.path('businessRoles') IS NOT NULL THEN
      v_role_list := json_list(v_request.path('businessRoles'));
      FOR j IN 1 .. v_role_list.count LOOP
        v_role         := json(v_role_list.get(j));
        v_node_role_id := dbpm_node_roles_s.nextval;
        INSERT INTO dbpm_node_roles
          (node_role_id,
           node_id,
           business_role,
           node_from_type,
           created_by,
           last_updated_by)
        VALUES
          (v_node_role_id,
           v_node_id,
           v_role.get('roleCode').get_string,
           'ProcessNode',
           v_current_user,
           v_current_user);
        -- 保存角色参数
        IF v_role.path('paramList') IS NOT NULL THEN
          v_param_list := json_list(v_role.path('paramList'));
          FOR k IN 1 .. v_param_list.count LOOP
            v_param := json(v_param_list.get(k));
            INSERT INTO dbpm_node_role_param_value
              (node_role_id, param_id, param_value, get_value_type)
            VALUES
              (v_node_role_id,
               v_param.get   ('paramId'   ).get_number,
               v_param.get   ('paramValue'   ).get_string,
               v_param.get   ('getValueType'   ).get_string);
          END LOOP;
        END IF;
      END LOOP;
    END IF;

    x_response := v_response.to_json;
  END proc_save_process_node_bak;
  ----用excel导入时专用
  PROCEDURE proc_save_process_nodes_ex(p_request CLOB, x_response OUT CLOB) IS
    v_request           json;
    v_response          pl_json := pl_json;
    v_process_node_list json_list;
    v_process_id        VARCHAR2(300);
    v_process_code      VARCHAR2(300);
    v_node_item         json;
    v_node_name         VARCHAR2(300);
    v_node_role_name    VARCHAR2(300);
    v_node_role_code    VARCHAR2(300);
    v_node_param        VARCHAR2(300);
    v_count             NUMBER;
    v_node_id           NUMBER;
    v_node_type         VARCHAR2(300) := 'Parallel';
    v_approve_type      VARCHAR2(300);
    v_node_itl_list     json_list;
    v_itl               json;
    v_itl_value         VARCHAR2(300);
    v_itl_code          VARCHAR2(300);
    v_node_role_id      NUMBER;
    v_node_rule         VARCHAR2(300);
    v_role_param_id     NUMBER;
  BEGIN
    v_request           := json(p_request);
    v_process_id        := v_request.get('processId').get_number;
    v_process_node_list := json_list(v_request.path('processNodes'));
    SELECT MAX(t.process_code)
      INTO v_process_code
      FROM dbpm_process t
     WHERE t.process_id = v_process_id;
    FOR v_index IN 1 .. v_process_node_list.count LOOP
      v_node_item      := json(v_process_node_list.get(v_index));
      v_node_name      := v_node_item.get('nodeName').get_string;
      v_node_role_name := v_node_item.get('nodeRole').get_string;
      v_node_param     := v_node_item.get('nodeParam').get_string;
      v_node_rule      := v_node_item.get('nodeRule').get_string;
      SELECT MAX(t.param_code)
        INTO v_node_rule
        FROM dbpm_process_params t
       WHERE t.process_id = v_process_id
         AND t.param_name = v_node_rule;
      SELECT COUNT(1)
        INTO v_count
        FROM DBPM_PROCESS_NODES t
       WHERE t.process_id = v_process_id
         AND t.node_name = v_node_name;
      IF v_node_name = '预算人审批' THEN
        v_approve_type := 'BudgetRule';
      ELSIF v_node_name = '直线经理' THEN
        v_approve_type := 'CreatorManager';
      ELSE
        v_approve_type := 'ParameTricRole';
      END IF;
      --申请节点不插入
      IF v_node_name != '申请' THEN
        IF v_count > 0 THEN
          SELECT MAX(t.node_id)
            INTO v_node_id
            FROM DBPM_PROCESS_NODES t
           WHERE t.process_id = v_process_id
             AND t.node_name = v_node_name;
          UPDATE DBPM_PROCESS_NODES t
             SET t.approver_type = v_approve_type,
                 t.order_num     = v_index - 1
           WHERE t.node_id = v_node_id;
        ELSE
          v_node_id := DBPM_PROCESS_NODES_S.NEXTVAL;
          INSERT INTO DBPM_PROCESS_NODES
            (NODE_ID,
             PROCESS_ID,
             NODE_NAME,
             NODE_TYPE,
             ORDER_NUM,
             OBJECT_VERSION_NUMBER,
             CREATION_DATE,
             CREATED_BY,
             LAST_UPDATED_BY,
             LAST_UPDATE_DATE,
             APPROVER_TYPE)
          VALUES
            (v_node_id,
             v_process_id,
             v_node_name,
             v_node_type,
             v_index - 1,
             1,
             sysdate,
             'weblogic',
             'weblogic',
             sysdate,
             v_approve_type);
        END IF;
      END IF;
      v_node_itl_list := json_list(v_node_item.path('itls'));
      FOR v_row IN 1 .. v_node_itl_list.count LOOP
        v_itl       := json(v_node_itl_list.get(v_row));
        v_itl_code  := v_itl.get('locale').get_string;
        v_itl_value := v_itl.get('lang').get_string;
        --插入国际化数据中间表
        /* SELECT COUNT(1)
          INTO v_count
          FROM cux_lang t
         WHERE t.process_code = v_process_code
           AND t.lang_code = v_itl_code
           AND t.node_name = v_node_name
           AND t.using_type = '节点名';
        IF v_count > 0 THEN
          UPDATE cux_lang t
             SET t.lang_data = v_itl_value
           WHERE t.process_code = v_process_code
             AND t.lang_code = v_itl_code
             AND t.using_type = '节点名'
             AND t.node_name = v_node_name;
        ELSE
          INSERT INTO CUX_LANG
            (PROCESS_CODE,
             LANG_CODE,
             LANG_DATA,
             USING_TYPE,
             NODE_NO,
             NODE_NAME)
          VALUES
            (v_process_code,
             v_itl_code,
             v_itl_value,
             '节点名',
             v_index,
             v_node_name);*/

        --   END IF;
        --插入节点国际化数据表
        /*  SELECT COUNT(1)
          INTO v_count
          FROM dbpm_process_nodes_tl t
         WHERE t.node_id = v_node_id
           AND t.locale = v_itl_code;
        */
        --如果国际化数据已经存在
        /*IF v_count > 0 THEN
          UPDATE dbpm_process_nodes_tl t
             SET t.node_name = v_itl_value , t.object_version_number =
                               t.object_version_number + 1
           WHERE t.node_id = v_node_id
             AND t.locale = v_itl_code;
        ELSE*/

        --不存在新增
        if v_node_id is not null then
          INSERT INTO DBPM_PROCESS_NODES_TL
            (NODE_ID,
             LOCALE,
             NODE_NAME,
             OBJECT_VERSION_NUMBER,
             CREATION_DATE,
             CREATED_BY,
             LAST_UPDATED_BY,
             LAST_UPDATE_DATE)
          VALUES
            (v_node_id,
             v_itl_code,
             v_itl_value,
             1,
             SYSDATE,
             'weblogic',
             'weblogic',
             SYSDATE);
        end if;
        /*     END IF;*/
      END LOOP;
      -- 新增节点参数（GEMS特殊需求）
      --导入节点参数中间表
      if v_node_id is not null then
        insert into dbpm_nodes_businessdata
          (id,
           node_id,
           business_code,
           business_name,
           business_content,
           object_version_number,
           creation_date,
           created_by,
           last_updated_by,
           last_update_date)
        values
          (dbpm_nodes_businessdata_s.nextval,
           v_node_id,
           'STEP_STATUS',
           '节点状态',
           v_node_param,
           1,
           sysdate,
           'weblogic',
           'weblogic',
           sysdate);
      end if;
      /* SELECT COUNT(1)
        INTO v_count
        FROM cux_gems_node_status_tmp t
       WHERE t.process_code = v_process_code
         AND t.node_name = v_node_name;
      IF v_count > 0 THEN
        UPDATE cux_gems_node_status_tmp t
           SET t.node_status = v_node_param
         WHERE t.process_code = v_process_code
           AND t.node_name = v_node_name;
      ELSE
        INSERT INTO CUX_GEMS_NODE_STATUS_TMP
          (PROCESS_CODE, NODE_NAME, NODE_STATUS)
        VALUES
          (v_process_code, v_node_name, v_node_param);
      END IF;*/
      /*--导入节点参数真实表
      SELECT COUNT(1)
        INTO v_count
        FROM cux_gems_node_params t
       WHERE t.node_id = v_node_id
         AND t.param_key = 'step_status';
      IF v_count > 0 THEN
        UPDATE cux_gems_node_params t
           SET t.param_value = v_node_param
         WHERE t.node_id = v_node_id
           AND t.param_key = 'step_status';
      ELSE
        INSERT INTO cux_gems_node_params
          (node_id, param_key, param_value)
        VALUES
          (v_node_id, 'step_status', v_node_param);
      END IF;*/
      -- 删除角色及角色参数
      DELETE FROM dbpm_node_role_param_value dnrp
       WHERE dnrp.node_role_id IN
             (SELECT dnr.node_role_id
                FROM dbpm_node_roles dnr
               WHERE dnr.node_id = v_node_id
                 AND dnr.node_from_type = 'ProcessNode');
      DELETE FROM dbpm_node_roles dnr
       WHERE dnr.node_id = v_node_id
         AND dnr.node_from_type = 'ProcessNode';
      IF v_approve_type = 'ParameTricRole' THEN
        --获取角色编号
        SELECT MAX(t.role_code)
          INTO v_node_role_code
          FROM dbpm_roles t
         WHERE t.role_name = v_node_role_name;
        IF v_node_role_code IS NOT NULL THEN
          v_node_role_id := dbpm_node_roles_s.nextval;
          --新增节点角色
          INSERT INTO dbpm_node_roles
            (node_role_id,
             node_id,
             business_role,
             node_from_type,
             created_by,
             last_updated_by)
          VALUES
            (v_node_role_id,
             v_node_id,
             v_node_role_code,
             'ProcessNode',
             'weblogic',
             'weblogic');
          --新增角色参数
          SELECT MAX(t.param_id)
            INTO v_role_param_id
            FROM dbpm_role_params t, dbpm_roles dr
           WHERE t.role_id = dr.role_id
             AND dr.role_code = v_node_role_code
             AND t.param_name = '所属组织'
             AND t.status = 'Y';
          INSERT INTO dbpm_node_role_param_value
            (node_role_id,
             param_id,
             param_value,
             get_value_type,
             operation_type)
          VALUES
            (v_node_role_id,
             v_role_param_id,
             v_node_rule,
             'PROCESSPARAM',
             '=');
        END IF;
      END IF;
    END LOOP;

    x_response := v_response.to_json;
  END proc_save_process_nodes_ex;
  /*==================================================
  Procedure/Function Name :
      proc_save_process_all_node
  Description:
      This function perform:
      保存流程全部节点
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-11-20  jinglun.xu   Creation
  ==================================================*/
  PROCEDURE proc_save_process_all_node(p_request CLOB, x_response OUT CLOB) IS
    v_request       json;
    v_response      pl_json := pl_json;
    v_current_user  VARCHAR2(50);
    v_node_id       NUMBER;
    v_node_type     VARCHAR2(100);
    v_node_name     VARCHAR2(100);
    v_approver_type VARCHAR2(100);
    v_role_list     json_list;
    v_param_list    json_list;
    v_chain_list    json_list;
    v_nodes_list    json_list;
    v_role          json;
    v_node_chain    json;
    v_param         json;
    v_node          json;
    v_node_role_id  NUMBER;
    v_node_chain_id NUMBER;
    --add by chenzhibin begin
    v_dynamic_value_type varchar2(100);
    v_dynamic_value      varchar2(100);
    v_dynamic_user       json;
    --add by chenzhibin end
    --xjl 节点顺序
    v_order_num number;
    --xjl 流程id
    v_process_id number;
    v_count      number;
    cursor c_nodes is
      select count(1) count_num
        from dbpm_process_nodes dpn
       where dpn.process_id = v_process_id
       group by dpn.order_num;
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;
    IF v_request.path('nodes') IS NOT NULL THEN
      v_nodes_list := json_list(v_request.path('nodes'));
      FOR j IN 1 .. v_nodes_list.count LOOP
        v_node    := json(v_nodes_list.get(j));
        v_node_id := v_node.get('nodeId').get_number;
        /*        v_node_type     := v_node.get('nodeType').get_string;
        v_node_name     := v_node.get('nodeName').get_string;
        v_approver_type := v_node.get_string('approverType');*/
        v_order_num := v_node.get('orderNum').get_number;
        /* select dpn.process_id
         into v_process_id
         from dbpm_process_nodes dpn
        where dpn.node_id = v_node_id;*/
        UPDATE dbpm_process_nodes dpn
           SET /*dpn.node_name             = v_node_name,
               dpn.node_type             = v_node_type,
               dpn.approver_type         = v_approver_type,
               dpn.object_version_number = dpn.object_version_number + 1,
               dpn.created_by            = v_current_user,
               dpn.last_updated_by       = v_current_user,*/ dpn.order_num = v_order_num
         WHERE dpn.node_id = v_node_id;
        /*       -- 更新多语言表
        UPDATE dbpm_process_nodes_tl dpnt
           SET dpnt.node_name             = v_node_name,
               dpnt.object_version_number = dpnt.object_version_number + 1,
               dpnt.created_by            = v_current_user,
               dpnt.last_updated_by       = v_current_user
         WHERE dpnt.node_id = v_node_id
           AND dpnt.locale = dbpm_comm_pkg.get_current_locale;*/
      /*  -- 删除角色及角色参数
                                                                                                                                                  DELETE FROM dbpm_node_role_param_value dnrp
                                                                                                                                                   WHERE dnrp.node_role_id IN
                                                                                                                                                         (SELECT dnr.node_role_id
                                                                                                                                                            FROM dbpm_node_roles dnr
                                                                                                                                                           WHERE dnr.node_id = v_node_id
                                                                                                                                                             AND dnr.node_from_type = 'ProcessNode');
                                                                                                                                                  DELETE FROM dbpm_node_roles dnr
                                                                                                                                                   WHERE dnr.node_id = v_node_id
                                                                                                                                                     AND dnr.node_from_type = 'ProcessNode';*/

      /*     -- 保存审批节点角色
                                                                                                                                                  IF v_node.path('businessRoles') IS NOT NULL THEN
                                                                                                                                                    v_role_list := json_list(v_node.path('businessRoles'));
                                                                                                                                                    FOR j IN 1 .. v_role_list.count LOOP
                                                                                                                                                      v_role         := json(v_role_list.get(j));
                                                                                                                                                      v_node_role_id := dbpm_node_roles_s.nextval;
                                                                                                                                                      INSERT INTO dbpm_node_roles
                                                                                                                                                        (node_role_id,
                                                                                                                                                         node_id,
                                                                                                                                                         business_role,
                                                                                                                                                         node_from_type,
                                                                                                                                                         created_by,
                                                                                                                                                         last_updated_by)
                                                                                                                                                      VALUES
                                                                                                                                                        (v_node_role_id,
                                                                                                                                                         v_node_id,
                                                                                                                                                         v_role.get('roleCode').get_string,
                                                                                                                                                         'ProcessNode',
                                                                                                                                                         v_current_user,
                                                                                                                                                         v_current_user);
                                                                                                                                                      -- 保存角色参数
                                                                                                                                                      IF v_role.path('paramList') IS NOT NULL THEN
                                                                                                                                                        v_param_list := json_list(v_role.path('paramList'));
                                                                                                                                                        FOR k IN 1 .. v_param_list.count LOOP
                                                                                                                                                          v_param := json(v_param_list.get(k));
                                                                                                                                                          INSERT INTO dbpm_node_role_param_value
                                                                                                                                                            (node_role_id,
                                                                                                                                                             param_id,
                                                                                                                                                             param_value,
                                                                                                                                                             operation_type,
                                                                                                                                                             get_value_type)
                                                                                                                                                          VALUES
                                                                                                                                                            (v_node_role_id,
                                                                                                                                                             v_param.get   ('paramId'   ).get_number,
                                                                                                                                                             v_param.get   ('paramValue'   ).get_string,
                                                                                                                                                             v_param.get   ('operationType'   ).get_string,
                                                                                                                                                             v_param.get   ('getValueType'   ).get_string);
                                                                                                                                                        END LOOP;
                                                                                                                                                      END IF;
                                                                                                                                                    END LOOP;
                                                                                                                                                  END IF;*/

      /*        -- 删除审批节点审批链
                                                                                                                                                  DELETE FROM dbpm_node_chains dnc
                                                                                                                                                   WHERE dnc.node_id = v_node_id
                                                                                                                                                     AND dnc.node_from_type = 'ProcessNode';
                                                                                                                                                  -- 保存审批节点子审批链
                                                                                                                                                  IF v_node.path('nodeChains') IS NOT NULL THEN
                                                                                                                                                    v_chain_list := json_list(v_node.path('nodeChains'));
                                                                                                                                                    FOR k IN 1 .. v_chain_list.count LOOP
                                                                                                                                                      v_node_chain := json(v_chain_list.get(k));
                                                                                                                                                      IF v_node_chain.get('isChecked').get_bool THEN
                                                                                                                                                        v_node_chain_id := dbpm_node_chains_s.nextval;
                                                                                                                                                        INSERT INTO dbpm_node_chains
                                                                                                                                                          (node_chain_id,
                                                                                                                                                           node_id,
                                                                                                                                                           chain_id,
                                                                                                                                                           node_from_type,
                                                                                                                                                           created_by,
                                                                                                                                                           last_updated_by)
                                                                                                                                                        VALUES
                                                                                                                                                          (v_node_chain_id,
                                                                                                                                                           v_node_id,
                                                                                                                                                           v_node_chain.get('chainId').get_number,
                                                                                                                                                           'ProcessNode',
                                                                                                                                                           v_current_user,
                                                                                                                                                           v_current_user);
                                                                                                                                                      END IF;
                                                                                                                                                    END LOOP;
                                                                                                                                                  END IF;*/
      --add by chenzhibin begin
      -- 增加动态参数取人设置值
      /*  delete from DBPM_DYNAMIC_APPROVERS t where t.node_id = v_node_id;
                                                                                                                                                  if v_approver_type = 'DynamicUser' then
                                                                                                                                                    if v_node.path('dynamicUser') IS NOT NULL then

                                                                                                                                                      v_dynamic_user       := json(v_node.path('dynamicUser'));
                                                                                                                                                      v_dynamic_value_type := v_dynamic_user.get_string('getValueType');
                                                                                                                                                      v_dynamic_value      := v_dynamic_user.get_string('dynamicValue');
                                                                                                                                                    end if;
                                                                                                                                                    insert into DBPM_DYNAMIC_APPROVERS
                                                                                                                                                      (APPROVER_ID,
                                                                                                                                                       NODE_ID,
                                                                                                                                                       DYNAMIC_VALUE,
                                                                                                                                                       GET_VALUE_TYPE,
                                                                                                                                                       OPERATION_TYPE)
                                                                                                                                                    values
                                                                                                                                                      (DBPM_DYNAMIC_APPROVERs_s.Nextval,
                                                                                                                                                       v_node_id,
                                                                                                                                                       v_dynamic_value,
                                                                                                                                                       v_dynamic_value_type,
                                                                                                                                                       '=');
                                                                                                                                                  end if;*/
      end loop;
    end if;
    --校验节点顺序的唯一性
    for c_nodes_cusor in c_nodes loop
      if c_nodes_cusor.count_num > 1 then
        rollback;
        return;
      end if;
    end loop;
    --add by chenzhibin end
    x_response := v_response.to_json;
  END proc_save_process_all_node;

  /*==================================================
  Procedure/Function Name :
      proc_query_next_nodes
  Description:
      This function perform:
      获取下级审批节点及审批人
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-09-15  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_query_next_node_approvers(p_request  CLOB,
                                           x_response OUT CLOB) IS
    v_request       json;
    v_response      pl_json := pl_json;
    v_node_json     pl_json := pl_json;
    v_approver_json pl_json := pl_json;
    v_process_id    NUMBER;
    v_node_id       NUMBER;
    CURSOR v_next_nodes_cur(p_node_id NUMBER) IS
      SELECT 10000 node_id, '部门经理' node_name
        FROM dual
      UNION ALL
      SELECT 10001 node_id, '公司领导' node_name
        FROM dual;
    CURSOR v_node_approvers_cur(p_node_id NUMBER) IS
      SELECT '0001' approver_code, '张三' approver_name
        FROM dual
      UNION ALL
      SELECT '0002' approver_code, '李四' approver_name
        FROM dual;
  BEGIN
    v_request := json(p_request);
    -- TODO 后续完善
    v_process_id := v_request.get('processId').get_number;
    v_node_id    := v_request.get('currentNodeId').get_number;

    FOR v_node IN v_next_nodes_cur(10101) LOOP
      v_response.set_value('processId', v_process_id);
      v_response.set_value('currentNodeId', v_node_id);
      v_node_json := pl_json;
      v_node_json.set_value('nodeId', v_node.node_id);
      v_node_json.set_value('nodeName', v_node.node_name);

      FOR v_approver IN v_node_approvers_cur(v_node.node_id) LOOP
        v_approver_json := pl_json;
        v_approver_json.set_value('approverCode', v_approver.approver_code);
        v_approver_json.set_value('approverName', v_approver.approver_name);
        v_node_json.add_list_item('approverList', v_approver_json);
      END LOOP;
      v_response.add_list_item('nextNodeList', v_node_json);
    END LOOP;
    x_response := v_response.to_json;

  END proc_query_next_node_approvers;
END dbpm_process_node_api_pkg;

/

