create PACKAGE BODY     dbpm_process_params_api_pkg IS

  /*==================================================
  Procedure/Function Name :
      proc_query_process_params
  Description:
      This function perform:
      查询流程参数
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-07-06  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_query_process_params(p_request CLOB, x_response OUT CLOB) IS
    v_request  json;
    v_response pl_json := pl_json;
    CURSOR v_process_params_cur(p_process_id NUMBER) IS
      SELECT dpp.*
        FROM dbpm_process_params dpp
       WHERE dpp.process_id = p_process_id;
    v_process_id NUMBER;
    v_line       pl_json;
    v_total      NUMBER := 0;
  BEGIN
    v_request := json(p_request, 'OBJECT');
    IF v_request.get('processId') IS NULL THEN
      x_response := v_response.to_json;
      RETURN;
    END IF;
    v_process_id := v_request.get('processId').get_number;
    FOR v_process_param IN v_process_params_cur(v_process_id) LOOP
      v_line := pl_json;
      v_line.set_value('paramId', v_process_param.param_id);
      v_line.set_value('paramCode', v_process_param.param_code);
      v_line.set_value('paramName', v_process_param.param_name);
      v_line.set_value('paramType', v_process_param.param_type);
      v_response.add_list_item('processParamsList', v_line);
      v_total := v_total + 1;
    END LOOP;
    v_response.set_value('total', v_total);
    x_response := v_response.to_json;
  END proc_query_process_params;

  /*==================================================
  Procedure/Function Name :
      proc_save_process_param
  Description:
      This function perform:
      保存流程参数，需要判断是新增还是修改
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-07-06  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_save_process_param(p_request IN CLOB, x_response OUT CLOB) IS
    v_request    json;
    v_response   pl_json := pl_json;
    v_process_id NUMBER;
    v_pkg_name   VARCHAR2(100) := 'proc_save_process_param';
    v_param_code VARCHAR2(100);
    v_param_name VARCHAR2(100);
    v_param_type VARCHAR2(100);
    v_param_id   NUMBER;
  BEGIN
    v_request := json(p_request, 'OBJECT');
    --v_request    := json(p_request);
    v_process_id := v_request.get_number('processId');
    v_param_code := v_request.get_string('paramCode');
    v_param_name := v_request.get_string('paramName');
    v_param_type := v_request.get_string('paramType');
    --判断v_param_id是否为空
    IF v_request.get('paramId') IS NULL THEN
      INSERT INTO dbpm_process_params
        (param_id, process_id, param_code, param_name, param_type)
      VALUES
        (dbpm_process_params_s.nextval,
         v_process_id,
         v_param_code,
         v_param_name,
         v_param_type);
    ELSE
      v_param_id := v_request.get('paramId').get_number;
      UPDATE dbpm_process_params
         SET process_id = v_process_id,
             param_code = v_param_code,
             param_name = v_param_name,
             param_type = v_param_type
       WHERE param_id = v_param_id;
    END IF;
    x_response := v_response.to_json;
    /*  EXCEPTION--migrate by xiaowei.yao 20180416 异常在OSB中处理
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail(v_pkg_name || '接口发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_save_process_param;

  /*==================================================
  Procedure/Function Name :
      proc_del_process_param
  Description:
      This function perform:
      删除流程参数
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-05-13  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_del_process_param(p_request IN CLOB, x_response OUT CLOB) IS
    v_request  json;
    v_response pl_json := pl_json;
    v_pkg_name VARCHAR2(100) := 'proc_del_process_param';
    v_param_id NUMBER;
  BEGIN
    v_request := json(p_request, 'OBJECT');
    --获取参数的id
    v_param_id := v_request.get('paramId').get_number;
    IF v_param_id IS NOT NULL THEN
      DELETE FROM dbpm_process_params dpp WHERE dpp.param_id = v_param_id;
    END IF;
    x_response := v_response.to_json;
    /*EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail(v_pkg_name || '接口出现错误，错误原因是:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_del_process_param;
  /*==================================================
  Procedure/Function Name :
      proc_get_process_req_params
  Description:
      This function perform:
      获取json格式
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-09-29  张俊强~  Creation
  ==================================================*/
  PROCEDURE proc_get_process_req_params(p_request  IN CLOB,
                                        x_response OUT CLOB) IS
    v_api           VARCHAR2(100) := 'proc_get_process_req_params';
    v_request       json;
    v_business_json pl_json := pl_json; --businessParams
    v_process_json  pl_json := pl_json; --processParams
    v_delivery_json pl_json;
    v_response      pl_json := pl_json;
    v_form_id       NUMBER;
    v_attr_code     VARCHAR2(100);
    v_process_id    NUMBER;
    v_params_json   pl_json := pl_json;
    v_req_url       VARCHAR2(4000);

    CURSOR v_req_params_cur(c_form_id NUMBER) IS
      SELECT dff.parent_id, dff.type, dff.attr_code, dff.label
        FROM dbpm_form_field dff
       WHERE dff.form_id = c_form_id
         AND dbpm_comm_pkg.is_standard_component(p_type => dff.type) = 'N';
    /*AND NOT EXISTS (SELECT 1
     FROM dbpm_form_field
    WHERE dff.parent_id = parent_id
      AND dff.attr_code < attr_code);*/

    CURSOR v_process_parent_cur(c_form_id VARCHAR2, c_parent_id VARCHAR2) IS
      SELECT dff2.attr_code, dff2.label
        FROM dbpm_form_field dff2
       WHERE dff2.form_id = c_form_id
         AND dff2.parent_id = c_parent_id;

    CURSOR v_get_processcode_cur(c_process_id NUMBER) IS
      SELECT dpp.param_code, dpp.param_name
        FROM dbpm_process_params dpp
       WHERE dpp.process_id = c_process_id;

  BEGIN
    -- 得到传入的参数
    v_request := json(p_request, 'OBJECT');
    v_form_id := v_request.get('formId').get_number;

    FOR req_params_cur IN v_req_params_cur(v_form_id) LOOP
      IF req_params_cur.parent_id IS NULL THEN
        -- 不是 table input
        IF req_params_cur.type != 'table-input' AND
           req_params_cur.attr_code IS NOT NULL THEN
          IF req_params_cur.label IS NULL THEN
            v_business_json.set_value(req_params_cur.attr_code, ' ');
          ELSE
            v_business_json.set_value(req_params_cur.attr_code,
                                      req_params_cur.label);
          END IF;

        ELSE
          NULL;
        END IF;
      ELSE
        -- 如v_param_json是 table input
        SELECT dff1.attr_code
          INTO v_attr_code
          FROM dbpm_form_field dff1
         WHERE dff1.id = req_params_cur.parent_id
           AND dff1.form_id = v_form_id;
        -- 查找其他的属性
        IF v_attr_code IS NOT NULL THEN
          v_delivery_json := pl_json;
          FOR attr_code_cur IN v_process_parent_cur(v_form_id,
                                                    req_params_cur.parent_id) LOOP
            IF attr_code_cur.attr_code IS NOT NULL THEN
              IF attr_code_cur.label IS NULL THEN
                v_delivery_json.set_value(attr_code_cur.attr_code, ' ');
              ELSE
                v_delivery_json.set_value(attr_code_cur.attr_code,
                                          attr_code_cur.label);
              END IF;
            ELSE
              NULL;
            END IF;
          END LOOP;
          v_business_json.add_list_item(v_attr_code, v_delivery_json);
        ELSE
          NULL;
        END IF;
      END IF;
    END LOOP;
    -- 添加流程param
    SELECT df.process_id
      INTO v_process_id
      FROM dbpm_form df
     WHERE df.form_id = v_form_id;

    FOR processcode_cur IN v_get_processcode_cur(v_process_id) LOOP
      IF processcode_cur.param_name IS NULL THEN
        v_process_json.set_value(processcode_cur.param_code, ' ');
      ELSE
        v_process_json.set_value(processcode_cur.param_code,
                                 processcode_cur.param_name);
      END IF;
    END LOOP;

    v_params_json.set_value('processCode', '流程编码');
    v_params_json.set_value('processTitle', '流程标题');
    v_params_json.set_value('processApplier', '发起人编码');
    v_params_json.set_value('processApplierName', '发起人姓名');
    v_params_json.set_value('documentNumber', '单据编号');
    v_params_json.set_value('documentId', '单据ID');
    v_params_json.set_value('departmentId', '部门ID');
    --v_params_json.set_value('companyId', '公司ID');
    v_params_json.set_value('keyword', '关键字');
    v_params_json.set_value('businessSysCode', '系统编码');
    v_params_json.set_value('locale', '语言');
    v_params_json.set_value('businessParams', v_business_json);
    v_params_json.set_value('processParams', v_process_json);

    SELECT df.property_value
      INTO v_req_url
      FROM dfnd_properties df
     WHERE df.property_key = 'START_PROCESS_URL';
    v_response.set_value('url', v_req_url);
    v_response.set_value('params', v_params_json);

    x_response := v_response.to_json;

    /*  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;
    */
  END proc_get_process_req_params;
END dbpm_process_params_api_pkg;

/

