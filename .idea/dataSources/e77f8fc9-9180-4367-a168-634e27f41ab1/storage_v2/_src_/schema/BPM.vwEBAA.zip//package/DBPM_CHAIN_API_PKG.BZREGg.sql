create PACKAGE     dbpm_chain_api_pkg IS

  /*===================================================
  Procedure Name :
        proc_query_approval_chain
    Description:
         查询某个流程的所有审批链
    Argument:
        p_request：  请求（json）
        x_response： 响应（json）
    History:
        1.00  2017-03-21  chenming Creation
  ===================================================*/
  PROCEDURE proc_query_process_chains(p_request CLOB, x_response OUT CLOB);

  /*===================================================
   Procedure Name :
         proc_save_process_chain
     Description:
          保存审批链，需要判断是新建还是更新
     Argument:
         p_request：  请求（json）
         x_response： 响应（json）
     History:
         1.00  2017-04-08  skycloud.wang
  =================================================== */
  PROCEDURE proc_save_process_chain(p_request CLOB, x_response OUT CLOB);

  /*===================================================
   Procedure Name :
         proc_del_approval_chain
     Description:
          删除审批链及审批节点
     Argument:
         p_request：  请求（json）
         x_response： 响应（json）
     History:
         1.00  2017-03-21  chenming Creation
  =================================================== */
  PROCEDURE proc_del_approval_chain(p_request CLOB, x_response OUT CLOB);
  /*==================================================
  Procedure/Function Name :
      proc_query_add_chain_rule_data
  Description:
      This function perform:
      查询在添加审批链规则时所需要的数据
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-10  chenming  Creation
  ==================================================*/
  PROCEDURE proc_query_add_chain_rule_data(p_request  CLOB,
                                           x_response OUT CLOB);
  /*==================================================
  Procedure/Function Name :
      proc_query_chain_node
  Description:
      This function perform:
      查询配置或添加审批节点所需数据
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-10  chenming  Creation
  ==================================================*/
  PROCEDURE proc_query_chain_node(p_request CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_query_business_role
  Description:
      This function perform:
      查询业务角色
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-20  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_query_business_role(p_request CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_query_form_fields
  Description:
      This function perform:
      查询某个表单的所有组件
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-20  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_query_form_fields(p_request CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure Name :
      proc_query_admin_orginizations
  Description:
      查询管理员管理的组织
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2017-04-22  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_query_admin_orginizations(p_request  IN CLOB,
                                           x_response OUT CLOB);
  PROCEDURE proc_save_process_chain_ex(p_request CLOB, x_response OUT CLOB);
END dbpm_chain_api_pkg;

/

