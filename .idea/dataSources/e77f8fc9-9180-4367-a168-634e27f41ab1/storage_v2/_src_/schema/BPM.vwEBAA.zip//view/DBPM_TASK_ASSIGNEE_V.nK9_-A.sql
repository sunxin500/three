create view DBPM_TASK_ASSIGNEE_V as
SELECT dta.task_id,
       dta.assignee,
       dta.assignee_type,
       emp.employee_name AS assignee_name
  FROM dbpm_task_assignees dta, dfnd_employees emp
 WHERE upper(dta.assignee) = upper(emp.employee_code(+))
/

