create procedure     proc_test_fault_policy is
begin
  DELETE FROM BPM_SHALL_TEST;
  commit;
end proc_test_fault_policy;

/

