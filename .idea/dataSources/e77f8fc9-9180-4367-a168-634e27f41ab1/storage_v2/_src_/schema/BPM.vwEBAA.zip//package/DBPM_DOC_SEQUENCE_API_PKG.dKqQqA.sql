create PACKAGE     dbpm_doc_sequence_api_pkg IS
  /*==================================================
  Procedure/Function Name :
      proc_query_doc_sequences
  Description:
      This function perform:
      查询流水码管理
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-05-13  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_query_doc_sequences(p_request CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_save_doc_sequence
  Description:
      This function perform:
      保存流水码，需要判断是新增还是修改
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-20  skycloud.wang  Creation
      2.00  2018-02-08  wlj  modified  更改清零实现的方式
  ==================================================*/
  PROCEDURE proc_save_doc_sequence(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_del_doc_sequence
  Description:
      This function perform:
      删除流水码
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-05-13  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_del_doc_sequence(p_request IN CLOB, x_response OUT CLOB);
END dbpm_doc_sequence_api_pkg;

/

