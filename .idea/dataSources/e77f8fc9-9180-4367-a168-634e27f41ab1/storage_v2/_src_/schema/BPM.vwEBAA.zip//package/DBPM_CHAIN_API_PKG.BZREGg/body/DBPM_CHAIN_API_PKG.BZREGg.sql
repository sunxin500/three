create PACKAGE BODY     "DBPM_CHAIN_API_PKG" IS

  /*===================================================
   Procedure Name :
         proc_query_approval_chain
     Description:
          查询某个流程的所有审批链
     Argument:
         p_request：  请求（json）
         x_response： 响应（json）
     History:
         1.00  2017-03-21  chenming Creation
         1.1   2017-04-07  skycloud.wang
         1.2   2018-02-26  echo.zeng updated
  =================================================== */
  PROCEDURE proc_query_process_chains(p_request CLOB, x_response OUT CLOB) IS
    v_api                 VARCHAR2(100) := 'proc_query_approval_chain';
    v_request             json;
    v_response            pl_json := pl_json;
    v_current_user        VARCHAR2(50);
    v_chain_json          pl_json;
    v_rule_json           pl_json;
    v_node_json           pl_json;
    v_role_json           pl_json;
    v_param_json          pl_json;
    v_process_id          NUMBER;
    v_form_id             NUMBER;
    v_organization_id     VARCHAR2(50);
    v_total               NUMBER := 0;
    v_node_chain          pl_json;
    v_dynamic_user        pl_json; --add by chenzhibin
    v_dynamic_value_type  varchar2(100); --add by chenzhibin
    v_dynamic_value       varchar2(100); --add by chenzhibin
    v_space_id            varchar2(100); --add by wlj
    v_super_admin_count   number; --add by wlj
    v_process_classs      varchar2(100); --add by wlj 流程种类
    v_rule_tree_clob      clob; -- add by wlj 规则树
    v_rule_tree_json_list json_list; -- add by wlj 规则树
    CURSOR v_user_list_cur(p_node_id NUMBER) IS
      select * from cux_bpm_common_rule t where t.node_id = p_node_id;
    v_sql_user   pl_json;
    v_type_split type_split;
    v_approves   json_list;

    -- 流程审批链
    CURSOR v_chain_cur IS
      SELECT dac.*, tree.chain_rule_tree
        FROM dbpm_approval_chain dac, dbpm_chain_rules_tree tree
       WHERE dac.process_id = v_process_id
         AND dac.organization_id = v_organization_id
         AND dac.chain_id = tree.chain_id(+)
         AND (dac.is_deleted is null or dac.is_deleted = 'N')
       ORDER BY dac.chain_id;

    -- 外部流程审批链
    CURSOR v_chain_ext_cur IS
      SELECT *
        FROM dbpm_approval_chain dac
       WHERE dac.process_id = v_process_id
         AND (dac.is_deleted is null or dac.is_deleted = 'N')
       ORDER BY dac.chain_id;
    -- 流程审批规则
    /*   CURSOR v_rule_cur(p_chain_id NUMBER) IS
    SELECT dcr.*, rownum rule_seq
      FROM dbpm_chain_rules dcr
     WHERE dcr.chain_id = p_chain_id;*/
    --migrate by xiaowei.yao 20180512 begin
    CURSOR v_rule_cur(p_chain_id NUMBER) IS
      SELECT dcr.*,
             dff.data_source_text,
             dff.data_source_code,
             rownum rule_seq,
             (select dsv.value_name
                from dbpm_data_source_values dsv
               where dsv.status = 'Y'
                 and dsv.data_source_code = dff.data_source_code
                 and dsv.value_code = dcr.param_meaning) data_source_meaning
        FROM dbpm_chain_rules dcr,
             (select *
                from dbpm_form_field dfft
               where dfft.form_id = v_form_id) dff
       WHERE dcr.param_name = dff.id(+)
         AND dcr.chain_id = p_chain_id;
    --migrate by xiaowei.yao 20180512 end

    -- 审批链节点
    CURSOR v_node_cur(p_chain_id NUMBER) IS
      SELECT dcn.*
        FROM dbpm_chain_nodes dcn
       WHERE dcn.chain_id = p_chain_id
         AND DCN.IS_DELETED = 'N'
       ORDER BY dcn.order_num;

    -- 审批角色
    CURSOR v_role_cur(p_node_id NUMBER) IS
      SELECT dnr.*, dr.role_id, dr.role_name
        FROM dbpm_node_roles dnr, dbpm_roles dr
       WHERE dnr.business_role = dr.role_code
         AND dnr.node_id = p_node_id
         AND DNR.IS_DELETED = 'N'
         AND dnr.node_from_type = 'ChainNode'
       ORDER BY dnr.node_role_id;

    -- 审批角色参数
    CURSOR v_param_cur(p_node_role_id NUMBER) IS
      SELECT dnrp.param_id,
             dnrp.param_value,
             drp.param_name,
             dnrp.operation_type, --migrate by xiaowei.yao 20180512
             dnrp.get_value_type
        FROM dbpm_node_role_param_value dnrp,
             dbpm_node_roles            dnr,
             dbpm_role_params           drp
       WHERE dnrp.node_role_id = dnr.node_role_id
         AND dnr.node_from_type = 'ChainNode'
         AND dnrp.param_id = drp.param_id
         AND DNRP.IS_DELETED = 'N'
         AND dnrp.node_role_id = p_node_role_id;
    -- 节点审批链-migrate by xiaowei.yao20180512 begin
    CURSOR v_node_chain_cur(p_node_id NUMBER) IS
      SELECT dac.chain_id, dac.chain_name
        FROM dbpm_node_chains dnc, dbpm_approval_chain dac
       WHERE dnc.node_id = p_node_id
         and dnc.chain_id = dac.chain_id;
    --  and
    -- 节点审批链-migrate by xiaowei.yao20180512 end
    --add by yxw 节点国际化值

  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;
    v_process_id   := v_request.get('processId').get_number;
    --获取流程种类
    select dp.process_class
      into v_process_classs
      from dbpm_process dp
     where dp.process_id = v_process_id;
    --待商榷 begin
    --v_space_id     := cux_comm_pkg.func_get_space_id(v_current_user);
    v_space_id := v_request.get_string('spaceId');

    --如果未找到company_id,设置company_id为-1
    --如果是超级管理员,设置company_id为null
    select count(1)
      into v_super_admin_count
      from dbpm_administrators t
     where t.user_code = v_current_user
       and t.admin_type = 'SuperAdmin';
    if v_space_id is null then
      v_space_id := '-';
    end if;
    if v_super_admin_count > 0 then
      v_space_id := null;
    end if;
    --待商榷 end

    IF v_request.get('organizationId') IS NULL THEN
      BEGIN
        SELECT organization_id
          INTO v_organization_id
          FROM (SELECT *
                  FROM dbpm_administrators da
                 WHERE da.user_code = v_current_user
                 ORDER BY da.administrator_id)
         WHERE rownum = 1;
      EXCEPTION
        WHEN OTHERS THEN
          RETURN;
      END;
    ELSE
      v_organization_id := v_request.get('organizationId').get_string;
      if v_organization_id is not null then
        v_space_id := v_organization_id;
      end if;
    END IF;

    v_form_id := dbpm_comm_pkg.func_get_process_form(p_process_id => v_process_id);
    v_response.set_value('processId', v_process_id);
    v_response.set_value('organizationId', v_organization_id);
    if v_process_classs = 'EXTERNAL' then
      FOR v_chain IN v_chain_ext_cur LOOP
        v_total      := v_total + 1;
        v_chain_json := pl_json;
        v_chain_json.set_value('chainId', v_chain.chain_id);
        v_chain_json.set_value('chainName', v_chain.chain_name);
        v_chain_json.set_value('chainType', v_chain.chain_type); --migrate by xiaowei.yao 20180512
        v_chain_json.set_value('processId', v_process_id);
        v_chain_json.set_value('formId', v_form_id);

        FOR v_node IN v_node_cur(v_chain.chain_id) LOOP
          v_node_json := pl_json;
          v_node_json.set_value('nodeId', v_node.node_id);
          v_node_json.set_value('nodeName', v_node.node_name);
          v_node_json.set_value('nodeType', v_node.node_type);
          v_node_json.set_value('approverType', v_node.approver_type);
          v_node_json.set_value('nodeSeq', v_node.order_num);
          v_node_json.set_value('nodeThumbPic', 'null');
          v_node_json.set_value('parentId', v_node.parent_id);
          v_node_json.set_value('backNodeId', v_node.back_node_id);
          --migrate by xiaowei.yao 20180512 begin
          IF v_node.is_required = 'Y' THEN
            --add by wlj
            v_node_json.set_value('isRequired', TRUE);
          ELSE
            v_node_json.set_value('isRequired', FALSE);
          END IF;
          IF v_node.is_auto_approve = 'Y' THEN
            --add by wlj
            v_node_json.set_value('isAutoApprove', TRUE);
          ELSE
            v_node_json.set_value('isAutoApprove', FALSE);
          END IF;
          v_chain_json.add_list_item('nodes', v_node_json);
        END LOOP;

        v_response.add_list_item('chains', v_chain_json);
      END LOOP;
    elsif v_process_classs = 'INTERNAL' THEN
      FOR v_chain IN v_chain_cur LOOP
        v_total      := v_total + 1;
        v_chain_json := pl_json;
        v_chain_json.set_value('chainId', v_chain.chain_id);
        v_chain_json.set_value('chainName', v_chain.chain_name);
        v_chain_json.set_value('chainType', v_chain.chain_type); --migrate by xiaowei.yao 20180512
        v_chain_json.set_value('processId', v_process_id);
        v_chain_json.set_value('formId', v_form_id);
        /*SELECT do.organization_name
          INTO v_organization_name
          FROM dfnd.dfnd_organizations do
         WHERE do.organization_id = v_chain.organization_id;
        v_chain_json.set_value('organizationName', v_organization_name);*/

        FOR v_rule IN v_rule_cur(v_chain.chain_id) LOOP
          v_rule_json := pl_json;
          v_rule_json.set_value('ruleId', v_rule.rule_id);
          v_rule_json.set_value('ruleSeq', v_rule.rule_seq);
          v_rule_json.set_value('paramName', v_rule.param_name);
          v_rule_json.set_value('paramMeaning', v_rule.param_meaning);
          v_rule_json.set_value('operation', v_rule.operation_type);
          --获取下拉框meaning migrate by xiaowei.yao 20180512
          --
          if v_rule.data_source_text is null and
             v_rule.data_source_code is null then
            v_rule_json.set_value('paramValue', v_rule.param_value);
            v_rule_json.set_value('paramCode', v_rule.param_value);
          elsif instr(v_rule.data_source_text, v_rule.param_value) > 0 then
            v_rule_json.set_value('paramValue', v_rule.param_value);
            v_rule_json.set_value('paramCode', v_rule.param_value);
          else
            v_rule_json.set_value('paramValue', v_rule.param_value);
            --
            v_rule_json.set_value('paramCode', v_rule.param_value);
          end if;
          v_rule_json.set_value('ruleUuid', v_rule.rule_uuid);
          v_rule_json.set_value('getValueType', v_rule.get_value_type);
          v_chain_json.add_list_item('rules', v_rule_json);
        END LOOP;

        FOR v_node IN v_node_cur(v_chain.chain_id) LOOP
          v_node_json := pl_json;
          v_node_json.set_value('nodeId', v_node.node_id);
          v_node_json.set_value('nodeName', v_node.node_name);
          v_node_json.set_value('nodeType', v_node.node_type);
          v_node_json.set_value('approverType', v_node.approver_type);
          v_node_json.set_value('nodeSeq', v_node.order_num);
          v_node_json.set_value('nodeThumbPic', 'null');
          v_node_json.set_value('parentId', v_node.parent_id);
          v_node_json.set_value('backNodeId', v_node.back_node_id);
          --migrate by xiaowei.yao 20180512 begin
          IF v_node.is_required = 'Y' THEN
            --add by wlj
            v_node_json.set_value('isRequired', TRUE);
          ELSE
            v_node_json.set_value('isRequired', FALSE);
          END IF;
          IF v_node.is_auto_approve = 'Y' THEN
            --add by wlj
            v_node_json.set_value('isAutoApprove', TRUE);
          ELSE
            v_node_json.set_value('isAutoApprove', FALSE);
          END IF;
          --migrate by xiaowei.yao 20180512 end

          FOR v_role IN v_role_cur(v_node.node_id) LOOP
            v_role_json := pl_json;
            v_role_json.set_value('roleId', v_role.role_id);
            v_role_json.set_value('roleCode', v_role.business_role);
            v_role_json.set_value('roleName', v_role.role_name);
            v_role_json.set_value('customRoleName',
                                  v_role.custom_role_name);
            FOR v_param IN v_param_cur(v_role.node_role_id) LOOP
              v_param_json := pl_json;
              v_param_json.set_value('getValueType',
                                     v_param.get_value_type);
              v_param_json.set_value('operationType',
                                     v_param.operation_type);

              v_param_json.set_value('paramId', v_param.param_id);
              v_param_json.set_value('paramName', v_param.param_name);
              v_param_json.set_value('paramValue', v_param.param_value);
              v_role_json.add_list_item('paramList', v_param_json);
            END LOOP;

            v_node_json.add_list_item('businessRoles', v_role_json);
          END LOOP;

          --marigate by xiaowei.yao 20180512
          FOR v_chain IN v_node_chain_cur(v_node.node_id) LOOP
            v_node_chain := pl_json;
            v_node_chain.set_value('chainId', v_chain.chain_id);
            v_node_chain.set_value('chainName', v_chain.chain_name);
            /* IF v_chain.is_checked = 'Y'
            THEN
              v_node_chain.set_value('isChecked', TRUE);
            ELSE
              v_node_chain.set_value('isChecked', FALSE);
            END IF;*/
            v_node_json.add_list_item('nodeChains', v_node_chain);
          END LOOP;
          --add by chenzhibin begin
          if v_node.approver_type = 'DynamicUser' then
            v_dynamic_user := pl_json;
            select nvl(max(t.dynamic_value), ''),
                   nvl(max(t.get_value_type), '')
              into v_dynamic_value, v_dynamic_value_type
              from DBPM_DYNAMIC_APPROVERS t
             where t.node_id = v_node.node_id;
            v_dynamic_user.set_value('getValueType', v_dynamic_value_type);
            if v_dynamic_value_type = 'SQL' then
              for v_row in v_user_list_cur(v_node.node_id) loop
                v_sql_user := pl_json;
                v_sql_user.set_value('rule', v_row.rule_expression);
                v_sql_user.set_value('getValueType', v_row.get_value_type);
                v_type_split := func_string_split(v_row.rule_value, ',');
                v_approves   := json_list;
                for i in 1 .. v_type_split.count loop
                  v_approves.append(v_type_split(i));
                end loop;
                v_sql_user.set_value('approverList', v_approves);
                v_dynamic_user.add_list_item('sqlUsers', v_sql_user);
              end loop;
            else
              v_dynamic_user.set_value('dynamicValue', v_dynamic_value);
            end if;
            v_node_json.set_value('dynamicUser', v_dynamic_user);
          end if;
          --add by chenzhibin end

          --add by wlj begin
          if v_node.approver_type = 'StaticUser' then
            begin
              select nvl(t.dynamic_value, '')
                into v_dynamic_value
                from DBPM_DYNAMIC_APPROVERS t
               where t.node_id = v_node.node_id
                 and t.get_value_type = 'STATIC';
            exception
              when no_data_found then
                v_dynamic_value := '';
            end;
            v_node_json.set_value('StaticUser', v_dynamic_value);
          end if;

          v_chain_json.add_list_item('nodes', v_node_json);

        END LOOP;

        begin
          --维护ruleTree add by wlj end
          v_rule_tree_clob      := v_chain.chain_rule_tree;
          v_rule_tree_json_list := json_list(v_rule_tree_clob);
          v_chain_json.set_value('ruleTree', v_rule_tree_json_list);
        exception
          when no_data_found then
            null;
        end;
        v_response.add_list_item('chains', v_chain_json);
      END LOOP;
    end if;

    v_response.set_value('total', v_total);
    x_response := v_response.to_json;
    /*EXCEPTION
    WHEN OTHERS THEN
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_query_process_chains;

  /*===================================================
   Procedure Name :
         proc_save_process_chain
     Description:
          保存审批链，需要判断是新建还是更新
     Argument:
         p_request：  请求（json）
         x_response： 响应（json）
     History:
         1.00  2017-04-08  skycloud.wang
         1.10  2018-02-26  echo.zeng   updated
         1.11  2018-03-12  echo.zeng   updated
  =================================================== */
  PROCEDURE proc_save_process_chain(p_request CLOB, x_response OUT CLOB) IS
    v_api           VARCHAR2(100) := 'proc_save_process_chain';
    v_request       json;
    v_response      pl_json := pl_json;
    v_current_user  VARCHAR2(50);
    v_rule_list     json_list;
    v_rule          json;
    v_node_list     json_list;
    v_node          json;
    v_role_list     json_list;
    v_role          json;
    v_param_list    json_list;
    v_param         json;
    v_chain_id      NUMBER;
    v_rule_id       NUMBER;
    v_node_id       NUMBER;
    v_node_role_id  NUMBER;
    v_field_type    VARCHAR2(100);
    v_param_type    VARCHAR2(30);
    v_count         NUMBER := 0;
    v_chain_list    json_list;
    v_chain         json;
    v_node_chain_id NUMBER;
    v_form_id       NUMBER;
    --add by chenzhibin begin
    v_node_dynamic_value_type varchar2(100);
    v_node_dynamic_value      varchar2(100);
    v_node_dynamic_user       json;
    v_approver_users          varchar2(1000);
    --add by chenzhibin end
    --add by echo.zeng begin
    v_sql_users    json_list;
    v_sql_user     json;
    v_sql_rule     varchar2(1000);
    v_user_list    json_list;
    v_approvers    varchar2(4000);
    v_process_code varchar2(300);
    --add by echo.zeng end
    v_space_id           varchar2(100); --add by wlj
    v_organization_id    varchar2(100); --add by wlj
    v_is_required        varchar2(10); --add by wlj
    v_is_auto_approve    varchar2(10); --add by wlj
    v_err_msg            varchar2(4000); -- add by wlj
    v_max_version        number; -- add by wlj
    v_response_node_list pl_json := pl_json; -- add by wlj
    v_response_node_item pl_json; -- add by wlj
    v_rule_tree_clob     clob; --add by wlj

    --add by yxw end
    cursor v_button_list_cur is
      select regexp_substr('APPROVE,REJECT,DESTROY', '[^,]+', 1, level) col
        from dual
      connect by level <= regexp_count('APPROVE,REJECT,DESTROY', ',') + 1; -- add by wlj
    --add by xiaowei.yao 20190320
    v_rulelist_tmp  json_list;
    v_ruletree_tmp  json_list;
    v_ruletree_list json_list;
    v_rule_str      VARCHAR2(32767 byte);
    v_tree          json;
    v_rul           json;
    --add by xiaowei.yao
    v_sql_getvalue_type varchar2(200);
    v_back_node_id      number;
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;
    v_err_msg      := dcld_comm_pkg.func_get_err_msg('DCLD-00001',
                                                     v_request.locale);
    --v_space_id     := cux_comm_pkg.func_get_space_id(v_current_user);
    v_organization_id := v_request.get_string('organizationId');
    v_space_id        := v_request.get_string('spaceId');

    IF v_request.get('chainId') IS NULL OR v_request.get('chainId')
      .get_number = 0 THEN
      v_chain_id := dbpm_approval_chain_s.nextval;
    ELSE
      v_chain_id := v_request.get('chainId').get_number;
    END IF;
    -- 1.保存审批链
    SELECT COUNT(1), nvl(max(dac.version), 0)
      INTO v_count, v_max_version
      FROM dbpm_approval_chain dac
     WHERE dac.chain_id = v_chain_id;
    --维护规则树
    IF v_request.path('ruleTree') IS NOT NULL THEN
      dbms_lob.createtemporary(v_rule_tree_clob, false);
      json_list(v_request.get('ruleTree')).to_clob(v_rule_tree_clob);
    END IF;
    ---让规则树和规则表的条件保持一致
    IF v_request.path('ruleTree') IS NOT NULL and
       v_request.path('rules') IS NOT NULL then
      v_rulelist_tmp := json_list(v_request.path('rules'));
      v_ruletree_tmp := json_list(v_request.path('ruleTree'));
      v_rule_str     := dbpm_rule_api_pkg.func_parse_rule(v_ruletree_tmp);

      for k in 1 .. v_rulelist_tmp.count loop
        v_rul      := json(v_rulelist_tmp.get(k));
        v_rule_str := replace(v_rule_str,
                              ':' || v_rul.get_string('ruleUuid'),
                              1);
      end loop;
      if instr(v_rule_str, ':') > 0 then
        /*  v_response.fail(DCLD_COMM_PKG.func_get_err_msg('DCLD-00024',
        v_request.locale));*/
        v_response.fail('规则表和规则树数据结构不一致');
        x_response := v_response.to_json;
        return;
      end if;

    end if;
    IF v_count > 0 THEN
      UPDATE dbpm_approval_chain dac
         SET dac.chain_name            = v_request.get('chainName')
                                         .get_string,
             dac.chain_type            = v_request.get('chainType')
                                         .get_string,
             dac.organization_id       = v_request.get('organizationId')
                                         .get_string,
             dac.space_id              = v_space_id,
             dac.object_version_number = dac.object_version_number + 1,
             dac.last_updated_by       = v_current_user,
             dac.version               = dac.version + 1,
             dac.last_update_date      = sysdate
       WHERE dac.chain_id = v_chain_id;
      UPDATE dbpm_chain_rules_tree tree
         SET tree.chain_name            = v_request.get('chainName')
                                          .get_string,
             tree.chain_type            = v_request.get('chainType')
                                          .get_string,
             tree.organization_id       = v_request.get('organizationId')
                                          .get_string,
             tree.space_id              = v_space_id,
             tree.object_version_number = tree.object_version_number + 1,
             tree.last_updated_by       = v_current_user,
             tree.version               = tree.version + 1,
             tree.chain_rule_tree       = v_rule_tree_clob,
             tree.last_update_date      = sysdate
       WHERE tree.chain_id = v_chain_id;
    ELSE
      INSERT INTO dbpm_approval_chain
        (chain_id,
         chain_name,
         chain_type,
         process_id,
         organization_id,
         status,
         created_by,
         last_updated_by,
         space_id)
      VALUES
        (v_chain_id,
         v_request.get ('chainName' ).get_string,
         v_request.get ('chainType' ).get_string,
         v_request.get ('processId' ).get_number,
         v_request.get ('organizationId' ).get_string,
         'Y',
         v_current_user,
         v_current_user,
         v_space_id);
      INSERT INTO dbpm_chain_rules_tree
        (chain_id,
         chain_name,
         chain_type,
         process_id,
         organization_id,
         status,
         created_by,
         last_updated_by,
         space_id,
         chain_rule_tree)
      VALUES
        (v_chain_id,
         v_request.get   ('chainName'   ).get_string,
         v_request.get   ('chainType'   ).get_string,
         v_request.get   ('processId'   ).get_number,
         v_request.get   ('organizationId'   ).get_string,
         'Y',
         v_current_user,
         v_current_user,
         v_space_id,
         v_rule_tree_clob);
    END IF;
    v_form_id := dbpm_comm_pkg.func_get_process_form(p_process_id => v_request.get('processId')
                                                                     .get_number);
    -- 2. 保存审批规则
    DELETE dbpm_chain_rules dcr WHERE dcr.chain_id = v_chain_id;
    IF v_request.path('rules') IS NOT NULL THEN
      v_rule_list := json_list(v_request.path('rules'));

      FOR i IN 1 .. v_rule_list.count LOOP
        v_rule := json(v_rule_list.get(i));
        IF v_rule.get('ruleId') IS NULL THEN
          v_rule_id := dbpm_chain_rules_s.nextval;
        ELSE
          v_rule_id := v_rule.get('ruleId').get_number;
        END IF;
        IF v_rule.get('getValueType').get_string = 'FIELD' THEN
          SELECT dff.type
            INTO v_field_type
            FROM dbpm_form_field dff
           WHERE dff.id = v_rule.get('paramName').get_string
             AND dff.form_id = v_form_id;
          IF dbpm_comm_pkg.is_number_component(v_field_type) = 'Y' THEN
            v_param_type := 'NUMBER';
          ELSE
            v_param_type := 'VARCHAR';
          END IF;
        ELSIF v_rule.get('getValueType').get_string = 'PROCESSPARAM' THEN
          SELECT dpp.param_type
            INTO v_param_type
            FROM dbpm_process_params dpp
           WHERE dpp.process_id = v_request.get('processId').get_number
             AND dpp.param_code = v_rule.get('paramName').get_string;
        END IF;
        INSERT INTO dbpm_chain_rules
          (rule_id,
           chain_id,
           param_name,
           param_meaning,
           param_type,
           get_value_type,
           operation_type,
           param_value,
           created_by,
           last_updated_by,
           rule_uuid)
        VALUES
          (v_rule_id,
           v_chain_id,
           v_rule.get('paramName').get_string, -- 表单组件上面的ID
           v_rule.get('paramMeaning').get_string, -- 表单组件上的显示名称
           v_param_type,
           v_rule.get('getValueType').get_string,
           v_rule.get('operation').get_string,
           v_rule.get('paramValue').get_string,
           v_current_user,
           v_current_user,
           v_rule.get_string('ruleUuid'));
      END LOOP;
    END IF;
    -- 3. 保存审批节点
    -- 先删除(假删除)
    FOR v_node_del IN (SELECT *
                         FROM dbpm_chain_nodes dcn
                        WHERE dcn.chain_id = v_chain_id) LOOP
      FOR v_role_del IN (SELECT *
                           FROM dbpm_node_roles dnr
                          WHERE dnr.node_id = v_node_del.node_id
                            AND dnr.node_from_type = 'ChainNode') LOOP
        UPDATE dbpm_node_role_param_value dnrp
           set dnrp.is_deleted = 'Y'
         WHERE dnrp.node_role_id = v_role_del.node_role_id;
        UPDATE dbpm_node_roles dnr
           set dnr.is_deleted = 'Y'
         WHERE dnr.node_role_id = v_role_del.node_role_id
           AND dnr.node_from_type = 'ChainNode';

      END LOOP;
      UPDATE dbpm_chain_nodes dcn
         SET DCN.IS_DELETED = 'Y'
       WHERE dcn.node_id = v_node_del.node_id;

      UPDATE dbpm_chain_nodes_tl dcnt
         SET DCNT.IS_DELETED = 'Y'
       WHERE dcnt.node_id = v_node_del.node_id;
      -- and dcnt.locale = dbpm_comm_pkg.get_current_locale;

      --删除动态审批人
      update DBPM_DYNAMIC_APPROVERS t
         set t.is_deleted = 'Y'
       where t.node_id = v_node_del.node_id;
      --海尔的定制化规则
      update cux_bpm_common_rule t
         set t.is_deleted = 'Y'
       where t.node_id = v_node_del.node_id;
      -- 删除节点审批链
      DELETE FROM dbpm_node_chains dnc
       WHERE dnc.node_id = v_node_del.node_id
         AND dnc.node_from_type = 'ChainNode';
    END LOOP;
    -- 新建
    v_response_node_list.set_data_type('ARRAY');
    IF v_request.path('nodes') IS NOT NULL THEN
      v_node_list := json_list(v_request.path('nodes'));
      FOR i IN 1 .. v_node_list.count LOOP
        v_node := json(v_node_list.get(i));
        -- 验证子审批链不能创建子流程节点
        IF v_request.get('chainType').get_string = 'SubChain' AND v_node.get('nodeType')
           .get_string = 'SubProcess' THEN
          ROLLBACK;
          /*v_response.fail(v_node.get('nodeName')
          .get_string || '节点配置不合法，子审批链中不能存在子流程节点！');*/
          v_response.fail(v_node.get('nodeName').get_string || v_err_msg);
          x_response := v_response.to_json;
          RETURN;
        END IF;

        v_node_id            := dbpm_chain_nodes_s.nextval;
        v_response_node_item := pl_json;
        v_response_node_item.set_value('nodeId', v_node_id);
        --默认添加所有的按钮
        for v_btn_cur in v_button_list_cur loop
          insert into dbpm_node_buttons
            (node_button_id, node_id, button_code)
          values
            (dbpm_node_buttons_s.nextval, v_node_id, v_btn_cur.col);
        end loop;
        v_response_node_list.add_list_item(v_response_node_item);

        v_is_required := 'N';
        IF v_node.get('isRequired') IS NOT NULL AND v_node.get('isRequired')
          .get_bool = TRUE THEN
          v_is_required := 'Y';
        END IF;
        v_is_auto_approve := 'N';
        IF v_node.get('isAutoApprove') IS NOT NULL AND v_node.get('isAutoApprove')
          .get_bool = TRUE THEN
          v_is_auto_approve := 'Y';
        END IF;
        if v_node.get('nodeType').get_string = 'SubProcess' then
          v_back_node_id := -1;
        else
          v_back_node_id := v_node.get_number('backNodeId');
        end if;
        INSERT INTO dbpm_chain_nodes
          (node_id,
           chain_id,
           node_name,
           node_type,
           approver_type,
           order_num,
           created_by,
           last_updated_by,
           is_required, --add by wlj
           is_auto_approve,
           version,
           parent_id,
           back_node_id) --add by xiaowei.yao
        VALUES
          (v_node_id,
           v_chain_id,
           v_node.get('nodeName').get_string,
           v_node.get('nodeType').get_string,
           v_node.get('approverType').get_string,
           v_node.get('nodeSeq').get_number,
           v_current_user,
           v_current_user,
           v_is_required, --add by wlj
           v_is_auto_approve,
           v_max_version + 1,
           v_node.get_number('parentId'),
           v_node.get_number('backNodeId')); --add by wlj;
        -- 添加多语言表
        INSERT INTO dbpm_chain_nodes_tl
          (node_id,
           locale,
           node_name,
           created_by,
           last_updated_by,
           object_version_number)
        VALUES
          (v_node_id,
           dbpm_comm_pkg.get_current_locale,
           v_node.get('nodeName').get_string,
           v_current_user,
           v_current_user,
           v_max_version + 1);

        -- 3.1 保存审批节点角色
        IF v_node.path('businessRoles') IS NOT NULL THEN
          v_role_list := json_list(v_node.path('businessRoles'));
          FOR j IN 1 .. v_role_list.count LOOP
            v_role         := json(v_role_list.get(j));
            v_node_role_id := dbpm_node_roles_s.nextval;
            INSERT INTO dbpm_node_roles
              (node_role_id,
               node_id,
               business_role,
               node_from_type,
               created_by,
               last_updated_by,
               custom_role_name)
            VALUES
              (v_node_role_id,
               v_node_id,
               v_role.get('roleCode').get_string,
               'ChainNode',
               v_current_user,
               v_current_user,
               v_role.get_string('customRoleName'));
            -- 3.1.1 保存角色参数
            IF v_role.path('paramList') IS NOT NULL THEN
              v_param_list := json_list(v_role.path('paramList'));
              FOR k IN 1 .. v_param_list.count LOOP
                v_param := json(v_param_list.get(k));
                INSERT INTO dbpm_node_role_param_value
                  (node_role_id,
                   param_id,
                   param_value,
                   operation_type,
                   get_value_type)
                VALUES
                  (v_node_role_id,
                   v_param.get   ('paramId'   ).get_number,
                   v_param.get   ('paramValue'   ).get_string,
                   v_param.get   ('operationType'   ).get_string,
                   v_param.get   ('getValueType'   ).get_string);
              END LOOP;
            END IF;
          END LOOP;
        END IF;

        -- 3.1 保存审批节点子审批链
        IF v_node.path('nodeChains') IS NOT NULL THEN
          v_chain_list := json_list(v_node.path('nodeChains'));
          FOR k IN 1 .. v_chain_list.count LOOP
            v_chain         := json(v_chain_list.get(k));
            v_node_chain_id := dbpm_node_chains_s.nextval;
         --   IF v_chain.get('isChecked').get_bool THEN
              INSERT INTO dbpm_node_chains
                (node_chain_id,
                 node_id,
                 chain_id,
                 node_from_type,
                 created_by,
                 last_updated_by)
              VALUES
                (v_node_chain_id,
                 v_node_id,
                 v_chain.get('chainId').get_number,
                 'ChainNode',
                 v_current_user,
                 v_current_user);
          --  END IF;
          END LOOP;
        END IF;
        --add by chenzhibin begin
        if v_node.get('approverType') is not null and v_node.get('approverType')
          .get_string = 'DynamicUser' and
           v_node.path('dynamicUser') IS NOT NULL THEN
          v_node_dynamic_user := json(v_node.path('dynamicUser'));
          --update by echo.zeng 2018-02-26 begin
          if v_node_dynamic_user.get_string('getValueType') = 'SQL' then
            v_sql_users := json_list(v_node_dynamic_user.get('sqlUsers'));
            for i in 1 .. v_sql_users.count loop
              v_sql_user          := json(v_sql_users.get(i));
              v_sql_rule          := v_sql_user.get_string('rule');
              v_sql_getvalue_type := v_sql_user.get_string('getValueType');
              v_approvers         := '';
              v_user_list         := json_list(v_sql_user.get('approverList'));
              for j in 1 .. v_user_list.count loop
                if v_approvers is null then
                  v_approvers := v_user_list.get(j).get_string;
                else
                  v_approvers := v_approvers || ',' || v_user_list.get(j)
                                .get_string;
                end if;
              end loop;
              insert into cux_bpm_common_rule t
                (common_rule_id,
                 node_id,
                 rule_expression,
                 rule_value,
                 get_value_type)
              values
                (cux_bpm_common_rule_s.nextval,
                 v_node_id,
                 v_sql_rule,
                 v_approvers,
                 v_sql_getvalue_type);
            end loop;
          end if;
          --update by echo.zeng 2018-02-26 end
          insert into DBPM_DYNAMIC_APPROVERS
            (APPROVER_ID,
             NODE_ID,
             DYNAMIC_VALUE,
             GET_VALUE_TYPE,
             OPERATION_TYPE)
          values
            (DBPM_DYNAMIC_APPROVERs_s.Nextval,
             v_node_id,
             nvl(v_node_dynamic_user.get_string('dynamicValue'), 'null'),
             v_node_dynamic_user.get_string('getValueType'),
             null);
        end if;
        --add by chenzhibin end
        --add by wlj begin
        if v_node.get('approverType') is not null and v_node.get('approverType')
          .get_string = 'StaticUser' -- and v_node.exist('approverUsers')
         THEN
          insert into DBPM_DYNAMIC_APPROVERS
            (APPROVER_ID,
             NODE_ID,
             DYNAMIC_VALUE,
             GET_VALUE_TYPE,
             OPERATION_TYPE)
          values
            (DBPM_DYNAMIC_APPROVERs_s.Nextval,
             v_node_id,
             v_node.get_string('StaticUser'),
             'STATIC',
             null);
        end if;
        --add by wlj end
      END LOOP;
      --add by echo.zeng begin
      select dp.process_code
        into v_process_code
        from dbpm_process dp
       where dp.process_id = v_request.get('processId').get_number;

      -- basic_data_pkg.proc_itl_param_correct(v_process_code);
      --add by echo.zeng end
    END IF;
    v_response.set_value('chainId', v_chain_id);
    v_response.set_value('nodes', v_response_node_list);

    x_response := v_response.to_json;

    /*EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_save_process_chain;

  /*===================================================
  Procedure Name :
        proc_del_approval_chain
    Description:
         删除审批链及审批节点(某个审批链)
    Argument:
        p_request：  请求（json）
        x_response： 响应（json）
    History:
        1.00  2017-03-21  chenming Creation
  ===================================================*/
  PROCEDURE proc_del_approval_chain(p_request CLOB, x_response OUT CLOB) IS
    v_api      VARCHAR2(100) := 'proc_del_approval_chain';
    v_request  json;
    v_response pl_json := pl_json;
    v_chain_id NUMBER;
  BEGIN
    v_request  := json(p_request, 'OBJECT');
    v_chain_id := v_request.get('chainId').get_number;

    UPDATE dbpm_approval_chain dac
       set dac.is_deleted = 'Y'
     WHERE dac.chain_id = v_chain_id;
    x_response := v_response.to_json;
    /*  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_del_approval_chain;
  /*==================================================
  Procedure/Function Name :
      proc_query_add_chain_rule_data
  Description:
      This function perform:
      查询在添加审批链规则时所需要的数据
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-10  chenming  Creation
  ==================================================*/
  PROCEDURE proc_query_add_chain_rule_data(p_request  CLOB,
                                           x_response OUT CLOB) IS
    v_api           VARCHAR2(1000) := 'proc_query_add_chain_rule_data';
    v_request       json;
    v_response      pl_json := pl_json;
    v_form_id       NUMBER;
    v_process_id    NUMBER;
    v_line          pl_json;
    v_operationlist pl_json;
    v_data_source   pl_json; --migrate by xiaowei.yao 20180512
    v_is_number     VARCHAR2(10);
    v_data_type     VARCHAR2(50);
    /*CURSOR data_cur IS
    SELECT * FROM dbpm_form_field WHERE form_id = v_form_id;*/
    CURSOR data_cur IS
      SELECT dff.*,
             t1.component_name,
             NVL2(T2.COMPONENT_NAME, T1.component_name, DFF.LABEL) LOCALE_NAME
        FROM dbpm_form_field dff,
             (select t.component_name, t.component_code
                from dcld_component_tl t
               where instr(T.LOCALE, v_request.locale) > 0) t1,
             dcld_component_tl t2
       WHERE dff.form_id = v_form_id
         AND DFF.TYPE = t1.COMPONENT_CODE(+)
         AND DFF.TYPE = T2.COMPONENT_CODE(+)
         AND DFF.LABEL = T2.COMPONENT_NAME(+)
       ORDER BY dff.order_seq;
    CURSOR op_cur IS
      SELECT dact.operation_type,
             dcld_comm_pkg.func_get_sys_msg(dact.operation_type,
                                            v_request.locale) operation_name
        FROM dbpm_data_compare_type dact
       WHERE dact.data_type = v_data_type;
    CURSOR v_process_param_cur IS
      SELECT dpp.*
        FROM dbpm_process_params dpp
       WHERE dpp.process_id = v_process_id;
    --migrate by xiaowei.yao 20180512 begin
    CURSOR v_data_source_cur(p_ds_code varchar2) IS
      SELECT ddsv.*
        FROM dbpm_data_source_values ddsv
       WHERE ddsv.data_source_code = p_ds_code
         AND ddsv.status = 'Y'
       ORDER BY ddsv.display_seq;
    CURSOR v_data_list_cur(p_list_str varchar2) IS
      select regexp_substr(p_list_str, '[^,|，]+', 1, level) col
        from dual
      connect by level <= regexp_count(p_list_str, '[,|，]') + 1;
    --migrate by xiaowei.yao 20180512 end
  BEGIN
    v_request := json(p_request, 'OBJECT');
    IF v_request.get('formId') IS NOT NULL THEN
      v_form_id := v_request.get('formId').get_number;
    END IF;
    v_process_id := v_request.get('processId').get_number;
    v_response.set_value('processId', v_process_id);
    v_response.set_value('formId', v_form_id);
    FOR data IN data_cur LOOP
      v_line := pl_json;
      v_line.set_value('id', data.id);
      v_line.set_value('label', data.locale_name);
      v_line.set_value('getValueType', 'FIELD');
      v_line.set_value('type', data.type);
      v_is_number := dbpm_comm_pkg.is_number_component(data.type);
      IF v_is_number = 'Y' THEN
        v_data_type := 'NUMBER';
      ELSE
        v_data_type := 'VARCHAR';
      END IF;
      FOR op IN op_cur LOOP
        v_operationlist := pl_json;
        v_operationlist.set_value('operationType', op.operation_type);
        v_operationlist.set_value('operationName', op.operation_name);
        v_line.add_list_item('operationList', v_operationlist);
      END LOOP;
      v_response.add_list_item('fieldList', v_line);
    END LOOP;
    FOR v_process_param IN v_process_param_cur LOOP
      v_line := pl_json;
      v_line.set_value('id', v_process_param.param_code);
      v_line.set_value('label', v_process_param.param_name);
      v_line.set_value('getValueType', 'PROCESSPARAM'); --migrate by xiaowei.yao 20180512

      v_data_type := v_process_param.param_type;
      FOR op IN op_cur LOOP
        v_operationlist := pl_json;
        v_operationlist.set_value('operationType', op.operation_type);
        v_operationlist.set_value('operationName', op.operation_name);
        v_line.add_list_item('operationList', v_operationlist);
      END LOOP;
      v_response.add_list_item('fieldList', v_line);
    END LOOP;

    x_response := v_response.to_json;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;
  END proc_query_add_chain_rule_data;

  /*==================================================
  Procedure/Function Name :
      proc_query_chain_node
  Description:
      This function perform:
      查询配置或添加审批节点所需数据
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-10  chenming  Creation
  ==================================================*/
  PROCEDURE proc_query_chain_node(p_request CLOB, x_response OUT CLOB) IS
    v_api           VARCHAR2(100) := 'proc_query_chain_node';
    v_request       json;
    v_response      pl_json := pl_json;
    v_node_id       NUMBER;
    v_node_name     VARCHAR2(500);
    v_node_type     VARCHAR2(50);
    v_approver_type VARCHAR2(50);
    v_order_num     NUMBER;
    v_form_id       NUMBER;
    v_chain_id      NUMBER;
    v_process_id    NUMBER;

    v_businessroles pl_json := pl_json;
    v_paramlist     pl_json := pl_json;
    v_parent_id     number;
    CURSOR v_role_cur IS
      SELECT dnr.business_role, dnr.node_role_id, dr.role_id, dr.role_name
        FROM dbpm_node_roles dnr, dbpm_roles dr
       WHERE dnr.node_id = v_node_id
         AND dnr.node_from_type = 'ChainNode'
         AND dnr.business_role = dr.role_code;
    CURSOR v_param_cur(p_node_role_id NUMBER) IS
      SELECT dnrp.param_id,
             dnrp.param_value,
             drp.param_name,
             dnrp.get_value_type
        FROM dbpm_node_role_param_value dnrp,
             dbpm_node_roles            dnr,
             dbpm_role_params           drp
       WHERE dnrp.node_role_id = dnr.node_role_id
         AND dnr.node_from_type = 'ChainNode'
         AND dnrp.param_id = drp.param_id
         AND dnrp.node_role_id = p_node_role_id;
  BEGIN
    v_request := json(p_request, 'OBJECT');
    v_node_id := v_request.get('nodeId').get_number;

    SELECT dca.node_name,
           dca.node_type,
           dca.approver_type,
           dca.order_num,
           dca.chain_id,
           dac.process_id,
           dca.parent_id
      INTO v_node_name,
           v_node_type,
           v_approver_type,
           v_order_num,
           v_chain_id,
           v_process_id,
           v_parent_id
      FROM dbpm_chain_nodes dca, dbpm_approval_chain dac
     WHERE dca.chain_id = dac.chain_id
       AND dca.node_id = v_node_id;

    v_form_id := dbpm_comm_pkg.func_get_process_form(p_process_id => v_process_id);
    v_response.set_value('nodeId', v_node_id);
    v_response.set_value('nodeName', v_node_name);
    v_response.set_value('nodeType', v_node_type);
    v_response.set_value('approverType', v_approver_type);
    v_response.set_value('orderNum', v_order_num);
    v_response.set_value('chainId', v_chain_id);
    v_response.set_value('processId', v_process_id);
    v_response.set_value('formId', v_form_id);
    v_response.set_value('parentId', v_parent_id);

    FOR v_role IN v_role_cur LOOP
      v_businessroles := pl_json;
      v_businessroles.set_value('roleId', v_role.role_id);
      v_businessroles.set_value('roleCode', v_role.business_role);
      v_businessroles.set_value('roleName', v_role.role_name);
      FOR v_param IN v_param_cur(v_role.node_role_id) LOOP
        v_paramlist := pl_json;
        v_paramlist.set_value('getValueType', v_param.get_value_type);
        v_paramlist.set_value('paramId', v_param.param_id);
        v_paramlist.set_value('paramName', v_param.param_name);
        v_paramlist.set_value('paramValue', v_param.param_value);
        v_businessroles.add_list_item('paramList', v_paramlist);
      END LOOP;
      v_response.add_list_item('businessRoles', v_businessroles);
    END LOOP;
    x_response := v_response.to_json;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;
  END proc_query_chain_node;

  /*==================================================
  Procedure/Function Name :
      proc_query_business_role
  Description:
      This function perform:
      查询业务角色
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-20  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_query_business_role(p_request CLOB, x_response OUT CLOB) IS
    v_request    json;
    v_response   pl_json := pl_json;
    v_role_json  pl_json;
    v_param_json pl_json;
    --分页
    v_total NUMBER := 0;
    v_size  number := 20;
    v_page  number := 1;
    --查询条件
    v_filter         json;
    v_search_content varchar2(4000);
    v_lov_flag       varchar2(10); --使用LOV的标志

    CURSOR v_role_cur IS
      SELECT * FROM dbpm_roles dr ORDER BY dr.role_name;
    CURSOR v_role_param_cur(p_role_id varchar2) IS
      SELECT *
        FROM dbpm_role_params drp
       WHERE drp.role_id = p_role_id
       ORDER BY drp.param_id;

    --lov
    v_space_id         number;
    CURSOR v_lov_role_cur IS
      SELECT *
        FROM (SELECT v.*, rownum cnt
                FROM (SELECT COUNT(1) OVER(PARTITION BY 1) TOTAL, dr.*
                        FROM dbpm_roles dr
                       WHERE INSTR(NVL(DR.ROLE_CODE || DR.ROLE_NAME, 'NL'),
                                   NVL(v_search_content,
                                       NVL(DR.ROLE_CODE || DR.ROLE_NAME, 'NL'))) > 0
                                       and dr.space_id=decode(dr.is_shared,'Y',dr.space_id,v_space_id)
                       ORDER BY dr.role_name) v
               WHERE rownum <= v_page * v_size)
       WHERE cnt > (v_page - 1) * v_size;

  BEGIN
    v_request := json(p_request, 'OBJECT');
    if v_request.exist('page') then
      v_page     := v_request.get_number('page');
      v_lov_flag := 'Y';
    end if;
    if v_request.exist('size') then
      v_lov_flag := 'Y';
      v_size     := v_request.get_number('size');
    end if;
     if v_request.exist('spaceId')
    then
      v_space_id    := v_request.get_number('spaceId');
      v_lov_flag := 'Y';
    end if;
    v_search_content := dcld_comm_pkg.get_filter_value('all', v_request);
    /*    if v_request.exist('filter') then
      v_lov_flag       := 'Y';
      v_filter         := json(v_request.get('filter'));
      v_search_content := v_filter.get_string('all');
    end if;*/

    IF v_lov_flag = 'Y' THEN
      FOR v_role IN v_lov_role_cur LOOP
        v_total     := v_role.total;
        v_role_json := pl_json;
        v_role_json.set_value('roleId', v_role.role_id);
        v_role_json.set_value('roleCode', v_role.role_code);
        v_role_json.set_value('roleName', v_role.role_name);
        FOR v_role_param IN v_role_param_cur(v_role.role_id) LOOP
          v_param_json := pl_json;
          v_param_json.set_value('paramId', v_role_param.param_id);
          v_param_json.set_value('paramName', v_role_param.param_name);
          v_role_json.add_list_item('paramList', v_param_json);
        END LOOP;
        v_response.add_list_item('roles', v_role_json);
      END LOOP;
    ELSE
      FOR v_role IN v_role_cur LOOP
        v_total     := v_total + 1;
        v_role_json := pl_json;
        v_role_json.set_value('roleId', v_role.role_id);
        v_role_json.set_value('roleCode', v_role.role_code);
        v_role_json.set_value('roleName', v_role.role_name);
        FOR v_role_param IN v_role_param_cur(v_role.role_id) LOOP
          v_param_json := pl_json;
          v_param_json.set_value('paramId', v_role_param.param_id);
          v_param_json.set_value('paramName', v_role_param.param_name);
          v_role_json.add_list_item('paramList', v_param_json);
        END LOOP;
        v_response.add_list_item('roles', v_role_json);
      END LOOP;
    END IF;

    v_response.set_value('total', v_total);
    x_response := v_response.to_json;
  END proc_query_business_role;

  /*==================================================
  Procedure/Function Name :
      proc_query_form_fields
  Description:
      This function perform:
      查询某个表单的所有组件
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-20  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_query_form_fields(p_request CLOB, x_response OUT CLOB) IS
    v_request    json;
    v_response   pl_json := pl_json;
    v_field_json pl_json;
    v_form_id    NUMBER;
    CURSOR v_form_field_cur(p_form_id NUMBER) IS
      SELECT *
        FROM dbpm_form_field dff
       WHERE dff.form_id = p_form_id
         AND dff.parent_id IS NULL;
  BEGIN
    v_request := json(p_request, 'OBJECT');
    v_form_id := v_request.get('formId').get_number;
    v_response.set_value('formId', v_form_id);
    FOR v_field IN v_form_field_cur(v_form_id) LOOP
      v_field_json := pl_json;
      v_field_json.set_value('id', v_field.id);
      v_field_json.set_value('label', v_field.label);
      v_response.add_list_item('fieldList', v_field_json);
    END LOOP;

    x_response := v_response.to_json;
  END proc_query_form_fields;

  /*==================================================
  Procedure Name :
      proc_query_admin_orginizations
  Description:
      查询管理员管理的组织
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2017-04-22  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_query_admin_orginizations(p_request  IN CLOB,
                                           x_response OUT CLOB) IS
    v_request      json;
    v_response     pl_json := pl_json;
    v_admin_json   pl_json;
    v_count        NUMBER := 0;
    v_current_user VARCHAR2(50);
    CURSOR v_admin_cur IS
      SELECT da.*, do.organization_code, do.organization_name
        FROM dbpm_administrators da, dfnd_organizations do
       WHERE da.organization_id = do.organization_id
         AND upper(da.user_code) = upper(v_current_user)
       ORDER BY da.administrator_id;
  BEGIN
    v_request := json(p_request, 'OBJECT');
    v_response.set_value('userCode', v_current_user);
    v_current_user := v_request.username;

    FOR v_admin IN v_admin_cur LOOP
      v_admin_json := pl_json;
      v_admin_json.set_value('organizationId',
                             to_char(v_admin.organization_id));
      v_admin_json.set_value('organizationCode', v_admin.organization_code);
      v_admin_json.set_value('organizationName', v_admin.organization_name);
      v_response.add_list_item('organizationList', v_admin_json);
      v_count := v_count + 1;
    END LOOP;
    v_response.set_value('count', v_count);
    x_response := v_response.to_json;
  END proc_query_admin_orginizations;

  PROCEDURE proc_save_process_chain_ex(p_request CLOB, x_response OUT CLOB) IS
    v_api              VARCHAR2(100) := 'proc_save_process_chain';
    v_request          json;
    v_response         pl_json := pl_json;
    v_current_user     VARCHAR2(50);
    v_rule_list        json_list;
    v_rule             json;
    v_node_list        json_list;
    v_node             json;
    v_role_list        json_list;
    v_role             json;
    v_param_list       json_list;
    v_param            json;
    v_chain_id         NUMBER;
    v_rule_id          NUMBER;
    v_node_id          NUMBER;
    v_node_role_id     NUMBER;
    v_field_type       VARCHAR2(100);
    v_param_type       VARCHAR2(30);
    v_count            NUMBER := 0;
    v_role_name        VARCHAR2(300);
    v_role_code        VARCHAR2(300);
    v_role_param_id    NUMBER;
    v_role_param_value VARCHAR2(300);
    v_process_id       NUMBER;
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;
    v_process_id   := v_request.get('processId').get_number;
    IF v_request.get('chainId') IS NULL OR v_request.get('chainId')
      .get_number = 0 THEN
      v_chain_id := dbpm_approval_chain_s.nextval;
    ELSE
      v_chain_id := v_request.get('chainId').get_number;
    END IF;
    -- 1.保存审批链
    SELECT COUNT(1)
      INTO v_count
      FROM dbpm_approval_chain dac
     WHERE dac.chain_id = v_chain_id;
    IF v_count > 0 THEN
      UPDATE dbpm_approval_chain dac
         SET dac.chain_name            = v_request.get('chainName')
                                         .get_string,
             dac.organization_id       = v_request.get('organizationId')
                                         .get_string,
             dac.object_version_number = dac.object_version_number + 1,
             dac.last_updated_by       = v_current_user
       WHERE dac.chain_id = v_chain_id;
    ELSE
      INSERT INTO dbpm_approval_chain
        (chain_id,
         chain_name,
         chain_type,
         process_id,
         organization_id,
         status,
         created_by,
         last_updated_by)
      VALUES
        (v_chain_id,
         v_request.get ('chainName' ).get_string,
         'Custom',
         v_request.get ('processId' ).get_number,
         v_request.get ('organizationId' ).get_string,
         'Y',
         v_current_user,
         v_current_user);
    END IF;
    -- 2. 保存审批规则
    DELETE dbpm_chain_rules dcr WHERE dcr.chain_id = v_chain_id;
    IF v_request.path('rules') IS NOT NULL THEN
      v_rule_list := json_list(v_request.path('rules'));

      FOR i IN 1 .. v_rule_list.count LOOP
        v_rule := json(v_rule_list.get(i));
        IF v_rule.get('ruleId') IS NULL THEN
          v_rule_id := dbpm_chain_rules_s.nextval;
        ELSE
          v_rule_id := v_rule.get('ruleId').get_number;
        END IF;
        BEGIN
          SELECT dff.type
            INTO v_field_type
            FROM dbpm_form_field dff
           WHERE dff.id = v_rule.get('paramName').get_string;
          IF dbpm_comm_pkg.is_number_component(v_field_type) = 'Y' THEN
            v_param_type := 'NUMBER';
          ELSE
            v_param_type := 'VARCHAR';
          END IF;
        EXCEPTION
          WHEN no_data_found THEN
            -- 没找到，找参数配置
            SELECT dpp.param_type
              INTO v_param_type
              FROM dbpm_process_params dpp
             WHERE dpp.process_id = v_request.get('processId').get_number
               AND dpp.param_code = v_rule.get('paramName').get_string;
        END;
        INSERT INTO dbpm_chain_rules
          (rule_id,
           chain_id,
           param_name,
           param_meaning,
           param_type,
           operation_type,
           param_value,
           created_by,
           last_updated_by)
        VALUES
          (v_rule_id,
           v_chain_id,
           v_rule.get    ('paramName'    ).get_string, -- 表单组件上面的ID
           v_rule.get    ('paramMeaning'    ).get_string, -- 表单组件上的显示名称
           v_param_type,
           v_rule.get    ('operation'    ).get_string,
           v_rule.get    ('paramValue'    ).get_string,
           v_current_user,
           v_current_user);
      END LOOP;
    END IF;
    -- 3. 保存审批节点
    -- 先删除
    FOR v_node_del IN (SELECT *
                         FROM dbpm_chain_nodes dcn
                        WHERE dcn.chain_id = v_chain_id) LOOP
      FOR v_role_del IN (SELECT *
                           FROM dbpm_node_roles dnr
                          WHERE dnr.node_id = v_node_del.node_id
                            AND dnr.node_from_type = 'ChainNode') LOOP
        DELETE FROM dbpm_node_role_param_value dnrp
         WHERE dnrp.node_role_id = v_role_del.node_role_id;
        DELETE FROM dbpm_node_roles dnr
         WHERE dnr.node_role_id = v_role_del.node_role_id
           AND dnr.node_from_type = 'ChainNode';
      END LOOP;
      DELETE FROM dbpm_chain_nodes dcn
       WHERE dcn.node_id = v_node_del.node_id;
      -- 删除多语言表
      DELETE FROM dbpm_chain_nodes_tl dcnt
       WHERE dcnt.node_id = v_node_del.node_id;
    END LOOP;
    -- 新建
    IF v_request.path('nodes') IS NOT NULL THEN
      v_node_list := json_list(v_request.path('nodes'));
      FOR i IN 1 .. v_node_list.count LOOP
        v_node := json(v_node_list.get(i));
        IF v_node.get('nodeId') IS NULL THEN
          v_node_id := dbpm_chain_nodes_s.nextval;
        ELSE
          v_node_id := v_node.get('nodeId').get_number;
        END IF;
        INSERT INTO dbpm_chain_nodes
          (node_id,
           chain_id,
           node_name,
           node_type,
           approver_type,
           order_num,
           created_by,
           last_updated_by)
        VALUES
          (v_node_id,
           v_chain_id,
           v_node.get    ('nodeName'    ).get_string,
           v_node.get    ('nodeType'    ).get_string,
           v_node.get    ('approverType'    ).get_string,
           v_node.get    ('nodeSeq'    ).get_number,
           v_current_user,
           v_current_user);
        -- 添加多语言表
        INSERT INTO dbpm_chain_nodes_tl
          (node_id, locale, node_name, created_by, last_updated_by)
        VALUES
          (v_node_id,
           dbpm_comm_pkg.get_current_locale,
           v_node.get('nodeName').get_string,
           v_current_user,
           v_current_user);
        -- 3.1 保存审批节点角色
        IF v_node.path('businessRoles') IS NOT NULL THEN
          v_role_list := json_list(v_node.path('businessRoles'));
          FOR j IN 1 .. v_role_list.count LOOP
            v_role         := json(v_role_list.get(j));
            v_node_role_id := dbpm_node_roles_s.nextval;
            v_role_name    := v_role.get('roleName').get_string;
            SELECT MAX(t.role_code)
              INTO v_role_code
              FROM dbpm_roles t
             WHERE t.role_name = v_role_name;
            INSERT INTO dbpm_node_roles
              (node_role_id,
               node_id,
               business_role,
               node_from_type,
               created_by,
               last_updated_by)
            VALUES
              (v_node_role_id,
               v_node_id,
               v_role_code,
               'ChainNode',
               v_current_user,
               v_current_user);
            -- 3.1.1 保存角色参数
            IF v_role.path('paramList') IS NOT NULL THEN
              v_param_list := json_list(v_role.path('paramList'));
              FOR k IN 1 .. v_param_list.count LOOP
                v_param := json(v_param_list.get(k));
                SELECT MAX(t.param_id)
                  INTO v_role_param_id
                  FROM dbpm_role_params t, dbpm_roles dr
                 WHERE t.role_id = dr.role_id
                   AND dr.role_code = v_role_code
                   AND t.param_name = '所属组织'
                   AND t.status = 'Y';
                SELECT MAX(t.param_code)
                  INTO v_role_param_value
                  FROM dbpm_process_params t
                 WHERE t.process_id = v_process_id
                   AND t.param_name = v_param.get('paramValue').get_string;
                INSERT INTO dbpm_node_role_param_value
                  (node_role_id, param_id, param_value, get_value_type)
                VALUES
                  (v_node_role_id,
                   v_role_param_id,
                   v_role_param_value,
                   v_param.get('getValueType').get_string);
              END LOOP;
            END IF;
          END LOOP;
        END IF;
      END LOOP;
    END IF;
    v_response.set_value('chainId', v_chain_id);
    x_response := v_response.to_json;

    /*EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_save_process_chain_ex;
END dbpm_chain_api_pkg;

/

