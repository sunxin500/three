create package     DBPM_RULE_API_PKG is

  -- Author  : WLJ
  -- Created : 2018/5/31 15:14:16
  -- Purpose : 流程/审批链规则API

  /*==================================================
  Procedure/Function Name :
      func_parse_rule
  Description:
      This function perform:
       转换规则为字符串
  Argument:
     p_rule_list： 请求参数
  History:
      1.00  2018-05-31  wlj  Creation
  ==================================================*/
  FUNCTION func_parse_rule(p_rule_list json_list) return varchar2;

  /*==================================================
  Procedure/Function Name :
      proc_upgrade_old_chain_rule
  Description:
      This function perform:
       将老版本中没有规则树的审批连升级
  Argument:
     p_rule_list： 请求参数
  History:
      1.00  2018-07-18  wlj  Creation
  ==================================================*/
  PROCEDURE proc_upgrade_old_chain_rule;
end DBPM_RULE_API_PKG;

/

