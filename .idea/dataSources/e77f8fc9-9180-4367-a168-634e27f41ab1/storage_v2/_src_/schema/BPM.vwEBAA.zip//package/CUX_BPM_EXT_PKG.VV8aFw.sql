create PACKAGE "CUX_BPM_EXT_PKG" is

  -- Author  : xiaowei.yao
  -- Created : 20/3/18 01:14:58
  -- Purpose : 

  type type_split is table of varchar2(4000);
  function get_reassign_flag(p_task_id in varchar2, p_new_assignee in varchar2) return varchar2;
   /*========================================================
    Description:    分割字符串函数，用参数二（默认逗号），分割成字符串1为 多列
                   （此处，我的做法是分割到零时表中，然后可循环读取等）
  ==========================================================*/
  function split(p_list varchar2, p_sep varchar2) return type_split pipelined;
end cux_bpm_ext_pkg;

/

