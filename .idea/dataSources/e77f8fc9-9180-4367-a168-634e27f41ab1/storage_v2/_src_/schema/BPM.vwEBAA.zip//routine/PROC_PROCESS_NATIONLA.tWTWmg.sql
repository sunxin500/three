create procedure     proc_process_nationla(p_processCode varchar2) is

  v_process      dbpm_process_tl%rowtype;
  v_locale_count number;
  v_nation_value varchar2(64);
begin

  begin
    SELECT count(1)
      into v_locale_count
      FROM dbpm_process dp, dbpm_process_tl dpt
     WHERE dp.process_id = dpt.process_id
       AND dp.process_code = p_processCode;
  END;
  if v_locale_count <> 2 then
    --判断流程名称缺少国际化值
    begin
      SELECT dpt.*
        into v_process
        FROM dbpm_process dp, dbpm_process_tl dpt
       WHERE dp.process_id = dpt.process_id
         AND dp.process_code = p_processCode;
    end;
    begin
      select distinct cnt.nation_value --查出国际化值
        into v_nation_value
        from CUX_language_NATION_TEMP cnt
       where cnt.node_name = v_process.process_name
         and 'en_US' = cnt.locale;
    end;
    v_process.process_name := v_nation_value;
    v_process.locale       := 'en_US';
    insert into dbpm_process_tl values v_process; --插入到流程表中
  end if;
end proc_process_nationla;

/

