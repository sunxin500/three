create view DBPM_TASK_PARTAKE_QUERY_V as
SELECT HIS.Taskid task_id,
       dd.document_id,
       dd.form_id,
       dd.process_id,
       nvl(dd.doc_number, 'INSTANCE-' || his.instanceid) task_number,
       nvl(dd.title, HIS.title) title,
       nvl(dd.status, 'PROCESSING') status,
       dd.process_name,
       dd.process_code,
       dd.process_type,
       nvL(dd.creation_date, ci.creation_date + 0) creation_date,
       dd.doc_creator created_user_code,
       dd.doc_creator_name created_user_name,
       his.Approvers par_user_code,
       (SELECT LISTAGG(ASS.ASSIGNEE, ',') WITHIN GROUP(ORDER BY ASS.ASSIGNEE) approver_code
          FROM WFTASK WF, WFASSIGNEE ASS
         WHERE WF.STATE IN ('ASSIGNED', 'INFO_REQUESTED')
           AND ASS.TASKID = WF.TASKID
           AND WF.INSTANCEID = HIS.instanceId) approve_user_code,
       (SELECT LISTAGG(E.EMPLOYEE_NAME, ',') WITHIN GROUP(ORDER BY ASS.ASSIGNEE) approver_code
          FROM WFTASK WF, WFASSIGNEE ASS, DFND_EMPLOYEES E
         WHERE WF.STATE IN ('ASSIGNED', 'INFO_REQUESTED')
           AND ASS.TASKID = WF.TASKID
           AND WF.INSTANCEID = HIS.instanceId
           AND UPPER(ASS.ASSIGNEE) = E.EMPLOYEE_CODE) approve_user_name,
       dd.doc_url,
       NVL(dd.doc_sys_code, '---') doc_sys_code,
       NVL(dd.process_class, 'EXTERNAL') process_class,
       nvl(dd.todo_flag, 'NONE') todo_flag,
       ci.state,
       ci.domain_name || '/' || ci.composite_name || '/' ||
       ci.component_name register_process_code,
       his.instanceid bpm_instance_id,
       his.enddate
  FROM wftask HIS,
       cube_instance ci,
       (select form_id,
               document_id,
               doc_number,
               bpm_instance_id,
               dp.process_id,
               dpt.process_name,
               dp.process_code,
               dp.process_type,
               dp.process_class,
               dp.todo_flag,
               d.doc_sys_code,
               d.title,
               d.doc_creator,
               d.doc_creator_name,
               d.doc_create_time,
               d.status,
               d.doc_url,
               d.creation_date
          from dbpm_documents d, dbpm_process dp, dbpm_process_tl dpt
         where dp.process_id = dpt.process_id
           AND dpt.locale = dbpm_comm_pkg.get_current_locale
           and d.process_id = dp.process_id(+)) dd
 WHERE his.instanceid = ci.cikey
   AND his.instanceid = dd.bpm_instance_id(+)
   AND his.STATE IS NULL
   and his.workflowpattern = 'Participant'
   and his.compositedn IN
       (SELECT P.COMPOSITEDN
          FROM DBPM_PROCESS_REGISTRY RE, BPM_CUBE_PROCESS P
         WHERE RE.DOMAINNAME = P.DOMAINNAME
           AND RE.PROCESSNAME = P.PROCESSNAME
           AND RE.COMPOSITENAME = P.COMPOSITENAME
           AND RE.PROCESS_MODEL_TYPE IN ('BPM', 'OBPM')
           AND RE.ENABLED_FLAG = 'Y')
UNION ALL
SELECT ct.df_task_id TASK_ID,
       NULL document_id,
       NULL form_id,
       CT.PROCESS_ID process_id,
       DECODE(CT.DOCUMENT_NUMBER,
              CT.PARENT_DOCUMENT_NUMBER,
              CT.DOCUMENT_NUMBER,
              CT.PARENT_DOCUMENT_NUMBER || '/' || CT.DOCUMENT_NUMBER) task_number,
       CT.TITLE title,
       CT.STATE status,
       CT.process_name,
       CT.process_code,
       '-' process_type,
       CT.CREATEDDATE creation_date,
       CT.CREATOR created_user_code,
       (SELECT E.EMPLOYEE_NAME
          FROM DFND_EMPLOYEES E
         WHERE E.EMPLOYEE_CODE = UPPER(CT.CREATOR)) created_user_name,
       CT.Approvers par_user_code,
       NULL approve_user_code,
       NULL approve_user_name,
       CT.URL doc_url,
       'OTHERS' doc_sys_code,
       'OTHERS' process_class,
       CT.TODO_FLAG,
       NULL state,
       NULL register_process_code,
       NULL bpm_instance_id,
       CT.APPROVE_DATE
  FROM CUX_PROCESS_TODO CT
 WHERE CT.state IN ('PROCESSED')

  
/

