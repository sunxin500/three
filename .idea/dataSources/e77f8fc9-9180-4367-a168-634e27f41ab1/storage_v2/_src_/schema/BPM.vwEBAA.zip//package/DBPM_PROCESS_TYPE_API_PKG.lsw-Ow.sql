create PACKAGE     dbpm_process_type_api_pkg IS

  /*==================================================
  Procedure/Function Name :
      proc_query_process_types
  Description:
      This function perform:
      查询流分类
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-05-22  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_query_process_types(p_request CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_save_process_node
  Description:
      This function perform:
      保存流程分类
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-05-17  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_save_process_type(p_request CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_del_process_type
  Description:
      This function perform:
      删除流程分类
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-05-22  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_del_process_type(p_request CLOB, x_response OUT CLOB);

END dbpm_process_type_api_pkg;

/

