create view DBPM_OBPM_TODO_V as
SELECT task.taskid,
       task.tasknumber,
       task.title,
       task.createddate,
       UPPER(task.creator) creator,
       UPPER(ass.assignee) assignee,
       task.assigneddate,
       task.state,
       task.protectedtextattribute1 document_id,
       task.protectedtextattribute2 node_name,
       task.protectedtextattribute3 document_number,
       task.protectedtextattribute4 process_code,
       task.protectednumberattribute1 node_id,
       task.instanceid,
       task.activityname,
       task.compositecreatedtime,
       task.protectedtextattribute5 cux_form_url,
       task.protectedtextattribute6 cux_params,
       task.protectedtextattribute7 cux_form_key,
       TASK.PROTECTEDFORMATTRIBUTE2 cux_return_flag,
       t.Sys_Code,
       T.PROCESS_CODE REGISTER_PROCESS_CODE
  FROM wftask task,
       wfassignee ass,
       (SELECT P.COMPOSITEDN, RE.Sys_Code,RE.PROCESS_CODE
          FROM DBPM_PROCESS_REGISTRY RE, BPM_CUBE_PROCESS P
         WHERE RE.DOMAINNAME = P.DOMAINNAME
           AND RE.PROCESSNAME = P.PROCESSNAME
           AND RE.COMPOSITENAME = P.COMPOSITENAME
           AND RE.PROCESS_MODEL_TYPE IN ('BPM', 'OBPM')
           AND RE.ENABLED_FLAG = 'Y') t
 WHERE task.taskid = ass.taskid
   AND ass.assigneetype = 'user'
   AND task.state IN ('ASSIGNED', 'INFO_REQUESTED')
      --and task.processid='DBPMCoreProcess'
   and task.compositedn = t.COMPOSITEDN

/

