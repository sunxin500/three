create PACKAGE     dbpm_document_sequences_pkg IS

  FUNCTION proc_get_message(p_message_code IN VARCHAR2) RETURN VARCHAR2;

  PROCEDURE proc_get_sequence(x_next_sequence  OUT NUMBER, --下一个序列号
                              x_return_message OUT NOCOPY VARCHAR2, --错误消息
                              p_document_type  IN VARCHAR2, --单据类型
                              p_date_code      IN VARCHAR2 -- 日期编码
                              );

  PROCEDURE proc_get_doc_number(p_document_type   IN VARCHAR2,
                                x_document_number OUT VARCHAR2, --单据编号
                                x_return_message  OUT NOCOPY VARCHAR2 --错误消息
                                --单据类型
                                );
END dbpm_document_sequences_pkg;

/

