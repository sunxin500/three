create PROCEDURE     "UPDATE_CHAIN_NODE_ATTR1" is

  v_process_code   varchar2(200);
  v_node_name      varchar2(200);
  v_node_status    varchar2(200);
  v_dbpm_node_name varchar2(200);
  v_node_id        number;
  v_count          NUMBER;
  cursor gems_chain_node_cur is
    select * from cux_gems_node_status_tmp t;
  /*where t.process_code = p_process_code*/
  cursor dbpm_chain_node_cur(p_process_code varchar2) is
    select dcn.node_id, dcn.node_name
      from dbpm_process dp, dbpm_approval_chain dac, dbpm_chain_nodes dcn
     where dp.process_id = dac.process_id
       and dac.chain_id = dcn.chain_id
       and dp.process_code = p_process_code;
begin
  for gems_cur in gems_chain_node_cur loop
    v_process_code := gems_cur.process_code;
    v_node_name    := gems_cur.node_name;
    v_node_status  := gems_cur.node_status;
    for node_cur in dbpm_chain_node_cur(v_process_code) loop
      v_dbpm_node_name := node_cur.node_name;
      v_node_id        := node_cur.node_id;
      if v_node_name = v_dbpm_node_name then
        /*update dbpm_chain_nodes dcn
          set dcn.attribute1 = v_node_status
        where dcn.node_id = v_node_id;*/
        SELECT COUNT(1)
          INTO v_count
          FROM cux_gems_node_params t
         WHERE t.node_id = v_node_id;
        IF v_count > 0 THEN
          update cux_gems_node_params t
             set t.param_value = v_node_status
           where t.node_id = v_node_id;
        ELSE
          insert into cux_gems_node_params
          values
            (v_node_id, 'step_status', v_node_status);
        END IF;
      end if;
    end loop;
  end loop;
end UPDATE_CHAIN_NODE_ATTR1;

/

