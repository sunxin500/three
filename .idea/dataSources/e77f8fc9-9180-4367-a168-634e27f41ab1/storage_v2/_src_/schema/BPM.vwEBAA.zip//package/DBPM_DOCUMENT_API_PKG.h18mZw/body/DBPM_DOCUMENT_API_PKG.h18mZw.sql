create PACKAGE BODY dbpm_document_api_pkg IS

  /*==================================================
  Procedure/Function Name :
      proc_create_document_data
  Description:
      This function perform:
      保存表单数据，需要判断是新建还更新
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-09-12  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_create_document_data(p_request CLOB, x_response OUT CLOB) IS
    v_request            json;
    v_response           pl_json := pl_json;
    v_process_code       VARCHAR2(100);
    v_creator            VARCHAR2(100);
    v_creator_name       VARCHAR2(100);
    v_doc_number         VARCHAR2(100);
    v_process_id         NUMBER;
    v_process_name       VARCHAR2(500);
    v_form_id            NUMBER;
    v_title              VARCHAR2(500);
    v_keyword            VARCHAR2(4000);
    v_company_id         VARCHAR2(100);
    v_attrs_map          json;
    v_columns_map        json;
    v_str_value          VARCHAR2(4000);
    v_value_list         json_list;
    v_document_id        NUMBER;
    v_organization_id    VARCHAR2(100);
    v_organization_name  VARCHAR2(100);
    v_source_document_id VARCHAR2(100);
    v_line_id            NUMBER;
    v_sql                clob;
    v_column_sql         VARCHAR2(4000);
    v_params_map         json;
    v_attachment_list    json_list;
    v_attachment_json    json;
    v_att_creator_name   VARCHAR2(100);
    v_count              NUMBER;

    CURSOR v_form_field_cur(p_form_id VARCHAR2) IS
      SELECT dff.id, dff.attr_code, dff.label, dffm.attr_name, dff.is_title
        FROM dbpm_form_field dff, dbpm_form_field_mapping dffm
       WHERE dff.form_id = dffm.form_id(+)
         AND dff.id = dffm.id(+)
         AND dff.parent_id IS NULL
         AND dff.form_id = p_form_id;
    CURSOR v_column_field_cur(p_form_id VARCHAR2, p_table_id VARCHAR2) IS
      SELECT dff.id, dff.attr_code, dff.label, dffm.attr_name
        FROM dbpm_form_field dff, dbpm_form_field_mapping dffm
       WHERE dff.form_id = dffm.form_id
         AND dff.id = dffm.id
         AND dff.form_id = p_form_id
         AND dff.parent_id = p_table_id;
  BEGIN
    --v_request := json(p_request, 'OBJECT');
    v_request := json(p_request);

    IF v_request.get('processCode') IS NULL OR v_request.get('processCode')
      .get_string IS NULL THEN
      v_response.fail('输入参数processCode不能为空');
      x_response := v_response.to_json;
      RETURN;
    END IF;
    IF v_request.get('processApplier') IS NULL OR v_request.get('processApplier')
      .get_string IS NULL THEN
      v_response.fail('输入参数processApplier不能为空');
      x_response := v_response.to_json;
      RETURN;
    END IF;
    IF v_request.get('documentId') IS NULL OR v_request.get('documentId')
      .get_string IS NULL THEN
      v_response.fail('输入参数documentId不能为空');
      x_response := v_response.to_json;
      RETURN;
    END IF;

    v_process_code := v_request.get('processCode').get_string;
    v_creator      := v_request.get('processApplier').get_string;

    -- 获取创建人姓名
    IF v_request.get('processApplierName') IS NULL OR v_request.get('processApplierName')
      .get_string IS NULL THEN
      BEGIN
        SELECT fe.employee_name
          INTO v_creator_name
          FROM dfnd_employees fe
         WHERE upper(fe.employee_code) = upper(v_creator);
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;
    ELSE
      v_creator_name := v_request.get('processApplierName').get_string;
    END IF;

    -- 获取表单ID
    BEGIN
      SELECT df.form_id, df.process_id, dp.process_name
        INTO v_form_id, v_process_id, v_process_name
        FROM dbpm_form df, dbpm_process dp
       WHERE df.process_id = dp.process_id
         AND df.status = 'Published'
         AND dp.process_code = v_process_code;
    EXCEPTION
      WHEN OTHERS THEN
        v_response.fail('输入参数processCode不正确');
        x_response := v_response.to_json;
        RETURN;
    END;

    -- 获取单据编号
    IF v_request.get('documentNumber') IS NOT NULL THEN
      v_doc_number := v_request.get('documentNumber').get_string;
    END IF;

    -- 获取标题
    IF v_request.get('processTitle') IS NOT NULL THEN
      v_title := v_request.get('processTitle').get_string;
    ELSE
      v_title := '由' || nvl(v_creator_name, v_creator) || '发起的' ||
                 v_process_name;
    END IF;

    -- 获取组织ID
    IF v_request.get('departmentId') IS NULL THEN
      dcld_comm_pkg.get_user_master_organization(p_user_code         => v_creator,
                                                 x_organization_id   => v_organization_id,
                                                 x_organization_name => v_organization_name);
    ELSE
      v_organization_id := v_request.get('departmentId').get_string;
    END IF;

    -- 获取源单据ID
    IF v_request.get('documentId') IS NOT NULL THEN
      v_source_document_id := v_request.get('documentId').get_string;
    END IF;

    -- 获取关键字
    IF v_request.get('keyword') IS NOT NULL THEN
      v_keyword := v_request.get('keyword').get_string;
    ELSE
      v_keyword := '';
    END IF;

    -- 获取公司ID
    BEGIN
      SELECT fo.company_id
        INTO v_company_id
        FROM dfnd_organizations fo
       WHERE fo.organization_id = v_organization_id;
    EXCEPTION
      WHEN OTHERS THEN
        v_company_id := '';
    END;

    BEGIN
      SELECT dd.document_id
        INTO v_document_id
        FROM dbpm_documents dd
       WHERE dd.source_document_id = v_source_document_id
         AND dd.process_code = v_process_code;
    EXCEPTION
      WHEN OTHERS THEN
        v_document_id := '';
    END;
    IF v_document_id IS NULL THEN
      v_document_id := dbpm_documents_s.nextval;
      INSERT INTO dbpm_documents
        (document_id,
         doc_number,
         title,
         process_id,
         process_code,
         form_id,
         status,
         organization_id,
         doc_creator,
         doc_creator_name,
         doc_create_time,
         source_document_id,
         doc_keyword,
         company_id)
      VALUES
        (v_document_id,
         v_doc_number,
         v_title,
         v_process_id,
         v_process_code,
         v_form_id,
         'PROCESSING',
         v_organization_id,
         v_creator,
         v_creator_name,
         SYSDATE,
         v_source_document_id,
         v_keyword,
         v_company_id);
    ELSE
      UPDATE dbpm_documents dd
         SET dd.doc_number       = v_doc_number,
             dd.title            = v_title,
             dd.organization_id  = v_organization_id,
             dd.company_id       = v_company_id,
             dd.form_id          = v_form_id,
             dd.doc_creator      = v_creator,
             dd.doc_creator_name = v_creator_name,
             dd.doc_keyword      = v_keyword
       WHERE dd.source_document_id = v_source_document_id
         AND dd.process_code = v_process_code;
      -- 删除单据行
      DELETE FROM dbpm_document_lines ddl
       WHERE ddl.document_id = v_document_id;
    END IF;

    -- 获取业务字段
    IF v_request.get('businessParams') IS NOT NULL THEN
      v_attrs_map := json(v_request.get('businessParams'));

      FOR v_form_field IN v_form_field_cur(v_form_id) LOOP
        IF v_attrs_map.get(v_form_field.attr_code) IS NOT NULL THEN
          IF v_attrs_map.get(v_form_field.attr_code).is_array THEN
            BEGIN
              v_value_list := json_list(v_attrs_map.path(v_form_field.attr_code));
            EXCEPTION
              WHEN OTHERS THEN
                ROLLBACK;
                v_response.fail('请确认' || v_form_field.attr_code || '是否准确');
                x_response := v_response.to_json;
                RETURN;
            END;
            FOR i IN 1 .. v_value_list.count LOOP
              v_columns_map := json(v_value_list.get(i));
              -- 插入表行数据
              v_line_id := dbpm_document_lines_s.nextval;
              INSERT INTO dbpm_document_lines
                (line_id, document_id, table_id)
              VALUES
                (v_line_id, v_document_id, v_form_field.id);
              FOR v_column_field IN v_column_field_cur(v_form_id,
                                                       v_form_field.id) LOOP
                BEGIN
                  v_str_value := v_columns_map.get(v_column_field.attr_code)
                                 .get_string;
                EXCEPTION
                  WHEN OTHERS THEN
                    ROLLBACK;
                    v_response.fail('请确认' || v_column_field.attr_code ||
                                    '是否准确');
                    x_response := v_response.to_json;
                    RETURN;
                END;
                v_column_sql := 'update dbpm_document_lines set ' ||
                                v_column_field.attr_name || '=''' ||
                                v_str_value || '''
              where line_id = ' || v_line_id;
                EXECUTE IMMEDIATE v_column_sql;
              END LOOP;
            END LOOP;
          ELSE
            -- 更新表单头数据
            v_str_value := v_attrs_map.get(v_form_field.attr_code)
                           .get_string;

            IF v_form_field.attr_name IS NULL THEN
              IF v_form_field.is_title = 'Y' THEN
                v_sql := 'update dbpm_documents set title = ''' ||
                         v_str_value || ''' where document_id = ' ||
                         v_document_id;
              END IF;
            ELSE
              v_sql := 'update dbpm_documents set ' ||
                       v_form_field.attr_name || '=''' || v_str_value ||
                       ''' where document_id = ' || v_document_id;
            END IF;
            EXECUTE IMMEDIATE v_sql;
          END IF;
        END IF;
      END LOOP;
    END IF;
    -- 获取流程参数
    IF v_request.get('processParams') IS NOT NULL THEN
      v_params_map := json(v_request.get('processParams'));
      FOR v_param IN (SELECT *
                        FROM dbpm_process_params dpp
                       WHERE dpp.process_id = v_process_id) LOOP
        IF v_params_map.get(v_param.param_code) IS NOT NULL THEN
          BEGIN
            v_str_value := v_params_map.get(v_param.param_code).get_string;
          EXCEPTION
            WHEN OTHERS THEN
              ROLLBACK;
              v_response.fail('请确认' || v_param.param_code || '是否准确');
              x_response := v_response.to_json;
              RETURN;
          END;
          SELECT COUNT(1)
            INTO v_count
            FROM dbpm_process_param_value dppv
           WHERE dppv.param_id = v_param.param_id
             AND dppv.document_id = v_document_id;
          IF v_count = 0 THEN
            INSERT INTO dbpm_process_param_value
              (param_id,
               document_id,
               param_value,
               object_version_number,
               created_by,
               creation_date,
               last_updated_by,
               last_update_date)
            VALUES
              (v_param.param_id,
               v_document_id,
               v_str_value,
               1,
               v_creator,
               SYSDATE,
               v_creator,
               SYSDATE);
          ELSE
            UPDATE dbpm_process_param_value dppv
               SET dppv.param_value = v_str_value
             WHERE dppv.param_id = v_param.param_id
               AND dppv.document_id = v_document_id;
          END IF;
        END IF;
      END LOOP;
    END IF;
    -- 获取流程附件
    IF v_request.get('attachments') IS NOT NULL THEN
      v_attachment_list := json_list(v_request.path('attachments'));
      DELETE FROM dfnd_attachments da WHERE da.document_id = v_document_id;
      FOR i IN 1 .. v_attachment_list.count LOOP
        v_attachment_json := json(v_attachment_list.get(i));
        BEGIN
          SELECT de.employee_name
            INTO v_att_creator_name
            FROM dfnd_employees de
           WHERE upper(de.employee_code) =
                 upper(v_attachment_json.get('creator').get_string);
        EXCEPTION
          WHEN OTHERS THEN
            v_att_creator_name := '';
        END;

        INSERT INTO dfnd_attachments
          (attachment_id,
           attachment_name,
           document_id,
           download_url,
           creator_name,
           fun_id,
           fun_name,
           object_version_number,
           created_by,
           creation_date,
           last_updated_by,
           last_update_date,
           suffix)
        VALUES
          (dfnd_attachments_s.nextval,
           v_attachment_json.get('attachmentName').get_string,
           v_document_id,
           v_attachment_json.get('downloadURL').get_string,
           v_att_creator_name,
           v_request.get('documentId').get_string,
           v_process_code,
           1,
           v_attachment_json.get('creator').get_string,
           to_date(v_attachment_json.get('createTime').get_string,
                   'yyyy-MM-dd'),
           v_attachment_json.get('creator').get_string,
           to_date(v_attachment_json.get('createTime').get_string,
                   'yyyy-MM-dd'),
           reverse(substr(reverse(v_attachment_json.get('attachmentName')
                                  .get_string),
                          1,
                          INSTR(reverse(v_attachment_json.get('attachmentName')
                                        .get_string),
                                '.') - 1))); -- add by chenzhibin
      END LOOP;
    END IF;

    v_response.set_value('processCode', v_process_code);
    v_response.set_value('processTitle', v_title);
    v_response.set_value('processApplier', v_creator);
    v_response.set_value('processApplierName', v_creator_name);
    v_response.set_value('documentNumber', v_doc_number);
    v_response.set_value('documentId', to_char(v_document_id));
    v_response.set_value('keyword', v_keyword);
    v_response.set_value('businessSysCode',
                         v_request.get('businessSysCode').get_string);
    v_response.set_value('locale', v_request.get('locale').get_string);
    v_response.set_value('sourceDocumentId', v_source_document_id);

    x_response := v_response.to_data_json;
    /* EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_create_document_data;

  /*
  * 进入表单详细时，初始化数据
  */
  PROCEDURE proc_init_form_detail(p_request CLOB, x_response OUT CLOB) IS
    v_request         json;
    v_response        pl_json := pl_json;
    v_task_id         VARCHAR2(100);
    v_document_id     NUMBER;
    v_process_id      NUMBER;
    v_form_id         NUMBER;
    v_node_id         NUMBER;
    v_node_name       VARCHAR2(100);
    v_state           VARCHAR2(100);
    v_status          VARCHAR2(100);
    v_bpm_instance_id varchar2(100);
    v_next_node_id    NUMBER;
    v_approver_type   VARCHAR2(100);
    --BEGIN add by wlj 扩展外部流程
    v_process_register_code varchar2(400);
    v_domain_name           varchar2(500);
    v_composite_name        varchar2(500);
    --END add by wlj 扩展外部流程
    --BEGIN ADD BY WLJ 获取按钮配置
    v_button_item      pl_json := pl_json;
    v_button_list      pl_json := pl_json;
    v_exist_count      number;
    v_activity_name    varchar2(4000);
    v_locale           varchar2(10);
    v_process_class    varchar2(100); --流程种类
    v_doc_sys_code     varchar2(100); --实际的单据编号
    v_config_sys_code  varchar2(100); --流程上配置的单据编号
    v_ext_form_url     varchar2(4000); --表单链接
    v_base_form_url    varchar2(4000); --域名字符串
    v_mob_form_url     varchar2(4000); --移动端表单链接
    v_page_type        varchar2(100); --用于区分待办todo/已办participate/待阅unread/草稿draft/申请apply/已发起new
    v_sys_code         varchar2(100); --系统来源
    v_platform         varchar2(100); --标识请求的设备（WEB/MOB）
    v_mob_data         clob; --移动端数据
    v_mob_data_json    json;
    v_workflow_pattern varchar2(2000);
    v_process_model    varchar2(1000); --流程模型类型
    v_process_code  varchar2(1000); --流程编号
    CURSOR v_button_cur IS
      SELECT db.button_code,
             NVL(TL.BUTTON_NAME, db.button_name) button_name
        FROM dbpm_buttons db, dbpm_buttons_tl TL, dbpm_node_buttons dnb
       WHERE db.button_code = dnb.button_code
         AND DB.BUTTON_CODE = TL.BUTTON_CODE(+)
         AND TL.LOCALE = v_locale
         AND dnb.node_id = v_node_id
       order by db.order_num asc;
         v_instanceid varchar2(100);
    --END ADD BY WLJ 获取按钮配置
  BEGIN
    v_request   := json(p_request, 'OBJECT');
    v_locale    := v_request.locale;
    v_page_type := v_request.get_string('pageType');
    v_platform  := v_request.get_string('platform');

    --根据taskId查询基本信息
    IF v_page_type IN ('todo', 'participate') AND v_request.exist('taskId') THEN
      v_task_id := v_request.get('taskId').get_string;
      if instr(v_task_id, 'DF-') = 1 then
        proc_init_form_detail_ext(p_request, x_response);
        return;
      else
        SELECT dd.document_id,
               dd.process_id,
               dd.form_id,
               t.protectednumberattribute1 "node_id",
               t.protectedformattribute1 "node_name",
               t.state,
               dd.status,
               T.ACTIVITYNAME,
               dd.doc_sys_code,
               t.instanceid,
               dbpm_comm_pkg.func_get_task_url(p_domain_url  => t.protectedtextattribute5,
                                               p_instance_id => t.instanceid,
                                               p_form_key    => t.protectedtextattribute7,
                                               p_task_id     => v_task_id,
                                               p_params      => t.protectedtextattribute6,
                                               p_sys_code    => t.protectedtextattribute2),
               rt.sys_code,
               t.workflowpattern,
               rt.PROCESS_MODEL_TYPE,
               t.protectedformattribute3
          INTO v_document_id,
               v_process_id,
               v_form_id,
               v_node_id,
               v_node_name,
               v_state,
               v_status,
               v_activity_name,
               v_doc_sys_code,
               v_bpm_instance_id,
               v_ext_form_url,
               v_sys_code,
               v_workflow_pattern,
               v_process_model,
               v_process_code
          FROM wftask t,
               dbpm_documents dd,
               (SELECT P.COMPOSITEDN, RE.Sys_Code, RE.PROCESS_MODEL_TYPE
                  FROM DBPM_PROCESS_REGISTRY RE, BPM_CUBE_PROCESS P
                 WHERE RE.DOMAINNAME = P.DOMAINNAME
                   AND RE.PROCESSNAME = P.PROCESSNAME
                   AND RE.COMPOSITENAME = P.COMPOSITENAME
                   AND RE.PROCESS_MODEL_TYPE IN ('BPM', 'OBPM')
                   AND RE.ENABLED_FLAG = 'Y') rt
         WHERE t.instanceid = dd.bpm_instance_id(+)
           AND t.taskid = v_task_id
           and t.compositedn = rt.COMPOSITEDN;
        IF v_process_id IS NULL THEN
          --如果得云单据表中没有对应的待办
          if v_process_model = 'OBPM' THEN
            begin
              --获取在流程注册表中的编码（对应得云流程编码）
              select ci.domain_name || '/' || ci.composite_name || '/' ||
                     ci.component_name
                into v_process_register_code
                from cube_instance ci
               where ci.cikey = v_bpm_instance_id;
              select dp.process_id
                into v_process_id
                from dbpm_process dp, dbpm_process_registry pr
               where dp.process_code = pr.process_code
                 and pr.compositerdn = v_process_register_code;
            exception
              when others then
                v_process_id := null;
            end;
          ELSIF v_process_model = 'BPM' THEN
            v_process_class := 'INTERNAL';
          END IF;
        END IF;
      end if;
    END IF;

    IF v_page_type = 'todo' THEN
      -- 待办情况，需要审批
      --v_task_id := v_request.get('taskId').get_string;
      --判断是否是第三方待办ID
      /*if instr(v_task_id, 'DF-') = 1 then
        proc_init_form_detail_ext(p_request, x_response);
        return;
      else
        SELECT dd.document_id,
               dd.process_id,
               dd.form_id,
               t.protectednumberattribute1 "node_id",
               t.protectedtextattribute2 "node_name",
               t.state,
               dd.status,
               T.ACTIVITYNAME,
               dd.doc_sys_code,
               t.instanceid,
               dbpm_comm_pkg.func_get_task_url(p_domain_url  => t.protectedtextattribute5,
                                               p_instance_id => t.instanceid,
                                               p_form_key    => t.protectedtextattribute7,
                                               p_task_id     => v_task_id,
                                               p_params      => t.protectedtextattribute6,
                                               p_sys_code    => ''),
               rt.sys_code
          INTO v_document_id,
               v_process_id,
               v_form_id,
               v_node_id,
               v_node_name,
               v_state,
               v_status,
               v_activity_name,
               v_doc_sys_code,
               v_bpm_instance_id,
               v_ext_form_url,
               v_sys_code
          FROM wftask t,
               dbpm_documents dd,
               (SELECT P.COMPOSITEDN, RE.Sys_Code
                  FROM DBPM_PROCESS_REGISTRY RE, BPM_CUBE_PROCESS P
                 WHERE RE.DOMAINNAME = P.DOMAINNAME
                   AND RE.PROCESSNAME = P.PROCESSNAME
                   AND RE.COMPOSITENAME = P.COMPOSITENAME
                   AND RE.PROCESS_MODEL_TYPE IN ('BPM', 'OBPM')
                   AND RE.ENABLED_FLAG = 'Y') rt
         WHERE t.instanceid = dd.bpm_instance_id(+)
           AND t.taskid = v_task_id
           and t.compositedn = rt.COMPOSITEDN;
        IF v_process_id IS NULL THEN
          --如果得云单据表中没有对应的待办
          begin
            --获取在流程注册表中的编码（对应得云流程编码）
            select ci.domain_name || '/' || ci.composite_name || '/' ||
                   ci.component_name
              into v_process_register_code
              from cube_instance ci
             where ci.cikey = v_bpm_instance_id;
            select dp.process_id
              into v_process_id
              from dbpm_process dp
             where dp.process_code = v_process_register_code;
          exception
            when others then
              v_process_id := null;
          end;
        END IF;


      end if;*/
      v_next_node_id := dbpm_comm_pkg.get_next_node_id(v_node_id);
      BEGIN
        SELECT dcn.approver_type
          INTO v_approver_type
          FROM dbpm_chain_nodes dcn
         WHERE dcn.node_id = v_next_node_id;
      EXCEPTION
        WHEN OTHERS THEN
          v_approver_type := '';
      END;
    if v_process_code is not null then
      select decode(t.doc_sys_code,'OTHERS','SCI',t.doc_sys_code) into v_sys_code
      from dbpm_process t where t.process_code=v_process_code;
      else
          select decode(dp.doc_sys_code,'OTHERS','SCI', dp.doc_sys_code)
          into v_sys_code
           from cux_bpm_all_instance ci,dbpm_process dp
          where dp.process_code=ci.process_code
          and ci.instance_id=v_bpm_instance_id;
      end if ;
      v_response.set_value('nodeId', v_node_id);
      v_response.set_value('nodeName', v_node_name);
      v_response.set_value('state', v_state);
      v_response.set_value('status', v_status);
      v_response.set_value('nextNodeApproverType', v_approver_type);
      v_response.set_value('sysCode', v_sys_code);
    ELSIF v_page_type = 'new' THEN
      -- 新建流程，需要编辑
      v_process_id := v_request.get('processId').get_number;
      v_form_id    := dbpm_comm_pkg.func_get_process_form(p_process_id => v_process_id);
      v_response.set_value('formId', v_form_id);

      --扩展外部流程-得云表单
      DBPM_PROCESS_EXT_PKG.proc_get_external_process_info(v_process_id,
                                                          v_domain_name,
                                                          v_composite_name);
      v_response.set_value('domainName', v_domain_name);
      v_response.set_value('compositeName', v_composite_name);
      --扩展外部流程-得云表单
    ELSIF v_page_type = 'apply' THEN
      -- 我的申请
      v_document_id := v_request.get('documentId').get_number;
      SELECT dd.process_id,
             dd.form_id,
             dd.bpm_instance_id,
             dd.doc_sys_code,
             DD.DOC_URL
        INTO v_process_id,
             v_form_id,
             v_bpm_instance_id,
             v_doc_sys_code,
             v_ext_form_url
        FROM dbpm_documents dd
       WHERE dd.document_id = v_document_id;
      begin
        SELECT WF.TASKID,
               wf.protectednumberattribute1 "node_id",
               wf.protectedtextattribute2   "node_name"
          INTO v_task_id, v_node_id, v_node_name
          FROM WFTASK WF, WFASSIGNEE ASS
         WHERE WF.STATE = 'ASSIGNED'
           AND ASS.TASKID = WF.TASKID
           AND LOWER(ASS.ASSIGNEE) = LOWER(v_request.username)
           AND WF.INSTANCEID = v_bpm_instance_id
         ORDER BY WF.tasknumber, WF.version ASC;
        v_response.set_value('nodeId', v_node_id);
        v_response.set_value('nodeName', v_node_name);
      exception
        when others then
          v_task_id := null;
      end;

      --扩展外部流程-得云表单
      DBPM_PROCESS_EXT_PKG.proc_get_external_process_info(v_process_id,
                                                          v_domain_name,
                                                          v_composite_name);
      v_response.set_value('domainName', v_domain_name);
      v_response.set_value('compositeName', v_composite_name);
      --扩展外部流程-得云表单
    ELSIF v_page_type = 'participate' THEN
      --已办
      v_bpm_instance_id := v_request.get_string('instanceId');


    ELSIF v_page_type = 'draft' THEN
      --草稿箱
      v_document_id := v_request.get('documentId').get_number;
      SELECT dd.process_id,
             dd.form_id,
             dd.bpm_instance_id,
             dd.doc_sys_code,
             DD.DOC_URL
        INTO v_process_id,
             v_form_id,
             v_bpm_instance_id,
             v_doc_sys_code,
             v_ext_form_url
        FROM dbpm_documents dd
       WHERE dd.document_id = v_document_id;
    ELSIF v_page_type = 'unread' THEN
      --待阅
      --TODO
      NULL;
    END IF;

    --获取详情的基础参数
    begin
      select dp.process_class, dp.form_url, dp.doc_sys_code
        into v_process_class, v_base_form_url, v_config_sys_code
        from dbpm_process dp
       where dp.process_id = v_process_id;
      v_base_form_url := dbpm_comm_pkg.func_get_task_url(p_domain_url  => v_base_form_url,
                                                         p_instance_id => v_bpm_instance_id,
                                                         p_form_key    => null,
                                                         p_task_id     => null,
                                                         p_params      => null,
                                                         p_sys_code    => null);
    exception
      when others then
        v_process_class   := NVL(v_process_class, 'EXTERNAL');
        v_config_sys_code := 'OTHERS';
        v_base_form_url   := '-';
    end;
    --设置详情的基础参数
    v_response.set_value('processId', v_process_id);
    v_response.set_value('processClass', v_process_class);
    v_response.set_value('instanceId', v_bpm_instance_id);
    v_response.set_value('taskId', v_task_id);
    v_response.set_value('formId', v_form_id);
    v_response.set_value('documentId', v_document_id);
    v_response.set_value('externalFormUrl',
                         nvl(v_ext_form_url, v_base_form_url));

    if v_mob_form_url is null and v_platform = 'MOB' then
      --备注:只有流程发起后写入维护了CUX_PROCESS_MOB_DATA才能查到数据，
      --此处通过实例号和系统来源来查询
      begin
        select md.mobile_data, md.mobile_url
          into v_mob_data, v_mob_form_url
          from cux_process_mob_data md
         where md.document_number = v_bpm_instance_id;
        --and nvl(md.sys_code, 'NL') = nvl(v_sys_code, 'NL');
      exception
        when others then
          --移动端查找链接失败时返回默认链接
          v_mob_form_url := '-';
      end;
      if v_mob_form_url is not null then
        --拼接参数
        if instr(v_ext_form_url, '?') > 0 then
          v_mob_form_url := v_mob_form_url ||
                            substr(v_ext_form_url,
                                   instr(v_ext_form_url, '?'));
        end if;
        if v_mob_form_url = '-' then
          v_response.set_value('mobileUrl', '');
        else
          v_response.set_value('mobileUrl', v_mob_form_url);
        end if;

      else
        begin
          v_mob_data_json := json(v_mob_data);
          if v_mob_data_json.exist('mobileData') then
            v_response.set_value('data',
                                 json(v_mob_data_json.get('mobileData')));
            v_doc_sys_code := 'CONFIG';
          end if;
          if v_mob_data_json.exist('mobileButtons') then
            v_response.set_value('buttonList',
                                 json_list(v_mob_data_json.get('mobileButtons')));
             v_response.set_value('docSysCode',
                                 nvl(v_doc_sys_code, v_config_sys_code));
           x_response := v_response.to_json;
           return;
          end if;
        exception
          when others then
            null;
        end;
      end if;
    end if;
    v_response.set_value('docSysCode',
                         nvl(v_doc_sys_code, v_config_sys_code));

    --BEGIN ADD BY WLJ 获取按钮配置
    --只配置待办的按钮,并且待办不属于第三方待办
    v_button_list.set_data_type('ARRAY');
    IF v_page_type = 'todo' THEN

      --如果是签批状态
      if v_state = 'INFO_REQUESTED' AND v_process_class = 'INTERNAL' then
        v_button_item := pl_json;
        v_button_item.set_value('buttonCode', 'SUBMIT_INFO');
        v_button_item.set_value('buttonName',
                                dcld_comm_pkg.func_get_sys_msg('QP',
                                                               v_locale));
        v_button_list.add_list_item(v_button_item);
      ELSIF v_workflow_pattern = 'FYI' THEN
        v_button_item := pl_json;
        v_button_item.set_value('buttonCode', 'APPROVE');
        v_button_item.set_value('buttonName',
                                dcld_comm_pkg.func_get_sys_msg('OK',
                                                               v_locale));
        v_button_list.add_list_item(v_button_item);
      ELSIF v_state = 'ASSIGNED' THEN

        --如果是其他OBPM流程，则通过节点名称查询对应的节点ID
        select count(1)
          into v_exist_count
          from dbpm_process dp, dbpm_process_registry r
         where dp.process_id = v_process_id
           and dp.process_code = r.process_code
           and r.process_model_type = 'OBPM';
        if v_exist_count > 0 then
          v_node_id := dbpm_process_ext_pkg.func_get_process_node(v_process_id,
                                                                  v_activity_name);
        end if;
        FOR v_button IN v_button_cur LOOP
          v_button_item := pl_json;
          v_button_item.set_value('buttonCode', v_button.button_code);
          v_button_item.set_value('buttonName', v_button.button_name);
          v_button_list.add_list_item(v_button_item);
        END LOOP;
        IF v_button_list.atom_list.count = 0 AND v_node_id = -1 THEN
          --当前节点为申请人节点
          v_button_item := pl_json;
          v_button_item.set_value('buttonCode', 'SUBMIT');
          v_button_item.set_value('buttonName',
                                  dcld_comm_pkg.func_get_sys_msg('RESUBMIT',
                                                                 v_locale));
          v_button_list.add_list_item(v_button_item);
          v_button_item := pl_json;
          v_button_item.set_value('buttonCode', 'DESTROY');
          v_button_item.set_value('buttonName',
                                  dcld_comm_pkg.func_get_sys_msg('DESTORY',
                                                                 v_locale));
          v_button_list.add_list_item(v_button_item);
        END IF;
      END IF;
    ELSE
      NULL;
    END IF;
  v_response.set_value('buttonList', v_button_list);
    --END ADD BY WLJ 获取按钮配置

    x_response := v_response.to_json;

  END proc_init_form_detail;

  /*
  * 进入表单详细时，初始化第三方数据
  */
  PROCEDURE proc_init_form_detail_ext(p_request CLOB, x_response OUT CLOB) AS
    v_request       json;
    v_response      pl_json := pl_json;
    v_task_id       varchar2(100);
    v_df_task_id    varchar2(100);
    v_sys_code      varchar2(100);
    v_mob_form_url  varchar2(4000);
    v_ext_form_url  varchar2(4000);
    v_todo_flag     varchar2(100);
    v_process_class varchar2(100);
    v_doc_sys_code  varchar2(100);
    v_data          clob;
    v_data_json     json;
    v_data_exist    varchar2(1) := 'Y';
  BEGIN

    v_request       := json(p_request, 'OBJECT');
    v_process_class := 'OTHERS';
    v_df_task_id    := v_request.get('taskId').get_string;
    begin
      select td.task_id, td.sys_code, td.mobile_url, td.url, td.todo_flag
        into v_task_id,
             v_sys_code,
             v_mob_form_url,
             v_ext_form_url,
             v_todo_flag
        from cux_process_todo td
       where td.df_task_id = v_df_task_id;
    exception
      when others then
        null;
    end;

    begin
      select ptd.mobile_data
        into v_data
        from cux_process_todo_detail ptd
       where ptd.df_task_id = v_df_task_id;
    exception
      when others then
        v_data_exist := 'N';
    end;

    --设置详情的基础参数
    v_response.set_value('processClass', v_process_class);
    v_response.set_value('taskId', v_task_id);
    v_response.set_value('externalFormUrl', v_ext_form_url);
    v_response.set_value('mobileUrl', v_mob_form_url);

    IF v_data_exist = 'Y' THEN
      v_data_json := json(v_data);
      if v_data_json.exist('mobileData') then
        v_response.set_value('data', json(v_data_json.get('mobileData')));
      end if;

      if v_data_json.exist('mobileButtons') then
        v_response.set_value('buttonList',
                             json_list(v_data_json.get('mobileButtons')));
      end if;
      v_doc_sys_code := 'CONFIG';
    END IF;
    IF v_mob_form_url IS NOT NULL THEN
      v_doc_sys_code := 'OTHERS';
    END IF;
    v_response.set_value('docSysCode', v_doc_sys_code);
    x_response := v_response.to_json;
  END;

END dbpm_document_api_pkg;

/

