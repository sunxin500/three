create view DBPM_BUSINESS_APPLY_V as
select distinct "EMPLOYEE_CODE","PROCESS_ID","PROCESS_CODE","PROCESS_NAME","PROCESS_TYPE","SPACE_ID",
"FORM_URL","PROCESS_CLASS","DOC_SYS_CODE","PROCESS_OWNER"
  from (select t1.employee_code,
               dp.process_id,
               dp.process_code,
               dp.process_name,
               dp.process_type,
               dp.space_id,
               dp.form_url,
               dp.process_class,
               dp.doc_sys_code,
               dp.process_owner
          from (SELECT gr.process_id, fe.employee_code
                  FROM dbpm_role_members           drm,
                       dbpm_roles                  dr,
                       dfnd_employees              fe,
                       dbpm_process_group_realtion gr
                 WHERE drm.role_id = dr.role_id
                   AND drm.member_code = fe.employee_code
                   and dr.role_code = gr.auth_code
                   and gr.auth_type = 'ROLE'
                   AND drm.role_id = dr.role_id
                    AND NVL(DBPM_PROCESS_AUTH_PKG.proc_get_auth_role_param(gr.realtion_id,drm.member_code),'N')='Y'
                      /*           and fe.employee_code = '101A0107'
                      */
                   AND EXISTS
                 (SELECT drmp.param_value, drmp.param_value_name
                          FROM dbpm_role_member_params drmp,
                               dbpm_role_members       drp
                         WHERE drmp.member_id(+) = drp.member_id
                           and (drp.member_id = drm.member_id))
                union all
                select dr.process_id, pa.auth_code employee_code
                  from dbpm_process_group_realtion dr,
                       dbpm_process_auth_group     ag,
                       dbpm_process_auth           pa
                 where pa.group_id = ag.group_id
                   and dr.auth_code = ag.group_code
                   and dr.auth_type = 'GROUP'
                   and pa.auth_type = 'PERSON' /* and pa.auth_code = '502A2403'*/
                union all /* 所有人都可以发起*/
                select dr.process_id, t.employee_code employee_code
                  from dbpm_process_group_realtion dr ,dfnd_employees t
                 where
                    dr.auth_code = 'ALL'
                    /* 所有人都可以发起*/
                union all
                select tt.process_id, oe.employee_code
                  from (select pa.auth_code, dr.process_id
                          from dbpm_process_group_realtion dr,
                               dbpm_process_auth_group     ag,
                               dbpm_process_auth           pa
                         where pa.group_id = ag.group_id
                           and dr.auth_code = ag.group_code
                           and dr.auth_type = 'GROUP'
                           and pa.auth_type = 'ORG') tt,
                       dfnd_org_employees oe
                 where /*oe.employee_code = '502A2403'
                                                      and*/
                 oe.enabled_flag='Enabled'          and
                 to_char(oe.organization_id) = tt.auth_code) t1,
               dbpm_process dp,
               (select * from dbpm_form df where df.status = 'Published') df
         where t1.process_id = dp.process_id
           and dp.process_id = df.process_id(+)
           and (dp.form_url is not null or df.form_id is not null)
           --and df.status = 'Published'
           and dp.enabled_flag = 'Y')

/

