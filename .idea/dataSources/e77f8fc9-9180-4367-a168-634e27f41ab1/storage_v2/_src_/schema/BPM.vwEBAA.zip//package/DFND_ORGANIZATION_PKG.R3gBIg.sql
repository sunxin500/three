create PACKAGE dfnd_organization_pkg IS
  /*
  得云升级新增包
  migrate by xiaowei.yao  20180411
  */
  /*
  Procedure Name :
        proc_add_organization
    Description:
        添加下级组织
    Argument:
        p_request：  请求（json）
        x_response： 响应（json）
    History:
        1.00  2017-03-20  chenming Creation
  */
  PROCEDURE proc_add_organization(p_request CLOB, x_response OUT CLOB);
  /*
  Procedure Name :
        proc_del_organization
    Description:
         删除当前组织及组织成员
    Argument:
        p_request：  请求（json）
        x_response： 响应（json）
    History:
        1.00  2017-03-20  chenming Creation
  */
  PROCEDURE proc_del_organization(p_request CLOB, x_response OUT CLOB);
  /*
  Procedure Name :
        proc_add_emp_to_organization
    Description:
         在当前组织下添加人员
    Argument:
        p_request：  请求（json）
        x_response： 响应（json）
    History:
        1.00  2017-03-20  chenming Creation
  */
  PROCEDURE proc_add_emp_to_organization(p_request  CLOB,
                                         x_response OUT CLOB);
  /*
  Procedure Name :
        proc_del_emp_from_organization
    Description:
         在当前组织下删除人员
    Argument:
        p_request：  请求（json）
        x_response： 响应（json）
    History:
        1.00  2017-03-20  chenming Creation
  */
  PROCEDURE proc_del_emp_from_organization(p_request  CLOB,
                                           x_response OUT CLOB);
  /*
  Procedure Name :
        proc_query_organization_emps
    Description:
         查询某个组织下所有人员
    Argument:
        p_request：  请求（json）
        x_response： 响应（json）
    History:
        1.00  2017-03-20  chenming Creation
  */
  PROCEDURE proc_query_organization_emps(p_request  CLOB,
                                         x_response OUT CLOB);
  /*
  Procedure Name :
        proc_update_organization
    Description:
         更新当前组织信息
    Argument:
        p_request：  请求（json）
        x_response： 响应（json）
    History:
        1.00  2017-03-20  chenming Creation
  */

  PROCEDURE proc_update_organization(p_request CLOB, x_response OUT CLOB);
  FUNCTION query_all(p_organization_id   VARCHAR2,
                     p_organization_name VARCHAR2) RETURN pl_json;
  /*
  Procedure Name :
        proc_query_all_organizations
    Description:
         查询组织信息
    Argument:
        p_request：  请求（json）
        x_response： 响应（json）
    History:
        1.00  2017-03-20  chenming Creation
  */
  PROCEDURE proc_query_all_organizations(p_request  CLOB,
                                         x_response OUT CLOB);

  /*
  Procedure Name :
        proc_save_org_employees
    Description:
        保存组织的分配人员信息
    Argument:
        p_request：  请求（json）
        x_response： 响应（json）
    History:
        1.00  2017-0４-2８  skycloud.wang Creation
  */
  PROCEDURE proc_save_org_employees(p_request CLOB, x_response OUT CLOB);

END dfnd_organization_pkg;

/

