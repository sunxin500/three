create PACKAGE BODY dfnd_foundation_api_pkg IS
  /*==================================================
  Procedure Name :
      proc_lookup_add_type
  Description:
      创建值列表类型
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2016-11-21  jianfeng.zheng  Creation
  Sample input:
      {
         "lookup_type": "xxx",
         "meaning": "xxxx",
         "description": "xxxx",
         "status": "Y"
       }
         lookup_type: 值列表类型
         meaning:     值列表含义
         description: 值列表描述
         status:      状态（Y/N）
  Sample output:
         标准输出
  ==================================================*/
  PROCEDURE proc_lookup_add_type(p_request IN CLOB, x_response OUT CLOB) IS
    v_api          VARCHAR2(30) := 'proc_lookup_add_type';
    v_look_type    VARCHAR2(30);
    v_count        NUMBER;
    v_current_user VARCHAR2(50); --获取当前用户
    v_response     pl_json := pl_json;
    v_request      json;
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;

    v_look_type := v_request.get('lookup_type').get_string;
    --判断该lookup_type是否存在
    SELECT COUNT(1)
      INTO v_count
      FROM dfnd_lookup_types t
     WHERE t.lookup_type = v_look_type;
    --
    IF TRIM(v_look_type) IS NOT NULL THEN
      IF v_count = 0 THEN
        --执行插入操作
        INSERT INTO dfnd_lookup_types
          (lookup_type,
           meaning,
           description,
           status,
           object_version_number,
           creation_date,
           created_by,
           last_updated_by,
           last_update_date)
        VALUES
          (v_look_type,
           v_request.get ('meaning' ).get_string,
           v_request.get ('description' ).get_string,
           v_request.get ('status' ).get_string,
           1,
           SYSDATE,
           v_current_user,
           v_current_user,
           SYSDATE);
      ELSE
        --返回错误信息
        v_response.fail('值列表类型:' || v_look_type || '已存在');
      END IF;
    ELSE
      v_response.fail('值列表类型不能为空');
    END IF;
    x_response := v_response.to_json;
    /* EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口||' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_lookup_add_type;

  /*==================================================
  Procedure Name :
      proc_lookup_remove_type
  Description:
      移除值列表类型
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2016-11-25  Kerry.Wu  Creation
  Sample input:
      {
         "lookup_type": "xxx",
       }
         lookup_type: 值列表类型
  Sample output:
         标准输出
  ==================================================*/
  PROCEDURE proc_lookup_remove_type(p_request IN CLOB, x_response OUT CLOB) IS
    v_api       VARCHAR2(30) := 'proc_lookup_remove_type';
    v_look_type VARCHAR2(30);
    v_count     NUMBER;
    v_response  pl_json := pl_json;
    v_request   json;
  BEGIN
    v_request   := json(p_request, 'OBJECT');
    v_look_type := v_request.get('lookup_type').get_string;
    --判断该lookup_type是否存在
    SELECT COUNT(1)
      INTO v_count
      FROM dfnd_lookup_types t
     WHERE t.lookup_type = v_look_type;
    IF TRIM(v_look_type) IS NOT NULL THEN
      IF v_count > 0 THEN
        DELETE FROM dfnd_lookup_types t WHERE t.lookup_type = v_look_type; --删 值列表类型
        DELETE FROM dfnd_lookup_values t WHERE t.lookup_type = v_look_type; --删 值列表值
      ELSE
        v_response.fail('该值列表类型:' || v_look_type || '不存在,无法删除');
      END IF;
    ELSE
      v_response.fail('该值列表类型不能为空');
    END IF;
    x_response := v_response.to_json;
    /*  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口||' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_lookup_remove_type;

  /*==================================================
  Procedure Name :
      proc_lookup_add_value
  Description:
      创建值列表值
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2016-11-25  Kerry.Wu  Creation
  Sample input:
      {
         "lookup_type": "xxxx",
         "lookup_code": "xxxx",
         "meaning": "xxxx",
         "description": "xxxx",
         "status": "xxxx",
         "tag": "xxxx",
         "order_num": 1
       }
         lookup_type: 值列表类型
         lookup_code: 值编码
         meaning:     值含义
         description: 描述
         status:      状态（Y/N）
         tag：        标签
         order_num:   显示顺序
  Sample output:
         标准输出
  ==================================================*/
  PROCEDURE proc_lookup_add_value(p_request IN CLOB, x_response OUT CLOB) IS
    v_api          VARCHAR2(30) := 'proc_lookup_add_value';
    v_look_type    VARCHAR2(30);
    v_look_code    VARCHAR2(100);
    v_count        NUMBER;
    v_type_count   NUMBER;
    v_current_user VARCHAR2(50); --获取当前用户
    v_response     pl_json := pl_json;
    v_request      json;
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;

    v_look_type := v_request.get('lookup_type').get_string;
    v_look_code := v_request.get('lookup_code').get_string;

    SELECT COUNT(1)
      INTO v_type_count
      FROM dfnd_lookup_types t
     WHERE t.lookup_type = v_look_type; --判断是否重复
    SELECT COUNT(1)
      INTO v_count
      FROM dfnd_lookup_values t
     WHERE t.lookup_type = v_look_type
       AND t.lookup_code = v_look_code;
    IF TRIM(v_look_type) IS NOT NULL AND TRIM(v_look_code) IS NOT NULL THEN
      IF v_type_count = 1 THEN
        IF v_count = 0 THEN
          INSERT INTO dfnd_lookup_values
            (lookup_type,
             lookup_code,
             meaning,
             description,
             status,
             tag,
             order_num,
             object_version_number,
             creation_date,
             created_by,
             last_updated_by,
             last_update_date)
          VALUES
            (v_look_type,
             v_look_code,
             v_request.get ('meaning' ).get_string,
             v_request.get ('description' ).get_string,
             v_request.get ('status' ).get_string,
             v_request.get ('tag' ).get_string,
             v_request.get ('order_num' ).get_number,
             1,
             SYSDATE,
             v_current_user,
             v_current_user,
             SYSDATE);
        ELSE
          v_response.fail('值列表类型:' || v_look_type || ' 中的值:' ||
                          v_look_code || ' 已存在');
        END IF;
      ELSE
        v_response.fail('值列表类型:' || v_look_type || ' 不存在，无法插入值列表值');
      END IF;
    ELSE
      v_response.fail('值列表类型，值列表值都不能为空');
    END IF;
    x_response := v_response.to_json;
    /* EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口||' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_lookup_add_value;

  /*==================================================
  Procedure Name :
      proc_lookup_query_types
  Description:
      查询值列表类型
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2016-11-25  Kerry.Wu  Creation
  Sample input:
      {
         "fields": [
               {
                 "field": "lookup_type",
                 "op": "like",
                  "value": "xxxx"
                },{
                 "field": "meaning",
                 "op": "like",
                  "value": "xxxx"
                }],
          "page": 100,
          "size": 101,
          "order": "xxxx",
          "order_type": "xxxxx"
       }
  Sample output:
         [
         "lookup_type": "xxxx",
         "meaning": "xxxx",
         "description": "xxxx",
         "status": "xxxx",
       ]
  ==================================================*/
  PROCEDURE proc_lookup_query_types(p_request IN CLOB, x_response OUT CLOB) IS
    v_api       VARCHAR2(30) := 'proc_lookup_query_types';
    v_look_type VARCHAR2(50);
    v_meaning   VARCHAR2(50);
    v_response  pl_json := pl_json;
    v_request   json;
    v_line_json pl_json := pl_json;
    v_json      pl_json := pl_json;
    v_total     NUMBER;
  BEGIN
    v_request   := json(p_request, 'OBJECT');
    v_look_type := dcld_comm_pkg.get_filter_value('lookup_type', v_request);
    v_meaning   := dcld_comm_pkg.get_filter_value('meaning', v_request);
    SELECT COUNT(1)
      INTO v_total
      FROM dfnd_lookup_types t
     WHERE nvl(t.lookup_type, 'NL') LIKE '%' || v_look_type || '%'
       AND nvl(t.meaning, 'NL') LIKE '%' || v_meaning || '%';
    v_json.set_value('total', v_total); --total
    FOR v_values_row IN (SELECT t.lookup_type,
                                t.meaning,
                                t.description,
                                t.status
                           FROM dfnd_lookup_types t
                          WHERE nvl(t.lookup_type, 'NL') LIKE
                                '%' || v_look_type || '%'
                            AND nvl(t.meaning, 'NL') LIKE
                                '%' || v_meaning || '%') LOOP
      v_line_json := pl_json;
      v_line_json.set_value('lookup_type', v_values_row.lookup_type);
      v_line_json.set_value('meaning', v_values_row.meaning);
      v_line_json.set_value('description', v_values_row.description);
      v_line_json.set_value('status', v_values_row.status);
      v_json.add_list_item('list', v_line_json);
    END LOOP;
    x_response := v_json.to_json;
    /* EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口||' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_lookup_query_types;

  /*==================================================
  Procedure Name :
      proc_lookup_query_values
  Description:
      查询值列表值
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2016-11-25  Kerry.Wu  Creation
  Sample input:
      {
         "fields": [
               {
                 "field": "lookup_type",
                 "op": "like",
                  "value": "xxxx"
                }],
          "page": 100,
          "size": 101,
          "order": "xxxx",
          "order_type": "xxxxx"
       }
  Sample output:
         [
         "lookup_code": "xxxx",
         "meaning": "xxxx",
         "description": "xxxx",
         "status": "xxxx",
         "tag": "xxxx",
        ]
  ==================================================*/
  PROCEDURE proc_lookup_query_values(p_request  IN CLOB,
                                     x_response OUT CLOB) IS
    v_api       VARCHAR2(30) := 'proc_lookup_query_values';
    v_look_type VARCHAR2(50);
    v_line_json pl_json := pl_json;
    v_json      pl_json := pl_json;
    v_response  pl_json := pl_json;
    v_request   json;
    v_total     NUMBER;
  BEGIN
    v_request   := json(p_request, 'OBJECT');
    v_look_type := dcld_comm_pkg.get_filter_value('lookup_type', v_request);
    SELECT COUNT(1)
      INTO v_total
      FROM dfnd_lookup_values t
     WHERE nvl(t.lookup_type, 'NL') LIKE '%' || v_look_type || '%';
    v_json.set_value('total', v_total); --total
    FOR v_values_row IN (SELECT t.lookup_code,
                                t.meaning,
                                t.description,
                                t.status,
                                t.tag
                           FROM dfnd_lookup_values t
                          WHERE nvl(t.lookup_type, 'NL') LIKE
                                '%' || v_look_type || '%') LOOP
      v_line_json := pl_json;
      v_line_json.set_value('lookup_code', v_values_row.lookup_code);
      v_line_json.set_value('meaning', v_values_row.meaning);
      v_line_json.set_value('description', v_values_row.description);
      v_line_json.set_value('status', v_values_row.status);
      v_line_json.set_value('tag', v_values_row.tag);
      v_json.add_list_item('list', v_line_json);
    END LOOP;
    x_response := v_json.to_json;
    /*  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口||' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_lookup_query_values;

  /*==================================================
  Procedure Name :
      proc_lookup_remove_values
  Description:
      移除值列表类型
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2016-12-29  Kerry.Wu  Creation
  Sample input:
      {
         "lookup_type": "xxx",
         "lookup_code": "xxx"
       }
         lookup_type: 值列表类型
         lookup_code: 值列表值
  Sample output:
         标准输出
  ==================================================*/
  PROCEDURE proc_lookup_remove_values(p_request  IN CLOB,
                                      x_response OUT CLOB) IS
    v_api       VARCHAR2(30) := 'proc_lookup_remove_values';
    v_look_type VARCHAR2(30);
    v_look_code VARCHAR2(30);
    v_count     NUMBER;
    v_response  pl_json := pl_json;
    v_request   json;
  BEGIN
    v_request   := json(p_request, 'OBJECT');
    v_look_type := v_request.get('lookup_type').get_string;
    v_look_code := v_request.get('lookup_code').get_string;
    --判断该lookup_type+lookup_code 是否存在
    SELECT COUNT(1)
      INTO v_count
      FROM dfnd_lookup_values t
     WHERE t.lookup_type = v_look_type
       AND t.lookup_code = v_look_code;

    IF v_count > 0 THEN
      DELETE FROM dfnd_lookup_values t
       WHERE t.lookup_type = v_look_type
         AND t.lookup_code = v_look_code; --删除值列表值
    ELSE
      v_response.fail('该值列表类型:' || v_look_type || '不存在,无法删除');
    END IF;
    x_response := v_response.to_json;
    /*  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口||' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_lookup_remove_values;

  /*==================================================
  Procedure Name :
      proc_lookup_type_update
  Description:
      编辑值列表类型
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2016-12-29  kerry.wu  Creation
  Sample input:
      {
         "lookup_type": "xxx",
         "meaning": "xxxx",
         "description": "xxxx",
         "status": "Y"
       }
         lookup_type: 值列表类型
         meaning:     值列表含义
         description: 值列表描述
         status:      状态（Y/N）
  Sample output:
         标准输出
  ==================================================*/
  PROCEDURE proc_lookup_type_update(p_request IN CLOB, x_response OUT CLOB) IS
    v_api          VARCHAR2(30) := 'proc_lookup_type_update';
    v_look_type    VARCHAR2(30);
    v_count        NUMBER;
    v_current_user VARCHAR2(50); --获取当前用户
    v_response     pl_json := pl_json;
    v_request      json;
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;

    v_look_type := v_request.get('lookup_type').get_string;
    --判断该lookup_type是否存在
    SELECT COUNT(1)
      INTO v_count
      FROM dfnd_lookup_types t
     WHERE t.lookup_type = v_look_type;
    --执行编辑操作
    IF v_count = 1 THEN
      UPDATE dfnd_lookup_types t
         SET t.meaning          = v_request.get('meaning').get_string,
             t.description      = v_request.get('description').get_string,
             t.status           = v_request.get('status').get_string,
             t.last_updated_by  = v_current_user,
             t.last_update_date = SYSDATE
       WHERE t.lookup_type = v_look_type;
    ELSE
      --返回错误信息
      v_response.fail('值列表类型:' || v_look_type || ' 不存在，或存在多条');
    END IF;
    x_response := v_response.to_json;
    /* EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口||' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_lookup_type_update;

  /*==================================================
  Procedure Name :
      proc_lookup_value_update
  Description:
      编辑值列表值
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2016-11-29  Kerry.Wu  Creation
  Sample input:
      {
         "lookup_type": "xxxx",
         "lookup_code": "xxxx",
         "meaning": "xxxx",
         "description": "xxxx",
         "status": "xxxx",
         "tag": "xxxx",
         "order_num": 1
       }
         lookup_type: 值列表类型
         lookup_code: 值编码
         meaning:     值含义
         description: 描述
         status:      状态（Y/N）
         tag：        标签
         order_num:   显示顺序
  Sample output:
         标准输出
  ==================================================*/
  PROCEDURE proc_lookup_value_update(p_request  IN CLOB,
                                     x_response OUT CLOB) IS
    v_api          VARCHAR2(30) := 'proc_lookup_value_update';
    v_look_type    VARCHAR2(30);
    v_look_code    VARCHAR2(100);
    v_count        NUMBER;
    v_current_user VARCHAR2(50); --获取当前用户
    v_response     pl_json := pl_json;
    v_request      json;
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;

    v_look_type := v_request.get('lookup_type').get_string;
    v_look_code := v_request.get('lookup_code').get_string;

    SELECT COUNT(1)
      INTO v_count
      FROM dfnd_lookup_values t
     WHERE t.lookup_type = v_look_type
       AND t.lookup_code = v_look_code;

    IF v_count = 1 THEN
      UPDATE dfnd_lookup_values t
         SET t.meaning          = v_request.get('meaning').get_string,
             t.description      = v_request.get('description').get_string,
             t.status           = v_request.get('status').get_string,
             t.tag              = v_request.get('tag').get_string,
             t.order_num        = v_request.get('order_num').get_number,
             t.last_updated_by  = v_current_user,
             t.last_update_date = SYSDATE
       WHERE t.lookup_type = v_look_type
         AND t.lookup_code = v_look_code;

    ELSE
      v_response.fail('值列表类型:' || v_look_type || ' 中对应的值:' || v_look_code ||
                      ' 不存在，或存在多条');
    END IF;
    x_response := v_response.to_json;
    /* EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口||' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_lookup_value_update;

  --个人资料接口(曾勇)
  /*==================================================
  Procedure Name :
      proc_role_add
  Description:
      个人资料查询接口
      涉及表dfnd_employees
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2016-12-08  yong.zeng  Creation
  Sample input:

  Sample output:
         标准输出
    {
     "login_name":"xxxx",
     "name":"xxxx",
     "sex":"xxxx",
     "phone":"xxxx",
     "email":"xxxx",
     "office_phone":"xxxx"
    }
     login_name      登录名
     name            姓名
     sex             性别
     phone           手机
     email           邮箱
     office_phone    办公电话
  ==================================================*/
  PROCEDURE proc_user_info_query(p_request CLOB, x_response OUT CLOB) IS
    v_api          VARCHAR2(30) := 'proc_user_info_query';
    v_request      json;
    v_response     pl_json := pl_json;
    v_login_name   VARCHAR2(100);
    v_user_code    VARCHAR2(100);
    v_name         VARCHAR2(100);
    v_sex          VARCHAR2(10);
    v_phone        VARCHAR2(100);
    v_email        VARCHAR2(100);
    v_office_phone VARCHAR2(100);
    v_count        NUMBER;
    v_current_user VARCHAR2(50);
    --v_is_process_admin varchar2(10):='N';--是否为流程平台管理员
    v_user_type  VARCHAR2(50); --用户类型
    v_space_id   VARCHAR2(100);
    v_space_code VARCHAR2(100);
    v_space_name VARCHAR2(1000);
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;

    SELECT COUNT(1)
      INTO v_count
      FROM dfnd_employees emp
     WHERE upper(emp.employee_code) = upper(v_current_user);
    --如果只有一条用户记录执行赋值
    IF v_count = 1 THEN
      SELECT emp.login_name,
             emp.employee_code,
             emp.employee_name,
             emp.sex,
             emp.phone,
             emp.email,
             emp.office_phone
        INTO v_login_name,
             v_user_code,
             v_name,
             v_sex,
             v_phone,
             v_email,
             v_office_phone
        FROM dfnd_employees emp
       WHERE upper(emp.employee_code) = upper(v_current_user);
    END IF;
    begin
      /*select 'Y' into  v_is_process_admin
      from dual
      where exists (select 1 from dbpm_administrators t where t.user_code=v_current_user);
      exception when no_data_found then
        v_is_process_admin:='N';*/
      SELECT t.admin_type, t.space_id, t.space_code, t.space_name
        into v_user_type, v_space_id, v_space_code, v_space_name
        FROM (select t.admin_type, t.space_id, ds.space_code, ds.space_name
                from dbpm_administrators t, dbpm_spaces ds
               where t.space_id = ds.space_id(+)
                 and upper(t.user_code) = upper(v_current_user)
               ORDER BY T.ADMIN_TYPE DESC, to_number(t.space_id) ASC) T
       WHERE ROWNUM = 1;
    exception
      when no_data_found then
        v_user_type := null;
    end;
    --行赋值
    v_response.set_value('login_name', v_login_name);
    v_response.set_value('userCode', v_user_code);
    v_response.set_value('name', v_name);
 --   v_response.set_value('sex',dcld_comm_pkg.get_lookup_meaning(v_df_sex_type, v_sex,v_request.locale,v_request.locale));
    v_response.set_value('phone', v_phone);
    v_response.set_value('email', v_email);
    v_response.set_value('office_phone', v_office_phone);
    v_response.set_value('userType', v_user_type);
    v_response.set_value('spaceId', v_space_id);
    v_response.set_value('spaceCode', v_space_code);
    v_response.set_value('spaceName', v_space_name);
    x_response := v_response.to_json;
    /*  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END;
  /*==================================================
  Procedure Name :
      proc_role_add
  Description:
      个人资料保存接口
      涉及表dfnd_employees
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2016-12-08  yong.zeng  Creation
  Sample input:
      {
     "login_name":"xxxx",
     "name":"xxxx",
     "sex":"xxxx",
     "phone":"xxxx",
     "email":"xxxx",
     "office_phone":"xxxx"
    }

     login_name      登录名
     name            姓名
     sex             性别
     phone           手机
     email           邮箱
     office_phone    办公电话
  Sample output:
         标准输出
  ==================================================*/
  PROCEDURE proc_user_info_edit(p_request IN CLOB, x_response OUT CLOB) IS
    v_api                VARCHAR2(30) := 'proc_user_info_edit';
    v_request            json;
    v_response           pl_json := pl_json;
    v_count_same_name    NUMBER;
    v_count_current_user NUMBER;
    v_current_user       VARCHAR2(50);
    v_name               VARCHAR2(100);
    v_login_name         VARCHAR2(100);
  BEGIN
    --解析字段
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;

    v_name       := v_request.get('name').get_string;
    v_login_name := v_request.get('login_name').get_string;
    --查询非当前用户是否存在相同登录名
    SELECT COUNT(1)
      INTO v_count_same_name
      FROM dfnd_employees emp
     WHERE emp.login_name = v_login_name
       AND emp.employee_code != v_current_user;
    IF v_name IS NULL THEN
      v_response.fail('姓名不能为空');
    ELSIF v_login_name IS NULL THEN
      v_response.fail('登录名不能为空');
    ELSIF v_count_same_name > 0 THEN
      v_response.fail('登录名:' || v_login_name || ',已存在');
    ELSE
      SELECT COUNT(1)
        INTO v_count_current_user
        FROM dfnd_employees emp
       WHERE emp.employee_code = v_current_user;
      --如果只有一条用户记录执行更新
      IF v_count_current_user = 1 THEN
        UPDATE dfnd_employees emp
           SET emp.login_name    = v_login_name,
               emp.employee_name = v_name,
               emp.sex           = v_request.get('sex').get_string,
               emp.phone         = v_request.get('phone').get_string,
               emp.email         = v_request.get('email').get_string,
               emp.office_phone  = v_request.get('office_phone').get_string
         WHERE emp.employee_code = v_current_user;
      END IF;
    END IF;
    x_response := v_response.to_json;
    /*  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END;
  --属性管理接口(许浩池)
  /*==================================================
  Procedure Name :
      proc_prop_add
  Description:
      创建属性
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2016-11-21  jianfeng.zheng  Creation
  Sample input:
      {
         "property_key": "xxxx",
         "property_value": "xxxx",
         "description": "xxxx",
         "status": "xxx"
     }
         property_key:         属性key
         property_value:       属性值
         description:          属性描述
         status:               状态Y/N
  Sample output:
         标准输出
  ==================================================*/
  PROCEDURE proc_prop_add(p_request IN CLOB, x_response OUT CLOB) IS
    v_api          VARCHAR2(30) := 'proc_prop_add';
    v_property_key VARCHAR2(30);
    v_count        NUMBER;
    v_current_user VARCHAR2(50); --获取当前用户
    v_response     pl_json := pl_json;
    v_request      json;
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;

    v_property_key := v_request.get('property_key').get_string;
    --判断该property_key是否存在
    SELECT COUNT(1)
      INTO v_count
      FROM dfnd_properties t
     WHERE t.property_key = v_property_key;
    IF v_count = 0 THEN
      --执行插入操作
      INSERT INTO dfnd_properties
        (property_id,
         property_key,
         property_value,
         description,
         status,
         object_version_number,
         creation_date,
         created_by,
         last_updated_by,
         last_update_date)
      VALUES
        (dfnd_properties_s.nextval,
         v_property_key,
         v_request.get            ('property_value'            ).get_string,
         v_request.get            ('description'            ).get_string,
         v_request.get            ('status'            ).get_string,
         1,
         SYSDATE,
         v_current_user,
         v_current_user,
         SYSDATE);
    ELSE
      --返回错误信息
      v_response.fail('属性key:' || v_property_key || '已存在');
    END IF;
    x_response := v_response.to_json;
    /* EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口||' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/

  END;

  /*==================================================
  Procedure Name :
      proc_prop_remove
  Description:
      删除属性
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2016-11-21  jianfeng.zheng  Creation
  Sample input:
      {
         "property_key": "xxxx"
     }
         property_key:         属性key
  Sample output:
         标准输出
  ==================================================*/
  PROCEDURE proc_prop_remove(p_request IN CLOB, x_response OUT CLOB) IS
    v_api          VARCHAR2(30) := 'proc_prop_remove';
    v_property_key VARCHAR2(100);
    v_count        NUMBER;
    v_response     pl_json := pl_json;
    v_request      json;
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_property_key := v_request.get('property_key').get_string;
    --判断该property_key是否存在
    SELECT COUNT(1)
      INTO v_count
      FROM dfnd_properties t
     WHERE t.property_key = v_property_key;
    IF v_count = 0 THEN
      v_response.fail('属性key:' || v_property_key || '不存在');
    ELSE
      DELETE FROM dfnd_properties t WHERE t.property_key = v_property_key;
    END IF;
    x_response := v_response.to_json;
    /* EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口||' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/

  END;

  /*==================================================
  Procedure Name :
      proc_role_query_members
  Description:
      查询角色成员信息
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2016-11-21  jianfeng.zheng  Creation
  Sample input:
      {
         "fields": [
               {
                 "field": "property_key/property_value",
                 "op": "like/like",
                  "value": "xxxx"
                }],
          "page": 100,
          "size": 101,
          "order": "xxxx",
          "order_type": "xxxxx"
       }
  Sample output:
         [
         "property_key": "xxxx",
         "property_value": "xxxx",
         "description": "xxxx",
         "status": "xxx"
        ]
         property_key:         属性key
         property_value:       属性值
         description:          属性描述
         status:               状态Y/N
  ==================================================*/
  PROCEDURE proc_prop_query_properties(p_request  IN CLOB,
                                       x_response OUT CLOB) IS
    v_api            VARCHAR2(30) := 'proc_prop_query_properties';
    v_request        json;
    v_response       pl_json := pl_json;
    v_line           pl_json;
    v_property_key   VARCHAR2(50);
    v_property_value VARCHAR2(200);
    v_description    VARCHAR2(500);
    v_status         VARCHAR2(50);
    v_page           NUMBER;
    v_size           NUMBER;
    v_row_count      NUMBER;
    --定义游标，支持分页查询
    CURSOR v_property_cur IS
      SELECT *
        FROM (SELECT t.property_key,
                     t.property_value,
                     t.description,
                     t.status,
                     rownum cnt
                FROM dfnd_properties t
               WHERE nvl(t.property_key, 'NL') LIKE
                     '%' || property_key || '%'
                 AND nvl(t.property_key, 'NL') LIKE
                     '%' || v_property_key || '%'
                 AND nvl(t.property_value, 'NL') LIKE
                     '%' || v_property_value || '%'
                 AND nvl(t.description, 'NL') LIKE
                     '%' || v_description || '%'
                 AND nvl(t.status, 'NL') LIKE '%' || v_status || '%'
                 AND rownum <= v_page * v_size)
       WHERE cnt > (v_page - 1) * v_size;

    v_property_row v_property_cur%ROWTYPE;

  BEGIN
    --解析字段
    v_request        := json(p_request, 'OBJECT');
    v_page           := nvl(v_request.get('page').get_number, 1);
    v_size           := nvl(v_request.get('size').get_number, 20);
    v_property_key   := dcld_comm_pkg.get_filter_value('property_key',
                                                       v_request);
    v_property_value := dcld_comm_pkg.get_filter_value('property_value',
                                                       v_request);
    v_description    := dcld_comm_pkg.get_filter_value('description',
                                                       v_request);
    v_status         := dcld_comm_pkg.get_filter_value('status', v_request);
    --查询记录总条数
    SELECT COUNT(1)
      INTO v_row_count
      FROM dfnd_properties t
     WHERE nvl(t.property_key, 'NL') LIKE '%' || property_key || '%'
       AND nvl(t.property_key, 'NL') LIKE '%' || v_property_key || '%'
       AND nvl(t.property_value, 'NL') LIKE '%' || v_property_value || '%'
       AND nvl(t.description, 'NL') LIKE '%' || v_description || '%'
       AND nvl(t.status, 'NL') LIKE '%' || v_status || '%';
    v_response.set_value('total', v_row_count);

    --查询行
    FOR v_property_row IN v_property_cur LOOP
      v_line := pl_json;
      v_line.set_value('property_key', v_property_row.property_key);
      v_line.set_value('property_value', v_property_row.property_value);
      v_line.set_value('description', v_property_row.description);
      v_line.set_value('status', v_property_row.status);
      v_response.add_list_item('list', v_line);
    END LOOP;
    x_response := v_response.to_json;
    /*  EXCEPTION
    WHEN OTHERS THEN
      v_response.fail('接口' || v_api || '发生错误,原因:' || SQLERRM);
      x_response := v_response.to_json;*/

  END;

  /*==================================================
  Procedure Name :
      proc_query_user_organizations
  Description:
      查询用户的组织信息
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2017-04-28  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_query_user_organizations(p_request  IN CLOB,
                                          x_response OUT CLOB) IS
    v_request      json;
    v_response     pl_json := pl_json;
    v_current_user VARCHAR2(50); --获取当前用户
    v_organization pl_json;
    CURSOR v_emp_organization_cur IS
      SELECT doe.*, do.organization_name
        FROM dfnd_org_employees doe, dfnd_organizations do
       WHERE doe.organization_id = do.organization_id
         AND upper(doe.employee_code) = upper(v_current_user)
         AND doe.enabled_flag = 'Y';   -- add by xuy 20190422
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;
    v_response.set_value('userCode', v_current_user);
    FOR v_emp_organization IN v_emp_organization_cur LOOP
      v_organization := pl_json;
      v_organization.set_value('organizationId',
                               v_emp_organization.organization_id);
      v_organization.set_value('organizationName',
                               v_emp_organization.organization_name);
      v_organization.set_value('isMasterOrganization',
                               v_emp_organization.is_master_organization);
      v_response.add_list_item('organizationList', v_organization);
    END LOOP;

    x_response := v_response.to_json;
  END proc_query_user_organizations;
END dfnd_foundation_api_pkg;
/

