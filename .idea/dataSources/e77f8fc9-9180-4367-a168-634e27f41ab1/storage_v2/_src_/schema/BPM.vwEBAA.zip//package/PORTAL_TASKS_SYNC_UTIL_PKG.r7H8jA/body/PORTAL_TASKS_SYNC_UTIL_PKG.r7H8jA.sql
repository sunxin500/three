create PACKAGE BODY     PORTAL_TASKS_SYNC_UTIL_PKG IS

  /***************************************************************************************
  * * * * * * *  根据当前时间生成一个时间标志供批量维护状态使用以提升性能* * * * * * * * * * * * * *
  ***************************************************************************************/
  FUNCTION GET_BATCH_DATA_TIME_MARK RETURN VARCHAR2 AS
    V_TIME_MARK VARCHAR2(20);
  BEGIN
    SELECT (TO_CHAR(SYSTIMESTAMP, 'YYYYMMDDHH24MISSFF6')) V_TIME_MARK
      INTO V_TIME_MARK
      FROM DUAL;
    RETURN V_TIME_MARK;
  END GET_BATCH_DATA_TIME_MARK;
  /***************************************************************************************
  * * * * * * *  将新的待办插入到临时表* * * * * * * * * * * * * *
  ***************************************************************************************/
  PROCEDURE NEW_TASKS_TO_TEMP_TABLE IS
  BEGIN
    INSERT INTO TASKS_LIST_FOR_PORTAL_TEMP
      (TASK_ID, ASSIGNEE, STATUS)
      SELECT *
        FROM (SELECT T.TASKID TASK_ID, T.ASSIGNEE, 'NEW' STATUS
                FROM BPM_WF_TASK_V T,
                     (SELECT REGEXP_SUBSTR(CSUC.PROCESS_CODE, '[^,]+', 1, L) AS PROCESS_CODE
                        FROM (SELECT LEVEL L FROM DUAL CONNECT BY LEVEL <= 100) B,
                             CUX_SYNC_URL_CONFIG_T CSUC
                       WHERE L <=
                             (LENGTH(CSUC.PROCESS_CODE) -
                             LENGTH(REPLACE(CSUC.PROCESS_CODE, ',')) + 1)
                         AND (CSUC.ENABLE_FLAG = 'Y' OR
                             CSUC.MOBILE_FLAG = 'Y')) CONF_V
               WHERE T.PROCESSCODE = CONF_V.PROCESS_CODE) V
       WHERE NOT EXISTS (SELECT 1
                FROM TASKS_LIST_FOR_PORTAL_TEMP T
               WHERE T.TASK_ID = V.TASK_ID
                 AND T.ASSIGNEE = V.ASSIGNEE
                 AND V.STATUS = 'NEW');
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      CUX_BPM_LOGGER.ERROR('同步新的待办到临时表异常', SYSDATE);

      COMMIT;
  END NEW_TASKS_TO_TEMP_TABLE;
  /***************************************************************************************
  * * * * * * * * * * * * * * * * 将已处理的待办数据状态维护至临时表* * * * * * * * * * * * * *
  ***************************************************************************************/
  PROCEDURE COMPLETE_TASKS_TO_TEMP_TABLE AS
  BEGIN
    UPDATE TASKS_LIST_FOR_PORTAL_TEMP TMP
       SET TMP.STATUS = 'COMPLETED'
     WHERE (TMP.STATUS = 'NEW-UPDATED' OR TMP.STATUS = 'NEW')
       AND NOT EXISTS (SELECT 1
              FROM BPM_WF_TASK_V V
             WHERE V.TASKID = TMP.TASK_ID
               AND V.ASSIGNEE = TMP.ASSIGNEE);

    COMMIT;

  END COMPLETE_TASKS_TO_TEMP_TABLE;
  /***************************************************************************************
  * *   修改指定已完成的待办至PORTAL的待办的状态，避免重复发送  * *
  ***************************************************************************************/
  PROCEDURE UPDATE_TASKS_STATUS(P_TIME_MARK IN VARCHAR2,
                                P_STATUS    IN VARCHAR2) AS
  BEGIN
    UPDATE TASKS_LIST_FOR_PORTAL_TEMP TMP
       SET TMP.STATUS = P_STATUS
     WHERE TMP.MARK = P_TIME_MARK;
    COMMIT;
  END UPDATE_TASKS_STATUS;
  /***************************************************************************************
  * *   根据时间标志查询一个当前新待办的数据集游标，并设置其时间标记为对应的时间标记，以供变更状态使用  * *
  ***************************************************************************************/
  PROCEDURE GET_NEW_TASKS_FOR_PROTAL(P_TIME_MARK OUT VARCHAR2,
                                     P_TASKS_CUR OUT TASKLIST_CUR) AS
    V_TIME_MARK VARCHAR2(20);
  BEGIN
    V_TIME_MARK := GET_BATCH_DATA_TIME_MARK();
    P_TIME_MARK := V_TIME_MARK;
    --设置批量维护标识
    UPDATE TASKS_LIST_FOR_PORTAL_TEMP TMP
       SET TMP.MARK = V_TIME_MARK
     WHERE TMP.STATUS = 'NEW'
       AND ROWNUM <= 50;
    COMMIT;

    --修改为具体的待办信息
    OPEN P_TASKS_CUR FOR
      SELECT TASK.TASKID,
             UPPER(TASK.ASSIGNEE) ASSIGNEE,
             TASK.ASSIGNEENAME,
             TASK.ASSIGNEDDATE,
             TASK.PROCESSTITLE,
             func_get_task_url(task.INSTANCEID,
                               task.processFormNo,
                               task.TASKID,
                               task.processParam,
                               task.businessSysCode) TASKURL,
             '' MOBILEURL,
             GET_FORM_USER_ID(TASK.INSTANCEID) FORM_USER_ID,
             TASK.CREATOR
        from BPM_WF_TASK_V TASK,
             TASKS_LIST_FOR_PORTAL_TEMP TMP,
             (SELECT DISTINCT REGEXP_SUBSTR(CSUC.PROCESS_CODE, '[^,]+', 1, L) AS PROCESS_CODE
                FROM (SELECT LEVEL L FROM DUAL CONNECT BY LEVEL <= 100) B,
                     CUX_SYNC_URL_CONFIG_T CSUC
               WHERE L <= (LENGTH(CSUC.PROCESS_CODE) -
                     LENGTH(REPLACE(CSUC.PROCESS_CODE, ',')) + 1)
                 AND (CSUC.ENABLE_FLAG = 'Y' OR CSUC.MOBILE_FLAG = 'Y')) CONF_V
       WHERE TMP.MARK = V_TIME_MARK
         AND TMP.TASK_ID = TASK.TASKID
         AND TMP.ASSIGNEE = TASK.ASSIGNEE
         AND TASK.PROCESSCODE = CONF_V.PROCESS_CODE
         AND TASK.CREATOR IS NOT NULL;
    --OPEN P_TASKS_CUR FOR SELECT TASK_ID FROM TASKS_LIST_FOR_PORTAL_TEMP TMP WHERE TMP.STATUS = 'NEW';
    --JAVA CODE 取到TIME_MARK以及待办结果集后，REST传输给PORTAL，根据接口结果来处理对应MARK的状态

    RETURN;
    --CLOSE P_TASKS_CUR;
  END GET_NEW_TASKS_FOR_PROTAL;
  /***************************************************************************************
  * *   根据时间标志查询一个已完成待办的数据集游标，并设置其时间标记为对应的时间标记，以供变更状态使用  * *
  ***************************************************************************************/
  PROCEDURE GET_COMPLETED_TASKS_FOR_PROTAL(P_TIME_MARK OUT VARCHAR2,
                                           P_TASKS_CUR OUT TASKLIST_CUR) AS
    V_TIME_MARK VARCHAR2(20);
  BEGIN
    V_TIME_MARK := GET_BATCH_DATA_TIME_MARK();
    P_TIME_MARK := V_TIME_MARK;

    --设置批量维护标识
    UPDATE TASKS_LIST_FOR_PORTAL_TEMP TMP
       SET TMP.MARK = V_TIME_MARK
     WHERE TMP.STATUS = 'COMPLETED'
       AND ROWNUM <= 50;
    COMMIT;

    OPEN P_TASKS_CUR FOR
      SELECT distinct TMP.TASK_ID, UPPER(TMP.ASSIGNEE) ASSIGNEE
        FROM TASKS_LIST_FOR_PORTAL_TEMP TMP
       WHERE not exists
       (select 1 from BPM_wf_task_v v where v.TASKID = tmp.task_id)
         and tmp.mark = V_TIME_MARK;

  END GET_COMPLETED_TASKS_FOR_PROTAL;
  /**************************************************************************************
  * *   获取审批页面对应的任务节点的URL对应的单点登陆的URL，避免URL连接无登陆  * *
  ***************************************************************************************/
  FUNCTION GET_TASK_SSO_URL(P_NODEID     NUMBER,
                            P_INSTANCEID VARCHAR2,
                            P_TASKID     VARCHAR2,
                            P_FORMKEY    VARCHAR2 DEFAULT NULL --每个系统中的流程的编码 没有的话取默认的
                            ) RETURN VARCHAR2 IS
    V_FORMURL VARCHAR2(2000);
  BEGIN
    BEGIN
      SELECT T.NODE_FORMURL
        INTO V_FORMURL
        FROM DBPM_CHAIN_NODES T
       WHERE T.NODE_ID = P_NODEID;
    EXCEPTION
      WHEN OTHERS THEN
        V_FORMURL := 'https://portal.haier.com';
    END;
    V_FORMURL := V_FORMURL || '?instanceId=' || P_INSTANCEID || '&formKey=' ||
                 P_FORMKEY || '&taskId=' || P_TASKID;

    RETURN V_FORMURL;
  END GET_TASK_SSO_URL;
  /**************************************************************************************
  * *   获取实例当前待办的上一个审批人  * *
  ***************************************************************************************/
  FUNCTION GET_FORM_USER_ID(P_INSTANCEID VARCHAR2) RETURN VARCHAR2 is
    v_from_user_id varchar2(2000);
  begin
    begin
      select updatedby
        into v_from_user_id
        from (select t.updatedby
                from wftaskhistory t
               where t.instanceid = P_INSTANCEID
                 and t.outcome is not null
                 and t.enddate is not null
               order by t.updateddate desc)
       where rownum = 1;
    exception
      when others then
        v_from_user_id := 'weblogic';
    end;
    return v_from_user_id;
  end GET_FORM_USER_ID;
  /*==================================================
  Procedure/Function Name :
      func_get_task_url
  Description:
      This function perform:
      获取单点登录审批地址
  Argument:

  History:
      1.00  2018-10-23  xw.y Creation
  ==================================================*/
  function func_get_task_url(p_instance_id varchar2,
                             p_form_key    varchar2,
                             p_task_id     varchar2,
                             p_params      varchar2,
                             p_sys_code    varchar2) return varchar2 as
    v_url     varchar2(4000);
    v_formKey varchar2(400);
    v_params  varchar2(400);
    v_actCode varchar2(400);

  begin
    begin
      select wf.protectedtextattribute9
        into v_actCode
        from wftask wf
       where wf.taskid = p_task_id;
    exception
      when others then
        v_actCode := 'NULL';
    end;
    v_formKey := p_form_key;
    v_params  := p_params;
    if p_instance_id is null and p_task_id is null and p_form_key is null and
       p_params is null then
      return '';
    end if;
    if p_sys_code = 'SCI' then
      --基于一期的开发模式
      v_url := 'http://10.138.8.68:7777/authority/loginpro.jsp?definesys=definesys';
      --拼接一个默认串
    ELSIF p_sys_code = 'GEMS' then
      --GEMS流程
      v_url := '';
    ELSIF p_sys_code = 'HOOMS' then
      --出国流程一期 自开发
      if v_actCode <> 'NULL' then
        begin
          select t.acitivity_formurl,
                 wf.protectedtextattribute3,
                 wf.protectedtextattribute10
            into v_url, v_formKey, v_params
            from cux_hooms_process_node t, wftask wf
           where t.activity_code = wf.protectedtextattribute9
             and wf.taskid = p_task_id;
        exception
          when others then
            v_url := '';
        end;
      else
        --出国流程二期 自开发
        begin
          select t.node_formurl,
                 wf.protectedtextattribute3,
                 wf.protectedtextattribute10
            into v_url, v_formKey, v_params
            from dbpm_chain_nodes t, wftask wf
           where t.node_id = wf.protectednumberattribute1
             and wf.taskid = p_task_id;
        exception
          when others then
            v_url := '';
        end;
      end if;

    else
      v_url := '10.138.8.68:7777/BPMUI?definesys=definesys';
    end if;
    --拼接taskId
    if instr(v_url, '?') <= 0 then
      v_url := v_url || '?';
    else
      v_url := v_url || '&';
    end if;
    select v_url || nvl2(p_instance_id, 'instanceId=' || p_instance_id, '') ||
           nvl2(p_task_id, '&' || 'taskId=' || p_task_id, '') ||
           nvl2(v_formKey, '&' || 'formKey=' || v_formKey, '') ||
           nvl2(v_params, '&' || v_params, '')
      into v_url
      from dual;
    return v_url;
  end;

END PORTAL_TASKS_SYNC_UTIL_PKG;

/

