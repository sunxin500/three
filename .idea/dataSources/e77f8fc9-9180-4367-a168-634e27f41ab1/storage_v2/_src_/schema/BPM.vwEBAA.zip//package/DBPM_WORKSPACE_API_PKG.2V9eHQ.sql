create PACKAGE dbpm_workspace_api_pkg IS

  /*
  * 创建审批历史
  */
  PROCEDURE proc_create_approval_history(p_request  IN CLOB,
                                         x_response OUT CLOB);

  /*==================================================
  Procedure Name :
      proc_task_drafts_query
  Description:
      查询草稿箱信息
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2016-11-30  曾勇 Creation
  ==================================================*/
  PROCEDURE proc_task_drafts_query(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure Name :
      proc_task_apply_query
  Description:
      查询我的申请
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2016-12-01  曾勇 Creation
  ==================================================*/
  PROCEDURE proc_task_apply_query(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure Name :
      proc_task_drafts_remove
  Description:
      移除草稿，支持批量
    1、非空校验
    2、判断是否存在
    3、存在删除
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2016-11-21  jianfeng.zheng  Creation
  ==================================================*/
  PROCEDURE proc_task_drafts_remove(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure Name :
      proc_task_partake_query
  Description:
      查询我的参与
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2016-12-01  曾勇 Creation
  ==================================================*/
  PROCEDURE proc_task_partake_query(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure Name :
      proc_task_schedule_query
  Description:
      查询我的待办
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2016-12-04  曾勇 Creation
  ==================================================*/
  PROCEDURE proc_task_todo_query(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_query_top_process
  Description:
      This function perform:
      业务申请-查询常用流程
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-06  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_query_top_process(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_query_all_process
  Description:
      This function perform:
      业务申请-查询所有流程
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-06  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_query_all_process(p_request IN CLOB, x_response OUT CLOB);
  /*==================================================
  Procedure/Function Name :
      proc_query_business_apply
  Description:
      This function perform:
      业务申请
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-02-08  jinglun.xu  Creation
  ==================================================*/
  PROCEDURE proc_query_business_apply(p_request  IN CLOB,
                                      x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_query_comm_process
  Description:
      This function perform:
      业务申请-查询通用的流程
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-11-30  liangjun.wu  Creation
  ==================================================*/
  PROCEDURE proc_query_comm_process(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_save_process
  Description:
      This function perform:
      流程配置-保存流程基本信息，需要判断是新建还是更新
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-07  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_save_process(p_request IN CLOB, x_response OUT CLOB);
  /*==================================================
  Procedure/Function Name :
      proc_save_process
  Description:
      This function perform:
      流程配置-保存流程国际化值
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-05-14  xiaowei.yao  migrate
  ==================================================*/
  PROCEDURE proc_save_process_tl(p_request CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_save_node_buttons
  Description:
      This function perform:
      保存节点的按钮信息
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-11  chenming  Creation
  ==================================================*/
  PROCEDURE proc_save_node_buttons(p_request IN CLOB, x_response OUT CLOB);
  /*==================================================
  Procedure/Function Name :
      proc_query_node_buttons
  Description:
      This function perform:
      查询某个审批节点的按钮信息，需要显示所有的按钮信息
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-11  chenming  Creation
  ==================================================*/
  PROCEDURE proc_query_node_buttons(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_query_process_chain_nodes
  Description:
      This function perform:
      查询流程的审批链及审批节点信息
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-11  chenming  Creation
  ==================================================*/
  PROCEDURE proc_query_process_chain_nodes(p_request  IN CLOB,
                                           x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_query_node_form_fields
  Description:
      This function perform:
      查询流程审批节点的表单字段权限信息
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-11  chenming  Creation
  ==================================================*/
  PROCEDURE proc_query_node_form_fields(p_request  IN CLOB,
                                        x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_save_node_form_fields
  Description:
      This function perform:
       保存流程审批节点的表单字段权限信息
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-11  chenming  Creation
  ==================================================*/
  PROCEDURE proc_save_node_form_fields(p_request  IN CLOB,
                                       x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_query_process_types
  Description:
      This function perform:
       查看所有流程分类信息
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-12  chenming  Creation
  ==================================================*/
  /*PROCEDURE proc_query_process_types(p_request  IN CLOB,
  x_response OUT CLOB);*/

  /*==================================================
  Procedure/Function Name :
      proc_query_process
  Description:
      This function perform:
       查询流程基本信息
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-12  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_query_process(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_get_type_count
  Description:
      This function perform:
       查询各种类型的数量，比如待办数量
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-18  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_get_type_count(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_query_approval_history
  Description:
      This function perform:
       查询流程审批历史
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-26  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_query_approval_history(p_request  IN CLOB,
                                        x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_query_get_approvers_type
  Description:
      This function perform:
       查询审批人类型
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-07-11  zhiheng.wei  Creation
  ==================================================*/
  PROCEDURE proc_query_get_approvers_type(p_request  CLOB,
                                          x_response OUT CLOB);

  /*
  * 获取待办数量
  */
  FUNCTION func_get_todo_count(p_current_user VARCHAR2) RETURN NUMBER;
  /*
  * 获取待办数量
  */
  FUNCTION func_get_read_count(p_current_user VARCHAR2) RETURN NUMBER;

  /*==================================================
  Procedure/Function Name :
      proc_add_add_select_approvers
  Description:
      This function perform:
       添加选中的审批人
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-07-11  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_add_select_approvers(p_request CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_query_data_operation_type
  Description:
      This function perform:
       查询数据判断类型
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-09-29  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_query_data_operation_type(p_request  CLOB,
                                           x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_query_history_graph
  Description:
      This function perform:
       查询审批历史流程图
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-05-08  wlj  Creation
  ==================================================*/
  PROCEDURE proc_query_history_graph(p_request  IN CLOB,
                                     x_response OUT CLOB);
  /*==================================================
  Procedure/Function Name :
      proc_copy_process
  Description:
      This function perform:
      流程配置-复制流程，
      当某些流程是一样的（或者大体一样），但是不能当做一条流程的时候，更加快捷方便的配置
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-02-28  echo.zeng  Creation
  ==================================================*/
  PROCEDURE proc_copy_process(p_request IN CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_copy_role
  Description:
      This function perform:
      流程配置-复制流程-复制角色信息和动态找人规则
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-02-28  echo.zeng  Creation
  ==================================================*/
  procedure proc_copy_role(p_node_id      in number,
                           p_current_user in varchar2,
                           v_to_node_id   in number,
                           p_node_type    in varchar2);
END dbpm_workspace_api_pkg;

/

