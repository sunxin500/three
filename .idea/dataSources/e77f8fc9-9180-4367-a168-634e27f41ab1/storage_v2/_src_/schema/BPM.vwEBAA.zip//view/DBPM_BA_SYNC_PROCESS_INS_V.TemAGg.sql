create view DBPM_BA_SYNC_PROCESS_INS_V as
select          ci.cikey                   instance_id,
                dp.process_id process_id,
                dp.process_code process_code,
                dp.system_code system_code,
                ca.instance_creator creator,
                ca.process_form_id process_form_id,
                ci.state,
                ci.creation_date,
                ci.modify_date
  from  cux_bpm_all_instance ca, cube_instance ci,dbpm_ba_process dp
  where ci.cikey=ca.instance_id
  and   ca.process_code=dp.process_code
/

