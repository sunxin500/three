create PACKAGE BODY "DBPA_BA_WARNING_PKG" is

  /*==================================================
  Procedure/Function Name :
      proc_create_warning_event
  Description:
      This function perform:
      创建预警事件


  Argument:
     --入参
     p_waring_id       预警id
     --出参
     无
  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  procedure proc_create_warning_event(p_waring_id in number) is
    v_process_code       dbpm_ba_process.process_code%TYPE;
    v_cdt_str            varchar2(300);
    v_str                varchar2(4000);
    v_rule_id            number;
    v_ins_cur            refcur;
    v_warning_name       dbpm_ba_warning.warning_name%TYPE;
    v_notifica_type      dbpm_ba_warning.notifica_type%TYPE;
    v_notifica_tmplet_id dbpm_ba_warning.notifica_tmplet_id%TYPE;
    v_instance_id        dbpm_ba_process_instance.instance_id%TYPE;
    v_process_form_id    dbpm_ba_process_instance.process_form_id%TYPE;
    v_count              number;
  begin
    --warning_id 不能为空
    if p_waring_id is not null then
      select t.warning_name,
             t.rule_id,
             t.process_code,
             t.notifica_type,
             t.notifica_tmplet_id
        into v_warning_name,
             v_rule_id,
             v_process_code,
             v_notifica_type,
             v_notifica_tmplet_id
        from dbpm_ba_warning t
       where t.warning_id = p_waring_id;
      --获取规则表达式，并替换成实际sql表达式
      v_cdt_str := func_replace_rule_key(func_get_rule_cdt(v_rule_id));
      v_str     := 'select distinct ins.instance_id,ins.process_form_id
                           from dbpm_ba_process_instance ins
                           where ' || v_cdt_str ||
                   ' and ins.state = 1 and ins.process_code = :1';
      --查询出满足规则的所有单据
      open v_ins_cur for v_str
        using v_process_code;
      loop
        fetch v_ins_cur
          into v_instance_id, v_process_form_id;
        exit when v_ins_cur%notfound;
        --如果已经预警过了，则不再预警
        select count(1)
          into v_count
          from dbpm_ba_warning_event t
         where t.process_code = v_process_code
           and t.instance_id = v_instance_id
           and t.process_form_id = v_process_form_id;
        if v_count > 0 then
          null;
        else
          --生成预警事件
          insert into dbpm_ba_warning_event
            (warning_event_id,
             warning_id,
             warning_name,
             notifica_type,
             notifica_tmplet_id,
             creation_date,
             created_by,
             update_date,
             updated_by,
             status,
             process_code,
             process_form_id,
             instance_id,
             activity_id,
             activity_code,
             activity_name,
             partition_date)
          values
            (dbpm_ba_warning_event_s.nextval,
             p_waring_id,
             v_warning_name,
             v_notifica_type,
             v_notifica_tmplet_id,
             sysdate,
             'BPM',
             null,
             null,
             'NEW',
             v_process_code,
             v_process_form_id,
             v_instance_id,
             null,
             null,
             null,
             sysdate);
        end if;
      end loop;
    end if;
  end proc_create_warning_event;

  /*==================================================
  Procedure/Function Name :
      proc_query_warnings
  Description:
      This function perform:
      查询预警配置，支持分页
  Argument:
     --入参 p_request json
          {
              "user": "",
              "data":
              {
                  "systemCode": "GEMS",
                  "params": [
                      "warningName": "test",
                      "processName": "test",
                      "notificaType": "test",
                      "startDate": "test",
                      "endDate": "test",
                      "createBy": "",
                      "notificaRecipients": "",
                      "notificaCC": ""
                  ],
                  "pageNo": 1,
                  "size": 10
              }
          }
     --出参 x_response  json
            {
                "code": "SUCCESS",
                "data":
                {
                    "warnings": [
                    {
                        "warningId": 1,
                        "warningName": "",
                        "process":
                        {
                            "code": "xxxx",
                            "name": "测试"
                        },
                        "notificaType":
                        {
                            "code": "email",
                            "name": "邮件"
                        },
                        "startDate": "",
                        "endDate": "",
                        "createBy":
                        {
                            "code": "a0017702",
                            "name": "曾勇"
                        },
                        "enable":
                        {
                            "code": "Y",
                            "name": "启用"
                        },
                        "notificaRecipients": [
                        {
                            "code": "a0017702",
                            "name": "曾勇"
                        },
                        {
                            "code": "a0017702",
                            "name": "曾勇"
                        }],
                        "notificaCC": [
                        {
                            "code": "a0017702",
                            "name": "曾勇"
                        },
                        {
                            "code": "a0017702",
                            "name": "曾勇"
                        }]
                    },
                    {
                        "warningId": 1,
                        "warningName": "",
                        "process":
                        {
                            "code": "xxxx",
                            "name": "测试"
                        },
                        "notificaType":
                        {
                            "code": "email",
                            "name": "邮件"
                        },
                        "startDate": "",
                        "endDate": "",
                        "createBy":
                        {
                            "code": "a0017702",
                            "name": "曾勇"
                        },
                        "enable":
                        {
                            "code": "Y",
                            "name": "启用"
                        },
                        "notificaRecipients": [
                        {
                            "code": "a0017702",
                            "name": "曾勇"
                        },
                        {
                            "code": "a0017702",
                            "name": "曾勇"
                        }],
                        "notificaCC": [
                        {
                            "code": "a0017702",
                            "name": "曾勇"
                        },
                        {
                            "code": "a0017702",
                            "name": "曾勇"
                        }]
                    }],
                    "pageNo": 1,
                    "total": 50
                }
            }
  History:
      1.00  2018-01-30    Echo.Zeng
  ==================================================*/
  procedure proc_query_warnings(p_request IN CLOB, x_response OUT CLOB) is
    v_process_name       varchar2(300);
    v_noti_type          varchar2(300);
    v_create_by          varchar2(300);
    v_noti_recipients    varchar2(300);
    v_date_format        varchar2(300) := 'yyyy-mm-dd hh24:mi:ss';
    v_user               varchar2(300);
    v_role               varchar2(300);
    v_au_sys_code        varchar2(300);
    v_noti_cc            varchar2(300);
    v_page_no            number;
    v_size               number;
    v_system_code        varchar2(300);
    v_sql_str            varchar2(4000);
    v_request            json;
    v_params             json;
    v_response           pl_json := pl_json;
    v_warning_cur        refcur;
    v_warning_id         dbpm_ba_warning.warning_id%TYPE;
    v_warning_name       dbpm_ba_warning.warning_name%TYPE;
    v_process_code       dbpm_ba_warning.process_code%TYPE;
    v_notifica_type      dbpm_ba_warning.notifica_type%TYPE;
    v_start_date         dbpm_ba_warning.start_date%TYPE;
    v_end_date           dbpm_ba_warning.end_date%TYPE;
    v_created_by         dbpm_ba_warning.created_by%TYPE;
    v_status             dbpm_ba_warning.status%TYPE;
    v_notifica_recipient dbpm_ba_warning.notifica_recipient%TYPE;
    v_notifica_cc        dbpm_ba_warning.notifica_cc%TYPE;
    v_pl_json            pl_json := pl_json;
    v_name               varchar2(300);
    v_total              number := 0;
    v_item               pl_json;
    v_type_split         type_split;
    cursor v_param_value_cur(p_user_code varchar2) is
      select dr.role_code,
             dr.role_name,
             drp.data_source_code,
             t.param_value,
             drp.param_name,
             drm.member_code
        from dbpm_role_member_params t,
             dbpm_role_params        drp,
             dbpm_role_members       drm,
             dbpm_roles              dr
       where t.param_id = drp.param_id
         and t.member_id = drm.member_id
         and drp.role_id = dr.role_id
         and drm.role_id = dr.role_id
         and dr.role_code = 'plat_admin'
         and lower(drm.member_code) = p_user_code;
  begin
    v_request         := json(p_request, 'OBJECT');
    v_params          := json(v_request.get('params'));
    v_system_code     := v_request.get('systemCode').get_string;
    v_warning_name    := v_params.get('warningName').get_string;
    v_process_name    := v_params.get('processName').get_string;
    v_noti_type       := v_params.get('notificaType').get_string;
    v_start_date      := v_params.get('startDate').get_string;
    v_end_date        := v_params.get('endDate').get_string;
    v_create_by       := v_params.get('createBy').get_string;
    v_noti_recipients := v_params.get('notificaRecipients').get_string;
    v_noti_cc         := v_params.get('notificaCC').get_string;
    v_page_no         := v_request.get('pageNo').get_number;
    v_size            := v_request.get('size').get_number;

    --判断角色
    for v_row in v_param_value_cur(v_user) loop
      if v_row.data_source_code = 'admin_type' then
        v_role := v_row.param_value;
      end if;
      if v_row.data_source_code = 'DbpmSysCode' then
        v_au_sys_code := v_row.param_value;
      end if;
    end loop;
    --判断权限
    if (v_role = 'system' and v_system_code <> v_au_sys_code) or
       v_role = 'process' then
      v_response.fail('权限不足！');
      x_response := v_response.to_json;
      return;
    end if;
    if v_warning_name is not null then
      v_sql_str := ' where t.warning_name like ''%' || v_warning_name ||
                   '%''';
    else
      v_sql_str := ' where 1 = 1';
    end if;
    if v_process_name is not null then
      v_sql_str := v_sql_str ||
                   ' and t.process_code in (select dbp.process_code from dbpm_ba_process dbp where dbp.process_code like ''%' ||
                   v_process_name || '%'' OR dbp.process_name like ''%' ||
                   v_process_name || '%'')';
    end if;
    if v_noti_type is not null then
      v_sql_str := v_sql_str ||
                   ' and t.notifica_type in (select dsv.value_code from dbpm_data_source_values dsv where dsv.data_source_code = ''noti_type'' and (dsv.value_name like ''%' ||
                   v_noti_type || '%'' or dsv.value_code like ''%' ||
                   v_noti_type || '%''))';
    end if;
    if v_start_date is not null then
      v_sql_str := v_sql_str || ' and t.start_date >= to_date(''' ||
                   v_start_date || ''',''' || v_date_format || ''')';
    end if;
    if v_end_date is not null then
      v_sql_str := v_sql_str || ' and t.end_date >= to_date(''' ||
                   v_end_date || ''',''' || v_date_format || ''')';
    end if;
    if v_create_by is not null then
      v_sql_str := v_sql_str ||
                   ' and t.created_by in (select de.employee_code from dfnd_employees de where lower(de.employee_code) like ''%' ||
                   lower(v_create_by) ||
                   '%'' or lower(de.employee_name) like ''%' ||
                   lower(v_create_by) || '%'')';
    end if;
    if v_noti_recipients is not null then
      v_sql_str := v_sql_str ||
                   ' and t.warning_id in (select distinct x.warning_id from (select distinct dbw.warning_id,regexp_substr(dbw.notifica_recipient,''[^,]+'',1,level) emp from dbpm_ba_warning dbw connect by level <= length(dbw.notifica_recipient) - length(replace(dbw.notifica_recipient, '','', '''')) + 1) x,dfnd_employees rde where x.emp = rde.employee_code and (rde.employee_code like ''%' ||
                   v_noti_recipients || '%'' or rde.employee_name like ''%' ||
                   v_noti_recipients || '%''))';
    end if;
    if v_noti_cc is not null then
      v_sql_str := v_sql_str ||
                   ' and t.warning_id in (select distinct x.warning_id from (select distinct dbw.warning_id,regexp_substr(dbw.notifica_cc,''[^,]+'',1,level) emp from dbpm_ba_warning dbw connect by level <= length(dbw.notifica_cc) - length(replace(dbw.notifica_cc, '','', '''')) + 1) x,dfnd_employees rde where x.emp = rde.employee_code and (rde.employee_code like ''%' ||
                   v_noti_cc || '%'' or rde.employee_name like ''%' ||
                   v_noti_cc || '%''))';
    end if;
    open v_warning_cur for 'select tmp.warning_id,tmp.warning_name,tmp.process_code,tmp.notifica_type,tmp.start_date,tmp.end_date,tmp.created_by,tmp.status,tmp.notifica_recipient,tmp.notifica_cc from (select t.*,rownum rn from dbpm_ba_warning t ' || v_sql_str || ' ) tmp where tmp.rn > (:0 - 1) * :1 and tmp.rn < :2 * :3'
      using v_page_no, v_size, v_page_no, v_size;
    loop
      fetch v_warning_cur
        into v_warning_id,
             v_warning_name,
             v_process_code,
             v_notifica_type,
             v_start_date,
             v_end_date,
             v_created_by,
             v_status,
             v_notifica_recipient,
             v_notifica_cc;
      exit when v_warning_cur%notfound;
      v_total := v_total + 1;
      v_item  := pl_json;
      v_item.set_value('warningId', v_warning_id);
      v_item.set_value('warningName', v_warning_name);
      --查询流程名称
      v_pl_json.set_value('code', v_process_code);
      select max(t.process_name)
        into v_name
        from dbpm_ba_process t
       where t.process_code = v_process_code;
      v_pl_json.set_value('name', v_name);
      v_item.set_value('process', v_pl_json);
      --查询通知类型名称
      v_pl_json := pl_json();
      v_pl_json.set_value('code', v_notifica_type);
      v_pl_json.set_value('name',
                          DBPA_BA_CORE_PKG.func_get_data_value('noti_type',
                                                               v_notifica_type));
      v_item.set_value('notificaType', v_pl_json);
      v_item.set_value('startDate', v_start_date);
      v_item.set_value('endDate', v_end_date);
      --查询创建人姓名
      v_pl_json := pl_json();
      v_pl_json.set_value('code', v_created_by);
      select max(t.employee_name)
        into v_name
        from dfnd_employees t
       where t.employee_code = v_created_by;
      v_pl_json.set_value('name', v_name);
      v_item.set_value('createBy', v_pl_json);
      --是否启用，暂时硬编码
      v_pl_json := pl_json();
      v_pl_json.set_value('code', v_status);
      if v_status = 'Y' then
        v_name := '启用';
      elsif v_status = 'N' then
        v_name := '禁用';
      end if;
      v_pl_json.set_value('name', v_name);
      v_item.set_value('enable', v_pl_json);
      --获取通知人
      v_type_split := func_string_split(v_notifica_recipient, ',');
      for v_index in 1 .. v_type_split.count loop
        v_pl_json := pl_json();
        v_pl_json.set_value('code', v_type_split(v_index));
        select max(t.employee_name)
          into v_name
          from dfnd_employees t
         where t.employee_code = v_type_split(v_index);
        v_pl_json.set_value('name', v_name);
        v_item.add_list_item('notificaRecipients', v_pl_json);
      end loop;
      --获取抄送人
      v_type_split := func_string_split(v_notifica_cc, ',');
      for v_index in 1 .. v_type_split.count loop
        v_pl_json := pl_json();
        v_pl_json.set_value('code', v_type_split(v_index));
        select max(t.employee_name)
          into v_name
          from dfnd_employees t
         where t.employee_code = v_type_split(v_index);
        v_pl_json.set_value('name', v_name);
        v_item.add_list_item('notificaCC', v_pl_json);
      end loop;
      v_response.add_list_item('warnings', v_item);
    end loop;
    close v_warning_cur;
    v_response.set_value('pageNo', v_page_no);
    v_response.set_value('size', v_total);
    x_response := v_response.to_json;
  exception
    when others then
      v_response.fail('获取数据失败，请稍后再试');
      x_response := v_response.to_json;
  end proc_query_warnings;

  /*==================================================
  Procedure/Function Name :
      proc_get_warning
  Description:
      This function perform:
      根据预警id查询预警信息
  Argument:
     --入参 p_request json
          {
              "systemCode": "GEMS",
              "warningId": 100
          }
     --出参 x_response  json
          {
              "code": "SUCCESS",
              "data":
              {
                  "warningId": 1,
                  "warningName": "",
                  "process":
                  {
                      "code": "xxxx",
                      "name": "测试"
                  },
                  "template":
                  {
                      "id": 1,
                      "name": "xxx"
                  },
                  "type": "email"
                  "startDate": "",
                  "endDate": "",
                  "enable": "Y",
                  "notificaRecipients": [
                  {
                      "code": "a0017702",
                      "name": "曾勇"
                  },
                  {
                      "code": "a0017702",
                      "name": "曾勇"
                  }],
                  "notificaCC": [
                  {
                      "code": "a0017702",
                      "name": "曾勇"
                  },
                  {
                      "code": "a0017702",
                      "name": "曾勇"
                  }],
                  "rules":
                  {
                      "ruleType": "BTW_GROUP",
                      "ruleKey": "",
                      "ruleOp": "AND",
                      "ruleValue": "",
                      "childs": [
                      {
                          "ruleType": "BTW_GROUP",
                          "ruleKey": "",
                          "ruleOp": "AND",
                          "ruleValue": "",
                          "childs": []
                      },
                      {
                          "ruleType": "BTW_GROUP",
                          "ruleKey": "",
                          "ruleOp": "AND",
                          "ruleValue": "",
                          "childs": []
                      }]
                  }
              }
          }

  History:
      1.00  2018-01-30    Echo.Zeng
  ==================================================*/
  procedure proc_get_warning(p_request IN CLOB, x_response OUT CLOB) is
    v_request            json;
    v_response           pl_json := pl_json;
    v_system_code        dfnd_app.system_code%TYPE;
    v_warning_id         dbpm_ba_warning.warning_id%TYPE;
    v_warning_name       dbpm_ba_warning.warning_name%TYPE;
    v_process_code       dbpm_ba_warning.process_code%TYPE;
    v_notifica_type      dbpm_ba_warning.notifica_type%TYPE;
    v_noti_tmplet_id     dbpm_ba_warning.notifica_tmplet_id%TYPE;
    v_start_date         varchar2(300);
    v_end_date           varchar2(300);
    v_status             dbpm_ba_warning.status%TYPE;
    v_notifica_recipient dbpm_ba_warning.notifica_recipient%TYPE;
    v_notifica_cc        dbpm_ba_warning.notifica_cc%TYPE;
    v_rule_id            dbpm_ba_warning.rule_id%TYPE;
    v_pl_json            pl_json := pl_json;
    v_name               varchar2(300);
    v_type_split         type_split;
  begin
    v_request     := json(p_request, 'OBJECT');
    v_system_code := v_request.get('systemCode').get_string;
    v_warning_id  := v_request.get('warningId').get_number;
    --查询预警信息
    select t.warning_id,
           t.warning_name,
           t.process_code,
           t.notifica_type,
           t.notifica_tmplet_id,
           to_char(t.start_date, 'yyyy-mm-dd'),
           to_char(t.end_date, 'yyyy-mm-dd'),
           t.status,
           t.notifica_recipient,
           t.notifica_cc,
           t.rule_id
      into v_warning_id,
           v_warning_name,
           v_process_code,
           v_notifica_type,
           v_noti_tmplet_id,
           v_start_date,
           v_end_date,
           v_status,
           v_notifica_recipient,
           v_notifica_cc,
           v_rule_id
      from dbpm_ba_warning t
     where t.warning_id = v_warning_id;
    --返回信息
    v_response.set_value('warningId', v_warning_id);
    v_response.set_value('warningName', v_warning_name);
    --返回流程对象
    select max(t.process_name)
      into v_name
      from dbpm_ba_process t
     where t.process_code = v_process_code;
    v_pl_json := pl_json();
    v_pl_json.set_value('name', v_name);
    v_pl_json.set_value('code', v_process_code);
    v_response.set_value('process', v_pl_json);
    --返回通知模板对象
    select max(t.tmplet_name)
      into v_name
      from dbpm_notification_tmplet t
     where t.noti_tmplet_id = v_noti_tmplet_id;
    v_pl_json := pl_json();
    v_pl_json.set_value('name', v_name);
    v_pl_json.set_value('id', v_noti_tmplet_id);
    v_response.set_value('template', v_pl_json);
    v_response.set_value('type', v_notifica_type);
    v_response.set_value('startDate', v_start_date);
    v_response.set_value('endDate', v_end_date);
    v_response.set_value('enable', v_status);
    --返回通知人
    v_type_split := func_string_split(v_notifica_recipient, ',');
    for v_index in 1 .. v_type_split.count loop
      v_pl_json := pl_json();
      v_pl_json.set_value('code', v_type_split(v_index));
      select max(t.employee_name)
        into v_name
        from dfnd_employees t
       where t.employee_code = v_type_split(v_index);
      v_pl_json.set_value('name', v_name);
      v_response.add_list_item('notificaRecipients', v_pl_json);
    end loop;
    --返回抄送人
    v_type_split := func_string_split(v_notifica_cc, ',');
    for v_index in 1 .. v_type_split.count loop
      v_pl_json := pl_json();
      v_pl_json.set_value('code', v_type_split(v_index));
      select max(t.employee_name)
        into v_name
        from dfnd_employees t
       where t.employee_code = v_type_split(v_index);
      v_pl_json.set_value('name', v_name);
      v_response.add_list_item('notificaCC', v_pl_json);
    end loop;
    --返回规则
    v_response.set_value('rules', func_get_rule_json(v_rule_id));
    x_response := v_response.to_json;
    /*exception
    when NO_DATA_FOUND then
      v_response.fail('查询数据为空,请重试');
      x_response := v_response.to_json;
    when others then
      v_response.fail('获取数据失败,请稍后再试');
      x_response := v_response.to_json;*/
  end proc_get_warning;

  /*==================================================
  Procedure/Function Name :
      proc_add_warning
  Description:
      This function perform:
      添加/编辑预警配置，支持批量
  Argument:
     --入参 p_request json
            {
                "systemCode":"GEMS",
                "warnings": [
                        "warningId": 1,
                        "warningName": "",
                        "process":"",
                        "notification":{
                            "type":"email",
                            "templateId":1
                        },
                        "startDate": "",
                        "endDate": "",
                        "enable":"Y",
                        "notificaRecipients": ["a0017702","a0017701"],
                        "notificaCC":["a0017702","a0017701"],
                        "rules":{
                            "ruleType":"BTW_GROUP",
                            "ruleKey":"",
                            "ruleOp":"AND",
                            "ruleValue":"",
                            "childs":[
                                {
                                    "ruleType":"BTW_GROUP",
                                    "ruleKey":"",
                                    "ruleOp":"AND",
                                    "ruleValue":"",
                                    "childs":[]
                                },
                                {
                                    "ruleType":"BTW_GROUP",
                                    "ruleKey":"",
                                    "ruleOp":"AND",
                                    "ruleValue":"",
                                    "childs":[]
                                }
                            ]
                        }
                    ],
                "op":"add"
            }
     --出参 x_response  json
          {
              "code": "SUCCESS",
              "userMsg":"添加/编辑成功",
              "data":{}
          }
  History:
      1.00  2018-01-30    Echo.Zeng
  ==================================================*/
  procedure proc_add_warning(p_request IN CLOB, x_response OUT CLOB) is
    v_request        json;
    v_response       pl_json := pl_json;
    v_system_code    dfnd_app.system_code%TYPE;
    v_warning_name   dbpm_ba_warning.warning_name%TYPE;
    v_warning_id     dbpm_ba_warning.warning_id%TYPE;
    v_process        dbpm_ba_process.process_code%TYPE;
    v_notifi         json := json();
    v_start_date     varchar2(300);
    v_end_date       varchar2(300);
    v_status         dbpm_ba_warning.status%TYPE;
    v_noti_recipents json_list := json_list();
    v_noti_cc        json_list := json_list();
    v_rules          json := json();
    v_op             varchar2(30);
    v_seq            number;
    v_user           varchar2(300);
    v_noti_rec_str   varchar2(4000);
    v_noti_cc_str    varchar2(4000);
    v_warning_list   json_list := json_list();
    v_json           json := json();
    v_flag           varchar2(30);
    v_rule_id        number;
  begin
    v_request      := json(p_request, 'OBJECT');
    v_user         := json(p_request).get('user').get_string;
    v_system_code  := v_request.get('systemCode').get_string;
    v_op           := v_request.get('op').get_string;
    v_warning_list := json_list(v_request.get('warnings'));

    for v_i in 1 .. v_warning_list.count loop
      v_json           := json(v_warning_list.get(v_i));
      v_warning_id     := v_json.get('warningId').get_string;
      v_warning_name   := v_json.get('warningName').get_string;
      v_process        := v_json.get('process').get_string;
      v_notifi         := json(v_json.get('notification'));
      v_start_date     := v_json.get('startDate').get_string;
      v_end_date       := v_json.get('endDate').get_string;
      v_status         := v_json.get('enable').get_string;
      v_noti_recipents := json_list(v_json.get('notificaRecipients'));
      v_noti_cc        := json_list(v_json.get('notificaCC'));
      v_rules          := json(v_json.get('rules'));
      --添加规则
      v_seq := func_add_rule(v_rules, null, v_user);
      if v_seq is null then
        v_response.fail('规则新增失败');
        x_response := v_response.to_json;
        rollback;
        return;
      end if;
      --拼接通知接收人
      for i in 1 .. v_noti_recipents.count loop
        v_noti_rec_str := v_noti_rec_str || v_noti_recipents.get(i)
                         .get_string || ',';
      end loop;

      --拼接通知抄送人
      for j in 1 .. v_noti_cc.count loop
        v_noti_cc_str := v_noti_cc_str || v_noti_cc.get(j).get_string || ',';
      end loop;
      --添加
      if v_op = 'add' then
        insert into DBPM_BA_WARNING
          (WARNING_ID,
           WARNING_NAME,
           WARNING_DESC,
           RULE_ID,
           NOTIFICA_TYPE,
           NOTIFICA_TMPLET_ID,
           CREATION_DATE,
           CREATED_BY,
           UPDATE_DATE,
           UPDATED_BY,
           VERSION,
           PARTITION_DATE,
           PROCESS_CODE,
           START_DATE,
           END_DATE,
           STATUS,
           NOTIFICA_RECIPIENT,
           NOTIFICA_CC)
        values
          (DBPM_BA_WARNING_S.Nextval,
           v_warning_name,
           v_warning_name,
           v_seq,
           v_notifi.get('type').get_string,
           v_notifi.get('templateId').get_number,
           sysdate,
           v_user,
           sysdate,
           v_user,
           1,
           sysdate,
           v_process,
           to_date(v_start_date, 'yyyy-mm-dd'),
           to_date(v_end_date, 'yyyy-mm-dd'),
           v_status,
           v_noti_rec_str,
           v_noti_cc_str);
        v_response.set_user_msg('添加成功');
      elsif v_op = 'edit' then
        select t.rule_id
          into v_rule_id
          from dbpm_ba_warning t
         where t.warning_id = v_warning_id;
        --清除规则
        v_flag := func_delete_rule(v_rule_id);
        if v_flag = 'N' then
          v_response.fail('规则修改失败');
          x_response := v_response.to_json;
          rollback;
          return;
        end if;
        --添加规则
        v_seq := func_add_rule(v_rules, null, v_user);
        if v_seq is null then
          v_response.fail('规则修改失败');
          x_response := v_response.to_json;
          rollback;
          return;
        end if;
        --修改
        update DBPM_BA_WARNING t
           set t.warning_name       = v_warning_name,
               t.warning_desc       = v_warning_name,
               t.rule_id            = v_seq,
               t.notifica_type      = v_notifi.get('type').get_string,
               t.notifica_tmplet_id = v_notifi.get('templateId').get_number,
               t.update_date        = sysdate,
               t.updated_by         = v_user,
               t.process_code       = v_process,
               t.start_date         = to_date(v_start_date, 'yyyy-mm-dd'),
               t.end_date           = to_date(v_end_date, 'yyyy-mm-dd'),
               t.status             = v_status,
               t.notifica_recipient = v_noti_rec_str,
               t.notifica_cc        = v_noti_cc_str
         where t.warning_id = v_warning_id;
        v_response.set_user_msg('修改成功');
      end if;
    end loop;
    x_response := v_response.to_json;
    /*exception
    when NO_DATA_FOUND then
      v_response.fail('查询数据为空,请重试');
      x_response := v_response.to_json;
    when others then
      v_response.fail('获取数据失败,请稍后再试');
      x_response := v_response.to_json;*/
  end proc_add_warning;

  /*==================================================
  Procedure/Function Name :
      proc_delete_warning
  Description:
      This function perform:
      删除预警配置，支持批量
  Argument:
     --入参 p_request json
            {
                "systemCode":"GEMS",
                "warningIds": [1,2,3,4,5,6]
            }
     --出参 x_response  json
            {
                "code": "SUCCESS",
                "userMsg":"删除成功",
                "data":{}
            }
  History:
      1.00  2018-01-30    Echo.Zeng
  ==================================================*/
  procedure proc_delete_warning(p_request IN CLOB, x_response OUT CLOB) is
    v_request     json;
    v_response    pl_json := pl_json;
    v_system_code dfnd_app.system_code%TYPE;
    v_warning_ls  json_list := json_list();
    v_rule_id     number;
    v_flag        varchar2(30);
  begin
    v_request     := json(p_request, 'OBJECT');
    v_system_code := v_request.get('systemCode').get_string;
    v_warning_ls  := json_list(v_request.get('warningIds'));
    --循环删除
    for i in 1 .. v_warning_ls.count loop
      --查询规则id
      select t.rule_id
        into v_rule_id
        from dbpm_ba_warning t
       where t.warning_id = v_warning_ls.get(i).get_number;
      --清除规则
      v_flag := func_delete_rule(v_rule_id);
      if v_flag = 'N' then
        v_response.fail('规则修改失败');
        x_response := v_response.to_json;
        rollback;
        return;
      end if;
      --删除预警
      delete from dbpm_ba_warning t
       where t.warning_id = v_warning_ls.get(i).get_number;
    end loop;
    v_response.set_user_msg('删除成功');
    x_response := v_response.to_json;
    /*exception
    when NO_DATA_FOUND then
      v_response.fail('查询数据为空,请重试');
      x_response := v_response.to_json;
    when others then
      v_response.fail('获取数据失败,请稍后再试');
      x_response := v_response.to_json;*/
  end proc_delete_warning;

  /*==================================================
  Procedure/Function Name :
      func_get_rule_json
  Description:
      This function perform:
      添加规则，用于递归
  Argument:
     --入参

     --出参
     无
  History:
      1.00  2018-02-01    Echo.Zeng Creation
  ==================================================*/
  function func_add_rule(p_json    IN json,
                         p_rule_id IN NUMBER,
                         p_user    IN VARCHAR2) return number is
    v_seq      number;
    v_children json_list := json_list();
    v_count    number;
  begin
    if p_json is not null then
      v_seq := DBPM_BA_WARNING_RULE_S.NEXTVAL;
      insert into DBPM_BA_WARNING_RULE
        (RULE_ID,
         RULE_TYPE,
         PARENT_RULE_ID,
         RULE_KEY,
         RULE_OP,
         RULE_VALUE,
         STATUS,
         VERSION,
         CREATION_DATE,
         CREATE_BY,
         UPDATE_DATE,
         UPDATE_BY,
         PARTITION_DATE)
      values
        (DBPM_BA_WARNING_RULE_S.NEXTVAL,
         p_json.get                    ('ruleType'                    )
         .get_string,
         p_rule_id,
         p_json.get                    ('ruleKey'                    )
         .get_string,
         p_json.get                    ('ruleOp'                    )
         .get_string,
         p_json.get                    ('ruleValue'                    )
         .get_string,
         'Y',
         1,
         sysdate,
         p_user,
         sysdate,
         p_user,
         sysdate);
      v_children := json_list(p_json.get('children'));
      if v_children.count > 0 then
        for i in 1 .. v_children.count loop
          v_count := func_add_rule(json(v_children.get(i)), v_seq, p_user);
          if v_count is null then
            return null;
          end if;
        end loop;
      end if;
    end if;
    return v_seq;
  exception
    when others then
      rollback;
      return null;
  end func_add_rule;

  /*==================================================
  Procedure/Function Name :
      func_delete_rule
  Description:
      This function perform:
      删除规则，删除父规则以及所有的子规则
  Argument:
     --入参

     --出参
     无
  History:
      1.00  2018-02-01    Echo.Zeng Creation
  ==================================================*/
  function func_delete_rule(p_rule_id IN NUMBER) return varchar2 is
    cursor v_rule_cur(p_rule_id number) is
      select t.rule_id
        from dbpm_ba_warning_rule t
       start with t.rule_id = p_rule_id
      connect by prior t.rule_id = t.parent_rule_id;
  begin
    --循环删除
    for v_rule_cur_row in v_rule_cur(p_rule_id) loop
      delete from dbpm_ba_warning_rule t
       where t.rule_id = v_rule_cur_row.rule_id;
    end loop;
    return 'Y';
  exception
    when others then
      rollback;
      return 'N';
  end func_delete_rule;

  /*==================================================
  Procedure/Function Name :
      func_get_rule_json
  Description:
      This function perform:
      解析预警规则返回json对象
  Argument:
     --入参
     p_rule_id       预警id
     --出参
     无
  History:
      1.00  2018-02-01    Echo.Zeng Creation
  ==================================================*/
  function func_get_rule_json(p_rule_id in number) return json is
    v_json       json;
    v_rule_type  dbpm_ba_warning_rule.rule_type%TYPE;
    v_rule_key   dbpm_ba_warning_rule.rule_key%TYPE;
    v_rule_op    dbpm_ba_warning_rule.rule_op%TYPE;
    v_rule_value dbpm_ba_warning_rule.rule_value%TYPE;
    v_pr_rule_id number;
  begin
    --查询根节点数据
    select t.rule_type,
           t.rule_key,
           t.rule_op,
           t.rule_value,
           t.parent_rule_id
      into v_rule_type, v_rule_key, v_rule_op, v_rule_value, v_pr_rule_id
      from dbpm_ba_warning_rule t
     where t.rule_id = p_rule_id;
    --返回数据
    v_json := json();
    v_json.put('ruleType', v_rule_type);
    v_json.put('ruleKey', v_rule_key);
    v_json.put('ruleOp', v_rule_op);
    v_json.put('ruleValue', v_rule_value);
    --子规则需要递归
    v_json.put('children', func_get_rule_childs(p_rule_id));
    return v_json;
  exception
    when NO_DATA_FOUND then
      return v_json;
  end func_get_rule_json;

  function func_get_rule_childs(p_rule_id in number) return json_list is
    cursor v_rule_cur(p_rule_id number) is
      select t.rule_type, t.rule_key, t.rule_op, t.rule_value, t.rule_id
        from dbpm_ba_warning_rule t
       where t.parent_rule_id = p_rule_id;
    v_json      json;
    v_json_list json_list := json_list();
  begin

    for v_rule_cur_row in v_rule_cur(p_rule_id) loop
      v_json := json();
      v_json.put('ruleType', v_rule_cur_row.rule_type);
      v_json.put('ruleKey', v_rule_cur_row.rule_key);
      v_json.put('ruleOp', v_rule_cur_row.rule_op);
      v_json.put('ruleValue', v_rule_cur_row.rule_value);
      v_json.put('children', func_get_rule_childs(v_rule_cur_row.rule_id));
      v_json_list.append(v_json.to_json_value);
    end loop;
    return v_json_list;
  exception
    when others then
      return v_json_list;
  end func_get_rule_childs;
  /*==================================================
  Procedure/Function Name :
      func_get_rule_op
  Description:
      This function perform:
      创建预警事件


  Argument:
     --入参
     p_waring_id       预警id
     --出参
     无
  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  function func_get_rule_op(p_op_code in varchar2) return varchar2 is
    v_op_value varchar2(30);
  begin
    if p_op_code = 'EQ' then
      v_op_value := '=';
    elsif p_op_code = 'N_EQ' then
      v_op_value := '<>';
    elsif p_op_code = 'GT' then
      v_op_value := '>';
    elsif p_op_code = 'GT_EQ' then
      v_op_value := '>=';
    elsif p_op_code = 'LT' then
      v_op_value := '<';
    elsif p_op_code = 'LT_EQ' then
      v_op_value := '<=';
    else
      v_op_value := '=';
    end if;
    return v_op_value;
  end func_get_rule_op;

  /*==================================================
  Procedure/Function Name :
      func_get_rule_cdt
  Description:
      This function perform:
      获取预警条件表达式


  Argument:
     --入参
     p_rule_id       根规则
     --出参
     无
  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  function func_get_rule_cdt(p_rule_id in number) return varchar2 is
    v_cdt_str varchar2(4000);
    /*cursor v_rule_cdt_cur(p_rule_id number) is
    select t.*
      from DBPM_BA_WARNING_RULE t
     where t.rule_type = 'BTW_GROUP'
     start with t.rule_id = p_rule_id
    connect by prior t.rule_id = t.parent_rule_id;*/
    cursor v_child_rule_cur(p_rule_id number) is
      select t.rule_id, t.rule_type, t.rule_key, t.rule_op, t.rule_value
        from dbpm_ba_warning_rule t
       where t.parent_rule_id = p_rule_id;
    v_btw_op  varchar2(300);
    v_btw_cdt varchar2(4000);
  begin
    --如果规则id为空，默认条件1 = 1
    if p_rule_id is null then
      v_cdt_str := '1 = 1';
    else
      --查询组间运算符
      select t.rule_op
        into v_btw_op
        from dbpm_ba_warning_rule t
       where t.rule_id = p_rule_id
         and t.rule_type = 'BTW_GROUP';
      --循环所有的子规则
      for v_child_cur_row in v_child_rule_cur(p_rule_id) loop
        --如果是
        if v_child_cur_row.rule_type = 'BTW_GROUP' then
          v_btw_cdt := func_get_rule_cdt(v_child_cur_row.rule_id);
          v_cdt_str := v_cdt_str || v_btw_cdt;
        elsif v_child_cur_row.rule_type = 'IN_GROUP' then
          v_cdt_str := v_cdt_str || ' ' || v_child_cur_row.rule_key || ' ' ||
                       func_get_rule_op(v_child_cur_row.rule_op) || ' ' ||
                       v_child_cur_row.rule_value || ' ' || v_btw_op;
        end if;
      end loop;
    end if;
    return ' (' || substr(v_cdt_str, 1, instr(v_cdt_str, v_btw_op, -1) - 1) || ') ';
  end func_get_rule_cdt;

  /*==================================================
  Procedure/Function Name :
      func_replace_rule_key
  Description:
      This function perform:
      替换关键字为流程信息


  Argument:
     --入参
     p_rule_cdt       规则表达式
     --出参
     无
  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  function func_replace_rule_key(p_rule_cdt in varchar2) return varchar2 is
  begin
    return replace(p_rule_cdt,
                   'process_during_time',
                   'sysdate - to_date(to_char(ins.creation_date, ''yyyy-mm-dd hh24:mi:ss''),''yyyy-mm-dd hh24:mi:ss'')');
  end func_replace_rule_key;

  /*==================================================
  Procedure/Function Name :
      func_get_notification_address
  Description:
      This function perform:
      获取通知地址


  Argument:
     --入参
     p_user_delim_str     用户规则集合，使用分隔符分隔的字符串
     p_delimiter          分隔符
     p_noti_type          通知类型：邮件、短信
     --出参
     替换成地址的字符串
  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  function func_get_notification_address(p_user_delim_str in varchar2,
                                         p_delimiter      in varchar2,
                                         p_noti_type      in varchar2)
    return varchar2 is
    v_spilt_array         type_split;
    v_curr_address        varchar2(300);
    v_replace_address_str varchar2(4000);
  begin
    v_spilt_array := func_string_split(p_user_delim_str, p_delimiter);
    for i in 1 .. v_spilt_array.count loop
      select max(decode(lower(p_noti_type),
                        'email',
                        t.email,
                        'message',
                        t.phone)) user_address
        into v_curr_address
        from dfnd_employees t
       where t.employee_code = v_spilt_array(i);
      v_replace_address_str := v_replace_address_str || v_curr_address ||
                               p_delimiter;
    end loop;
    return v_replace_address_str;
  end func_get_notification_address;

end DBPA_BA_WARNING_PKG;

/

