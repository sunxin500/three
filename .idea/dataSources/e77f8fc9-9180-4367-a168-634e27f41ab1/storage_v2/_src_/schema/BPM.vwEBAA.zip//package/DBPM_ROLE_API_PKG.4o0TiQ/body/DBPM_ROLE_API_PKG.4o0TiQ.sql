create PACKAGE BODY     "DBPM_ROLE_API_PKG" IS

  /*==================================================
  Procedure/Function Name :
      proc_query_roles
  Description:
      This function perform:
      查询审批角色
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-20  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_query_roles(p_request IN CLOB, x_response OUT CLOB) IS
    v_response   pl_json := pl_json;
    v_role_json  pl_json;
    v_param_json pl_json;
    v_request    json;

    --分页
    v_total NUMBER := 0;
    v_size  number := 20;
    v_page  number := 1;
    --查询条件
    v_filter    json;
    v_desc      varchar2(1000);
    v_role_code varchar2(100);
    v_role_name varchar2(1000);
    v_all       varchar2(4000);
    v_spaceid   varchar2(100);
    --排序参数
    v_sort_col varchar2(100);
    v_sort     json;
    CURSOR v_role_cur IS
      SELECT *
        FROM (SELECT v.*, rownum cnt
                FROM (SELECT COUNT(1) OVER(PARTITION BY 1) TOTAL,
                             DR.*,
                             ds.space_name,
                             dcld_comm_pkg.get_lookup_meaning('ROLE_CREATE_TYPE',
                                                              dr.CREATE_TYPE,
                                                              v_request.locale) CREATE_TYPE_MAENING
                        FROM DBPM_ROLES DR, DBPM_SPACES DS
                       WHERE DR.STATUS = 'Y' and
                             DR.Space_Id =
                             decode(dr.is_shared, 'N', v_spaceid, DR.Space_Id) AND
                             DR.SPACE_ID = DS.Space_Id(+) AND
                             INSTR(NVL(DR.ROLE_CODE, 'NL'),
                                   NVL(v_role_code, NVL(DR.ROLE_CODE, 'NL'))) > 0 AND
                             INSTR(NVL(DR.ROLE_NAME, 'NL'),
                                   NVL(v_role_name, NVL(DR.ROLE_NAME, 'NL'))) > 0 AND
                             INSTR(NVL(DR.DESCRIPTION, 'NL'),
                                   NVL(v_desc, NVL(DR.DESCRIPTION, 'NL'))) > 0
                       ORDER BY decode(v_sort_col,
                                       'role_code_desc',
                                       dr.role_code,
                                       'role_name_desc',
                                       dr.role_name,
                                       'description_desc',
                                       dr.description,
                                       'create_type_desc',
                                       dr.create_type) DESC,
                                decode(v_sort_col,
                                       'role_code_asc',
                                       dr.role_code,
                                       'role_name_asc',
                                       dr.role_name,
                                       'description_asc',
                                       dr.description,
                                       'create_type_asc',
                                       dr.create_type) ASC,
                                ROLE_ID desc) v
               WHERE rownum <= v_page * v_size)
       WHERE cnt > (v_page - 1) * v_size;

    CURSOR v_lov_role_cur IS
      SELECT *
        FROM (SELECT v.*, rownum cnt
                FROM (SELECT COUNT(1) OVER(PARTITION BY 1) TOTAL,
                             DR.*,
                             ds.space_name,
                             (SELECT LV.MEANING
                                FROM DFND_LOOKUP_VALUES LV
                               WHERE LV.LOOKUP_CODE = DR.CREATE_TYPE AND
                                     LV.LOOKUP_TYPE = 'ROLE_CREATE_TYPE') CREATE_TYPE_MAENING
                        FROM DBPM_ROLES DR, DBPM_SPACES DS
                       WHERE DR.STATUS = 'Y' AND DR.SPACE_ID = DS.Space_Id(+) AND
                             (INSTR(NVL(DR.ROLE_CODE, 'NL'),
                                    NVL(v_all, NVL(DR.ROLE_CODE, 'NL'))) > 0 or
                             INSTR(NVL(DR.ROLE_NAME, 'NL'),
                                    NVL(v_all, NVL(DR.ROLE_NAME, 'NL'))) > 0 or
                             INSTR(NVL(DR.DESCRIPTION, 'NL'),
                                    NVL(v_all, NVL(DR.DESCRIPTION, 'NL'))) > 0)
                       ORDER BY decode(v_sort_col,
                                       'role_code_desc',
                                       dr.role_code,
                                       'role_name_desc',
                                       dr.role_name,
                                       'description_desc',
                                       dr.description,
                                       'create_type_desc',
                                       dr.create_type) DESC,
                                decode(v_sort_col,
                                       'role_code_asc',
                                       dr.role_code,
                                       'role_name_asc',
                                       dr.role_name,
                                       'description_asc',
                                       dr.description,
                                       'create_type_asc',
                                       dr.create_type) ASC,
                                ROLE_ID desc) v
               WHERE rownum <= v_page * v_size)
       WHERE cnt > (v_page - 1) * v_size;
    CURSOR v_role_param_cur(p_role_id VARCHAR2) IS
      SELECT * FROM dbpm_role_params drp WHERE drp.role_id = p_role_id;

  BEGIN
    v_request := json(p_request, 'OBJECT');
    v_spaceid := v_request.get_string('spaceId');
    if v_request.exist('page')
    then
      v_page := v_request.get_number('page');
    end if;
    if v_request.exist('size')
    then
      v_size := v_request.get_number('size');
    end if;
    /*   if v_request.exist('searchField') then
      v_filter    := json(v_request.get('searchField'));
      v_desc      := v_filter.get_string('description');
      v_role_code := v_filter.get_string('roleCode');
      v_role_name := v_filter.get_string('roleName');
    end if;*/
    v_desc      := dcld_comm_pkg.get_filter_value('description', v_request);
    v_role_code := dcld_comm_pkg.get_filter_value('roleCode', v_request);
    v_role_name := dcld_comm_pkg.get_filter_value('roleName', v_request);
    --如果传入参数为all，则表明是lov
    v_all := dcld_comm_pkg.get_filter_value('all', v_request);

    if v_request.exist('sort')
    then
      v_sort     := json(v_request.get('sort'));
      v_sort_col := v_sort.get_string('value');
      v_sort_col := v_sort_col || '_' || v_sort.get_string('order');
    end if;

    if v_all is null
    then
      FOR v_role IN v_role_cur
      LOOP
        v_total     := v_role.total;
        v_role_json := pl_json;
        v_role_json.set_value('roleId', v_role.role_id);
        v_role_json.set_value('roleCode', v_role.role_code);
        v_role_json.set_value('roleName', v_role.role_name);
        v_role_json.set_value('spaceId', v_role.space_id);
        v_role_json.set_value('spaceName', v_role.space_name);
        v_role_json.set_value('description', v_role.description);
        v_role_json.set_value('isShare', v_role.is_shared);
        v_role_json.set_value('creationDate',
                              to_char(v_role.creation_date,
                                      'YYYY-MM-DD HH24:MI'));
        v_role_json.set_value('createType', v_role.create_type);
        v_role_json.set_value('createTypeMeaning',
                              v_role.create_type_maening);
        FOR v_role_param IN v_role_param_cur(v_role.role_id)
        LOOP
          v_param_json := pl_json;
          v_param_json.set_value('paramId', v_role_param.param_id);
          v_param_json.set_value('roleId', v_role_param.role_id);
          v_param_json.set_value('paramName', v_role_param.param_name);
          v_param_json.set_value('dataSourceCode',
                                 v_role_param.data_source_code);
          v_role_json.add_list_item('params', v_param_json);
        END LOOP;
        v_response.add_list_item('roles', v_role_json);
      END LOOP;
    else
      FOR v_role IN v_lov_role_cur
      LOOP
        v_total     := v_role.total;
        v_role_json := pl_json;
        v_role_json.set_value('roleId', v_role.role_id);
        v_role_json.set_value('roleCode', v_role.role_code);
        v_role_json.set_value('roleName', v_role.role_name);
        v_role_json.set_value('spaceId', v_role.space_id);
        v_role_json.set_value('spaceName', v_role.space_name);
        v_role_json.set_value('description', v_role.description);
        v_role_json.set_value('creationDate',
                              to_char(v_role.creation_date,
                                      'YYYY-MM-DD HH24:MI'));
        v_role_json.set_value('createType', v_role.create_type);
        v_role_json.set_value('createTypeMeaning',
                              v_role.create_type_maening);
        FOR v_role_param IN v_role_param_cur(v_role.role_id)
        LOOP
          v_param_json := pl_json;
          v_param_json.set_value('paramId', v_role_param.param_id);
          v_param_json.set_value('roleId', v_role_param.role_id);
          v_param_json.set_value('paramName', v_role_param.param_name);
          v_param_json.set_value('dataSourceCode',
                                 v_role_param.data_source_code);
          v_role_json.add_list_item('params', v_param_json);
        END LOOP;
        v_response.add_list_item('roles', v_role_json);
      END LOOP;
    end if;

    v_response.set_value('total', v_total);
    x_response := v_response.to_json;
  END proc_query_roles;

  /*==================================================
  Procedure/Function Name :
      proc_get_document_data
  Description:
      This function perform:
      保存审批角色，需要判断是新增还是修改
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-20  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_save_role(p_request IN CLOB, x_response OUT CLOB) IS
    v_api       VARCHAR2(30) := 'proc_save_role';
    v_request   json;
    v_response  pl_json := pl_json;
    v_params    json_list;
    v_param     json;
    v_role_code VARCHAR2(100);
    -- v_role_id      VARCHAR2(100);
    v_role_id      number; --海尔的表为number
    v_current_user VARCHAR2(50);
    v_is_new       varchar2(10);
    v_count        NUMBER;
    v_space_id     varchar2(100); --add by wlj 空间ID
    v_is_share     varchar2(100);
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;
    v_is_new       := v_request.get_string('isNew');
    v_role_code    := v_request.get('roleCode').get_string;
    v_space_id     := v_request.get_string('spaceId');
    v_is_share     := v_request.get_string('isShare');
    --查询是否存在该角色
    SELECT COUNT(1)
      INTO v_count
      FROM dbpm_roles t
     WHERE t.role_code = v_role_code;
    if v_is_new = 'Y' and v_count <> 0
    then
      --v_response.fail('该角色编码已经存在！');
      v_response.fail(DCLD_COMM_PKG.func_get_err_msg('DCLD-00015',
                                                     v_request.locale));
      x_response := v_response.to_json;
      RETURN;
    end if;
    IF v_count = 0 And v_is_new = 'Y'
    THEN
      v_role_id := dbpm_roles_s.nextval;
      INSERT INTO dbpm_roles
        (role_id,
         role_code,
         role_name,
         description,
         status,
         created_by,
         last_updated_by,
         SPACE_ID,
         is_shared)
      VALUES
        (v_role_id,
         v_role_code,
         v_request.get('roleName').get_string,
         v_request.get('description').get_string,
         'Y',
         v_current_user,
         v_current_user,
         v_space_id,
         v_is_share);
    ELSE
      /*SELECT dr.role_id
       INTO v_role_id
       FROM dbpm_roles dr
      WHERE dr.role_code = v_role_code;*/
      v_role_id := v_request.get_number('roleId');
      -- 先设置参数为失效
      UPDATE dbpm_role_params drp
         SET drp.status = 'N'
       WHERE drp.role_id = v_role_id;

      UPDATE dbpm_roles dr
         Set dr.role_code             = v_request.get('roleCode').get_string,
             dr.role_name             = v_request.get('roleName').get_string,
             dr.description           = v_request.get('description')
                                        .get_string,
             dr.object_version_number = dr.object_version_number + 1,
             dr.last_updated_by       = v_current_user,
             dr.is_shared             = v_is_share
      -- WHERE dr.role_code = v_role_code;
       WHERE dr.role_id = v_role_id;
    END IF;
    -- 获取角色参数列表
    IF v_request.get('params') IS NOT NULL
    THEN
      v_params := json_list(v_request.get('params'));
      FOR i IN 1 .. v_params.count
      LOOP
        v_param := json(v_params.get(i));
        IF v_param.get('paramId') IS NULL
        THEN
          INSERT INTO dbpm_role_params
            (param_id,
             role_id,
             param_name,
             data_source_code,
             status,
             created_by,
             last_updated_by)
          VALUES
            (dbpm_role_params_s.nextval,
             v_role_id,
             v_param.get('paramName').get_string,
             v_param.get('dataSourceCode').get_string,
             'Y',
             v_current_user,
             v_current_user);
        ELSE
          UPDATE dbpm_role_params drp
             SET drp.param_name       = v_param.get('paramName').get_string,
                 drp.data_source_code = v_param.get('dataSourceCode')
                                        .get_string,
                 drp.status           = 'Y'
           WHERE drp.param_id = v_param.get('paramId').get_number;
        END IF;
      END LOOP;
    END IF;
    -- 判断参数是否可以删除
    FOR v_del_param IN (SELECT *
                          FROM dbpm_role_params drp
                         WHERE drp.status = 'N' AND drp.role_id = v_role_id)
    LOOP
      SELECT COUNT(1)
        INTO v_count
        FROM dbpm_role_member_params drmp
       WHERE drmp.param_id = v_del_param.param_id;
      IF v_count > 0
      THEN
        ROLLBACK;
        --v_response.fail('该参数已经在角色成员中使用！');DCLD-00016
        v_response.fail(DCLD_COMM_PKG.func_get_err_msg('DCLD-00016',
                                                       v_request.locale));
        x_response := v_response.to_json;
        RETURN;
      END IF;
      SELECT COUNT(1)
        INTO v_count
        FROM dbpm_node_role_param_value dnrp
       WHERE dnrp.param_id = v_del_param.param_id;
      IF v_count > 0
      THEN
        ROLLBACK;
        --v_response.fail('该参数已经流程中使用！');
        v_response.fail(DCLD_COMM_PKG.func_get_err_msg('DCLD-00017',
                                                       v_request.locale));
        x_response := v_response.to_json;
        RETURN;
      END IF;
      DELETE FROM dbpm_role_params drp
       WHERE drp.status = 'N' AND drp.role_id = v_role_id;
    END LOOP;

    x_response := v_response.to_json;
    /* EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_save_role;

  /*==================================================
  Procedure/Function Name :
      proc_del_role
  Description:
      This function perform:
      保存审批角色，需要判断是新增还是修改
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-20  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_del_role(p_request IN CLOB, x_response OUT CLOB) IS
    v_api      VARCHAR2(30) := 'proc_del_role';
    v_request  json;
    v_response pl_json := pl_json;
    -- v_role_id   VARCHAR2(100);
    v_role_id   number; --海尔的表该列为number
    v_role_code VARCHAR2(100);
  BEGIN
    v_request   := json(p_request, 'OBJECT');
    v_role_code := v_request.get('roleCode').get_string;
    SELECT dr.role_id
      INTO v_role_id
      FROM dbpm_roles dr
     WHERE dr.role_code = v_role_code;
    DELETE FROM dbpm_roles dr WHERE dr.role_code = v_role_code;
    DELETE FROM dbpm_role_params drp WHERE drp.role_id = v_role_id;
    DELETE FROM dbpm_role_member_params drmp
     WHERE drmp.member_id IN
           (SELECT drm.member_id
              FROM dbpm_role_members drm
             WHERE drm.role_id = v_role_id);
    DELETE FROM dbpm_role_members drm WHERE drm.role_id = v_role_id;
    x_response := v_response.to_json;
    /* EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_del_role;

  /*==================================================
  Procedure/Function Name :
      proc_query_role_members
  Description:
      This function perform:
      查询角色成员列表
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-20  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_query_role_members(p_request IN CLOB, x_response OUT CLOB) IS
    v_request     json;
    v_response    pl_json := pl_json;
    v_member_json pl_json;
    v_param_json  pl_json;
    --  v_role_id           VARCHAR2(100);
    v_role_id           number; --海尔的表为number
    v_param_value       VARCHAR(4000);
    v_param_value_name  VARCHAR2(4000);
    v_total             NUMBER := 0;
    v_page              NUMBER := 1;
    v_size              NUMBER := 20;
    v_super_admin_count number;
    v_current_user      varchar2(30);

    v_search_condition   json;
    v_search_emp_code    varchar2(1000);
    v_search_emp_name    varchar2(1000);
    v_search_param_value varchar2(1000);
    v_space_id           varchar2(100);
    --排序参数
    v_sort_col varchar2(100);
    v_sort     json;

    CURSOR v_role_member_cur(p_role_id VARCHAR2) IS
      SELECT *
        FROM (SELECT tt.*, ROWNUM RN
                FROM (SELECT count(1) over(partition by 1) total,
                             drm.*,
                             fe.employee_name,
                             dr.role_code,
                             dr.role_name
                        FROM dbpm_role_members drm,
                             dbpm_roles        dr,
                             dfnd_employees    fe
                       WHERE drm.role_id = dr.role_id AND
                             upper(drm.member_code) = upper(fe.employee_code) AND
                             NVL(drm.space_id, 'NL') =
                             NVL(v_space_id, NVL(drm.space_id, 'NL')) AND
                             drm.role_id = p_role_id AND
                             INSTR(DRM.MEMBER_CODE,
                                   NVL(v_search_emp_code, DRM.MEMBER_CODE)) > 0 AND
                             INSTR(FE.EMPLOYEE_NAME,
                                   NVL(v_search_emp_name, FE.EMPLOYEE_NAME)) > 0 AND
                             EXISTS
                       (SELECT drmp.param_value, drmp.param_value_name
                                FROM dbpm_role_member_params drmp,
                                     dbpm_role_members       drp
                               WHERE drmp.member_id(+) = drp.member_id and
                                     (drp.member_id = drm.member_id) AND
                                     INSTR(NVL(DRMP.PARAM_VALUE_NAME, '1'),
                                           NVL(v_search_param_value,
                                               NVL(DRMP.PARAM_VALUE_NAME, '1'))) > 0)
                       ORDER BY decode(v_sort_col,
                                       'member_name_desc',
                                       fe.employee_name,
                                       'member_code_desc',
                                       drm.member_code) DESC,
                                decode(v_sort_col,
                                       'member_name_asc',
                                       fe.employee_name,
                                       'member_code_asc',
                                       drm.member_code) ASC,
                                drm.creation_date desc) tt
               WHERE ROWNUM <= (v_page * v_size))
       WHERE RN >= ((v_page - 1) * v_size) + 1;
    CURSOR v_role_param_cur(p_role_id VARCHAR2) IS
      SELECT *
        FROM dbpm_role_params drp
       WHERE drp.role_id = p_role_id
       ORDER BY drp.param_id;
  BEGIN
    v_request := json(p_request, 'OBJECT');
    v_role_id := v_request.get('roleId').get_string;
    v_response.set_value('roleId', v_role_id);
    v_current_user := v_request.username;

    --获取spaceId
    v_space_id := v_request.get_string('spaceId');
    if v_space_id is null
    then
      v_space_id := DFND_ADMIN_PKG.func_get_space_id(v_current_user);
    end if;
    --如果未找到company_id,设置company_id为-1
    --如果是超级管理员,设置company_id为null
    select count(1)
      into v_super_admin_count
      from dbpm_administrators t
     where t.user_code = v_current_user and t.admin_type = 'SuperAdmin';
    if v_super_admin_count > 0
    then
      v_space_id := null;
    end if;

    if v_request.exist('page')
    then
      v_page := v_request.get_number('page');
    end if;
    if v_request.exist('size')
    then
      v_size := v_request.get_number('size');
    end if;

    /* if v_request.exist('searchField') then
      v_search_condition   := json(v_request.get('searchField'));
      v_search_emp_code    := upper(v_search_condition.get_string('memberCode'));
      v_search_emp_name    := upper(v_search_condition.get_string('memberName'));
      v_search_param_value := v_search_condition.get_string('paramList');
    end if;*/
    v_search_emp_code    := upper(dcld_comm_pkg.get_filter_value('memberCode',
                                                                 v_request));
    v_search_emp_name    := upper(dcld_comm_pkg.get_filter_value('memberName',
                                                                 v_request));
    v_search_param_value := dcld_comm_pkg.get_filter_value('paramList',
                                                           v_request);
    if v_request.exist('sort')
    then
      v_sort     := json(v_request.get('sort'));
      v_sort_col := v_sort.get_string('value');
      v_sort_col := v_sort_col || '_' || v_sort.get_string('order');
    end if;

    FOR v_member IN v_role_member_cur(v_role_id)
    LOOP
      v_total       := v_member.total;
      v_member_json := pl_json;
      v_member_json.set_value('roleId', v_role_id);
      v_member_json.set_value('roleCode', v_member.role_code);
      v_member_json.set_value('roleName', v_member.role_name);
      v_member_json.set_value('memberId', v_member.member_id);
      v_member_json.set_value('memberType', v_member.member_type);
      v_member_json.set_value('memberTypeName', '人员');
      v_member_json.set_value('memberCode', v_member.member_code);
      v_member_json.set_value('memberName', v_member.employee_name);
      FOR v_param IN v_role_param_cur(v_role_id)
      LOOP
        v_param_json := pl_json;
        BEGIN
          SELECT drmp.param_value, drmp.param_value_name
            INTO v_param_value, v_param_value_name
            FROM dbpm_role_member_params drmp
           WHERE drmp.param_id = v_param.param_id AND
                 drmp.member_id = v_member.member_id;
        EXCEPTION
          WHEN OTHERS THEN
            v_param_value      := '';
            v_param_value_name := '';
        END;
        v_param_json.set_value('paramId', v_param.param_id);
        v_param_json.set_value('paramName', v_param.param_name);
        v_param_json.set_value('dataSourceCode', v_param.data_source_code);
        v_param_json.set_value('paramValue', v_param_value);
        v_param_json.set_value('paramValueName', v_param_value_name);
        v_member_json.add_list_item('paramList', v_param_json);
      END LOOP;
      v_response.add_list_item('memberList', v_member_json);
    END LOOP;

    v_response.set_value('total', v_total);
    x_response := v_response.to_json;
  END proc_query_role_members;

  /*==================================================
  Procedure/Function Name :
      proc_save_role_member
  Description:
      This function perform:
      保存角色成员列表，需要判断是新增还是修改
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-20  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_save_role_member(p_request IN CLOB, x_response OUT CLOB) IS
    v_api              VARCHAR2(100) := 'proc_save_role_member';
    v_request          json;
    v_response         pl_json := pl_json;
    v_param_list       json_list;
    v_param            json;
    v_param_value_name VARCHAR2(4000);
    v_current_user     VARCHAR2(50);
    v_member_id        NUMBER;
    v_count            NUMBER := 0;
    v_space_id         varchar2(100);
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;

    v_space_id := v_request.get_string('spaceId');
    if v_space_id is null
    then
      v_space_id := DFND_ADMIN_PKG.func_get_space_id(v_current_user);
    end if;

    IF v_request.get('memberId') IS NULL
    THEN
      v_member_id := dbpm_role_members_s.nextval;
      v_count     := 0;
    ELSE
      v_member_id := v_request.get('memberId').get_number;
      v_count     := 1;
    END IF;

    /*    if v_request.get_string('memberCode') is null then
      v_response.fail('员工号为必填项,请输入');
      x_response := v_response.to_json;
      return ;
    end if;*/
    IF v_count = 0
    THEN
      INSERT INTO dbpm_role_members
        (member_id,
         role_id,
         member_code,
         member_type,
         status,
         created_by,
         last_updated_by,
         space_id)
      VALUES
        (v_member_id,
         v_request.get('roleId').get_number,
         v_request.get('memberCode').get_string,
         'User',
         'Y',
         v_current_user,
         v_current_user,
         v_space_id);
    ELSE
      UPDATE dbpm_role_members drm
         SET drm.member_code           = v_request.get('memberCode')
                                         .get_string,
             drm.last_updated_by       = v_current_user,
             drm.object_version_number = drm.object_version_number + 1
       WHERE drm.member_id = v_member_id;
    END IF;

    DELETE FROM dbpm_role_member_params drmp
     WHERE drmp.member_id = v_member_id;

    IF v_request.get('paramList') IS NOT NULL
    THEN
      v_param_list := json_list(v_request.get('paramList'));
      FOR i IN 1 .. v_param_list.count
      LOOP
        v_param := json(v_param_list.get(i));
        IF v_param.get('paramValue') IS NOT NULL AND v_param.get('paramValue')
          .get_string IS NOT NULL
        THEN
          IF v_param.get('paramValueName') IS NOT NULL AND v_param.get('paramValueName')
            .get_string IS NOT NULL
          THEN
            v_param_value_name := v_param.get('paramValueName').get_string;
          ELSE
            v_param_value_name := v_param.get('paramValue').get_string;
          END IF;
          INSERT INTO dbpm_role_member_params
            (member_id,
             param_id,
             param_value,
             param_value_name,
             created_by,
             last_updated_by)
          VALUES
            (v_member_id,
             v_param.get('paramId').get_number,
             v_param.get('paramValue').get_string,
             v_param_value_name,
             v_current_user,
             v_current_user);
        END IF;
      END LOOP;
    END IF;
    x_response := v_response.to_json;

    /*EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_save_role_member;

  /*==================================================
  Procedure/Function Name :
      proc_del_role_members
  Description:
      This function perform:
      删除角色成员
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-20  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_del_role_members(p_request IN CLOB, x_response OUT CLOB) IS
    v_api       VARCHAR2(30) := 'proc_del_role_members';
    v_request   json;
    v_response  pl_json := pl_json;
    v_member_id NUMBER;
  BEGIN
    v_request   := json(p_request, 'OBJECT');
    v_member_id := v_request.get('memberId').get_number;
    DELETE FROM dbpm_role_member_params drmp
     WHERE drmp.member_id = v_member_id;
    DELETE FROM dbpm_role_members drm WHERE drm.member_id = v_member_id;
    x_response := v_response.to_json;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;
  END proc_del_role_members;
END dbpm_role_api_pkg;

/

