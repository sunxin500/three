create view DBPM_TASK_TODO_QUERY_V as
SELECT todo.taskid task_id,
       nvl(todo.document_id, dd.document_id) document_id,
       (select dd.form_id
          from dbpm_documents dd
         where dd.document_id = todo.document_id) form_id,
       nvl(dd.doc_number, 'INSTANCE-' || todo.instanceid) task_number,
       todo.title,
       'PROCESSING' status,
       todo.state,
       todo.createddate creation_date,
       todo.assigneddate assigne_date,
       todo.creator created_user_code,
       (select fe1.employee_name
          from dfnd_employees fe1
         where fe1.employee_code = todo.creator) created_user_name,
       todo.assignee assigness_user_code,
       (select fe1.employee_name
          from dfnd_employees fe1
         where fe1.employee_code = todo.assignee) assignee_name,
       todo.node_name,
       todo.node_id,
       todo.instanceid instance_id,
       todo.compositecreatedtime process_create_time,
       todo.REGISTER_PROCESS_CODE,
       dbpm_comm_pkg.func_get_task_url(p_domain_url  => todo.cux_form_url,
                                             p_instance_id => todo.instanceid,
                                             p_form_key    => todo.cux_form_key,
                                             p_task_id     => todo.taskid,
                                             p_params      => todo.cux_params,
                                             p_sys_code    => '') url,
       '' mobile_url,
       'N' is_readed,
       dd.process_id,
       dd.process_name,
       dd.process_code,
       nvl(dd.process_type,'-') process_type,
       dd.process_class,
       nvl(dd.todo_flag,'BOTH') todo_flag
  FROM dbpm_obpm_todo_v todo,
       (select form_id,
               document_id,
               doc_number,
               bpm_instance_id,
               dp.process_id,
               dpt.process_name,
               dp.process_code,
               dp.process_type,
               dp.process_class,
               dp.todo_flag
          from dbpm_documents d, dbpm_process dp, dbpm_process_tl dpt
         where dp.process_id = dpt.process_id
           AND dpt.locale = dbpm_comm_pkg.get_current_locale
           and d.process_id = dp.process_id(+)) dd
 WHERE todo.instanceid = dd.bpm_instance_id(+)
union all
SELECT t.df_task_id task_id,
       null              document_id,
       null              form_id,
       t.document_number task_number,
       t.title,
       'PROCESSING' status,
       t.state,
       t.createddate creation_date,
       t.assigneddate assigne_date,
       t.creator created_user_code,
       fe1.employee_name assignee_name,
       t.assignee assigness_user_code,
       fe2.employee_name created_user_name,
       null node_name,
       null node_id,
       t.document_number instance_id,
       systimestamp process_create_time,
       null REGISTER_PROCESS_CODE,
       t.url,
       t.mobile_url,
       'N' is_readed,
       t.process_id,
       t.process_name,
       null process_code,
       '第三方流程' process_type,
       'OTHERS' process_class,
       NVL(T.TODO_FLAG, 'BOTH') TODO_FLAG
  FROM cux_process_todo t, dfnd_employees fe1, dfnd_employees fe2
 WHERE t.assignee = fe1.employee_code
   and t.creator = fe2.employee_code
   and t.state = 'PROCESSING'
    
/

