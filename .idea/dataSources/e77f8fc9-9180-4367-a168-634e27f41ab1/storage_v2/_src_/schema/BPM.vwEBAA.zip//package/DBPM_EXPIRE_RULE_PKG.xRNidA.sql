create package     dbpm_expire_rule_pkg is

  -- author  : yaoshallwe
  -- created : 2019/5/17 12:04:34
  -- purpose : 超期预警功能

  /*
    获得需要执行预警的实例
  */
  procedure get_instances_for_warning(p_remark in varchar2);
  /*
    获得需要执行预警的任务号
  */
  procedure get_tasks_for_warning(p_remark in varchar2);
  /*
    同步预警任务
  */
  procedure sync_tasks_ins_for_warning;
  /*
  * 获取比较结果
  */
  function func_get_compare_result(p_data_type varchar2,
                                   p_operation varchar2,
                                   p_from_data varchar2,
                                   p_to_data   varchar2) return varchar2;
  /*
   获得单一预警邮件内容
  */
  procedure get_warning_single_email_def(p_instanceid       in varchar2,
                                         p_taskid           in varchar2,
                                         p_email_type       in varchar2,
                                         x_email_title      out varchar2,
                                         x_email_content    out varchar2,
                                         x_email_recipients out varchar2);
  /*
   获得批量预警邮件内容
  */
  procedure get_warning_batch_email_def(p_email_type in varchar2,
                                       x_remark     out varchar2,
                                        x_emails     out dbpm_email_tbl);

  /*
  * 获取动态参数值
  */
  FUNCTION func_get_process_param_value(p_business_param     dbpm_business_param_tbl,
                                        p_process_param_code VARCHAR2)
    RETURN VARCHAR2;
  /*
  * 更新上一批次任务状态，生成下一批次标志
  */
  procedure update_execute_log_status(p_remark in varchar2,
                                      p_waring_type in varchar2,
                                      p_instanceid in varchar2,
                                      x_remark out varchar2);

  /***************************************************************************************
  * * * * * * *  根据当前时间生成一个时间标志供批量维护状态使用以提升性能* * * * * * * * * * * * * *
  ***************************************************************************************/
  function get_batch_data_time_mark return varchar2;

   /*
  * 获得当前的remark
  */
  procedure get_cur_remark(x_remark out VARCHAR2);

end dbpm_expire_rule_pkg;

/

