create PACKAGE BODY     cux_dfnd_template_pkg IS

  PROCEDURE generate_template_post_data(p_document_id   IN NUMBER,
                                        p_template_code IN VARCHAR2,
                                        x_out_flag      OUT VARCHAR2,
                                        x_out_json      OUT CLOB) IS
    v_form_id NUMBER;
    TYPE v_table_lines_ref_cur IS REF CURSOR;
    --头信息cursor
    CURSOR v_template_detail_cur(p_template_code IN VARCHAR2) IS
      SELECT DISTINCT t.for_table,
                      t.ref_code,
                      t.mapping_filed,
                      t.ref_mapping_table_code,
                      dff.type
        FROM template_detail t,
             dbpm_form_field dff
       WHERE dff.id(+) = t.mapping_filed
         AND t.temp_field = p_template_code
            --and t.mapping_filed is not null         (2018-01-01 xueyou.xu)
         AND t.for_table = 'N';

    /*
    cursor v_template_detail_cur (p_template_code in varchar2) is
    select t.for_table,
           t.ref_code,
           t.mapping_filed,
           t.ref_mapping_table_code
    from  template_detail t
    where t.temp_field=p_template_code
      --and t.mapping_filed is not null         (2018-01-01 xueyou.xu)
      and t.for_table ='N';
    */
    -- 所有行表的cursor
    CURSOR v_template_tables_cur(p_template_code IN VARCHAR2) IS
      SELECT DISTINCT t.ref_mapping_table_code,
                      t.ref_table_code
        FROM template_detail t
       WHERE t.temp_field = p_template_code;
    -- 所有行表的详细信息cursor
    CURSOR v_template_line_detail_cur(p_template_code IN VARCHAR2,
                                      p_table_code    IN VARCHAR2) IS
      SELECT t.mapping_filed,
             t.ref_code
        FROM template_detail t
       WHERE t.for_table = 'Y'
         AND t.temp_field = p_template_code
         AND t.ref_mapping_table_code = p_table_code
         AND t.ref_mapping_table_code != 'auto-history'
         AND t.mapping_filed IS NOT NULL;
    --单个行表的各行主键信息
    CURSOR v_document_lines_cur(p_document_id IN NUMBER,
                                p_table_id    IN VARCHAR2) IS
      SELECT ddl.line_id
        FROM dbpm_document_lines ddl
       WHERE ddl.document_id = p_document_id
         AND ddl.table_id = p_table_id;
    --审批历史记录数据
    CURSOR v_history_cursor(p_document_id NUMBER) IS
      SELECT *
        FROM dbpm_approval_history t
       WHERE t.document_id = p_document_id
       ORDER BY t.creation_date;
    --审批历史绑定 code
    v_history_code VARCHAR2(100) := 'history';

    v_exe_sql                   VARCHAR2(4000);
    v_column_name               VARCHAR2(100);
    v_table_name                varchar2(100);
    v_column_value              VARCHAR2(4000);
    v_template_checkbox         VARCHAR2(2000);
    v_template_radio            VARCHAR2(2000);
    v_response                  pl_json := pl_json;
    v_data                      pl_json := pl_json;
    v_table_line                pl_json := pl_json;
    v_checkbox                  pl_json := pl_json;
    v_radio                     pl_json := pl_json;
    v_column_type               VARCHAR2(100);
    v_data_source_text          VARCHAR2(100);
    v_data_source_code          VARCHAR2(100);
    v_data_source_display_value VARCHAR2(1000);
    v_display_item              VARCHAR2(400);
    v_history_count             NUMBER := 0;
  BEGIN
    x_out_flag := 'Y';
    v_table_name := 'dbpm_documents';
    v_response.set_value('tempCode', p_template_code);
    FOR v_tempalte_detail IN v_template_detail_cur(p_template_code)
    LOOP

      IF v_tempalte_detail.mapping_filed IS NOT NULL THEN
        IF v_tempalte_detail.type = 'checkbox-input' OR v_tempalte_detail.type = 'radio-input' THEN
          SELECT dff.type
            INTO v_column_type
            FROM dbpm_form_field dff,
                 dbpm_documents  dd
           WHERE dff.id = v_tempalte_detail.mapping_filed
             AND dd.form_id = dff.form_id
             AND dd.document_id = p_document_id;
          IF v_column_type = 'applicant-readonly' THEN
            v_column_name := 'doc_creator';
          ELSIF v_column_type = 'document-number-readonly' THEN
            v_column_name := 'doc_number';
          ELSIF v_column_type = 'usercode-readonly' THEN
            v_column_name := 'doc_creator';
          ELSIF v_column_type = 'department-readonly' THEN
            NULL;
          ELSIF v_column_type = 'apply-date-readonly' THEN
            v_column_name := 'to_char(doc_create_time,''yyyy-MM-dd'')';
          ELSE
            SELECT dffm.attr_name, dffm.table_name
              INTO v_column_name,
              v_table_name
              FROM dbpm_documents          dd,
                   dbpm_form_field_mapping dffm
             WHERE dd.document_id = p_document_id
               AND dd.form_id = dffm.form_id
               AND dffm.id = v_tempalte_detail.mapping_filed;
          END IF;
          v_exe_sql := 'select ' || v_column_name || ' from ' || v_table_name || ' t where t.document_id=' || p_document_id;
          IF v_column_type = 'department-readonly' THEN
            v_exe_sql := 'select t.organization_name from dbpm_documents dd,dfnd_organizations t
                    where t.organization_id(+)=dd.organization_id
                      and  dd.document_id=' || p_document_id;
          END IF;
          EXECUTE IMMEDIATE v_exe_sql
            INTO v_column_value;

          SELECT dff.data_source_text,
                 dff.data_source_code
            INTO v_data_source_text,
                 v_data_source_code
            FROM dbpm_form_field dff,
                 templates       tep
           WHERE dff.id = v_tempalte_detail.mapping_filed
             AND dff.form_id = tep.form_id
             AND tep.template_code = p_template_code;

          --begin 获取数据源的displayValue
          v_data_source_display_value := dbpm_data_source_api_pkg.func_get_all_data_source_value(p_data_source_code => v_data_source_code);
          IF v_data_source_display_value IS NOT NULL THEN
            v_data_source_text := v_data_source_text || ',' || v_data_source_display_value;
          END IF;
          --end
          IF v_tempalte_detail.type = 'checkbox-input' THEN
            v_checkbox := pl_json;
            v_checkbox.set_value('value', v_column_value);
            v_checkbox.set_value('displayValue', v_data_source_text);
            v_checkbox.set_value('type', 'checkbox');
            v_data.set_value(TRIM(v_tempalte_detail.ref_code), v_checkbox);
          ELSE
            v_radio := pl_json;
            v_radio.set_value('value', v_column_value);
            v_radio.set_value('displayValue', v_data_source_text);
            v_radio.set_value('type', 'radio');
            v_data.set_value(TRIM(v_tempalte_detail.ref_code), v_radio);
          END IF;

          IF v_column_value IS NULL THEN
            v_column_value := '  ';
          END IF;

        ELSE
          IF (v_tempalte_detail.mapping_filed)= ' ' THEN
            v_column_value:='  ';
            --v_data.set_value(TRIM(v_tempalte_detail.ref_code), '   ');
          ELSE
          SELECT dff.type
            INTO v_column_type
            FROM dbpm_form_field dff,
                 dbpm_documents  dd
           WHERE dff.id = v_tempalte_detail.mapping_filed
             AND dd.form_id = dff.form_id
             AND dd.document_id = p_document_id;
          IF v_column_type = 'applicant-readonly' THEN
            v_column_name := 'doc_creator';
          ELSIF v_column_type = 'document-number-readonly' THEN
            v_column_name := 'doc_number';
          ELSIF v_column_type = 'usercode-readonly' THEN
            v_column_name := 'doc_creator';
          ELSIF v_column_type = 'department-readonly' THEN
            NULL;
          ELSIF v_column_type = 'apply-date-readonly' THEN
            v_column_name := 'to_char(doc_create_time,''yyyy-MM-dd'')';
          ELSE
            SELECT dffm.attr_name,
               dffm.table_name
              INTO v_column_name,
                   v_table_name
              FROM dbpm_documents          dd,
                   dbpm_form_field_mapping dffm
             WHERE dd.document_id = p_document_id
               AND dd.form_id = dffm.form_id
               AND dffm.id = v_tempalte_detail.mapping_filed;
          END IF;
          v_exe_sql := 'select ' || v_column_name || ' from ' || v_table_name || ' t where t.document_id=' || p_document_id;
          IF v_column_type = 'department-readonly' THEN
            v_exe_sql := 'select t.organization_name from dbpm_documents dd,dfnd_organizations t
                    where t.organization_id(+)=dd.organization_id
                      and  dd.document_id=' || p_document_id;
          END IF;
          EXECUTE IMMEDIATE v_exe_sql
            INTO v_column_value;
          IF v_column_value IS NULL THEN
            v_column_value := '  ';
          END IF;

          END IF ;
          v_data.set_value(TRIM(v_tempalte_detail.ref_code), v_column_value);
        END IF;


      ELSE
        v_column_value := '  ';
      END IF;

    END LOOP;
    --遍历所有的关联行表
    FOR v_template_table IN v_template_tables_cur(p_template_code)
    LOOP
      --遍历所有的行数据
      FOR v_doc_line IN v_document_lines_cur(p_document_id, v_template_table.ref_mapping_table_code)
      LOOP
        v_table_line := pl_json;
        --遍历行上对应的字段名称
        FOR v_table_lines IN v_template_line_detail_cur(p_template_code, v_template_table.ref_mapping_table_code)
        LOOP

          SELECT dffm.attr_name
            INTO v_column_name
            FROM dbpm_documents          dd,
                 dbpm_form_field_mapping dffm
           WHERE dd.document_id = p_document_id
             AND dd.form_id = dffm.form_id
             AND dffm.id = v_table_lines.mapping_filed;
          v_exe_sql := 'select ' || v_column_name || ' from dbpm_document_lines t where t.line_id=' ||
                       v_doc_line.line_id;
          EXECUTE IMMEDIATE v_exe_sql
            INTO v_column_value;
          IF v_column_value IS NULL THEN
            v_column_value := '  ';
          END IF;
          v_table_line.set_value(TRIM(v_table_lines.ref_code), v_column_value);
        END LOOP;
        v_data.add_list_item(TRIM(v_template_table.ref_table_code) || 's', v_table_line);
      END LOOP;
    END LOOP;

    --获取审批历史记录

    SELECT COUNT(1)
      INTO v_history_count
      FROM dbpm_approval_history t
     WHERE t.document_id = p_document_id;
    IF v_history_count = 0 THEN
      v_table_line := pl_json;
      FOR v_history_config IN (SELECT t.mapping_filed,
                                      t.ref_code,
                                      t.ref_table_code
                                 FROM template_detail t
                                WHERE t.for_table = 'Y'
                                  AND t.temp_field = p_template_code
                                  --AND t.ref_mapping_table_code = 'auto-history'
                                  )
      LOOP
        v_history_code := v_history_config.ref_table_code;
        IF v_history_config.mapping_filed = 'auto-histroy-node' THEN
          v_table_line.set_value(v_history_config.ref_code, '  ');
        ELSIF v_history_config.mapping_filed = 'auto-histroy-approver' THEN
          v_table_line.set_value(v_history_config.ref_code, '  ');
        ELSIF v_history_config.mapping_filed = 'auto-histroy-date' THEN
          v_table_line.set_value(v_history_config.ref_code, '  ');
        ELSIF v_history_config.mapping_filed = 'auto-histroy-comment' THEN
          v_table_line.set_value(v_history_config.ref_code, '  ');
        ELSIF v_history_config.mapping_filed = 'auto-histroy-operation' THEN
          v_table_line.set_value(v_history_config.ref_code, '  ');
        END IF;
      END LOOP;
      v_data.add_list_item(TRIM(v_history_code) || 's', v_table_line);
    END IF;
    FOR v_history IN v_history_cursor(p_document_id)
    LOOP
      v_table_line := pl_json;
      FOR v_history_config IN (SELECT t.mapping_filed,
                                      t.ref_code,
                                      t.ref_table_code
                                 FROM template_detail t
                                WHERE t.for_table = 'Y'
                                  AND t.temp_field = p_template_code
                                  --AND t.ref_mapping_table_code = 'auto-history'
                                  )
      LOOP
        v_history_code := v_history_config.ref_table_code;
        IF v_history_config.mapping_filed = 'auto-histroy-node' THEN
          v_table_line.set_value(v_history_config.ref_code, v_history.node_name);
        ELSIF v_history_config.mapping_filed = 'auto-histroy-approver' THEN
          v_table_line.set_value(v_history_config.ref_code, v_history.approver_name || v_history.approver_code);
        ELSIF v_history_config.mapping_filed = 'auto-histroy-date' THEN
          v_table_line.set_value(v_history_config.ref_code, to_char(v_history.creation_date, 'yyyy-MM-dd'));
        ELSIF v_history_config.mapping_filed = 'auto-histroy-comment' THEN
          v_table_line.set_value(v_history_config.ref_code, v_history.comment_detail);
        ELSIF v_history_config.mapping_filed = 'auto-histroy-operation' THEN
          IF v_history.operation = 'APPROVE' THEN
            v_table_line.set_value(v_history_config.ref_code, '审批通过');
          ELSIF v_history.operation = 'REJECT' THEN
            v_table_line.set_value(v_history_config.ref_code, '审批拒绝');
          END IF;

        END IF;

      END LOOP;
      v_data.add_list_item(TRIM(v_history_code) || 's', v_table_line);

    END LOOP;
    v_response.set_value('data', v_data);
    x_out_json := v_response.to_json;
    /*exception
    when others then
      x_out_flag := 'N';
      */
  END;
  /*

  获取所有的表单配置信息（包括审批历史）

  */
  PROCEDURE proc_query_form_field_config(p_request  IN CLOB,
                                         x_response OUT CLOB) IS
    v_request              json;
    v_response             pl_json := pl_json;
    v_field_json           pl_json;
    v_table_config         pl_json;
    v_table_config_p       pl_json;
    v_table_field_config   pl_json;
    v_form_id              NUMBER;
    v_history_config       pl_json;
    v_history_field_config pl_json;
    v_history_table        pl_json;
    CURSOR v_form_field_cur(p_form_id NUMBER) IS
      SELECT *
        FROM dbpm_form_field dff
       WHERE dff.form_id = p_form_id
         AND dff.parent_id IS NULL;
    CURSOR v_form_table_field_cur(p_table_id VARCHAR2,
                                  p_form_id  NUMBER) IS
      SELECT dff.*
        FROM dbpm_form_field dff
       WHERE dff.form_id = p_form_id
         AND dff.parent_id = p_table_id
       ORDER BY dff.order_seq;
  BEGIN
    v_request := json(p_request, 'OBJECT');
    v_form_id := v_request.get('formId').get_number;
    v_response.set_value('formId', v_form_id);
    FOR v_field IN v_form_field_cur(v_form_id)
    LOOP
      v_field_json := pl_json;
      v_field_json.set_value('id', v_field.id);
      v_field_json.set_value('label', v_field.label);
      IF v_field.type = 'table-input' THEN
        v_table_config   := pl_json;
        v_table_config_p := pl_json;
        FOR v_table_field IN v_form_table_field_cur(v_field.id, v_form_id)
        LOOP
          v_table_field_config := pl_json;
          v_table_field_config.set_value('id', v_table_field.id);
          v_table_field_config.set_value('label', v_table_field.label);
          v_table_config.add_list_item('columnConfigs', v_table_field_config);
        END LOOP;
        --v_table_config_p.set_value('tableConfig',v_table_config);
        v_field_json.set_value('tableConfig', v_table_config);
      END IF;
      v_response.add_list_item('fieldList', v_field_json);
    END LOOP;
    v_history_config       := pl_json;
    v_history_field_config := pl_json;
    v_history_table        := pl_json;
    v_history_field_config.set_value('id', 'auto-histroy-node');
    v_history_field_config.set_value('label', '审批节点');
    v_history_config.add_list_item('columnConfigs', v_history_field_config);
    v_history_field_config := pl_json;
    v_history_field_config.set_value('id', 'auto-histroy-approver');
    v_history_field_config.set_value('label', '审批人');
    v_history_config.add_list_item('columnConfigs', v_history_field_config);
    v_history_field_config := pl_json;
    v_history_field_config.set_value('id', 'auto-histroy-date');
    v_history_field_config.set_value('label', '审批时间');
    v_history_config.add_list_item('columnConfigs', v_history_field_config);
    v_history_field_config := pl_json;
    v_history_field_config.set_value('id', 'auto-histroy-comment');
    v_history_field_config.set_value('label', '审批意见');
    v_history_config.add_list_item('columnConfigs', v_history_field_config);
    v_history_field_config := pl_json;
    v_history_field_config.set_value('id', 'auto-histroy-operation');
    v_history_field_config.set_value('label', '审批操作');
    v_history_config.add_list_item('columnConfigs', v_history_field_config);

    v_history_table.set_value('id', 'auto-history');
    v_history_table.set_value('label', '默认审批历史');
    v_history_table.set_value('tableConfig', v_history_config);
    v_response.add_list_item('fieldList', v_history_table);
    x_response := v_response.to_json;
  END;

  /*

  获取模板详细

  */

  PROCEDURE query_template_detail(p_request  IN CLOB,
                                  x_response OUT CLOB) IS
    v_request            json;
    v_response           pl_json := pl_json;
    v_template_code      VARCHAR2(600);
    v_data               pl_json := pl_json;
    v_template_detail    pl_json := pl_json;
    v_template_general   pl_json := pl_json;
    v_template_table     pl_json := pl_json;
    v_temp_general       pl_json := pl_json;
    v_temp_table         pl_json := pl_json;
    temp_list            pl_json := pl_json;
    template_list_normal pl_json := pl_json;
    template_list_table  pl_json := pl_json;

    v_temp_id            NUMBER;
    v_temp_template_code VARCHAR2(600);
    v_temp_template_name VARCHAR2(600);
    v_temp_rotate        VARCHAR2(4);
    v_temp_form_id       VARCHAR2(100);
    v_temp_form_name     VARCHAR2(200);
    v_ref_table_code     VARCHAR2(100);
    v_mapping_table_code VARCHAR2(100);

    CURSOR v_template_detail_table_cur(v_template_code VARCHAR2) IS
      SELECT td.id,
             td.ref_code,
             td.temp_field,
             td.mapping_filed,
             td.for_table,
             td.ref_table_code,
             td.deleted,
             td.ref_mapping_table_code
        FROM template_detail td
       WHERE td.for_table = 'Y'
         AND td.temp_field = v_template_code;
    CURSOR v_template_detail_normal_cur(v_template_code VARCHAR2) IS
      SELECT td.id,
             td.ref_code,
             td.temp_field,
             td.mapping_filed,
             td.for_table,
             td.ref_table_code,
             td.deleted,
             td.ref_mapping_table_code
        FROM template_detail td
       WHERE td.for_table = 'N'
         AND td.temp_field = v_template_code;

  BEGIN
    v_temp_template_name := ' ';
    --测试数据
    --v_request := json('{"tempCode":"8b606f09-10a0-45a0-a9f3-34e3622ffdfb"}');
    -- 获取参数

    v_request := json(p_request, 'OBJECT');

    v_template_code := v_request.get_string('tempCode');

    SELECT temp.id,
           temp.template_code,
           --temp.template_name,
           temp.is_rotate,
           temp.form_id
      INTO v_temp_id,
           v_temp_template_code,
           --v_temp_template_name,
           v_temp_rotate,
           v_temp_form_id

      FROM templates temp
     WHERE temp.template_code = v_template_code;

    --查询模板对应表单名称
    IF v_temp_form_id IS NOT NULL THEN
      SELECT form.form_name
        INTO v_temp_template_name
        FROM dbpm_form form
       WHERE form.form_id = v_temp_form_id;
    END IF;

    v_data.set_value('id', v_temp_id);
    v_data.set_value('templateCode', v_temp_template_code);
    v_data.set_value('isRotate', nvl(v_temp_rotate, 'N'));
    v_data.set_value('templateName', nvl(v_temp_template_name, 'null'));
    v_data.set_value('formId', nvl(v_temp_form_id, 'null'));
    --v_data.set_value('formName', nvl(v_temp_template_name, 'null'));
    v_temp_general       := pl_json;
    v_temp_table         := pl_json;
    temp_list            := pl_json;
    template_list_normal := pl_json;
    template_list_table  := pl_json;
    temp_list.set_data_type('ARRAY');

    template_list_normal.set_data_type('ARRAY');
    FOR temp_detail IN v_template_detail_normal_cur(v_template_code)
    LOOP
      v_template_general := pl_json;
      v_template_general.set_value('id', temp_detail.id);
      v_template_general.set_value('deleted', nvl(temp_detail.deleted, 0));
      v_template_general.set_value('forTable', nvl(temp_detail.for_table, 'null'));
      v_template_general.set_value('mappingFiled', nvl(temp_detail.mapping_filed, 'null'));
      v_template_general.set_value('refCode', nvl(temp_detail.ref_code, 'null'));
      v_template_general.set_value('refTableCode', nvl(temp_detail.ref_table_code, 'null'));
      v_template_general.set_value('tempField', nvl(temp_detail.temp_field, 'null'));
      v_template_general.set_value('refMappingTableCode', nvl(temp_detail.ref_mapping_table_code, 'null'));
      v_mapping_table_code := temp_detail.ref_mapping_table_code;
      template_list_normal.add_list_item(v_template_general);
    END LOOP;
    v_temp_general.set_value('title', '表单字段');
    v_temp_general.set_value('templateList', template_list_normal);
    v_temp_general.set_value('mappingTableCode', nvl(v_mapping_table_code, 'null'));
    v_temp_general.set_value('isTable', FALSE);
    temp_list.add_list_item(v_temp_general);
    template_list_table.set_data_type('ARRAY');
    FOR temp_detail_table IN v_template_detail_table_cur(v_template_code)
    LOOP
      v_template_table := pl_json;
      v_template_table.set_value('id', temp_detail_table.id);
      v_template_table.set_value('deleted', nvl(temp_detail_table.deleted, 0));
      v_template_table.set_value('forTable', nvl(temp_detail_table.for_table, 'null'));
      v_template_table.set_value('mappingFiled', nvl(temp_detail_table.mapping_filed, 'null'));
      v_template_table.set_value('refCode', nvl(temp_detail_table.ref_code, 'null'));
      v_template_table.set_value('refTableCode', nvl(temp_detail_table.ref_table_code, 'null'));
      v_template_table.set_value('tempField', nvl(temp_detail_table.temp_field, 'null'));
      v_template_table.set_value('refMappingTableCode', nvl(temp_detail_table.ref_mapping_table_code, 'null'));
      v_ref_table_code     := temp_detail_table.ref_table_code;
      v_mapping_table_code := temp_detail_table.ref_mapping_table_code;
      template_list_table.add_list_item(v_template_table);
    END LOOP;
    v_temp_table.set_value('title', nvl(v_ref_table_code, 'null'));
    v_temp_table.set_value('templateList', template_list_table);
    v_temp_table.set_value('mappingTableCode', nvl(v_mapping_table_code, 'null'));
    v_temp_table.set_value('isTable', TRUE);

    temp_list.add_list_item(v_temp_table);
    v_response.set_value('code', 'SUCCESS');
    v_response.set_value('msg', '模板详细获取成功');
    v_data.set_value('tempList', temp_list);
    v_response.set_value('data', v_data);
    x_response := v_response.to_data_json;

  EXCEPTION

    WHEN OTHERS THEN
      v_response.set_value('code', 'ERROR');
      v_response.set_value('msg', '模板详细查询异常');
      x_response := v_response.to_data_json;

  END;

  /*==================================================
  Procedure/Function Name :
      proc_get_template_list
  Description:
      This function perform:
      获取模板列表
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-02-28  xueyou.xu  Creation
  ==================================================*/
  PROCEDURE proc_get_template_list(p_request  IN CLOB,
                                   x_response OUT CLOB) IS
    v_request       json;
    v_response      pl_json := pl_json;
    v_data          pl_json := pl_json;
    v_template_item pl_json;
    --查询参数
    --v_search_fields json;
    v_total    NUMBER := 0;
    v_size     NUMBER := 10;
    v_page     NUMBER := 1;
    v_space_id VARCHAR2(100);

    v_filter        json;
    v_template_name VARCHAR2(600);
    v_form_name     VARCHAR2(600);

    --排序参数
    v_sort_col VARCHAR2(100);
    v_sort     json;
    CURSOR v_template_cursor IS
      SELECT *
        FROM (SELECT v.*,
                     rownum cnt
                FROM (SELECT COUNT(1) over(PARTITION BY 1) total,
                             temp.id,
                             temp.template_name,
                             form.form_name,
                             concat(concat('v_', nvl(form.version, '1')), '.0') AS version,
                             temp.form_id,
                             temp.is_rotate,
                             temp.template_code
                        FROM BPM.templates temp,
                             BPM.dbpm_form form
                       WHERE temp.form_id = form.form_id(+)
                         AND temp.deleted = 0
                         AND temp.space_id = v_space_id
                         AND instr(nvl(temp.template_name, 'NL'), nvl(v_template_name, nvl(temp.template_name, 'NL'))) > 0
                         AND instr(nvl(form.form_name, 'NL'), nvl(v_form_name, nvl(form.form_name, 'NL'))) > 0
                       ORDER BY decode(v_sort_col,
                                       'template_name_desc',
                                       temp.template_name,
                                       'form_name_desc',
                                       form.form_name) DESC,
                                decode(v_sort_col,
                                       'template_name_asc',
                                       temp.template_name,
                                       'form_name_asc',
                                       form.form_name) ASC,
                                form.version) v
               WHERE rownum <= v_page * v_size)
       WHERE cnt > (v_page - 1) * v_size;
  BEGIN
    --测试数据
    --v_request := json('{"page":1,"size":10,"spaceId":"10026"}');
    -- 获取参数

    v_request := json(p_request, 'OBJECT');

    --v_current_user := v_request.username;

    IF v_request.exist('page') THEN
      v_page := v_request.get_number('page');
    END IF;
    IF v_request.exist('spaceId') THEN
      v_space_id := v_request.get_string('spaceId');
    END IF;
    IF v_request.exist('size') THEN
      v_size := v_request.get_number('size');
    END IF;
    IF v_request.exist('sort') THEN
      v_sort     := json(v_request.get('sort'));
      v_sort_col := v_sort.get_string('value');
      v_sort_col := v_sort_col || '_' || v_sort.get_string('order');
    END IF;
    /*    if v_request.exist('filter') then
      v_filter        := json(v_request.get('filter'));
      v_template_name := v_filter.get_string('templateName');
      v_form_name     := v_filter.get_string('formName');
    end if;*/
    v_template_name := dcld_comm_pkg.get_filter_value('templateName', v_request);
    v_form_name     := dcld_comm_pkg.get_filter_value('formName', v_request);
    v_data.set_data_type('ARRAY');
    FOR v_template_cur IN v_template_cursor
    LOOP
      v_template_item := pl_json;
      v_total         := v_template_cur.total;
      v_template_item.set_value('id', v_template_cur.id);
      v_template_item.set_value('templateName', v_template_cur.template_name);
      v_template_item.set_value('formName', v_template_cur.form_name);
      v_template_item.set_value('version', v_template_cur.version);
      v_template_item.set_value('formId', v_template_cur.form_id);
      v_template_item.set_value('isRotate', v_template_cur.is_rotate);
      v_template_item.set_value('templateCode', v_template_cur.template_code);
      v_data.add_list_item(v_template_item);
    END LOOP;
    v_response.set_value('templateList', v_data);
    v_response.set_value('total', v_total);
    x_response := v_response.to_json;
  END;
  /*==================================================
  Procedure/Function Name :
      proc_get_template_sample
  Description:
      This function perform:
      获取模板参数示例
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-02-28  xueyou.xu  Creation
  ==================================================*/
  PROCEDURE proc_get_template_sample(p_request  IN CLOB,
                                     x_response OUT CLOB) IS
    v_request  json;
    v_response pl_json := pl_json;
    v_data     pl_json := pl_json;
    --查询参数
    v_template_id NUMBER;

    v_template_code       VARCHAR2(600);
    v_template_sample     BLOB;
    v_template_sample_str VARCHAR2(32767);
    v_template_name       VARCHAR2(600);
  BEGIN
    --测试数据
    --v_request :=json('{"id":316}');
    --获取参数
    v_request := json(p_request, 'OBJECT');
    IF v_request.exist('id') THEN
      v_template_id := v_request.get_number('id');
    END IF;
    SELECT temp.template_code,
           temp.template_name,
           temp.template_sample
      INTO v_template_code,
           v_template_name,
           v_template_sample
      FROM BPM.templates temp
     WHERE temp.id = v_template_id;
    v_template_sample_str := utl_raw.cast_to_varchar2(dbms_lob.substr(v_template_sample));
    v_data.set_value('id', v_template_id);
    v_data.set_value('templateCode', v_template_code);
    v_data.set_value('templateName', v_template_name);
    v_data.set_value('templateSample', v_template_sample_str);
    v_response.set_value('template', v_data);
    x_response := v_response.to_json;

  END;
  /*==================================================
  Procedure/Function Name :
      proc_del_template
  Description:
      This function perform:
      删除模板
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-03-12  xueyou.xu  Creation
  ==================================================*/
  PROCEDURE proc_del_template(p_request  IN CLOB,
                              x_response OUT CLOB) IS
    v_request       json;
    v_response      pl_json := pl_json;
    v_template_code VARCHAR2(600);
  BEGIN
    --获取参数
    v_request := json(p_request, 'OBJECT');
    --测试数据
    --v_request := json('{"tempCode": "c52e1d12-3552-4073-9405-64da9b01a1b3"}');
    IF v_request.exist('tempCode') THEN
      v_template_code := v_request.get_string('tempCode');
    END IF;
    UPDATE BPM.templates t
       SET t.deleted = 1
     WHERE t.template_code = v_template_code;
    v_response.set_value('code', 'SUCCESS');
    x_response := v_response.to_data_json;
  EXCEPTION
    WHEN OTHERS THEN
      v_response.set_value('code', 'ERROR');
      x_response := v_response.to_data_json;
  END;
  /*==================================================
  Procedure/Function Name :
      proc_update_template
  Description:
      This function perform:
      更新模板配置
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-03-12  xueyou.xu  Creation
  ==================================================*/
  PROCEDURE proc_update_template(p_request  IN CLOB,
                                 x_response OUT CLOB) IS
    v_request                json;
    v_response               pl_json := pl_json;
    v_data                   pl_json := pl_json;
    v_temp_list              json_list;
    v_template_list          json_list;
    v_temp_detail_list       json_list;
    v_temp_detail            json;
    v_temp_field_detail      json;
    v_template               json;
    v_temp_code              VARCHAR2(600);
    v_temp_form_id           VARCHAR2(100);
    v_temp_id                NUMBER;
    v_id                     NUMBER;
    v_deleted                NUMBER;
    v_for_table              VARCHAR2(4);
    v_mapping_field          VARCHAR2(600);
    v_ref_code               VARCHAR2(600);
    v_ref_table_code         VARCHAR2(600);
    v_temp_field             VARCHAR2(600);
    v_ref_mapping_table_code VARCHAR2(600);
    v_is_rotate              VARCHAR2(24);
    v_form_id                VARCHAR2(100);
    v_template_id            NUMBER;

  BEGIN
    --获取参数
    v_request := json(p_request, 'OBJECT');

    --测试数据
    --v_request := json('{}');
    IF v_request.exist('tempDetail') THEN
      v_temp_detail := json(v_request.get('tempDetail'));
    END IF;

    --查询表单是否已经存在关联
    SELECT COUNT(1)
      INTO v_temp_id
      FROM templates t
     WHERE t.template_code != v_temp_detail.get_string('templateCode')
       AND t.form_id = v_temp_detail.get_string('formId')
       AND t.deleted = 0;

    IF v_temp_id >= 1 THEN
      --表单已经存在关联
      v_response.set_value('code', 'ERROR');
      v_response.set_value('msg', '该表单与 ' || v_temp_detail.get_string('templateName') || '存在关联');
    ELSE
      --更新templates表
      v_template_id := v_temp_detail.get_number('id');
      begin
      v_form_id     := to_number(v_temp_detail.get_string('formId'));
      --add by wlj, 当字符串转数字报错时，设置formId为空
      exception
        when others then
          v_form_id := null;
      end;
      v_is_rotate   := v_temp_detail.get_string('isRotate');
      UPDATE templates t
         SET t.is_rotate = v_is_rotate, t.form_id = v_form_id
       WHERE t.id = v_template_id;

      --更新template_detail表
      IF v_temp_detail.exist('tempList') THEN
        v_temp_list := json_list(v_temp_detail.get('tempList'));

        FOR i IN 1 .. v_temp_list.count
        LOOP
          v_template := json(v_temp_list.get(i));
          IF v_template.exist('templateList') THEN
            v_temp_detail_list := json_list(v_template.get('templateList'));

            FOR j IN 1 .. v_temp_detail_list.count
            LOOP
              v_temp_field_detail      := json(v_temp_detail_list.get(j));
              v_id                     := v_temp_field_detail.get_number('id');
              v_deleted                := v_temp_field_detail.get_number('deleted');
              v_for_table              := v_temp_field_detail.get_string('forTable');
              v_mapping_field          := v_temp_field_detail.get_string('mappingFiled');
              v_ref_code               := v_temp_field_detail.get_string('refCode');
              v_ref_table_code         := v_temp_field_detail.get_string('refTableCode');
              v_temp_field             := v_temp_field_detail.get_string('tempField');
              v_ref_mapping_table_code := v_temp_field_detail.get_string('refMappingTableCode');
              UPDATE BPM.template_detail td
                 SET td.deleted                = v_deleted,
                     td.for_table              = decode(v_for_table, 'null', ' ', v_for_table),
                     td.temp_field             = decode(v_temp_field, 'null', ' ', v_temp_field),
                     td.mapping_filed          = decode(v_mapping_field, 'null', ' ', v_mapping_field),
                     td.ref_code               = decode(v_ref_code, 'null', ' ', v_ref_code),
                     td.ref_table_code         = decode(v_ref_table_code, 'null', ' ', v_ref_table_code),
                     td.ref_mapping_table_code = decode(v_ref_mapping_table_code, 'null', ' ', v_ref_mapping_table_code)
               WHERE td.id = v_id;

            END LOOP;

          END IF;
        END LOOP;

      END IF;
      v_response.set_value('code', 'SUCCESS');
      v_response.set_value('msg', '模板配置保存成功');
    END IF;
    x_response := v_response.to_data_json;
    /*
    exception
      when others then
        v_response.set_value('code', 'ERROR');
        v_response.set_value('msg', '模板配置保存失败');
        x_response := v_response.to_data_json;
    */
  END;
END cux_dfnd_template_pkg;

/

