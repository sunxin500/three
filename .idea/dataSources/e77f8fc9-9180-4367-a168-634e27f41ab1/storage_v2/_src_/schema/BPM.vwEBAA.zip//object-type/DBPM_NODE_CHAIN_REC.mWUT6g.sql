create TYPE     "DBPM_NODE_CHAIN_REC" IS OBJECT
(
  chain_id   NUMBER
)

/

