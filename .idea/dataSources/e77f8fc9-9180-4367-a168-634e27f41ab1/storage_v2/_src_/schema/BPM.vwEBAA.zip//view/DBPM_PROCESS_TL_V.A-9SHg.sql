create view DBPM_PROCESS_TL_V as
SELECT dp.process_id,
       dp.process_code,
       dpt.locale,
       dpt.process_name,
       dpt.description
  FROM dbpm_process        dp,
       dbpm_process_tl dpt
 WHERE dp.process_id = dpt.process_id(+)
   ORDER BY dp.process_code
/

