create PACKAGE     dbpm_core_pkg IS
  /*
  * 获取单据信息
  */
  PROCEDURE proc_get_document_info(p_document_id     VARCHAR2,
                                   x_creator         OUT VARCHAR2,
                                   x_creator_name    OUT VARCHAR2,
                                   x_creation_time   OUT VARCHAR2,
                                   x_title           OUT VARCHAR2,
                                   x_process_id      OUT NUMBER,
                                   x_process_code    OUT VARCHAR2,
                                   x_form_id         OUT NUMBER,
                                   x_document_number OUT VARCHAR2);

  /*
  * 关联单据与流程ID
  */
  PROCEDURE proc_update_instance_id(p_document_id     VARCHAR2,
                                    p_bpm_instance_id VARCHAR2);

  /*
  * 修改单据状态
  */
  PROCEDURE proc_update_document_status(p_document_id VARCHAR2,
                                        p_status      VARCHAR2);

  /*
  * 获取审批链ID
  */
  PROCEDURE proc_get_chain_id(p_organization_id VARCHAR2,
                              p_process_id      NUMBER,
                              p_document_id     NUMBER,
                              p_process_param   dbpm_process_param_rec,
                              p_business_param  dbpm_business_param_tbl,
                              x_chain_id        OUT NUMBER,
                              x_result_flag     OUT VARCHAR2,
                              x_error_msg       OUT VARCHAR2);

  /*
  * 判断当前审批链的审批规则是否满足
  */
  PROCEDURE proc_get_chain_rule_result(p_chain_id       NUMBER,
                                       p_document_id    VARCHAR2,
                                       p_process_param  dbpm_process_param_rec,
                                       p_business_param dbpm_business_param_tbl,
                                       x_result         OUT VARCHAR2,
                                       x_result_flag    OUT VARCHAR2,
                                       x_error_msg      OUT VARCHAR2);

  /*
  * 获取比较结果
  */
  FUNCTION func_get_compare_result(p_data_type VARCHAR2,
                                   p_operation VARCHAR2,
                                   p_from_data VARCHAR2,
                                   p_to_data   VARCHAR2) RETURN VARCHAR2;

  /*
  * 获取审批链
  */
  PROCEDURE proc_get_approval_chain(p_document_id    VARCHAR2,
                                    p_process_param  dbpm_process_param_rec,
                                    p_business_param dbpm_business_param_tbl,
                                    x_chain          OUT dbpm_approval_chain_rec,
                                    x_result_flag    OUT VARCHAR2,
                                    x_error_msg      OUT VARCHAR2);

  /*
  * 获取审批人
  */
  PROCEDURE proc_get_approvers(p_node_id        NUMBER,
                               p_document_id    VARCHAR2,
                               p_process_param  dbpm_process_param_rec,
                               p_business_param dbpm_business_param_tbl,
                               x_approvers      OUT VARCHAR2,
                               x_result_flag    OUT VARCHAR2,
                               x_error_msg      OUT VARCHAR2);

  /*
  * 根据参数化角色获取审批人
  */
  PROCEDURE proc_get_role_approvers(p_node_id        NUMBER,
                                    p_document_id    VARCHAR2,
                                    p_process_param  dbpm_process_param_rec,
                                    p_business_param dbpm_business_param_tbl,
                                    x_approvers      OUT VARCHAR2,
                                    x_result_flag    OUT VARCHAR2,
                                    x_error_msg      OUT VARCHAR2);
  /*
  * 获取动态参数用户
  */
  procedure proc_get_node_dynamic_users(p_node_id        NUMBER,
                                        p_document_id    VARCHAR2,
                                        p_process_param  dbpm_process_param_rec,
                                        p_business_param dbpm_business_param_tbl,
                                        x_approvers      OUT VARCHAR2,
                                        x_result_flag    OUT VARCHAR2,
                                        x_error_msg      OUT VARCHAR2);
  /*
  * 根据sql获取审批人
  */
  FUNCTION func_get_approver_by_sql(p_node_id        NUMBER,
                                    p_document_id    VARCHAR2,
                                    p_process_param  dbpm_process_param_rec,
                                    p_business_param dbpm_business_param_tbl)
    RETURN VARCHAR2;

  /*
  * 根据申请人获取审批人
  */
  PROCEDURE proc_get_creator_approvers(p_document_id VARCHAR2,
                                       x_approvers   OUT VARCHAR2,
                                       x_result_flag OUT VARCHAR2,
                                       x_error_msg   OUT VARCHAR2);

  /*
  * 通过扩展插件方式，客户化获取审批人
  */
  PROCEDURE proc_get_approvers_plugin(p_approver_type  VARCHAR2,
                                      p_node_id        NUMBER,
                                      p_document_id    VARCHAR2,
                                      p_process_param  dbpm_process_param_rec,
                                      p_business_param dbpm_business_param_tbl,
                                      x_approvers      OUT VARCHAR2,
                                      x_result_flag    OUT VARCHAR2,
                                      x_error_msg      OUT VARCHAR2);

  /*
  * 获取参数值
  */
  FUNCTION func_get_node_role_param_value(p_node_id        NUMBER,
                                          p_role_code      VARCHAR2,
                                          p_param_id       NUMBER,
                                          p_document_id    VARCHAR2,
                                          p_business_param dbpm_business_param_tbl)
    RETURN VARCHAR2;

  /*
  * 获取表单域值
  */
  FUNCTION func_get_form_field_value(p_id VARCHAR2, p_document_id VARCHAR2)
    RETURN VARCHAR2;

  /*
  * 获取动态参数值
  */
  FUNCTION func_get_process_param_value(p_business_param     dbpm_business_param_tbl,
                                        p_process_param_code VARCHAR2)
    RETURN VARCHAR2;

  /*
  * 判断角色是否配置了参数
  */
  FUNCTION func_is_role_has_param(p_role_id NUMBER) RETURN VARCHAR2;

  /* \*
  * 获取成立的代理规则
  *\
  PROCEDURE proc_get_proxy_rules(p_owner          VARCHAR2,
                                 p_node_id        NUMBER,
                                 p_document_id    VARCHAR2,
                                 p_process_param  dbpm_process_param_rec,
                                 p_business_param dbpm_business_param_tbl,
                                 x_proxy_rules    OUT VARCHAR2,
                                 x_result_flag    OUT VARCHAR2,
                                 x_error_msg      OUT VARCHAR2);*/

  PROCEDURE proc_get_proxy_rules(p_owner           VARCHAR2,
                                 p_node_id         NUMBER,
                                 p_document_id     VARCHAR2,
                                 p_process_param   dbpm_process_param_rec,
                                 p_business_param  dbpm_business_param_tbl,
                                 x_proxy_approvers OUT VARCHAR2,
                                 x_proxy_rules     OUT VARCHAR2,
                                 x_result_flag     OUT VARCHAR2,
                                 x_error_msg       OUT VARCHAR2);
  /*
  * 获取成立的代理规则 v2.0
  * 增加返回被授权人信息 update by xuy 2017-12-02
  */
  PROCEDURE proc_get_proxy_rules(p_approvers       VARCHAR2,
                                 p_node_id         NUMBER,
                                 p_document_id     VARCHAR2,
                                 p_process_param   dbpm_process_param_rec,
                                 p_business_param  dbpm_business_param_tbl,
                                 x_proxy_approvers OUT VARCHAR2,
                                 x_proxy_rules     OUT VARCHAR2,
                                 x_result_flag     OUT VARCHAR2,
                                 x_error_msg       OUT VARCHAR2);
  /*
  * 升级表单版本
  */
  PROCEDURE proc_upgrade_form_version(p_form_id      VARCHAR2,
                                      p_current_user VARCHAR2,
                                      x_form_id      OUT NUMBER);

  /*
  * 获取升级后的版本号
  */
  FUNCTION func_get_lastest_version(p_form_code VARCHAR2) RETURN NUMBER;

  /*==================================================
  Procedure/Function Name :
      proc_export_process_form
  Description:
      This function perform:
      导出对应的表单
  Argument:
     p_form_id： 表单id
     x_form： 表单关联信息
  History:
      1.00  2017-11-01  zhiheng.wei  Creation
  ==================================================*/
  FUNCTION func_export_process_form(p_form_id NUMBER) RETURN CLOB;

  /*==================================================
  Procedure/Function Name :
      func_inport_process_form
  Description:
      This function perform:
      导入对应的表单
  Argument:
     p_form_content： 表单内容
  History:
      1.00  2017-11-08  chenmy.zhang@definesys.com Creation
  ==================================================*/
  PROCEDURE proc_import_process_form(p_request CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      func_export_process
  Description:
      This function perform:
      导出对应的流程
  Argument:
     p_process_id：流程id
  History:
      1.00  2017-11-10  zhiheng.wei  Creation
  ==================================================*/
  FUNCTION func_export_process(p_process_id NUMBER) RETURN CLOB;

  /*==================================================
  Procedure/Function Name :
      func_import_process
  Description:
      This function perform:
      导入对应的流程
  Argument:
     p_process_content ：流程的相关信息
  History:
      1.00  2017-11-13  zhiheng.wei  Creation
  ==================================================*/
  procedure proc_import_process(p_request CLOB, x_response out clob);

  /*==================================================
  Procedure/Function Name :
      proc_get_back_policy
  Description:
      This function perform:
      获取回退的策略
  Argument:
     p_process_content ：流程的相关信息
  History:
      1.00  2018-05-09  wlj  Creation
  ==================================================*/
  procedure proc_get_back_policy(p_cur_node_id IN NUMBER,
                                 x_outcome     OUT VARCHAR2,
                                 x_offset      OUT NUMBER,
                                 x_result_flag OUT VARCHAR2,
                                 x_error_msg   OUT VARCHAR2);

  /*==================================================
  Procedure/Function Name :
      proc_get_form_url
  Description:
      This function perform:
      获取表单链接（外部表单）
  Argument:
     P_DOCUMENT_ID ：得云表单ID
     X_URL : 外部表单链接
  History:
      1.00  2018-05-09  wlj  Creation
  ==================================================*/
  procedure proc_get_form_url(P_DOCUMENT_ID IN VARCHAR2,
                              X_URL         OUT VARCHAR2,
                              x_result_flag OUT VARCHAR2,
                              x_error_msg   OUT VARCHAR2);
  /*==================================================
  Procedure/Function Name :
      proc_get_approval_Formurl
  Description:

      获得节点绑定的审批页地址
  Argument:
      p_nodeid ：节点ID
      p_processCode ：流程编号
      p_attr ：备用属性
     X_URL : 审批页地址
  History:
      1.00  2019-01-06  xiaowei.yao  Creation
  ==================================================*/
  procedure proc_get_approval_formurl(p_nodeid      IN number,
                                      p_processCode IN VARCHAR2,
                                      p_attr        IN VARCHAR2,
                                      x_url         OUT VARCHAR2,
                                      x_nodename    OUT VARCHAR2,
                                      x_result_flag OUT VARCHAR2,
                                      x_error_msg   OUT VARCHAR2);

  /*==================================================
  Procedure/Function Name :
      proc_save_doc_chain
  Description:
      This function perform:
      proc_save_doc_chain
  Argument:
     P_DOCUMENT_ID ：得云表单ID
     x_chain : 审批链详情
  History:
      1.00  2018-05-21  wlj  Creation
  ==================================================*/
  procedure proc_save_instance_detail(p_bpm_instance_id IN VARCHAR2,
                                      x_chain           IN dbpm_approval_chain_rec,
                                      x_result_flag     OUT VARCHAR2,
                                      x_error_msg       OUT VARCHAR2);

  /*
  * 获取审批链
  */
  PROCEDURE proc_get_approval_chain(p_chain_id    NUMBER,
                                    x_chain       OUT dbpm_approval_chain_rec,
                                    x_result_flag OUT VARCHAR2,
                                    x_error_msg   OUT VARCHAR2);
  /*
  * 获取参数值
  */
  FUNCTION func_get_process_param_value(p_param_code  VARCHAR2,
                                        p_document_id VARCHAR2)
    RETURN VARCHAR2;
  /*
  * 获取节点参数判断类型
  */
  FUNCTION func_get_node_role_param_ope(p_node_id        NUMBER,
                                        p_role_code      VARCHAR2,
                                        p_param_id       NUMBER,
                                        p_document_id    VARCHAR2,
                                        p_business_param dbpm_business_param_tbl)
    RETURN VARCHAR2;
  /*
  * 获取审批节点下的审批链
  */
  PROCEDURE proc_get_node_chains(p_node_id     NUMBER,
                                 x_node_chains OUT dbpm_node_chain_tbl);
  /*
  * 获取子审批流流程编号
  * add by xiaowei.yao 20181228
  */
  PROCEDURE proc_get_sub_approval_chain(p_instanceid      VARCHAR2,
                                        p_document_id     VARCHAR2,
                                        p_process_param   dbpm_process_param_rec,
                                        p_business_param  dbpm_business_param_tbl,
                                        x_sub_porcesscode OUT VARCHAR2,
                                        x_porcesscode     OUT VARCHAR2,
                                        x_attr            OUT VARCHAR2,
                                        x_result_flag     OUT VARCHAR2,
                                        x_error_msg       OUT VARCHAR2);
  /*
  * 通过扩展插件方式，客户化获取代理规则
  */
  PROCEDURE proc_get_proxy_rules_plugin(p_approvers       VARCHAR2,
                                        p_node_id         NUMBER,
                                        p_document_id     VARCHAR2,
                                        p_process_param   dbpm_process_param_rec,
                                        p_business_param  dbpm_business_param_tbl,
                                        x_proxy_approvers OUT VARCHAR2,
                                        x_proxy_rules     OUT VARCHAR2,
                                        x_result_flag     OUT VARCHAR2,
                                        x_error_msg       OUT VARCHAR2);
  /*==================================================
  Procedure/Function Name :
      proc_get_email_ext
  Description:
      This function perform:
      使用扩展方式生成邮件的主题和body
  History:
      1.00  2019-03-01  xiaower.yao  Creation
  ==================================================*/
  PROCEDURE proc_get_email_ext(p_taskid         VARCHAR2,
                               P_locale         VARCHAR2,
                               p_process_param  dbpm_process_param_rec,
                               p_business_param dbpm_business_param_tbl,
                               x_email_title    OUT VARCHAR2,
                               x_email_body     OUT VARCHAR2,
                               x_result_flag    OUT VARCHAR2,
                               x_error_msg      OUT VARCHAR2);
  /*==================================================
  Procedure/Function Name :
      proc_get_email_ext
  Description:
      This function perform:
      插件化查的方式生成邮件的主题和body
  History:
      1.00  2019-03-01  xiaower.yao  Creation
  ==================================================*/
  PROCEDURE proc_get_email_plugin(p_taskid         VARCHAR2,
                                  P_locale         VARCHAR2,
                                  p_process_param  dbpm_process_param_rec,
                                  p_business_param dbpm_business_param_tbl,
                                  x_email_title    OUT VARCHAR2,
                                  x_email_body     OUT VARCHAR2,
                                  x_result_flag    OUT VARCHAR2,
                                  x_error_msg      OUT VARCHAR2);
  /*==================================================
  Procedure/Function Name :
      proc_get_business_param
  Description:
      This function perform:
      查询流程参数
  History:
      1.00  2019-06-26  xiaower.yao  Creation
  ==================================================*/
  PROCEDURE proc_get_business_param(p_instanceId     VARCHAR2,
                                    p_business_param dbpm_business_param_tbl,
                                    x_business_param out dbpm_business_param_tbl,
                                    x_result_flag    OUT VARCHAR2,
                                    x_error_msg      OUT VARCHAR2);

END dbpm_core_pkg;

/

