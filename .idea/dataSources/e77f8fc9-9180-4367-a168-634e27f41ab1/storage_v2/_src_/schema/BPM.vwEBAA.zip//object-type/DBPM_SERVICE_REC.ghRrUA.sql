create TYPE "DBPM_SERVICE_REC" force
                                             IS OBJECT
(
  service_map_id number,
  serivce_url   VARCHAR2(2000), -- 服务地址
  service_type VARCHAR2(200),--服务类别
  service_invoke_order NUMBER, -- 调用顺序
  service_invoke_stage VARCHAR2(2000),--调用阶段
  service_req clob,
  service_content_type VARCHAR2(200),
  service_request_method VARCHAR2(200),--服务请求方式
  attr VARCHAR2(2000) -- 扩展属性
)

/

