create package     dbpm_process_start_param_pkg is

  -- author  : yaoshallwe
  -- created : 2019/6/12 11:08:21
  -- purpose : 记录运行中的流程发起参数

  /*==================================================
  procedure name :
      proc_add_instance_param
  description:
      记录流程发起参数
  argument:
     p_instanceid：       实例号
     p_request_date:      请求时间
     p_request_content:   请求内容
     p_response_date:     响应时间
     p_response_content:  响应内容
     p_result:            接口调用接口（success/failure)
     p_error_log:         p_result='FAILURE'的错误日志
     x_msg:               调用结果
  history:
      1.00  2019-6-12  xiaowei.yao  creation
  ==================================================*/

  procedure proc_add_instance_param(p_instanceid       in varchar2,
                                    p_request_date     in date,
                                    p_request_content  in clob,
                                    p_response_date    in date,
                                    p_response_content in clob,
                                    p_result           in varchar2,
                                    p_error_log        in clob,
                                    x_msg              out varchar2,
                                    x_flag             out varchar2);
  /*==================================================
  procedure name :
      proc_update_instance_param
  description:
     更新流程参数
  argument:
     p_instanceid：       实例号
     p_new_param:         要更新的流程参数
     x_flag:          接口调用接口（success/failure)
     x_msg:             异常信息
  history:
      1.00  2019-6-14  xiaowei.yao  creation
  ==================================================*/

  procedure proc_update_instance_param(p_new_param in clob,
                                       x_msg       out varchar2,
                                       x_flag      out varchar2);
  /*==================================================
  procedure name :
      proc_check_instance_param
  description:
     校验流程参数
  argument:
     p_instance_param:       要校验的流程参数
     x_flag:          接口调用接口（success/failure)
     x_msg:             异常信息
  history:
      1.00  2019-6-24  xiaowei.yao  creation
  ==================================================*/

  procedure proc_check_instance_param(p_instance_param in clob,
                                      x_msg            out varchar2,
                                      x_flag           out varchar2);
/*==================================================
  procedure name :
      proc_get_error_email
  description:
     校验流程参数
  argument:
     p_instance_param:       要校验的流程参数
     x_flag:          接口调用接口（success/failure)
     x_msg:             异常信息
  history:
      1.00  2019-6-25  xiaowei.yao  creation
  ==================================================*/

  procedure proc_get_error_email(p_instance_param in clob,
                                 x_subject          out varchar2,
                                 x_content          out varchar2,
                                 x_reply   out varchar2,
                                 x_cc           out varchar2,
                                 x_tt           out varchar2);

end dbpm_process_start_param_pkg;

/

