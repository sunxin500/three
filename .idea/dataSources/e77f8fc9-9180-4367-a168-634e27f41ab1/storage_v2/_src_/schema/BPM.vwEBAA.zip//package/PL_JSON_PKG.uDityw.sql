create PACKAGE     "PL_JSON_PKG" IS

  -- Author  : ASAN
  -- Created : 2017/6/15 下午 5:32:37
  -- Purpose :

  PROCEDURE append_text(io_clob   IN OUT NOCOPY CLOB,
                        io_buffer IN OUT NOCOPY VARCHAR2,
                        i_text    IN VARCHAR2);
  PROCEDURE append_clob(io_clob   IN OUT NOCOPY CLOB,
                        io_buffer IN OUT NOCOPY VARCHAR2,
                        i_clob    IN CLOB);
  PROCEDURE write_append(io_clob   IN OUT NOCOPY CLOB,
                         io_buffer IN OUT NOCOPY VARCHAR2);
END pl_json_pkg;

/

