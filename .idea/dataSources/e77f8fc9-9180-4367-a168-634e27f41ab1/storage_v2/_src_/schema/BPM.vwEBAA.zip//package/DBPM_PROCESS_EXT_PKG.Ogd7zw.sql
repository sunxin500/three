create package DBPM_PROCESS_EXT_PKG is

  -- Author  : XJL
  -- Created : 2018/3/21 14:41:16
  -- Purpose :

  /*==================================================
  Procedure/Function Name :
      proc_query_external_process
  Description:
      This function perform:
      查询外部流程列表
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-03-21  jinglun.xu   Creation
  ==================================================*/
  PROCEDURE proc_query_external_process(p_request  CLOB,
                                        x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_update_external_node
  Description:
      This function perform:
      同步外部流程节点
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-03-21  jinglun.xu   Creation
  ==================================================*/
  /*  PROCEDURE proc_update_external_node(p_process_id number,
  x_code       out varchar2);*/
  /*==================================================
  Procedure/Function Name :
      proc_get_external_process_info
  Description:
      This function perform:
      铲鲟外部流程信息
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-03-21  jinglun.xu   Creation
  ==================================================*/
  PROCEDURE proc_get_external_process_info(p_process_id     number,
                                           p_domain_name    out varchar2,
                                           p_composite_name out varchar2);
  /*==================================================
  Procedure/Function Name :
      proc_get_external_process_parm
  Description:
      This function perform:
      铲鲟外部流程接口参数
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-03-23  jinglun.xu   Creation
  ==================================================*/
  PROCEDURE proc_get_external_process_parm(p_process_id  number,
                                           p_xml_varchar out varchar2);
  /*==================================================
  Procedure/Function Name :
      proc_save_ext_process
  Description:
      This function perform:
      维护外部流程
  Argument:
     p_process_id： 流程id
     x_result_flag： Y/N
     x_err_msg：
  History:
      1.00  2018-05-11  wlj   Creation
  ==================================================*/
  PROCEDURE proc_save_ext_process(p_process_id  number,
    p_bpm_id  number,
                                  p_locale      varchar2,
                                  x_result_flag out varchar2,
                                  x_err_msg     out varchar2);
  /*==================================================
  Procedure/Function Name :
      func_get_default_process
  Description:
      This function perform:
      查询默认版本的流程ID
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-05-10  wlj   Creation
  ==================================================*/
  FUNCTION func_get_default_process(p_process_name   varchar2,
                                    p_composite_name varchar2,
                                    p_domain_name    varchar2) return number;

  /*==================================================
  Procedure/Function Name :
      proc_process_register
  Description:
      This function perform:
      注册流程
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-05-14  wlj   Creation
  ==================================================*/
  PROCEDURE proc_process_register(p_request CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      func_get_process_node
  Description:
      This function perform:
      获取流程审批链对应的nodeId
  Argument:
     p_process_id： 流程id
     p_node_name：  节点名称
  History:
      1.00  2018-05-15  wlj   Creation
  ==================================================*/
  FUNCTION func_get_process_node(p_process_id varchar2,
                                 p_node_name  varchar2) return number;

  procedure proc_sync_process;
  procedure proc_sync_BPMprocess;

  procedure proc_purge_process;


end DBPM_PROCESS_EXT_PKG;

/

