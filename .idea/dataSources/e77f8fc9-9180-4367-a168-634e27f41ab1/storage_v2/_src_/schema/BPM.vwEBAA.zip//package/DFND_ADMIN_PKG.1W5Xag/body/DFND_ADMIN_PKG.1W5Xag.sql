create PACKAGE BODY     "DFND_ADMIN_PKG" is

  /*==================================================
  Procedure/Function Name :
      proc_get_admin_list
  Description:
      This function perform:
      获取管理员列表
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-12-04  liangjun.wu  Creation
  ==================================================*/
  procedure proc_get_admin_list(p_request IN CLOB, x_response OUT CLOB) as
    v_request    json;
    v_response   pl_json := pl_json;
    v_admin_list pl_json := pl_json;
    v_admin_item pl_json;
    v_space_id   varchar2(100);

    --查询参数
    v_search_fields json;
    v_total         number := 0;
    v_size          number := 200;
    v_page          number := 1;
    v_full_name     varchar2(1000);
    v_user_code     varchar2(100);
    --排序参数
    v_sort_col varchar2(100);
    v_sort     json;
    --v_company_name  varchar2(4000);

    cursor v_admins_cursor is
      SELECT *
        FROM (SELECT V.*, ROWNUM CNT
                FROM (SELECT COUNT(1) OVER(PARTITION BY 1) TOTAL,
                             T.USER_CODE,
                             T.ADMINISTRATOR_ID,
                             T.SPACE_ID,
                             DS.SPACE_CODE,
                             DS.SPACE_NAME,
                             NVL(DET.FULL_NAME,DET.EMPLOYEE_NAME) FULL_NAME,
                             T.ADMIN_TYPE
                        FROM DBPM_ADMINISTRATORS T,
                             DBPM_SPACES         DS,
                             DFND_EMPLOYEES      DET
                       WHERE T.SPACE_ID = DS.SPACE_ID(+)
                         AND upper(T.USER_CODE) = upper(DET.EMPLOYEE_CODE)
                         AND T.SPACE_ID = V_SPACE_ID
                         AND INSTR(NVL(DET.FULL_NAME, 'NL'),
                                   NVL(v_full_name, NVL(DET.FULL_NAME, 'NL'))) > 0
                         AND INSTR(NVL(T.USER_CODE, 'NL'),
                                   NVL(v_user_code, NVL(T.USER_CODE, 'NL'))) > 0
                       ORDER BY decode(v_sort_col,
                                       'full_name_desc',
                                       det.full_name,
                                       'user_code_desc',
                                       ds.space_name) DESC,
                                decode(v_sort_col,
                                       'full_name_asc',
                                       det.full_name,
                                       'user_code_asc',
                                       ds.space_name) ASC,
                                t.ADMINISTRATOR_ID) V
               WHERE ROWNUM <= V_PAGE * V_SIZE)
       WHERE CNT > (V_PAGE - 1) * V_SIZE;

  begin
    v_request  := json(p_request, 'OBJECT');
    v_space_id := v_request.get_string('spaceId');
    v_admin_list.set_data_type('ARRAY');

    if v_request.exist('page') then
      v_page := v_request.get_number('page');
    end if;
    if v_request.exist('size') then
      v_size := v_request.get_number('size');
    end if;
    /*  if v_request.exist('filter') then
      v_search_fields := json(v_request.get('filter'));
      v_full_name     := v_search_fields.get_string('fullName');
      v_user_code     := v_search_fields.get_string('userCode');
      --v_company_name  := v_search_fields.get_string('companyName');
    end if;*/
    v_full_name := dcld_comm_pkg.get_filter_value('fullName', v_request);
    v_user_code := dcld_comm_pkg.get_filter_value('userCode', v_request);

    if v_request.exist('sort') then
      v_sort     := json(v_request.get('sort'));
      v_sort_col := v_sort.get_string('value');
      v_sort_col := v_sort_col || '_' || v_sort.get_string('order');
    end if;

    FOR admin_cur IN v_admins_cursor LOOP
      v_admin_item := pl_json;
      v_total      := admin_cur.total;
      v_admin_item.set_value('fullName', admin_cur.full_name);
      v_admin_item.set_value('administratorId', admin_cur.administrator_id);
      v_admin_item.set_value('userCode', admin_cur.user_code);
      v_admin_item.set_value('adminType', admin_cur.admin_type);
      v_admin_item.set_value('spaceId', admin_cur.space_id);
      v_admin_item.set_value('spaceName', admin_cur.space_name);
      v_admin_item.set_value('spaceCode', admin_cur.space_code);
      v_admin_list.add_list_item(v_admin_item);
    END LOOP;
    v_response.set_value('adminList', v_admin_list);
    v_response.set_value('total', v_total);
    x_response := v_response.to_json;
  end proc_get_admin_list;

  /*==================================================
  Procedure/Function Name :
      proc_save_admin
  Description:
      This function perform:
      维护管理员
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-12-04  liangjun.wu  Creation
  ==================================================*/
  procedure proc_save_admin(p_request IN CLOB, x_response OUT CLOB) as
    v_request      json;
    v_response     pl_json := pl_json;
    v_admin_id     number;
    v_user_code    varchar2(100);
    v_space_id     varchar2(100);
    v_current_user varchar2(30);
    v_space_code   varchar2(100);
    v_admin_count  number;
    v_orgid  number;
  begin
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;
    v_admin_id     := v_request.get_number('administratorId');
    v_user_code    := v_request.get_string('userCode');
    v_space_id     := v_request.get_string('spaceId');

    select ds.space_code
      into v_space_code
      from dbpm_spaces ds
     where ds.space_id = v_space_id;

    select count(1)
      into v_admin_count
      from dbpm_administrators da
     where da.space_id = v_space_id
       and da.user_code = v_user_code;
       begin
       select t.organization_id
         into v_orgid
         from dfnd_org_employees t
       where upper(t.employee_code)=upper(v_user_code);
       EXCEPTION
    WHEN OTHERS THEN
      v_orgid :=1000;
       end;
    if v_admin_count > 0 and v_admin_id is null then
      --v_response.fail('工号为' || v_user_code || '的管理员已存在该空间');
      v_response.fail(DCLD_COMM_PKG.func_get_err_msg('DCLD-00021',v_request.locale,v_user_code));
      x_response := v_response.to_json;
      return;
    end if;
     if v_orgid is null then
      --v_response.fail('工号为' || v_user_code || '的管理员已存在该空间');
      v_response.fail(DCLD_COMM_PKG.func_get_err_msg('DCLD-00021',v_request.locale,v_user_code));
      x_response := v_response.to_json;
      return;
    end if;

    if v_admin_id is null then
      v_admin_id := DBPM_ADMINISTRATORS_S.NEXTVAL;
    end if;

    MERGE INTO DBPM_ADMINISTRATORS T
    USING (SELECT v_admin_id admin_id FROM DUAL) V
    ON (T.ADMINISTRATOR_ID = V.ADMIN_ID)
    WHEN MATCHED THEN
      UPDATE
         Set t.user_code        = nvl(v_user_code, t.user_code),
             t.last_updated_by  = v_current_user,
             t.organization_id  = nvl(v_orgid,1000),
             t.last_update_date = sysdate
    WHEN NOT MATCHED THEN
      insert
        (administrator_id,
         user_code,
         organization_id,
         space_id,
         created_by,
         last_updated_by)
      values
        (v_admin_id,
         v_user_code,
         nvl(v_orgid,1000),
         v_space_id,
         v_current_user,
         v_current_user);

    x_response := v_response.to_json;
  end proc_save_admin;

  /*==================================================
  Procedure/Function Name :
      proc_delete_admin
  Description:
      This function perform:
      删除管理员
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-12-04  liangjun.wu  Creation
  ==================================================*/
  procedure proc_delete_admin(p_request IN CLOB, x_response OUT CLOB) as
    v_request  json;
    v_response pl_json := pl_json;
    --v_current_user varchar2(30);
    v_admin_id number;
  begin
    v_request  := json(p_request, 'OBJECT');
    v_admin_id := v_request.get_number('administratorId');
    --v_current_user := v_request.username;
    DELETE FROM DBPM_ADMINISTRATORS DAT
     WHERE DAT.ADMINISTRATOR_ID = v_admin_id;
    x_response := v_response.to_json;
  end proc_delete_admin;

  /*==================================================
  Procedure/Function Name :
      proc_get_space_list
  Description:
      This function perform:
      获取空间列表
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-12-05  liangjun.wu  Creation
  ==================================================*/
  procedure proc_get_space_list(p_request IN CLOB, x_response OUT CLOB) as
    v_request    json;
    v_response   pl_json := pl_json;
    v_data       pl_json := pl_json;
    v_space_item pl_json;
    --查询参数
    --v_search_fields json;
    v_total number := 0;
    v_size  number := 20;
    v_page  number := 1;

    v_filter     json;
    v_space_code varchar2(1000);
    v_space_name varchar2(100);
    v_space_desc varchar2(4000);
    --v_current_user varchar2(30);
    --排序参数
    v_sort_col varchar2(100);
    v_sort     json;
    cursor v_space_cursor is
      SELECT *
        FROM (SELECT v.*, rownum cnt
                FROM (select COUNT(1) OVER(PARTITION BY 1) TOTAL,
                             ds.space_id,
                             ds.space_code,
                             ds.space_name,
                             ds.creation_date,
                             ds.space_description,
                             ds.space_type
                        from dbpm_spaces ds
                       where /*ds.space_type = 'NORMAL'
                         AND*/ INSTR(NVL(ds.space_code, 'NL'),
                                   NVL(v_space_code, NVL(ds.space_code, 'NL'))) > 0
                         AND INSTR(NVL(ds.space_name, 'NL'),
                                   NVL(v_space_name, NVL(ds.space_name, 'NL'))) > 0
                         AND INSTR(NVL(ds.space_description, 'NL'),
                                   NVL(v_space_desc,
                                       NVL(ds.space_description, 'NL'))) > 0
                       ORDER BY decode(v_sort_col,
                                       'space_code_desc',
                                       ds.space_code,
                                       'space_name_desc',
                                       ds.space_name,
                                       'space_desc_desc',
                                       ds.space_description) DESC,
                                decode(v_sort_col,
                                       'space_code_asc',
                                       ds.space_code,
                                       'space_name_asc',
                                       ds.space_name,
                                       'space_desc_asc',
                                       ds.space_description) ASC,
                                ds.space_id) v
               WHERE rownum <= v_page * v_size)
       WHERE cnt > (v_page - 1) * v_size;

  begin
    v_request := json(p_request, 'OBJECT');
    --v_current_user := v_request.username;
    if v_request.exist('page') then
      v_page := v_request.get_number('page');
    end if;
    if v_request.exist('size') then
      v_size := v_request.get_number('size');
    end if;
    if v_request.exist('sort') then
      v_sort     := json(v_request.get('sort'));
      v_sort_col := v_sort.get_string('value');
      v_sort_col := v_sort_col || '_' || v_sort.get_string('order');
    end if;
    /*   if v_request.exist('filter') then
      v_filter     := json(v_request.get('filter'));
      v_space_code := v_filter.get_string('spaceCode');
      v_space_name := v_filter.get_string('spaceName');
      v_space_desc := v_filter.get_string('spaceDesc');
    end if;*/
    v_space_code := dcld_comm_pkg.get_filter_value('spaceCode', v_request);
    v_space_name := dcld_comm_pkg.get_filter_value('spaceName', v_request);
    v_space_desc := dcld_comm_pkg.get_filter_value('spaceDesc', v_request);

    v_data.set_data_type('ARRAY');
    for v_space_cur in v_space_cursor loop
      v_space_item := pl_json;
      v_total      := v_space_cur.total;
      v_space_item.set_value('spaceId', v_space_cur.space_id);
      v_space_item.set_value('spaceCode', v_space_cur.space_code);
      v_space_item.set_value('spaceName', v_space_cur.space_name);
      v_space_item.set_value('createDate', v_space_cur.creation_date);
      v_space_item.set_value('spaceType', v_space_cur.space_type);
      v_space_item.set_value('spaceDesc', v_space_cur.space_description);
      v_data.add_list_item(v_space_item);
    end loop;
    v_response.set_value('spaceList', v_data);
    v_response.set_value('total', v_total);
    x_response := v_response.to_json;
  end proc_get_space_list;

  /*==================================================
  Procedure/Function Name :
      proc_save_space
  Description:
      This function perform:
      维护空间
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-12-05  liangjun.wu  Creation
  ==================================================*/
  procedure proc_save_space(p_request IN CLOB, x_response OUT CLOB) as
    v_request          json;
    v_response         pl_json := pl_json;
    v_current_user     varchar2(100);
    v_space_id         varchar2(100);
    v_space_code       varchar2(100);
    v_space_name       varchar2(1000);
    v_space_desc       varchar2(4000);
    v_space_code_count number;
  begin
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;
    v_space_id     := v_request.get_string('spaceId');
    v_space_code   := v_request.get_string('spaceCode');
    v_space_name   := v_request.get_string('spaceName');
    v_space_desc   := v_request.get_string('spaceDesc');

    --spaceCode是唯一的
    select count(1)
      into v_space_code_count
      from dbpm_spaces ds
     where ds.space_code = v_space_code;
    if v_space_code_count > 0 and v_space_id is null then
      --v_response.fail('该空间编码已重复');
      v_response.fail(DCLD_COMM_PKG.func_get_err_msg('DCLD-00022',v_request.locale));
      x_response := v_response.to_json;
      return;
    end if;

    if v_space_id is null then
      v_space_id := DBPM_SPACES_S.NEXTVAL;
    end if;

    MERGE INTO DBPM_SPACES T
    USING (SELECT v_space_id space_id FROM DUAL) V
    ON (T.SPACE_ID = V.SPACE_ID)
    WHEN MATCHED THEN
      UPDATE
         Set t.space_code        = nvl(v_space_code, t.space_code),
             t.space_name        = v_space_name,
             t.last_updated_by   = v_current_user,
             t.space_description = v_space_desc,
             t.last_update_date  = sysdate
    WHEN NOT MATCHED THEN
      insert
        (space_id,
         space_code,
         space_name,
         space_type,
         created_by,
         last_updated_by,
         space_description)
      values
        (v_space_id,
         v_space_code,
         v_space_name,
         'NORMAL',
         v_current_user,
         v_current_user,
         v_space_desc);

    x_response := v_response.to_json;
  end proc_save_space;

  /*==================================================
  Procedure/Function Name :
      proc_delete_space
  Description:
      This function perform:
      删除管理员
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-12-04  liangjun.wu  Creation
  ==================================================*/
  procedure proc_delete_space(p_request IN CLOB, x_response OUT CLOB) as
    v_request  json;
    v_response pl_json := pl_json;
    --v_current_user varchar2(30);
    v_space_id varchar2(100);
  begin
    v_request  := json(p_request, 'OBJECT');
    v_space_id := v_request.get_string('spaceId');
    --v_current_user := v_request.username;
    DELETE FROM DBPM_SPACES DS WHERE DS.SPACE_ID = v_space_id;
    --删除对应管理员
    DELETE FROM DBPM_ADMINISTRATORS DA WHERE DA.SPACE_ID = v_space_id;
    x_response := v_response.to_json;
  end proc_delete_space;
  /*==================================================
  Procedure/Function Name :
      proc_get_space_personal
  Description:
      This function perform:
      切换空间接口
        Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-12-14  jinglun.xu  Creation
      2.00  2018-1-29   wlj   modified
  ==================================================*/
  procedure proc_get_space_personal(p_request IN CLOB, x_response OUT CLOB) as
    v_request       json;
    v_search_fields json;
    v_array         pl_json := pl_json;
    v_response      pl_json := pl_json;
    v_space         pl_json := pl_json;
    v_current_user  varchar2(30);
    v_admin_type    varchar2(100);
    v_all           varchar2(1000);
    v_count         NUMBER := 0;
    v_size          NUMBER := 200;
    v_page          NUMBER := 1;
    cursor space_super_cur is
      SELECT *
        FROM (SELECT v.*, rownum cnt
                FROM (SELECT COUNT(1) over(PARTITION BY 1) total,
                             ds.space_id,
                             ds.space_code,
                             ds.space_name,
                             ds.space_type,
                             ds.space_description
                        from dbpm_spaces ds
                       where (INSTR(NVL(ds.space_code, 'NL'),
                                    NVL(v_all, NVL(ds.space_code, 'NL'))) > 0 or
                             INSTR(NVL(ds.space_name, 'NL'),
                                    NVL(v_all, NVL(ds.space_name, 'NL'))) > 0)

                       order by ds.space_name, ds.space_id desc) v
               WHERE rownum <= v_page * v_size)
       WHERE cnt > (v_page - 1) * v_size;
    cursor space_normal_cur is
      SELECT *
        FROM (SELECT v.*, rownum cnt
                FROM (SELECT COUNT(1) over(PARTITION BY 1) total,
                             ds.space_id,
                             ds.space_code,
                             ds.space_name,
                             ds.space_type,
                             ds.space_description
                        from dbpm_spaces ds, dbpm_administrators da
                       where upper(da.user_code) = upper(v_current_user)
                         and da.space_id = ds.space_id
                            --and da.space_id = decode( da.admin_type,'SuperAdmin',da.space_id,ds.space_id)
                         AND (INSTR(NVL(ds.space_code, 'NL'),
                                    NVL(v_all, NVL(ds.space_code, 'NL'))) > 0 or
                             INSTR(NVL(ds.space_name, 'NL'),
                                    NVL(v_all, NVL(ds.space_name, 'NL'))) > 0)

                       order by ds.space_name, ds.space_id desc) v
               WHERE rownum <= v_page * v_size)
       WHERE cnt > (v_page - 1) * v_size;

  begin
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;
    --判断是否为超级管理员
    begin
      SELECT t.admin_type
        INTO v_admin_type
        FROM dbpm_administrators t
       WHERE upper(t.user_code) = upper(v_current_user)
         AND T.ADMIN_TYPE = 'SuperAdmin';
    exception
      when no_data_found then
        v_admin_type := null;
    end;

    --过滤
    if v_request.exist('filter') then
      v_search_fields := json(v_request.get('filter'));
      v_all           := v_search_fields.get_string('all');
    end if;

    --分页
    IF v_request.exist('page') THEN
      v_page := v_request.get_number('page');
    END IF;
    IF v_request.exist('size') THEN
      v_size := v_request.get_number('size');
    END IF;

    if v_admin_type = 'SuperAdmin' then
      for c_space_cur in space_super_cur loop
        v_space := pl_json;
        v_space.set_value('spaceId', c_space_cur.space_id);
        v_space.set_value('spaceCode', c_space_cur.space_code);
        v_space.set_value('spaceName', c_space_cur.space_name);
        v_space.set_value('spaceType', c_space_cur.space_type);
        v_space.set_value('spaceDescription',
                          c_space_cur.space_description);
        v_count := c_space_cur.total;
        v_array.add_list_item(v_space);
      end loop;
    else
      for c_space_cur in space_normal_cur loop
        v_space := pl_json;
        v_space.set_value('spaceId', c_space_cur.space_id);
        v_space.set_value('spaceCode', c_space_cur.space_code);
        v_space.set_value('spaceName', c_space_cur.space_name);
        v_space.set_value('spaceType', c_space_cur.space_type);
        v_space.set_value('spaceDescription',
                          c_space_cur.space_description);
        v_count := c_space_cur.total;
        v_array.add_list_item(v_space);
      end loop;
    end if;
    v_response.set_value('total', v_count);
    v_array.set_data_type('ARRAY');
    v_response.set_value('spaceList', v_array);
    x_response := v_response.to_json;
  end proc_get_space_personal;

    /*==================================================
  Procedure/Function Name :
      func_get_space_id
  Description:
      This function perform:
      查询space空间
  Argument:
     p_user_code： 员工编号
  History:
      1.00  2017-12-06  liangjun.wu  Creation
  ==================================================*/
  function func_get_space_id(p_user_code varchar2) return varchar2 as
    v_user_code varchar2(30) := p_user_code;
    v_space_id  varchar2(100);
  begin
    --暂时只有管理员有space_id
    SELECT DS.SPACE_ID
      INTO v_space_id
      FROM DBPM_SPACES DS, DBPM_ADMINISTRATORS DA
     WHERE DS.SPACE_ID(+) = DA.SPACE_ID
       AND ROWNUM = 1
       AND UPPER(DA.USER_CODE) = UPPER(V_USER_CODE);
    return v_space_id;
  exception
    when others then
      return null;
  end;

end DFND_ADMIN_PKG;

/

