create TYPE "PL_JSON" FORCE AS OBJECT
(
  code      VARCHAR2(50),
  devmsg    VARCHAR2(50),
  usermsg   CLOB,
  datatype  VARCHAR2(20),
  atom_list json_atom_set,
  CONSTRUCTOR FUNCTION pl_json RETURN SELF AS RESULT,
  MEMBER PROCEDURE set_value(p_name IN VARCHAR2, p_value IN VARCHAR2),
  MEMBER PROCEDURE set_value(p_name IN VARCHAR2, p_value IN NUMBER),
  MEMBER PROCEDURE set_value(p_name IN VARCHAR2, p_value IN BOOLEAN),
  MEMBER PROCEDURE set_value(p_name IN VARCHAR2, p_value IN DATE),
  MEMBER PROCEDURE set_value(p_name IN VARCHAR2, p_value IN CLOB),
  MEMBER PROCEDURE set_value(p_name IN VARCHAR2, p_value IN pl_json),
  MEMBER PROCEDURE set_value(p_name IN VARCHAR2, p_value IN json),
  MEMBER PROCEDURE set_object(p_name IN VARCHAR2, p_value IN pl_json),
--update by Echo.zeng 2018-03-02
  MEMBER PROCEDURE set_value(p_name IN VARCHAR2, p_value IN json_list),
  MEMBER PROCEDURE set_data_type(p_type IN VARCHAR2),
  MEMBER PROCEDURE set_dev_msg(p_dev_msg IN VARCHAR2),
  MEMBER PROCEDURE set_user_msg(p_user_msg IN CLOB),
  MEMBER PROCEDURE set_msg(p_dev_msg IN VARCHAR2, p_user_msg IN VARCHAR2),
  MEMBER PROCEDURE fail(p_user_msg IN VARCHAR2),
  MEMBER PROCEDURE fail(p_dev_msg IN VARCHAR2, p_user_msg IN VARCHAR2),
  MEMBER PROCEDURE add_list_item(p_name IN VARCHAR2, p_value IN pl_json),
  MEMBER PROCEDURE add_list_item(p_name IN VARCHAR2, p_value IN json_list),
  MEMBER PROCEDURE add_list_item(p_value IN pl_json),
  MEMBER FUNCTION to_data_json RETURN CLOB,
  MEMBER FUNCTION to_json RETURN CLOB

)

/

