create package body     dbpm_event_pkg is

  /*==================================================
  Procedure/Function Name :
      proc_get_leader_approvers
  Description:
      This function perform:
      判断是否需要响应事件
  Argument:
     p_business_param： 流程业务参数
     p_process_param 流程基本参数
  History:
      1.00  2019-03-04 xiaowei.yao  Creation
  ==================================================*/

  procedure proc_get_event_flag(p_document_id  VARCHAR2,
                                p_process_code VARCHAR2,
                                p_instanceid   VARCHAR2,
                                p_event_type   VARCHAR2,
                                p_attr         VARCHAR2,
                                x_flag         OUT VARCHAR2,
                                x_error_msg    OUT VARCHAR2,
                                x_attr1        OUT VARCHAR2,
                                x_attr2        OUT VARCHAR2) is
    v_space_code varchar2(2000);
  begin
    select ds.space_code
      into v_space_code
      from dbpm_process t, dbpm_spaces ds
     where t.process_code = p_process_code
       and t.space_id = ds.space_id;
    ---GEMS 和AUTH有定制化的Bpel,这里就不再走公共事件 -update by  xiaowei.yao 20190812
    if v_space_code = 'GEMS' or v_space_code = 'AUTH' or v_space_code = 'KEMS' or v_space_code = 'RRSEMS' then
      x_flag := 'N';
    else
      x_flag := 'Y';
    end if;

  EXCEPTION
    WHEN OTHERS THEN
      x_flag := 'N';
  end proc_get_event_flag;
  /*==================================================
  Procedure/Function Name :
      proc_is_auto_approval
  Description:
      This function perform:
      从审批历史中查询是否应该自动审批
      1、申请人与申请人后第一个人工节点是同一个人，不自动审批
      2、在申请人之后如果存在与分配人相同的审批人，自动审批
  Argument:
     p_instance_id： instance_id
     p_assignee： 待办分配人
  History:
      1.00  2019-03-04 xiaowei.yao  Creation
  ==================================================*/
  PROCEDURE proc_is_auto_approval(p_instance_id VARCHAR2,
                                  p_assignee    VARCHAR2,
                                  x_result_flag OUT VARCHAR2,
                                  x_error_msg   OUT VARCHAR2) is
    v_count       NUMBER := 0;
    v_createdate  timestamp;
    v_updateddate timestamp;
    v_creator     VARCHAR2(300);
    v_processCode VARCHAR2(300);
  BEGIN
    x_result_flag := 'N';
    IF p_instance_id IS NULL OR p_assignee IS NULL THEN
      RETURN;
    END IF;
    --查询申请人创建时间
    SELECT nt.createddate, nt.creator
      INTO v_createdate, v_creator
      FROM wftask nt
     WHERE nt.instanceid = p_instance_id
       AND nt.creator IS NOT NULL
       AND nt.state = 'OPEN';
    SELECT COUNT(1)
      INTO v_count
      FROM wftask wt
     WHERE wt.instanceid = to_char(p_instance_id)
       AND (wt.outcome = 'REJECT' OR wt.state = 'WITHDRAWN')
       AND wt.hassubtask = 'F';
    --是否有回退
    IF v_count > 0 THEN
      --获取最后一个退回节点的时间
      SELECT MAX(wt.updateddate)
        INTO v_updateddate
        FROM wftask wt
       WHERE wt.instanceid = to_char(p_instance_id)
         AND (wt.outcome = 'REJECT' OR wt.state = 'WITHDRAWN')
         AND wt.hassubtask = 'F';
      --退回后是否是第一个审批人
      SELECT COUNT(1)
        INTO v_count
        FROM wftask wt
       WHERE wt.instanceid = to_char(p_instance_id) --updated by Echo.Zeng 2017-12-27
         AND wt.outcome IS NOT NULL
         AND wt.hassubtask = 'F'
         AND wt.updateddate > v_updateddate;
      IF v_count > 1 THEN
        SELECT COUNT(1)
          INTO v_count
          FROM dual
         WHERE p_assignee IN
               (SELECT wt.approvers
                  FROM wftask wt
                 WHERE wt.instanceid = to_char(p_instance_id) --updated by Echo.Zeng 2017-12-27
                   AND wt.outcome IS NOT NULL
                   AND wt.hassubtask = 'F'
                   AND wt.updateddate > v_updateddate);
        IF v_count > 0 THEN
          x_result_flag := 'Y';
        END IF;
      END IF;
    ELSE
      --是不是申请节点之后的第一个节点
      SELECT COUNT(1)
        INTO v_count
        FROM wftask wt
       WHERE wt.instanceid = to_char(p_instance_id) --updated by Echo.Zeng 2017-12-27
         AND wt.outcome IS NOT NULL
         AND wt.hassubtask = 'F'
         AND wt.updateddate > v_createdate;
      --不是第一个节点
      IF v_count > 0 THEN
        SELECT COUNT(1)
          INTO v_count
          FROM dual
         WHERE p_assignee IN (SELECT wt.approvers
                                FROM wftask wt
                               WHERE wt.instanceid = to_char(p_instance_id) --updated by Echo.Zeng 2017-12-27
                                 AND wt.outcome IS NOT NULL
                                 AND wt.hassubtask = 'F'
                                 AND wt.updateddate >= v_createdate
                              UNION ALL
                              SELECT v_creator approvers
                                FROM dual);
        IF v_count > 0 THEN
          x_result_flag := 'Y';
        END IF;
      END IF;
    END IF;
    --根据逻辑判断出是否需要自动审批之后，再判断是否需要走自动审批的逻辑
    select nvl(wf.protectedformattribute3, wf.protectedtextattribute4)
      into v_processCode
      from wftask wf
     where wf.instanceid = p_instance_id
       and wf.state = 'ASSIGNED'
       and rownum = 1;
    if x_result_flag = 'Y' then
      select dp.cux_auto_approve_flag
        into x_result_flag
        from dbpm_process dp
       where dp.process_code = v_processCode;
    end if;
  EXCEPTION
    WHEN OTHERS THEN
      x_result_flag := 'N';
      x_error_msg   := '判断自动审批异常，审批节点instance_id=' || p_instance_id ||
                       ',assignee=' || p_assignee;
  end proc_is_auto_approval;

  /*==================================================
  Procedure/Function Name :
      proc_get_email_ext

  Description:
      This function perform:
      使用扩展方式生成邮件的主题和body
      要是流程事件比如：PROCESS_START，PROCESS_END 发送的邮件，则p_taskid=PROCESS_START，PROCESS_END
  History:
      1.00  2019-03-01  xiaower.yao  Creation
  ==================================================*/
  PROCEDURE proc_get_email_ext(p_taskid         VARCHAR2,
                               P_locale         VARCHAR2,
                               p_process_param  dbpm_process_param_rec,
                               p_business_param dbpm_business_param_tbl,
                               x_email_title    OUT VARCHAR2,
                               x_email_body     OUT VARCHAR2,
                               x_result_flag    OUT VARCHAR2,
                               x_error_msg      OUT VARCHAR2) is

    v_process_name    varchar2(2000);
    v_email_id        number;
    v_content_clob    clob;
    v_node_id         number;
    v_proess_code     varchar2(2000);
    v_send_stage      varchar2(2000);
    v_email           json;
    v_body            varchar2(4000);
    v_title           varchar2(4000);
    v_templates       json_list;
    v_params          json_list;
    v_param           json;
    v_template        json;
    v_param_key       varchar2(4000);
    v_param_value     varchar2(4000);
    v_paramMapCode    varchar2(4000);
    v_paramType       varchar2(4000);
    v_paramCode       varchar2(4000);
    v_taskurl         varchar2(2000);
    v_process_title   varchar2(2000);
    v_apply_name      varchar2(2000);
    v_recipients      varchar2(200);
    v_recipients_type varchar2(200);
    v_instanceid      varchar2(200);
    v_formKey         varchar2(200);
    v_syscode         varchar2(200);
    v_para            varchar2(2000);
    v_node_name       varchar2(2000);
    v_task_count      number;
    v_taskid          varchar2(2000);
    v_assigne_user    varchar2(2000);
    cursor sub_task_cur(v_par_taskid varchar2) is
      select t.taskid from wftask t where t.taskgroupid = v_par_taskid;
  begin
    x_result_flag := 'Y';
    select nvl(dt.process_name, dp.process_name)
      into v_process_name
      from dbpm_process dp, dbpm_process_tl dt
     where dp.process_code = p_process_param.processCode
       and dp.process_id = dt.process_id(+)
       and dt.locale = nvl(P_locale, 'zh_CN');
    v_proess_code   := p_process_param.processCode;
    v_process_title := p_process_param.processTitle;
    begin
      select wf.protectedtextattribute5,
             wf.protectedtextattribute6,
             wf.instanceid,
             wf.protectedtextattribute7
        into v_taskurl, v_para, v_instanceid, v_formKey
        from wftask wf
       where wf.taskid = p_taskid;
    EXCEPTION
      WHEN no_data_found THEN
        v_taskurl    := '';
        v_instanceid := '';
        v_formKey    := '';
    end;
    v_taskurl := dbpm_comm_pkg.func_get_task_url(v_taskurl,
                                                 v_instanceid,
                                                 v_formKey,
                                                 p_taskid,
                                                 v_para,
                                                 v_syscode);
    if instr(p_taskid, 'PROCESS') = 0 --节点事件的邮件
     then
      /**
      select wf.protectednumberattribute1,
             wf.state,
             wf.protectedtextattribute5,
             wf.protectedformattribute1
        into v_node_id, v_send_stage, v_taskurl, v_node_name
        from wftask wf
       where wf.taskid = p_taskid;
       **/ --update by xuy 20191115
      select wf.protectednumberattribute1,
             wf.state,
             wf.protectedformattribute1
        into v_node_id, v_send_stage, v_node_name
        from wftask wf
       where wf.taskid = p_taskid;
    else
      --流程事件的邮件
      v_send_stage := p_taskid;
    end if;
    begin
      select nvl(dn.english_name, dn.employee_code)
        into v_apply_name
        from dfnd_employees dn
       where lower(dn.employee_code) =
             lower(p_process_param.processApplier);
    EXCEPTION
      WHEN no_data_found THEN
        v_apply_name := '';
    end;
    begin
      if v_node_id > 0 then
        select t.content, t.recipients, t.recipients_type
          into v_content_clob, v_recipients, v_recipients_type
          from dbpm_nodes_email_map t, dbpm_chain_nodes dcn
         where t.node_id = dcn.parent_id
           and t.send_stage = v_send_stage
           and dcn.node_id = v_node_id;
      else
        --申请人节点的待办
        select t.content, t.recipients, t.recipients_type
          into v_content_clob, v_recipients, v_recipients_type
          from dbpm_nodes_email_map t,
               dbpm_process_nodes   dpn,
               dbpm_process         dp
         where dpn.node_id = v_node_id
           and dp.process_code = v_proess_code
           and dp.process_id = dpn.process_id
           and t.send_stage = v_send_stage
           and dpn.order_num = 1;
      end if;
    EXCEPTION
      WHEN no_data_found THEN
        --节点级别未配置，则取流程级别的模板
        begin
          select dpm.content, dpm.recipients, dpm.recipients_type
            into v_content_clob, v_recipients, v_recipients_type
            from dbpm_process_email_map dpm, dbpm_process dp
           where dp.process_id = dpm.process_id
             and dpm.send_stage = v_send_stage
             and dp.process_code = v_proess_code;
        EXCEPTION
          WHEN no_data_found THEN
            x_result_flag := 'N';
            x_error_msg   := '邮件未配置';
            return;
        end;
    end;
    --初始化收件人
    --通过parentTaskId查询子任务的审批人(并签)
    begin
      select count(*)
        into v_task_count
        from wftask wf
       where wf.taskid = p_taskid
         and wf.hassubtask = 'T';
      if v_task_count > 0 then
        for sub_task in sub_task_cur(p_taskid) loop
          v_taskid := sub_task.taskid;
          select v.ASSIGNEE
            into v_assigne_user
            from dbpm_wf_task_v v
           where v.TASKID = v_taskid;
          if v_assigne_user is not null then
            x_error_msg := x_error_msg || v_assigne_user || ',';
          end if;
        end loop;
      end if;
      --去掉最后一个逗号
      if x_error_msg is not null and instr(x_error_msg, ',') > 0 then
        x_error_msg := substr(x_error_msg, 0, length(x_error_msg) - 1);
      end if;
    end;
    if v_recipients_type = 'STATIC' then
      x_error_msg := v_recipients;
    elsif v_recipients_type = 'PARAM' then
      x_error_msg := func_get_process_param_value(p_business_param,
                                                  v_recipients);
    end if;

    ---初始化邮件模板内容
    v_email     := json(v_content_clob);
    v_templates := json_list(v_email.get('template'));
    v_params    := json_list(v_email.get('params'));
    for i in 1 .. v_templates.count loop
      v_template := json(v_templates.get(i));
      if v_template.get_string('locale') = 'zh_CN' then
        v_body  := v_template.get_string('body');
        v_title := v_template.get_string('title');
        for k in 1 .. v_params.count loop
          v_param := json(v_params.get(k));
          if p_business_param.count = 0 then
            --得云配置表单，业务参数为空
            v_paramMapCode := v_param.get_string('paramMapCode');
            v_paramCode    := v_param.get_string('paramCode');

            select (case v_paramMapCode
                     when 'TASKURL' then
                      v_taskurl
                     when 'PROCESSNAME' then
                      v_process_name
                     when 'APPLYER' then
                      p_process_param.processApplier
                     when 'PROCESSTITLE' then
                      v_process_title
                     when 'APPLYERNAME' then
                      v_apply_name
                     when 'NODENAME' then
                      v_node_name
                     when v_param_key then
                      v_param_key
                   end)
              into v_param_value
              from dual;
            if v_param_value is not null then
              v_body  := replace(v_body, v_paramCode, v_param_value);
              v_title := replace(v_title, v_paramCode, v_param_value);
            end if;
          else
            FOR j IN 1 .. p_business_param.count LOOP
              v_param_key    := p_business_param(j).paramkey;
              v_paramMapCode := v_param.get_string('paramMapCode');
              v_paramCode    := v_param.get_string('paramCode');

              select (case v_paramMapCode
                       when 'TASKURL' then
                        v_taskurl
                       when 'PROCESSNAME' then
                        v_process_name
                       when 'APPLYER' then
                        p_process_param.processApplier
                       when 'PROCESSTITLE' then
                        v_process_title
                       when 'APPLYERNAME' then
                        v_apply_name
                       when 'NODENAME' then
                        v_node_name
                       when v_param_key then
                        p_business_param(j).paramvalue
                     end)
                into v_param_value
                from dual;
              if v_param_value is not null then
                v_body  := replace(v_body, v_paramCode, v_param_value);
                v_title := replace(v_title, v_paramCode, v_param_value);
              end if;

            END LOOP;
          end if;
        end loop;
      end if;
    end loop;
    x_email_title := v_title;
    x_email_body  := v_body;
    --初始化收件人

  EXCEPTION
    WHEN OTHERS THEN
      x_email_title := '';
      x_email_body  := '';
      x_result_flag := 'N';
      x_error_msg   := '获取标准流程模板异常,' || dbms_utility.format_error_backtrace ||
                       dbms_utility.format_error_stack;
      --raise_application_error(-20001, '获取标准流程模板异常');
    --update by xuy 20190813

  end proc_get_email_ext;

  /*==================================================
  Procedure/Function Name :
      proc_get_sevice_ext
  Description:
      This function perform:
      获得服务
  History:
       1.00  2019-03-22  xiaower.yao  Creation
  ==================================================*/
  PROCEDURE proc_get_sevice_ext(p_invoke_stage   VARCHAR2,
                                p_service_type   VARCHAR2,
                                p_task_id        VARCHAR2,
                                p_instance_id    VARCHAR2,
                                p_syscode        VARCHAR2,
                                p_process_param  dbpm_process_param_rec,
                                p_business_param dbpm_business_param_tbl,
                                x_services       OUT dbpm_service_tbl,
                                x_result_flag    OUT VARCHAR2,
                                x_error_msg      OUT VARCHAR2) is
    v_node_id    number;
    v_process_id number;
    --节点级别服务
    cursor v_node_service_cur(p_node_id number) is
      select ds.service_path,
             dm.invoke_order,
             dm.invoke_stage,
             dm.service_req,
             ds.service_contenttype,
             dm.map_id
        from dbpm_nodes_service_map dm, dbpm_service ds
       where dm.node_id = p_node_id
         and ds.id = dm.service_id
         and dm.invoke_stage = p_invoke_stage
       order by dm.invoke_order asc;
    --流程级别服务
    cursor v_process_service_cur(p_process_id number) is
      select ds.service_path,
             dm.invoke_order,
             dm.invoke_stage,
             dm.service_req,
             ds.service_contenttype,
             dm.map_id
        from dbpm_process_service_map dm, dbpm_service ds
       where dm.process_id = p_process_id
         and ds.id = dm.service_id
         and dm.invoke_stage = p_invoke_stage
       order by dm.invoke_order asc;
    v_services        dbpm_service_tbl := dbpm_service_tbl();
    v_service         dbpm_service_rec := dbpm_service_rec(null,
                                                           null,
                                                           null,
                                                           null,
                                                           null,
                                                           null,
                                                           null,
                                                           null,
                                                           null);
    v_index           number;
    v_req             json;
    v_param           json;
    v_params          json_list;
    v_param_key       varchar2(2000);
    v_paramMapCode    varchar2(2000);
    v_paramCode       varchar2(2000);
    v_req_str         varchar2(4000);
    v_param_value     varchar2(2000);
    v_process_outcome varchar2(2000);
    ---固化几个系统参数
    v_procss_outcome varchar2(32); --流程审批结果
    v_node_outcome   varchar2(32); --节点审批结果
    v_node_code      varchar2(32); --节点唯一标志
    v_wf_count       number;
  begin
    if p_service_type = 'NODE' then
      select wf.protectednumberattribute1, nvl(wf.outcome, wf.state)
        into v_node_id, v_node_outcome
        from wftask wf
       where wf.taskid = p_task_id;
      if v_node_id = -1 then
        select dn.node_id
          into v_node_id
          from dbpm_process_nodes dn, dbpm_process dp
         where dp.process_id = dn.process_id
           and dp.process_code = p_process_param.processCode
           and dn.order_num = 1;
      else
        select dns.parent_id
          into v_node_id
          from dbpm_chain_nodes dns
         where dns.node_id = v_node_id;
      end if;
      v_services := dbpm_service_tbl();
      v_index    := 1;
      for v_node in v_node_service_cur(v_node_id) loop
        v_services.extend();
        v_service.serivce_url          := v_node.service_path;
        v_service.service_content_type := v_node.service_contenttype;
        v_service.service_invoke_order := v_node.invoke_order;
        v_service.service_invoke_stage := v_node.invoke_stage;
        --初始化请求参数
        v_req     := json(v_node.service_req);
        v_params  := json_list(v_req.get('params'));
        v_req_str := v_req.get_string('invokeContent');
        for k in 1 .. v_params.count loop
          v_param := json(v_params.get(k));
          FOR j IN 1 .. p_business_param.count LOOP
            v_param_key    := p_business_param(j).paramkey;
            v_paramMapCode := v_param.get_string('paramMapCode');
            v_paramCode    := v_param.get_string('paramCode');
            select (case v_paramMapCode
                     when 'OUTCOME' then
                      v_node_outcome
                     when 'INSTANCEID' then
                      p_instance_id
                     when 'NODECODE' then
                      v_node_code
                     when v_param_key then
                      p_business_param(j).paramvalue
                   end)
              into v_param_value
              from dual;
            if v_param_value is not null then
              v_req_str := replace(v_req_str, v_paramCode, v_param_value);
            end if;
          END LOOP;
        end loop;
        v_service.service_req := v_req_str;
        v_service.service_map_id := v_node.map_id;
        v_service.service_type := 'NODE';
        v_services(v_index) := v_service;
        v_index := v_index + 1;
      end loop;
    elsif p_service_type = 'PROCESS' then
      begin
        select nvl(wf.outcome, 'START')
          into v_process_outcome
          from wftaskhistory wf
         where wf.instanceid = p_instance_id
           and wf.outcome is not null
           and rownum = 1
         order by wf.updateddate desc;
      exception
        when no_data_found then
          select count(1)
            into v_wf_count
            from wftaskhistory wf
           where wf.instanceid = p_instance_id
             and wf.assignees is null
             and wf.outcome is null;
          if v_wf_count > 0 then
            v_process_outcome := 'APPROVE';
          else
            v_process_outcome := 'START';
          end if;
      end;
      select dp.process_id
        into v_process_id
        from dbpm_process dp
       where dp.process_code = p_process_param.processCode;
      v_services := dbpm_service_tbl();
      v_index    := 1;
      for v_process in v_process_service_cur(v_process_id) loop
        v_services.extend();
        v_service.serivce_url          := v_process.service_path;
        v_service.service_content_type := v_process.service_contenttype;
        v_service.service_invoke_order := v_process.invoke_order;
        v_service.service_invoke_stage := v_process.invoke_stage;
        --初始化请求参数
        v_req     := json(v_process.service_req);
        v_params  := json_list(v_req.get('params'));
        v_req_str := v_req.get_string('invokeContent');
        for k in 1 .. v_params.count loop
          v_param := json(v_params.get(k));
          FOR j IN 1 .. p_business_param.count LOOP
            v_param_key    := p_business_param(j).paramkey;
            v_paramMapCode := v_param.get_string('paramMapCode');
            v_paramCode    := v_param.get_string('paramCode');
            select (case v_paramMapCode
                     when 'OUTCOME' then
                      v_process_outcome
                     when 'INSTANCEID' then
                      p_instance_id
                     when 'FORMKEY' then
                      v_node_code
                     when v_param_key then
                      p_business_param(j).paramvalue
                   end)
              into v_param_value
              from dual;

            if v_param_value is not null then
              v_req_str := replace(v_req_str, v_paramCode, v_param_value);
            end if;
          END LOOP;
        end loop;
        v_service.service_req := v_req_str;
        v_service.service_map_id := v_process.map_id;
        v_service.service_type := 'PROCESS';
        v_services(v_index) := v_service;
        v_index := v_index + 1;
      end loop;
    end if;
    x_services := v_services;
  EXCEPTION
    WHEN OTHERS THEN
      x_result_flag := 'N';
      x_error_msg   := '获取服务异常';
      raise_application_error(-20001, '获取服务异常');
  end proc_get_sevice_ext;
  /*
  * 获取动态参数值
  */
  FUNCTION func_get_process_param_value(p_business_param     dbpm_business_param_tbl,
                                        p_process_param_code VARCHAR2)
    RETURN VARCHAR2 IS
    v_param dbpm_business_param_rec;
  BEGIN
    FOR i IN 1 .. p_business_param.count LOOP
      v_param := p_business_param(i);
      IF v_param.paramkey = p_process_param_code THEN
        RETURN v_param.paramvalue;
      END IF;
    END LOOP;

    RETURN NULL;
  END func_get_process_param_value;
end dbpm_event_pkg;

/

