create package body     DBPM_PROCESS_HISTORY_PKG is
  G_SUBMIT_OP       VARCHAR2(100) := 'SUBMIT';
  G_WAIT_OP         VARCHAR2(100) := 'WAIT_OP';
  G_WAIT_COMMENT    VARCHAR2(100) := '';
  G_DEFAULT_NODE_ID NUMBER := -666;
  G_APPLY_NODE_NAME VARCHAR2(100) := 'APPLIER';
  G_APPLY_COMMENT   VARCHAR2(100) := 'SUBMIT';
  /*==================================================
  Procedure/Function Name :
      proc_query_history_graph
  Description:
      This function perform:
       查询审批历史流程图
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-05-08  wlj  Creation
  ==================================================*/
  PROCEDURE proc_query_history_graph(p_request  IN CLOB,
                                     x_response OUT CLOB) AS
    v_request         json;
    v_response        pl_json := pl_json;
    v_nodes           pl_json := pl_json;
    v_node            pl_json;
    v_history_array   pl_json := pl_json;
    v_history         pl_json;
    v_doc_id          number; --单据ID
    v_org_id          varchar2(100); --组织
    v_process_id      number; --流程
    v_bpm_instance_id varchar2(100); --流程实例号
    v_chain_id        number; --审批链
    v_chain_version   number; --版本号
    v_role_str        varchar2(4000); -- 角色字符串(逗号分隔)
    v_from_user       varchar2(200); --重新分配人
    v_from_user_name  varchar2(200); --重新分配人
    --v_task_id         varchar2(300);
    v_prev_outcome         varchar2(100);
    v_prev_node_id         number;
    v_cur_node_id          number; --当前节点ID
    v_cur_node_name        varchar2(4000); --当前节点名称
    v_cur_node_order       number; --当前节点的审批顺序
    v_instance_create_date date; --流程实例创建时间
    v_instance_update_date date; --流程实例最后更新时间
    v_instance_state       number; --流程状态
    v_instance_live_day    number; --流程持续天数
    v_in_op_str            varchar2(4000) := G_DEFAULT_NODE_ID;
    v_get_chain_sql        varchar2(4000); --动态获取审批链的sql
    v_old_state            varchar2(100) := 'OLD'; --标识审批历史节点的状态(OLD/CURR/NEW/ERROR)
    v_new_state            varchar2(100) := 'NEW'; --标识审批历史节点的状态(OLD/CURR/NEW/ERROR)
    v_curr_state           varchar2(100) := 'CURR'; --标识审批历史节点的状态(OLD/CURR/NEW/ERROR)
    v_err_state            varchar2(100) := 'ERROR'; --标识审批历史节点的状态(OLD/CURR/NEW/ERROR)
    v_count                number := 0; --用于计算循环次数的变量
    v_access_key           varchar2(100); --wftask上的字段：用于判断流程的状态
    v_callback_context     varchar2(100); --wftask上的字段：用于判断流程的状态
    TYPE ref_cursor_type IS REF CURSOR;
    v_chain_cursor ref_cursor_type;

    --根据流程实例查询历史
    CURSOR v_history_cur IS
      SELECT '' history_id,
             t.taskid,
             t.protectednumberattribute1 node_id,
             T.Activityname activity_name,
             T.approvers approver_code,
             (SELECT E.EMPLOYEE_NAME
                FROM DFND_EMPLOYEES E
               WHERE UPPER(E.EMPLOYEE_CODE) = UPPER(T.approvers)) approver_name,
             T.outcome operation,
             wfc.wfcomment comment_detail,
             T.assigneddate creation_date,
             T.ENDDATE APPROVE_DATE,
             T.STATE,
             T.SUBSTATE,
             T.workflowpattern,
             cn.node_type,
             (select dcld_comm_pkg.get_data_source_value('DbpmNodeType',
                                                         dv.value_code,
                                                         v_request.locale) value_name
                from dbpm_data_source_values dv
               where dv.data_source_code = 'DbpmNodeType'
                 and dv.value_code = cn.node_type
                 and dv.status = 'Y') node_type_name,
             cn.approver_type,
             decode(t.protectednumberattribute1,
                    -1,
                    dcld_comm_pkg.func_get_sys_msg(G_APPLY_NODE_NAME,
                                                   v_request.locale),
                    cn.node_name) NODE_NAME,
             (select dcld_comm_pkg.get_data_source_value('DbpmGetApproversType',
                                                         dv.value_code,
                                                         v_request.locale) value_name
                from dbpm_data_source_values dv
               where dv.data_source_code = 'DbpmGetApproversType'
                 and dv.status = 'Y'
                 and dv.value_code = cn.approver_type) approver_type_name,
             (SELECT dcld_comm_pkg.get_data_source_value('DbpmApprovalOperation',
                                                         ddsv.value_code,
                                                         v_request.locale) value_name
                FROM dbpm_data_source_values ddsv
               WHERE ddsv.data_source_code = 'DbpmApprovalOperation'
                 AND ddsv.value_code = T.outcome) operation_name
        from wftaskhistory T, wfcomments wfc, dbpm_chain_nodes cn
       where t.taskid = wfc.taskid(+)
         and t.protectednumberattribute1 = cn.node_id(+)
         and T.instanceid = v_bpm_instance_id
         and T.STATE IS NULL
         and T.workflowpattern IN ('Participant', 'FYI')
       ORDER BY T.tasknumber, T.version ASC;

    --当前审批人
    CURSOR v_curr_approvers IS
      SELECT '' history_id,
             WF.taskid,
             WF.protectednumberattribute1 node_id,
             wf.Activityname activity_name,
             ASS.ASSIGNEE approver_code,
             (SELECT E.EMPLOYEE_NAME
                FROM DFND_EMPLOYEES E
               WHERE UPPER(E.EMPLOYEE_CODE) = UPPER(ASS.ASSIGNEE)) approver_name,
             decode(wf.workflowpattern,
                    'FYI',
                    dcld_comm_pkg.func_get_sys_msg('FYI', v_request.locale),
                    dcld_comm_pkg.func_get_sys_msg(G_WAIT_OP,
                                                   v_request.locale)) operation,
             --decode(wf.workflowpattern,'FYI','FYI',G_WAIT_COMMENT) comment_detail,
             null comment_detail,
             WF.assigneddate creation_date,
             WF.ENDDATE APPROVE_DATE,
             WF.STATE,
             WF.SUBSTATE,
             WF.workflowpattern,
             cn.node_type,
             (select dcld_comm_pkg.get_data_source_value('DbpmNodeType',
                                                         dv.value_code,
                                                         v_request.locale) value_name
                from dbpm_data_source_values dv
               where dv.data_source_code = 'DbpmNodeType'
                 and dv.value_code = cn.node_type
                 and dv.status = 'Y') node_type_name,
             cn.approver_type,
             decode(WF.protectednumberattribute1,
                    -1,
                    dcld_comm_pkg.func_get_sys_msg(G_APPLY_NODE_NAME,
                                                   v_request.locale),
                    cn.node_name) NODE_NAME,
             (select dcld_comm_pkg.get_data_source_value('DbpmGetApproversType',
                                                         dv.value_code,
                                                         v_request.locale) value_name
                from dbpm_data_source_values dv
               where dv.data_source_code = 'DbpmGetApproversType'
                 and dv.status = 'Y'
                 and dv.value_code = cn.approver_type) approver_type_name,
             (SELECT dcld_comm_pkg.get_data_source_value('DbpmApprovalOperation',
                                                         ddsv.value_code,
                                                         v_request.locale) value_name
                FROM dbpm_data_source_values ddsv
               WHERE ddsv.data_source_code = 'DbpmApprovalOperation'
                 AND ddsv.value_code = WF.outcome) operation_name
        FROM WFTASK WF, WFASSIGNEE ASS, dbpm_chain_nodes cn
       WHERE WF.STATE IN ('ASSIGNED', 'INFO_REQUESTED')
         AND ASS.TASKID = WF.TASKID
         AND WF.protectednumberattribute1 = cn.node_id(+)
         AND WF.INSTANCEID = v_bpm_instance_id
       ORDER BY WF.tasknumber, WF.version ASC;

    --申请人节点
    CURSOR v_applier_cursor IS
      SELECT '' history_id,
             '' taskid,
             wf.creator approver_code,
             G_DEFAULT_NODE_ID node_id,
             dcld_comm_pkg.func_get_sys_msg(G_APPLY_NODE_NAME,
                                            v_request.locale) node_name,
             (SELECT E.EMPLOYEE_NAME
                FROM DFND_EMPLOYEES E
               WHERE UPPER(E.EMPLOYEE_CODE) = UPPER(wf.creator)) approver_name,
             dcld_comm_pkg.func_get_sys_msg(G_SUBMIT_OP, v_request.locale) operation,
             dcld_comm_pkg.func_get_sys_msg(G_APPLY_COMMENT,
                                            v_request.locale) comment_detail,
             '' creation_date,
             '' APPROVE_DATE
        FROM WFTASK WF
       WHERE WF.INSTANCEID = v_bpm_instance_id
         AND WF.CREATOR IS NOT NULL
         AND ROWNUM = 1
       ORDER BY WF.tasknumber, WF.version ASC;

    --查询审批链节点
    CURSOR v_node_cursor(p_chain_id number,
                         p_version  number,
                         p_order    number) IS
      select cn.node_name,
             cn.node_id,
             cn.node_type,
             cn.order_num,
             (select dcld_comm_pkg.get_data_source_value('DbpmNodeType',
                                                         dv.value_code,
                                                         v_request.locale) value_name
                from dbpm_data_source_values dv
               where dv.data_source_code = 'DbpmNodeType'
                 and dv.value_code = cn.node_type
                 and dv.status = 'Y') node_type_name,
             cn.approver_type,
             (select dcld_comm_pkg.get_data_source_value('DbpmGetApproversType',
                                                         dv.value_code,
                                                         v_request.locale) value_name
                from dbpm_data_source_values dv
               where dv.data_source_code = 'DbpmGetApproversType'
                 and dv.status = 'Y'
                 and dv.value_code = cn.approver_type) approver_type_name
        from dbpm_chain_nodes CN
       where cn.chain_id = p_chain_id
         and cn.version = p_version
         and cn.order_num > p_order
       order by cn.order_num asc;
  BEGIN
    v_request := json(p_request, 'OBJECT');
    --v_request     := json('{"instanceId":"561636"}');
    v_doc_id := nvl(v_request.get_number('documentId'),
                    v_request.get_string('documentId'));
    --v_task_id         := v_request.get_string('taskId');
    v_bpm_instance_id := nvl(v_request.get_number('instanceId'),
                             v_request.get_string('instanceId'));
    --若未传入实例号，则通过单据号获取实例
    if v_bpm_instance_id IS NULL THEN
      BEGIN
        SELECT D.ORGANIZATION_ID, D.PROCESS_ID, d.bpm_instance_id
          INTO v_org_id, v_process_id, v_bpm_instance_id
          FROM DBPM_DOCUMENTS D
         WHERE D.DOCUMENT_ID = v_doc_id;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          v_response.fail('单据不存在');
          x_response := v_response.to_json;
          return;
      END;
    END IF;

    --查询创建时间
    /*select t.creation_date+0, t.modify_date+0, t.state
     INTO v_instance_create_date, v_instance_update_date, v_instance_state
     from CUBE_INSTANCE t
    where t.cikey = v_bpm_instance_id;*/
    /*SELECT wf.createddate, WF.UPDATEDDATE
     INTO v_instance_create_date, v_instance_update_date
     FROM wftask WF
    WHERE WF.INSTANCEID = v_bpm_instance_id
      AND WF.TASKID = v_bpm_instance_id
      AND ROWNUM = 1;*/
    --判断流程状态
    select wf.callbackcontext, wf.accesskey
      into v_callback_context, v_access_key
      from wftask wf
     where wf.instanceid = v_bpm_instance_id
       and wf.taskid = v_bpm_instance_id;

    --设置数组类型
    v_nodes.set_data_type('ARRAY');
    v_history_array.set_data_type('ARRAY');
    --1.添加一条申请人
    FOR v_his_cur IN v_applier_cursor LOOP
      --设置审批历史的申请人节点
      v_history := pl_json;
      v_history.set_value('historyId', v_his_cur.history_id);
      v_history.set_value('nodeName', v_his_cur.node_name);
      v_history.set_value('nodeId', -1);
      v_history.set_value('approverCode', v_his_cur.approver_code);
      v_history.set_value('approverName', v_his_cur.approver_name);
      v_history.set_value('operation', v_his_cur.operation);
      v_history.set_value('comment', v_his_cur.comment_detail);
      v_history.set_value('assignedDate', v_instance_create_date);
      v_history.set_value('historyState', v_old_state);
      v_history_array.add_list_item(v_history);

      --设置节点数组中的申请人节点
      v_node := pl_json;
      v_node.set_value('nodeName', v_his_cur.node_name);
      v_node.set_value('nodeId', -1);
      v_node.set_value('nodeTypeName', '-');
      v_node.set_value('approverType',
                       dcld_comm_pkg.func_get_sys_msg(G_APPLY_NODE_NAME,
                                                      v_request.locale));
      v_nodes.add_list_item(v_node);
    END LOOP;

    --2.获取审批历史
    FOR v_his_cur IN v_history_cur LOOP
      --维护审批轨迹列表
      v_history := pl_json;
      v_history.set_value('approverType', v_his_cur.approver_type_name);
      IF v_his_cur.approver_type = 'ParameTricRole' AND
         v_his_cur.node_name != '申请人' THEN
        --查询所属角色
        select LISTAGG(to_char(dr.role_name), ',') WITHIN GROUP(ORDER BY dr.role_name) role_str
          into v_role_str
          from dbpm_role_members m, dbpm_roles dr
         where m.role_id = dr.role_id
           and upper(m.member_code) = upper(v_his_cur.approver_code);
        v_history.set_value('approverRoles', v_role_str);
      END IF;
      v_history.set_value('historyId', v_his_cur.history_id);
      v_history.set_value('nodeName', v_his_cur.node_name);
      v_history.set_value('nodeId', v_his_cur.node_id);
      --判断授权情况
      proc_get_reassign_user(v_his_cur.taskid,
                             v_his_cur.node_type,
                             v_from_user,
                             v_from_user_name);
      v_history.set_value('fromUser', v_from_user);
      v_history.set_value('fromUserName', v_from_user_name);
      v_history.set_value('approverCode', v_his_cur.approver_code);
      v_history.set_value('approverName', v_his_cur.approver_name);
      v_history.set_value('operation', v_his_cur.operation_name);
      v_history.set_value('comment', v_his_cur.comment_detail);
      v_history.set_value('assignedDate',
                          to_char(v_his_cur.creation_date,
                                  'YYYY-MM-DD HH24:MI:SS'));
      v_history.set_value('approvalDate',
                          to_char(v_his_cur.approve_date,
                                  'YYYY-MM-DD HH24:MI:SS'));
      v_history.set_value('historyState', v_old_state);
      --设置待办执行时间
      v_history.set_value('taskLiveDay',
                          round(v_his_cur.approve_date -
                                v_his_cur.creation_date));

      v_history_array.add_list_item(v_history);
      v_in_op_str    := v_in_op_str || ',' || v_his_cur.node_id;
      v_prev_outcome := v_his_cur.operation;
      v_prev_node_id := v_his_cur.node_id;
    END LOOP;

    --3.获取当前审批人
    FOR v_his_cur IN v_curr_approvers LOOP
      v_count := 1;
      --维护审批轨迹列表
      v_history := pl_json;
      v_history.set_value('approverType', v_his_cur.approver_type_name);
      IF v_his_cur.approver_type = 'ParameTricRole' AND
         v_his_cur.node_name != '申请人' THEN
        --查询所属角色
        select LISTAGG(to_char(dr.role_name), ',') WITHIN GROUP(ORDER BY dr.role_name) role_str
          into v_role_str
          from dbpm_role_members m, dbpm_roles dr
         where m.role_id = dr.role_id
           and upper(m.member_code) = upper(v_his_cur.approver_code);
        v_history.set_value('approverRoles', v_role_str);
      END IF;
      v_history.set_value('historyId', v_his_cur.history_id);
      v_history.set_value('nodeName', v_his_cur.node_name);
      v_history.set_value('nodeId', v_his_cur.node_id);
      --判断授权情况
      proc_get_reassign_user(v_his_cur.taskid,
                             v_his_cur.node_type,
                             v_from_user,
                             v_from_user_name);

      v_history.set_value('fromUser', v_from_user);
      v_history.set_value('fromUserName', v_from_user_name);
      v_history.set_value('approverCode', v_his_cur.approver_code);
      v_history.set_value('approverName', v_his_cur.approver_name);
      v_history.set_value('operation', v_his_cur.operation_name);
      v_history.set_value('comment', v_his_cur.comment_detail);
      v_history.set_value('assignedDate',
                          to_char(v_his_cur.creation_date,
                                  'YYYY-MM-DD HH24:MI:SS'));
      v_history.set_value('historyState', v_curr_state);
      --设置待办停留时间
      v_history.set_value('taskLiveDay',
                          round(sysdate - v_his_cur.creation_date));
      v_history_array.add_list_item(v_history);
      v_cur_node_id := v_his_cur.node_id;
      v_count       := v_count + 1;
    END LOOP;

    if v_cur_node_id is not null then
      v_in_op_str := v_in_op_str || ',' || v_cur_node_id;
      if v_cur_node_id = -1 then
        --当前节点是申请人节点，则无法查询出后续节点
        null;
      else
        SELECT CN.CHAIN_ID, CN.Version, CN.ORDER_NUM
          INTO v_chain_id, v_chain_version, v_cur_node_order
          FROM DBPM_CHAIN_NODES CN
         WHERE CN.NODE_ID = v_cur_node_id;
        --4.将后续节点也返回
        FOR V_NODE_CUR IN v_node_cursor(v_chain_id,
                                        v_chain_version,
                                        v_cur_node_order) LOOP
          --维护审批轨迹列表
          v_history := pl_json;
          v_history.set_value('nodeName', v_node_cur.node_name);
          v_history.set_value('nodeId', v_node_cur.node_id);
          v_history.set_value('approverType',
                              v_node_cur.approver_type_name);
          IF v_node_cur.approver_type = 'ParameTricRole' THEN
            select LISTAGG(to_char(r.role_name), ',') WITHIN GROUP(ORDER BY r.role_name)
              INTO v_role_str
              from dbpm_node_roles dr, dbpm_chain_nodes cn, dbpm_roles r
             where dr.node_id(+) = cn.node_id
               and dr.business_role = r.role_code(+)
               and cn.node_id = v_node_cur.node_id;
            v_history.set_value('approverRoles', v_role_str);
          END IF;
          v_history.set_value('historyState', v_new_state);
          v_history_array.add_list_item(v_history);
        END LOOP;
      end if;
    else
      --根据上一个节点预测当前节点
      begin
        v_cur_node_id := dbpm_comm_pkg.get_next_node_id(v_prev_node_id);
        select cn.node_name
          into v_cur_node_name
          from dbpm_chain_nodes cn
         where cn.node_id = v_cur_node_id;
      exception
        when others then
          v_cur_node_name := '';
      end;
      IF v_callback_context IN ('COMPLETED', 'CANCELED') THEN
        --没问题或者被取消了
        NULL;
      ELSIF v_callback_context = 'OPEN' THEN
        IF v_access_key != 'USER_TASK' THEN
          --有问题
          v_history := pl_json;
          v_history.set_value('nodeName', v_cur_node_name);
          v_history.set_value('nodeId', v_cur_node_id);
          v_history.set_value('historyState', v_err_state);
          v_history_array.add_list_item(v_history);
          NULL;
        END IF;
      ELSE
        --有问题
        v_history := pl_json;
        v_history.set_value('nodeName', v_cur_node_name);
        v_history.set_value('nodeId', v_cur_node_id);
        v_history.set_value('historyState', v_err_state);
        v_history_array.add_list_item(v_history);
        NULL;
      END IF;
    end if;
    --设置流程执行时间
    v_instance_live_day := dbpm_comm_pkg.func_instance_live_day(v_bpm_instance_id);
    /*IF v_callback_context IN ('COMPLETED', 'CANCELED') THEN
      --没问题或者被取消了
      v_instance_live_day := round(v_instance_update_date -
                                   v_instance_create_date);
    ELSE
      v_instance_live_day := round(sysdate - v_instance_create_date);
    END IF;*/
    v_response.set_value('instanceLiveDay', v_instance_live_day);

    v_response.set_value('history', v_history_array);

    --查询所有节点
    --构造sql
    v_get_chain_sql := 'select cn.chain_id,cn.version
     from dbpm_chain_nodes cn
    where cn.node_id in (' || v_in_op_str || ')
    group by cn.chain_id,cn.version';
    open v_chain_cursor for v_get_chain_sql;
    loop
      FETCH v_chain_cursor
        INTO v_chain_id, v_chain_version;
      EXIT WHEN v_chain_cursor%NOTFOUND;

      FOR V_NODE_CUR IN v_node_cursor(v_chain_id, v_chain_version, -1) LOOP
        v_node := pl_json;

        v_node.set_value('nodeName', v_node_cur.node_name);
        v_node.set_value('nodeId', v_node_cur.node_id);
        v_node.set_value('nodeTypeName', v_node_cur.node_type_name);
        v_node.set_value('approverType', v_node_cur.approver_type_name);
        IF v_node_cur.approver_type = 'ParameTricRole' THEN
          select LISTAGG(to_char(r.role_name), ',') WITHIN GROUP(ORDER BY r.role_name)
            INTO v_role_str
            from dbpm_node_roles dr, dbpm_chain_nodes cn, dbpm_roles r
           where dr.node_id(+) = cn.node_id
             and dr.business_role = r.role_code(+)
             and cn.node_id = v_node_cur.node_id;
          v_node.set_value('roleStr', v_role_str);
        END IF;
        v_nodes.add_list_item(v_node);
      END LOOP;
    end loop;
    close v_chain_cursor;

    v_response.set_value('nodes', v_nodes);
    x_response := v_response.to_json;
  END;

  /*==================================================
  Procedure/Function Name :
      proc_query_official_history
  Description:
      This function perform:
       查询流程官方的审批历史
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-05-17  wlj  Creation
  ==================================================*/
  PROCEDURE proc_query_official_history(p_request  IN CLOB,
                                        x_response OUT CLOB) AS
    v_request         json;
    v_response        pl_json := pl_json;
    v_history_json    pl_json;
    v_document_id     NUMBER;
    v_bpm_instance_id varchar2(100);
    v_creator         varchar2(100);
    v_create_date     varchar2(100);
    v_comment         varchar2(4000);

    --审批历史
    CURSOR v_history_cur IS
      SELECT '' history_id,
             t.taskid,
             t.protectednumberattribute1 node_id,
             (select cn.node_name
                from dbpm_chain_nodes cn
               where cn.node_id = t.protectednumberattribute1) node_name,
             T.Activityname activity_name,
             T.approvers approver_code,
             (SELECT E.EMPLOYEE_NAME
                FROM DFND_EMPLOYEES E
               WHERE UPPER(E.EMPLOYEE_CODE) = UPPER(T.approvers)) approver_name,
             T.outcome operation,
             (SELECT dcld_comm_pkg.get_data_source_value('DbpmApprovalOperation',
                                                         ddsv.value_code,
                                                         v_request.locale) value_name
                FROM dbpm_data_source_values ddsv
               WHERE ddsv.data_source_code = 'DbpmApprovalOperation'
                 AND ddsv.value_code = T.outcome) operation_name,
             wfc.wfcomment comment_detail,
             T.assigneddate creation_date,
             T.ENDDATE APPROVE_DATE
        from wftaskhistory T, wfcomments wfc
       where t.taskid = wfc.taskid(+)
         and T.instanceid = v_bpm_instance_id
         and T.STATE IS NULL
         and T.workflowpattern IN ('Participant', 'FYI')
       ORDER BY T.tasknumber, T.version ASC;
    --当前审批人
    CURSOR v_curr_approvers IS
      SELECT '' history_id,
             WF.taskid,
             WF.protectednumberattribute1 node_id,
             (select cn.node_name
                from dbpm_chain_nodes cn
               where cn.node_id = wf.protectednumberattribute1) node_name,
             wf.Activityname activity_name,
             ASS.ASSIGNEE approver_code,
             (SELECT E.EMPLOYEE_NAME
                FROM DFND_EMPLOYEES E
               WHERE UPPER(E.EMPLOYEE_CODE) = UPPER(ASS.ASSIGNEE)) approver_name,
             decode(wf.workflowpattern,
                    'FYI',
                    dcld_comm_pkg.func_get_sys_msg('FYI', v_request.locale),
                    dcld_comm_pkg.func_get_sys_msg(G_WAIT_OP,
                                                   v_request.locale)) operation,
             --decode(wf.workflowpattern,'FYI','FYI',G_WAIT_COMMENT) comment_detail,
             null            comment_detail,
             WF.assigneddate creation_date,
             WF.ENDDATE      APPROVE_DATE
        FROM WFTASK WF, WFASSIGNEE ASS
       WHERE WF.STATE IN ('ASSIGNED', 'INFO_REQUESTED')
         AND ASS.TASKID = WF.TASKID
         AND WF.INSTANCEID = v_bpm_instance_id
       ORDER BY WF.tasknumber, WF.version ASC;

    --申请人节点
    CURSOR v_applier_cursor IS
      SELECT '' history_id,
             '' taskid,
             wf.creator approver_code,
             '-1' node_id,
             dcld_comm_pkg.func_get_sys_msg(G_APPLY_NODE_NAME,
                                            v_request.locale) node_name,
             (SELECT E.EMPLOYEE_NAME
                FROM DFND_EMPLOYEES E
               WHERE UPPER(E.EMPLOYEE_CODE) = UPPER(wf.creator)) approver_name,
             dcld_comm_pkg.func_get_sys_msg(G_SUBMIT_OP, v_request.locale) operation,
             dcld_comm_pkg.func_get_sys_msg(G_APPLY_COMMENT,
                                            v_request.locale) comment_detail,
             '' creation_date,
             '' APPROVE_DATE
        FROM WFTASK WF
       WHERE WF.INSTANCEID = v_bpm_instance_id
         AND WF.CREATOR IS NOT NULL
         AND ROWNUM = 1
       ORDER BY WF.tasknumber, WF.version ASC;

  BEGIN
    v_request := json(p_request, 'OBJECT');
    --v_request     := json('{"instanceId":"470309"}');
    v_document_id := nvl(v_request.get_number('documentId'),
                         v_request.get_string('documentId'));
    v_response.set_value('documentId', v_document_id);
    v_bpm_instance_id := v_request.get_string('instanceId');
    --若未传入实例号，则通过单据号获取实例
    if v_bpm_instance_id IS NULL THEN
      BEGIN
        SELECT d.bpm_instance_id
          INTO v_bpm_instance_id
          FROM DBPM_DOCUMENTS D
         WHERE D.DOCUMENT_ID = v_document_id;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          v_response.fail('单据不存在');
          x_response := v_response.to_json;
          return;
      END;
    END IF;

    --查询流程实例ID
    IF v_bpm_instance_id IS NULL THEN
      SELECT D.Bpm_Instance_Id, d.doc_creator, d.creation_date
        INTO v_bpm_instance_id, v_creator, v_create_date
        FROM DBPM_DOCUMENTS D
       WHERE D.DOCUMENT_ID = v_document_id;
    END IF;

    --查询创建时间
    SELECT to_char(wf.createddate, 'YYYY-MM-DD HH24:MI:SS')
      INTO v_create_date
      FROM wftaskhistory WF
     WHERE WF.INSTANCEID = v_bpm_instance_id
       AND WF.STATE = 'OPEN'
       AND ROWNUM = 1
     ORDER BY WF.tasknumber, WF.version ASC;

    --添加一条申请人
    FOR v_history IN v_applier_cursor LOOP
      v_history_json := pl_json;
      v_history_json.set_value('historyId', v_history.history_id);
      v_history_json.set_value('nodeName', v_history.node_name);
      v_history_json.set_value('approverCode', v_history.approver_code);
      v_history_json.set_value('approverName', v_history.approver_name);
      v_history_json.set_value('operation', v_history.operation);
      v_history_json.set_value('comment', v_history.comment_detail);
      v_history_json.set_value('assignedDate', v_create_date);
      v_history_json.set_value('approvalDate', v_create_date);
      v_response.add_list_item('historyList', v_history_json);
    END LOOP;

    --审批历史
    FOR v_history IN v_history_cur LOOP
      v_history_json := pl_json;
      --update by xuy 2019.7.1 for SCI approve
      begin
        select his.his_comment_detail
          into v_comment
          from cux_bpm_approve_history his
         where his.his_taskid = v_history.taskid;
      exception
        when others then
          v_comment := null;
      end;
      if v_history.node_id = -1 then
        v_history_json.set_value('historyId', v_history.history_id);
        v_history_json.set_value('nodeName',
                                 dcld_comm_pkg.func_get_sys_msg(G_APPLY_NODE_NAME,
                                                                v_request.locale));
        v_history_json.set_value('approverCode', v_history.approver_code);
        v_history_json.set_value('approverName', v_history.approver_name);
        v_history_json.set_value('operation',
                                 dcld_comm_pkg.func_get_sys_msg(G_SUBMIT_OP,
                                                                v_request.locale));
        --v_history_json.set_value('comment', v_history.comment_detail);
        --update by xuy 2019.7.1 for SCI approve
        v_history_json.set_value('comment',
                                 nvl(v_history.comment_detail, v_comment));
        v_history_json.set_value('assignedDate',
                                 to_char(v_history.creation_date,
                                         'YYYY-MM-DD HH24:MI:SS'));
        v_history_json.set_value('approvalDate',
                                 to_char(v_history.approve_date,
                                         'YYYY-MM-DD HH24:MI:SS'));
      ELSE
        v_history_json.set_value('historyId', v_history.history_id);
        v_history_json.set_value('nodeName',
                                 nvl(v_history.node_name,
                                     v_history.activity_name));
        v_history_json.set_value('approverCode', v_history.approver_code);
        v_history_json.set_value('approverName', v_history.approver_name);
        v_history_json.set_value('operation', v_history.operation_name);
        --update by xuy 2019.7.1 for SCI approve
        v_history_json.set_value('comment',
                                 nvl(v_history.comment_detail, v_comment));
        v_history_json.set_value('assignedDate',
                                 to_char(v_history.creation_date,
                                         'YYYY-MM-DD HH24:MI:SS'));
        v_history_json.set_value('approvalDate',
                                 to_char(v_history.approve_date,
                                         'YYYY-MM-DD HH24:MI:SS'));
      end if;
      v_response.add_list_item('historyList', v_history_json);
    END LOOP;

    --当前审批人
    FOR v_history IN v_curr_approvers LOOP
      v_history_json := pl_json;
      if v_history.node_id = -1 then
        v_history_json.set_value('historyId', v_history.history_id);
        v_history_json.set_value('nodeName',
                                 dcld_comm_pkg.func_get_sys_msg(G_APPLY_NODE_NAME,
                                                                v_request.locale));
        v_history_json.set_value('approverCode', v_history.approver_code);
        v_history_json.set_value('approverName', v_history.approver_name);
        v_history_json.set_value('operation',
                                 dcld_comm_pkg.func_get_sys_msg(G_SUBMIT_OP,
                                                                v_request.locale));
        v_history_json.set_value('comment', v_history.comment_detail);
        v_history_json.set_value('assignedDate',
                                 to_char(v_history.creation_date,
                                         'YYYY-MM-DD HH24:MI:SS'));
        v_history_json.set_value('approvalDate',
                                 to_char(v_history.approve_date,
                                         'YYYY-MM-DD HH24:MI:SS'));
      ELSE
        v_history_json.set_value('historyId', v_history.history_id);
        v_history_json.set_value('nodeName',
                                 nvl(v_history.node_name,
                                     v_history.activity_name));
        v_history_json.set_value('approverCode', v_history.approver_code);
        v_history_json.set_value('approverName', v_history.approver_name);
        v_history_json.set_value('operation', v_history.operation);
        v_history_json.set_value('comment', v_history.comment_detail);
        v_history_json.set_value('assignedDate',
                                 to_char(v_history.creation_date,
                                         'YYYY-MM-DD HH24:MI:SS'));
        v_history_json.set_value('approvalDate',
                                 to_char(v_history.approve_date,
                                         'YYYY-MM-DD HH24:MI:SS'));
      END IF;
      v_response.add_list_item('historyList', v_history_json);
    END LOOP;
    x_response := v_response.to_json;
  END;

  /*==================================================
  Procedure/Function Name :
      func_get_reassign_user
  Description:
      This function perform:
       获取授权信息
  Argument:
     p_instance_id: 流程实例ID
     return : 重新分配的员工
  History:
      1.00  2018-05-25  wlj  Creation
  ==================================================*/
  PROCEDURE proc_get_reassign_user(p_task_id   varchar2,
                                   p_task_type varchar2,
                                   x_user      out varchar2,
                                   x_user_name out varchar2) as

  begin
    IF p_task_type = 'Single' THEN
      --protectedtextattribute7 这个字段是海尔用来标识fromuser的
      select distinct t.protectedtextattribute7
        into x_user
        from wftaskhistory T
       where t.taskid = p_task_id
         and t.customattributestring1 is not null;
    ELSE
      select t.fromuser
        into x_user
        from wftaskhistory T
       where t.taskid = p_task_id
         and t.substate = 'REASSIGNED';
    END IF;
    begin
      select e.employee_name
        into x_user_name
        from dfnd_employees e
       where e.employee_code = upper(x_user);
    exception
      when others then
        x_user_name := x_user;
    end;

  exception
    when others then
      x_user      := null;
      x_user_name := null;
  end;

end DBPM_PROCESS_HISTORY_PKG;

/

