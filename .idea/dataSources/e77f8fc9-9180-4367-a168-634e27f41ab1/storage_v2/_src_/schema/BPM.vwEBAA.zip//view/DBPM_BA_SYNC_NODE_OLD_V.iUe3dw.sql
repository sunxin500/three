create view DBPM_BA_SYNC_NODE_OLD_V as
select bpn.node_code,
       bpn.chain_code,
       bp.process_code,
       bp.id process_id,
       bpn.node_name,
       bpn.chain_node_seq order_num,
       bpn.create_date creation_date,
       bpn.last_update_date update_date,
       'bpm_process_node_conf' created_by,
       'bpm_process_node_conf' updated_by,
       bpn.id node_id
  from bpm_process_node_conf  bpn,
       bpm_process_def_conf   bp,
       bpm_process_chain_conf bpc
 where bpn.chain_code = bpc.chain_code
   and bpc.process_code = bp.process_code
   and bpn.chain_code = bpc.chain_code
   and bp.process_code not in
       (select t.process_code
          from bpm_process_chain_conf t
         where t.chain_name = '所有节点审批链')
union
select bpn.node_code,
       bpn.chain_code,
       bp.process_code,
       bp.id process_id,
       bpn.node_name,
       bpn.chain_node_seq order_num,
       bpn.create_date creation_date,
       bpn.last_update_date update_date,
       'bpm_process_node_conf' created_by,
       'bpm_process_node_conf' updated_by,
       bpn.id node_id
  from bpm_process_node_conf  bpn,
       bpm_process_def_conf   bp,
       bpm_process_chain_conf bpc
 where bpn.chain_code = bpc.chain_code
   and bpc.process_code = bp.process_code
   and bpn.chain_code = bpc.chain_code
   and bpc.chain_name = '所有节点审批链'
     
/

