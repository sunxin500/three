create trigger T$CUX_BPM_ALL_INSTANCE
    after insert or update or delete
    on CUX_BPM_ALL_INSTANCE
    for each row
declare
		V_FLAG	VARCHAR(1);
		V_INSTANCE_ID	NUMBER;
	begin
		if inserting then
			V_INSTANCE_ID := :new.INSTANCE_ID;
			V_FLAG := 'I';
		end if;
	
		if updating then
			V_INSTANCE_ID := :new.INSTANCE_ID;
			V_FLAG := 'I';
		end if;
	
		if deleting then
			V_INSTANCE_ID := :old.INSTANCE_ID;
			V_FLAG := 'D';
		end if;
	
		insert into BPM.J$CUX_BPM_ALL_INSTANCE
		(
			JRN_SUBSCRIBER,
			JRN_CONSUMED,
			JRN_FLAG,
			JRN_DATE,
			INSTANCE_ID
		)
		select	JRN_SUBSCRIBER,
			'0',
			V_FLAG,
			sysdate,
			V_INSTANCE_ID
		from	BPM.SNP_SUBSCRIBERS
		where	JRN_TNAME = 'BPM.CUX_BPM_ALL_INSTANCE'
		/* The following line can be uncommented for symetric replication */
		/* and	upper(USER) <> upper('bpm') */
		;
	end;

/

