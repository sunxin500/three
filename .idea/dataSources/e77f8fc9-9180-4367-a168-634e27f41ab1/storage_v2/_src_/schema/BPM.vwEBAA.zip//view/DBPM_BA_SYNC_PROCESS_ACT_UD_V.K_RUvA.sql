create view DBPM_BA_SYNC_PROCESS_ACT_UD_V as
select "ACTIVITY_TYPE","ACTIVITY_CODE","ACTIVITY_NAME","ACTIVITY_DESC","PROCESS_ID","PROCESS_CODE","ORDER_NUM","CREATION_DATE","UPDATE_DATE","CREATED_BY","UPDATED_BY","BPM_ACT_ID" from （
select 'USER_TASK' activity_type,
       (dp.process_code || '-' || nvl(dnr.business_role, dpn.approver_type)) activity_code,
       dpn.node_name activity_name,
       dpn.node_name activity_desc,
       dbp.process_id,
       dbp.process_code,
       dpn.order_num,
       dpn.creation_date,
       dpn.last_update_date update_date,
       'dbpm_process_nodes' created_by,
       'dbpm_process_nodes' updated_by,
       ('BPM' || dpn.node_id) bpm_act_id
  from dbpm_process_nodes dpn,
       dbpm_process       dp,
       dbpm_node_roles    dnr,
       dbpm_ba_process    dbp
 where dbp.attribute1 = 'BPM' || dp.process_id
   and dpn.process_id = dp.process_id
   and dpn.node_id = dnr.node_id(+)
   and dnr.node_from_type = 'ProcessNode'
union
select 'USER_TASK' activity_type,
       (dbp.process_code || '-' || v.node_code) activity_code,
       v.node_name activity_name,
       v.node_name activity_desc,
       dbp.process_id,
       dbp.process_code,
       to_number(v.order_num) order_num,
       v.creation_date,
       v.update_date,
       v.created_by,
       v.updated_by,
       ('dbpm' || v.node_id) bpm_act_id
  from DBPM_BA_SYNC_NODE_OLD_V v, dbpm_ba_process dbp
 where dbp.attribute1 = 'dbpm' || v.process_id
union
select bca.activitytype activity_type,
       bca.activityname activity_code,
       bca.label activity_name,
       bca.label activity_desc,
       dbp.process_id,
       dbp.process_code,
       null order_num,
       bcp.creationdate creation_date,
       bcp.lastupdated update_date,
       'bpm_cube_activity' created_by,
       'bpm_cube_activity' updated_by,
       ('obpm' || bca.activityid) bpm_act_id
  from bpm_cube_activity bca, bpm_cube_process bcp, dbpm_ba_process dbp
 where bcp.processid = bca.processid
   and dbp.attribute1 = 'obpm' || bcp.processid) v
   where  exists (select 1 from DBPM_BA_PROCESS_ACTIVITY da where da.activity_code=v.activity_code and da.process_id=v.process_id)
/

