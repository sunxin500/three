create view DBPM_BA_SYNC_APP_NEW_V as
select "APP_CODE","APP_NAME","APP_DESC","STATUS","OBJECT_VERSION_NUMBER","CREATE_BY","CREATE_DATE","LAST_UPDATE_BY","LAST_UPDATE_DATE"
  from (select sp.name app_code,
               sp.name app_name,
               '' app_desc,
               'Y' status,
               1 object_version_number,
               'sca_partion' create_by,
               sysdate create_date,
               'sca_partion' last_update_by,
               sysdate last_update_date
          from sca_partition sp
         where sp.name not in
               (select bpa.app_code from bpm_process_app_conf bpa)
        union
        select t.app_code,
               t.app_name,
               t.app_desc,
               case t.deleted
                 when 1 then
                  'N'
                 else
                  'Y'
               end status,
               t.object_version_number,
               NVL(t.create_by, 'bpm_process_app_conf'),
               nvl(t.create_date,sysdate),
               NVL(t.last_update_by, 'bpm_process_app_conf'),
               nvl(t.last_update_date,sysdate)
          from bpm_process_app_conf t) tt
 where not exists
 (select 1 from dfnd_app da where da.system_code = tt.app_code)
/

