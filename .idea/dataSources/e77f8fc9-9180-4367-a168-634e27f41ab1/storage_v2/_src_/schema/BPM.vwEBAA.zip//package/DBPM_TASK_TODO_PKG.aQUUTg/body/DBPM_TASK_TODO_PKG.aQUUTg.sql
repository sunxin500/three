create package body     DBPM_TASK_TODO_PKG is
  /*==================================================
  Procedure/Function Name :
      proc_save_todo_task
  Description:
      This function perform:
       维护第三方待办
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-05-10  wlj  Creation
  ==================================================*/
  PROCEDURE proc_save_todo_task(p_request IN CLOB, x_response OUT CLOB) as
    v_request                json;
    v_response               pl_json := pl_json;
    v_complete_list          json_list;
    v_complete_item          json;
    v_begin_list             json_list;
    v_begin_item             json;
    v_sys_code               varchar2(100);
    v_process_name           varchar2(3000);
    v_doc_number             varchar2(1000);
    v_assigneeDate           date;
    v_approveDate            date;
    v_createDate             date;
    v_outcome                varchar2(100);
    v_assignee               varchar2(100);
    v_taskId                 varchar2(300);
    v_title                  varchar2(4000);
    v_taskUrl                varchar2(4000);
    v_creator                varchar2(100);
    v_mobileViewUrl          varchar2(4000);
    v_exist_count            number;
    v_todo_flag              varchar2(10); --BOTH:推送两端/WEB:推送web/MOB:推送移动/NONE:不推送
    v_parent_sys_code        VARCHAR2(400); --主流程系统标识
    v_parent_process_name    VARCHAR2(4000); --主流程名称
    v_parent_document_number VARCHAR2(400); --  主流程单据号
    v_parent_title           VARCHAR2(4000); --  主流程标题
    v_approvers              VARCHAR2(400); --审批人
    v_process_code           VARCHAR2(100); --  流程编码
    v_parent_process_code    VARCHAR2(100); --  主流程编码
    v_df_task_id             varchar2(100); --主键
    v_df_sys_code            varchar2(10) := 'DF-'; --主键前缀,请勿修改,初始化表单时需要根据前缀判断
    v_mob_data_clob          clob; --移动端数据
  begin
    v_request  := json(p_request, 'OBJECT');
    v_sys_code := trim(v_request.get_string('sysCode'));
    --初始化clob
    dbms_lob.createtemporary(v_mob_data_clob, true);
    --校验业务系统编码是否存在
    SELECT COUNT(1)
      INTO v_exist_count
      FROM DBPM_PROCESS_REGISTRY R
     WHERE R.SYS_CODE = v_sys_code
       AND ROWNUM = 1;
    IF v_exist_count = 0 THEN
      --若不存在返回错误信息
      v_response.fail('未授权');
      x_response := v_response.to_json;
      return;
    END IF;
    --若存在则继续
    v_begin_list := json_list(v_request.get('begin'));
    for i in 1 .. v_begin_list.count loop
      v_begin_item := json(v_begin_list.get(i));

      v_process_name  := v_begin_item.get_string('processName');
      v_doc_number    := trim(v_begin_item.get_string('docNumber'));
      v_assigneeDate  := to_date(v_begin_item.get_string('assigneeDate'),
                                 'yyyy-mm-dd hh24:mi:ss');
      v_approveDate   := to_date(v_begin_item.get_string('approveDate'),
                                 'yyyy-mm-dd hh24:mi:ss');
      v_createDate    := to_date(v_begin_item.get_string('createDate'),
                                 'yyyy-mm-dd hh24:mi:ss');
      v_assignee      := trim(v_begin_item.get_string('assignee'));
      v_taskId        := trim(v_begin_item.get_string('taskId'));
      v_title         := trim(v_begin_item.get_string('title'));
      v_taskUrl       := trim(v_begin_item.get_string('taskUrl'));
      v_creator       := trim(v_begin_item.get_string('creator'));
      v_mobileViewUrl := trim(v_begin_item.get_string('mobileViewUrl'));

      v_todo_flag              := nvl(trim(v_begin_item.get_string('todoFlag')),
                                      'BOTH');
      v_parent_sys_code        := trim(v_begin_item.get_string('parentSysCode'));
      v_parent_process_name    := trim(v_begin_item.get_string('parentProcessName'));
      v_parent_document_number := trim(v_begin_item.get_string('parentDocNumber'));
      v_parent_title           := trim(v_begin_item.get_string('parentTitle'));
      v_parent_process_code    := trim(v_begin_item.get_string('parentProcessCode'));
      v_process_code           := trim(v_begin_item.get_string('processCode'));

      v_df_task_id := v_df_sys_code || sys_guid();
      IF v_parent_document_number IS NULL THEN
        v_parent_document_number := v_doc_number;
      END IF;

      MERGE INTO CUX_PROCESS_TODO T
      USING (SELECT v_taskId TASK_ID, v_sys_code SYS_CODE FROM DUAL) TMP
      ON (T.TASK_ID = TMP.TASK_ID AND T.SYS_CODE = TMP.SYS_CODE)
      WHEN MATCHED THEN
        UPDATE
           SET T.ASSIGNEE         = v_assignee,
               T.ASSIGNEDDATE     = v_assigneeDate,
               T.TITLE            = v_title,
               T.URL              = v_taskUrl,
               T.MOBILE_URL       = v_mobileViewUrl,
               t.last_update_date = sysdate
      WHEN NOT MATCHED THEN
        INSERT
          (TASK_ID,
           TITLE,
           CREATEDDATE,
           CREATOR,
           ASSIGNEE,
           ASSIGNEDDATE,
           DOCUMENT_NUMBER,
           URL,
           PROCESS_NAME,
           SYS_CODE,
           APPROVE_DATE,
           MOBILE_URL,
           TODO_FLAG,
           PARENT_SYS_CODE,
           PARENT_PROCESS_NAME,
           PARENT_DOCUMENT_NUMBER,
           PARENT_TITLE,
           PARENT_PROCESS_CODE,
           PROCESS_CODE,
           df_task_id)
        VALUES
          (v_taskId,
           v_title,
           v_createDate,
           v_creator,
           v_assignee,
           v_assigneeDate,
           v_doc_number,
           v_taskUrl,
           v_process_name,
           v_sys_code,
           v_approveDate,
           v_mobileViewUrl,
           v_todo_flag,
           v_parent_sys_code,
           v_parent_process_name,
           v_parent_document_number,
           v_parent_title,
           v_parent_process_code,
           v_process_code,
           v_df_task_id);

      --处理移动端：
      --如果TODO_FLAG为BOTH/MOB 并且有传入移动端数据，则维护进详情表
      if v_todo_flag IN ('BOTH', 'MOB') AND
         v_begin_item.exist('mobileData') AND
         v_begin_item.exist('mobileButtons') THEN

        v_begin_item.to_clob(v_mob_data_clob);
        MERGE INTO CUX_PROCESS_TODO_DETAIL T
        USING (SELECT DF_TASK_ID df_task_id FROM CUX_PROCESS_TODO td) TMP
        ON (T.DF_TASK_ID = TMP.DF_TASK_ID)
        WHEN MATCHED THEN
          UPDATE SET T.MOBILE_DATA = v_mob_data_clob
        WHEN NOT MATCHED THEN
          INSERT
            (df_task_id, mobile_data)
          VALUES
            (TMP.DF_TASK_ID, v_mob_data_clob);
      end if;
    end loop;

    --处理完成的待办
    v_complete_list := json_list(v_request.get('complete'));
    for j in 1 .. v_complete_list.count loop
      v_complete_item := json(v_complete_list.get(j));
      v_approveDate   := to_date(v_complete_item.get_string('approveDate'),
                                 'yyyy-mm-dd hh24:mi:ss');
      v_assignee      := trim(v_complete_item.get_string('assignee'));
      v_approvers     := trim(v_complete_item.get_string('approver'));
      v_taskId        := trim(v_complete_item.get_string('taskId'));
      v_outcome       := trim(v_complete_item.get('outcome').get_string);
      update cux_process_todo t
         set t.state            = 'PROCESSED',
             t.approve_date     = v_approveDate,
             t.last_update_date = sysdate,
             t.approvers        = v_approvers,
             t.outcome          = v_outcome
       where t.task_id = v_taskId
         and t.sys_code = v_sys_code;
    end loop;

    x_response := v_response.to_json;

  end;

  /*==================================================
  Procedure/Function Name :
      proc_merge_begin_task
  Description:
      This function perform:
       维护第三方待办
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-06-20  wlj  Creation
  ==================================================*/
  PROCEDURE proc_merge_begin_task(p_begin_item             clob,
                                  p_process_name           varchar2,
                                  p_doc_number             varchar2,
                                  p_assigneeDate           varchar2,
                                  p_approveDate            varchar2,
                                  p_createDate             varchar2,
                                  p_assignee               varchar2,
                                  p_taskId                 varchar2,
                                  p_title                  varchar2,
                                  p_taskUrl                varchar2,
                                  p_creator                varchar2,
                                  p_mobileViewUrl          varchar2,
                                  p_todo_flag              varchar2,
                                  p_parent_sys_code        varchar2,
                                  p_parent_process_name    varchar2,
                                  p_parent_document_number varchar2,
                                  p_parent_title           varchar2,
                                  p_parent_process_code    varchar2,
                                  p_process_code           varchar2,
                                  p_sys_code               varchar2,
                                  p_is_mob_data            varchar2) as
    v_sys_code               varchar2(100);
    v_process_name           varchar2(3000);
    v_doc_number             varchar2(1000);
    v_assigneeDate           date;
    v_approveDate            date;
    v_createDate             date;
    v_outcome                varchar2(100);
    v_assignee               varchar2(100);
    v_taskId                 varchar2(300);
    v_title                  varchar2(4000);
    v_taskUrl                varchar2(4000);
    v_creator                varchar2(100);
    v_mobileViewUrl          varchar2(4000);
    v_exist_count            number;
    v_todo_flag              varchar2(10); --BOTH:推送两端/WEB:推送web/MOB:推送移动/NONE:不推送
    v_parent_sys_code        VARCHAR2(400); --主流程系统标识
    v_parent_process_name    VARCHAR2(4000); --主流程名称
    v_parent_document_number VARCHAR2(400); --  主流程单据号
    v_parent_title           VARCHAR2(4000); --  主流程标题
    v_approvers              VARCHAR2(400); --审批人
    v_process_code           VARCHAR2(100); --  流程编码
    v_parent_process_code    VARCHAR2(100); --  主流程编码

    v_df_task_id  varchar2(100); --主键
    v_df_sys_code varchar2(10) := 'DF-'; --主键前缀,请勿修改,初始化表单时需要根据前缀判断

  begin
    --v_begin_item := json(p_begin_item);
    --x_result_flag := 'N';
    --初始化clob
    --dbms_lob.createtemporary(v_mob_data_clob, true);
    v_sys_code := trim(p_sys_code);
    --校验业务系统编码是否存在
    /*SELECT COUNT(1)
      INTO v_exist_count
      FROM DBPM_PROCESS_REGISTRY R
     WHERE R.SYS_CODE = v_sys_code
       AND ROWNUM = 1;
    IF v_exist_count = 0 THEN
      --若不存在返回错误信息
      --x_result_msg  := '未授权';
      --x_result_flag := 'N';
      RAISE_APPLICATION_ERROR('BPM-00001', '未授权');
      return;
    END IF;*/
    --若存在则继续

    v_df_task_id    := v_df_sys_code || sys_guid();
    v_process_name  := p_process_name;
    v_doc_number    := trim(p_doc_number);
    v_assigneeDate  := to_date(p_assigneeDate, 'yyyy-mm-dd hh24:mi:ss');
    v_approveDate   := to_date(p_approveDate, 'yyyy-mm-dd hh24:mi:ss');
    v_createDate    := to_date(p_createDate, 'yyyy-mm-dd hh24:mi:ss');
    v_assignee      := trim(p_assignee);
    v_taskId        := trim(p_taskId);
    v_title         := trim(p_title);
    v_taskUrl       := trim(p_taskUrl);
    v_creator       := trim(p_creator);
    v_mobileViewUrl := trim(p_mobileViewUrl);

    v_todo_flag              := nvl(trim(p_todo_flag), 'BOTH');
    v_parent_sys_code        := trim(p_parent_sys_code);
    v_parent_process_name    := trim(p_parent_process_name);
    v_parent_document_number := trim(p_parent_document_number);
    v_parent_title           := trim(p_parent_title);
    v_parent_process_code    := trim(p_parent_process_code);
    v_process_code           := trim(p_process_code);
    IF v_parent_document_number IS NULL THEN
      v_parent_document_number := v_doc_number;
    END IF;

    MERGE INTO CUX_PROCESS_TODO T
    USING (SELECT v_taskId TASK_ID, v_sys_code SYS_CODE FROM DUAL) TMP
    ON (T.TASK_ID = TMP.TASK_ID AND T.SYS_CODE = TMP.SYS_CODE)
    WHEN MATCHED THEN
      UPDATE
         SET T.ASSIGNEE         = v_assignee,
             T.ASSIGNEDDATE     = v_assigneeDate,
             T.TITLE            = v_title,
             T.URL              = v_taskUrl,
             T.MOBILE_URL       = v_mobileViewUrl,
             t.last_update_date = sysdate
    WHEN NOT MATCHED THEN
      INSERT
        (TASK_ID,
         TITLE,
         CREATEDDATE,
         CREATOR,
         ASSIGNEE,
         ASSIGNEDDATE,
         DOCUMENT_NUMBER,
         URL,
         PROCESS_NAME,
         SYS_CODE,
         APPROVE_DATE,
         MOBILE_URL,
         TODO_FLAG,
         PARENT_SYS_CODE,
         PARENT_PROCESS_NAME,
         PARENT_DOCUMENT_NUMBER,
         PARENT_TITLE,
         PARENT_PROCESS_CODE,
         PROCESS_CODE,
         df_task_id)
      VALUES
        (v_taskId,
         v_title,
         v_createDate,
         v_creator,
         v_assignee,
         v_assigneeDate,
         v_doc_number,
         v_taskUrl,
         v_process_name,
         v_sys_code,
         v_approveDate,
         v_mobileViewUrl,
         v_todo_flag,
         v_parent_sys_code,
         v_parent_process_name,
         v_parent_document_number,
         v_parent_title,
         v_parent_process_code,
         v_process_code,
         v_df_task_id);
    BEGIN
      select td.df_task_id
        into v_df_task_id
        from cux_process_todo td
       where td.sys_code = v_sys_code
         and td.task_id = v_taskId;
    EXCEPTION
      WHEN OTHERS THEN
        v_df_task_id := null;
    END;
    --处理移动端：
    --如果TODO_FLAG为BOTH/MOB 并且有传入移动端数据，则维护进详情表
    if v_todo_flag IN ('BOTH', 'MOB') AND p_is_mob_data = 'Y' AND
       v_df_task_id IS NOT NULL THEN
      MERGE INTO CUX_PROCESS_TODO_DETAIL T
      USING (SELECT v_df_task_id df_task_id FROM dual) TMP
      ON (T.DF_TASK_ID = TMP.DF_TASK_ID)
      WHEN MATCHED THEN
        UPDATE SET T.MOBILE_DATA = p_begin_item
      WHEN NOT MATCHED THEN
        INSERT
          (df_task_id, mobile_data)
        VALUES
          (TMP.DF_TASK_ID, p_begin_item);
    end if;
    --x_result_flag := 'Y';
  end;

  /*==================================================
  Procedure/Function Name :
      proc_merge_complete_task
  Description:
      This function perform:
       维护第三方已办
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-06-20  wlj  Creation
  ==================================================*/
  PROCEDURE proc_merge_complete_task(p_approveDate varchar2,
                                     p_approver    varchar2,
                                     p_taskId      varchar2,
                                     p_outcome     varchar2,
                                     p_sys_code    varchar2) AS
    v_sys_code    varchar2(100) := p_sys_code;
    v_approveDate date;
    v_outcome     varchar2(100);
    v_taskId      varchar2(300);
    v_approvers   VARCHAR2(400); --审批人
  BEGIN
    v_approveDate := to_date(p_approveDate, 'yyyy-mm-dd hh24:mi:ss');
    v_approvers   := trim(p_approver);
    v_taskId      := trim(p_taskId);
    v_outcome     := trim(p_outcome);
    update cux_process_todo t
       set t.state            = 'PROCESSED',
           t.approve_date     = v_approveDate,
           t.last_update_date = sysdate,
           t.approvers        = v_approvers,
           t.outcome          = v_outcome
     where t.task_id = v_taskId
       and t.sys_code = v_sys_code;
  END;

  /*==================================================
  Procedure/Function Name :
      proc_check_sys_code
  Description:
      This function perform:
       检查系统编码
  Argument:
  History:
      1.00  2018-06-29  wlj  Creation
  ==================================================*/
  PROCEDURE proc_check_sys_code(p_sys_code varchar2, x_flag out varchar2) as

  begin
    SELECT 'Y'
      INTO x_flag
      FROM DBPM_PROCESS_REGISTRY R
     WHERE R.SYS_CODE = p_sys_code
       AND ROWNUM = 1;
  EXCEPTION
    WHEN OTHERS THEN
      x_flag := 'N';
  end;

end DBPM_TASK_TODO_PKG;

/

