create PACKAGE BODY dfnd_organization_pkg IS

  /*
  Procedure Name :
        proc_add_organization
    Description:
        添加下级组织
    Argument:
        p_request：  请求（json）
        x_response： 响应（json）
    History:
        1.00  2017-03-20  chenming Creation
  */
  PROCEDURE proc_add_organization(p_request CLOB, x_response OUT CLOB)  IS
    v_api                    VARCHAR2(100) := 'proc_add_organization';
    v_request                json;
    v_response               pl_json := pl_json;
    v_current_user           VARCHAR2(50); --获取当前用户
    v_organization_name      VARCHAR2(100);
    v_parent_organization_id VARCHAR2(100);
    v_organization_id        VARCHAR2(100);
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;

    v_organization_name      := v_request.get('organizationName').get_string;
    v_parent_organization_id := v_request.get('parentOrganizationId')
                                .get_string;
    v_organization_id        := dfnd_organizations_s.nextval;
    INSERT INTO dfnd_organizations
      (organization_id,
       organization_code,
       organization_name,
       parent_organization_id,
       organization_status,
       created_by,
       last_updated_by)
    VALUES
      (v_organization_id,
       v_organization_id,
       v_organization_name,
       v_parent_organization_id,
       'Enabled',
       v_current_user,
       v_current_user);
    x_response := v_response.to_json;
    --commit;
    /*  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/

  END proc_add_organization;
  /*
  Procedure Name :
        proc_del_organization
    Description:
        删除当前组织及组织成员
    Argument:
        p_request：  请求（json）
        x_response： 响应（json）
    History:
        1.00  2017-03-20  chenming Creation
  */
  PROCEDURE proc_del_organization(p_request CLOB, x_response OUT CLOB) IS
    v_api             VARCHAR2(100) := 'proc_del_organization';
    v_request         json;
    v_response        pl_json := pl_json;
    v_organization_id VARCHAR2(100);
  BEGIN
    v_request := json(p_request, 'OBJECT');
    IF v_request.get('organizationId') IS NOT NULL THEN
      v_organization_id := v_request.get('organizationId').get_string;
    END IF;
    DELETE FROM dfnd_org_employees doe
     WHERE doe.organization_id = v_organization_id;
    DELETE FROM dfnd_organizations do
     WHERE do.organization_id = v_organization_id;
    x_response := v_response.to_json;
    /* EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_del_organization;
  /*
  Procedure Name :
        proc_add_emp_to_organization
    Description:
         在当前组织下添加人员
    Argument:
        p_request：  请求（json）
        x_response： 响应（json）
    History:
        1.00  2017-03-20  chenming Creation
  */
  PROCEDURE proc_add_emp_to_organization(p_request  CLOB,
                                         x_response OUT CLOB) IS
    v_api                    VARCHAR2(100) := 'proc_add_emp_to_organization';
    v_request                json;
    v_response               pl_json := pl_json;
    v_organization_id        VARCHAR2(100);
    v_user_code              VARCHAR2(100);
    v_is_master_organization VARCHAR(10);
    v_current_user           VARCHAR2(50); --获取当前用户
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;

    v_organization_id := v_request.get('organizationId').get_string;
    v_user_code       := v_request.get('user_code').get_string;
    IF v_request.get('is_master_organization') IS NULL THEN
      v_is_master_organization := 'N';
    ELSIF v_request.get('is_master_organization').get_bool THEN
      v_is_master_organization := 'Y';
    ELSE
      v_is_master_organization := 'N';
    END IF;
    INSERT INTO dfnd_org_employees
      (org_employee_id,
       organization_id,
       employee_code,
       enabled_flag,
       is_master_organization,
       created_by,
       last_updated_by)
    VALUES
      (dfnd_org_employees_s.nextval,
       v_organization_id,
       v_user_code,
       v_current_user,
       'Y',
       v_is_master_organization,
       v_current_user);
    x_response := v_response.to_json;
    /*  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_add_emp_to_organization;
  /*
  Procedure Name :
        proc_del_emp_from_organization
    Description:
         在当前组织下删除人员
    Argument:
        p_request：  请求（json）
        x_response： 响应（json）
    History:
        1.00  2017-03-20  chenming Creation
  */
  PROCEDURE proc_del_emp_from_organization(p_request  CLOB,
                                           x_response OUT CLOB) IS
    v_api             VARCHAR2(100) := 'proc_del_emp_to_organization';
    v_request         json;
    v_response        pl_json := pl_json;
    v_organization_id VARCHAR2(100);
    v_user_code       VARCHAR2(100);
  BEGIN
    v_request         := json(p_request, 'OBJECT');
    v_organization_id := v_request.get('organizationId').get_string;
    v_user_code       := v_request.get('user_code').get_string;
    DELETE FROM dfnd_org_employees doe
     WHERE v_organization_id = doe.organization_id
       AND upper(v_user_code) = upper(doe.employee_code);
    x_response := v_response.to_json;
    /*  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_del_emp_from_organization;
  /*
  Procedure Name :
        proc_query_organization_emps
    Description:
         查询某个组织下所有人员
    Argument:
        p_request：  请求（json）
        x_response： 响应（json）
    History:
        1.00  2017-03-20  chenming Creation
  */

  PROCEDURE proc_query_organization_emps(p_request  CLOB,
                                         x_response OUT CLOB) IS
    v_api             VARCHAR2(100) := 'proc_query_organization_emps';
    v_request         json;
    v_response        pl_json := pl_json;
    v_organization_id VARCHAR2(100);
    v_page            NUMBER;
    v_size            NUMBER;
    v_line            pl_json := pl_json;
    v_start_rownum    NUMBER;
    v_end_rownum      NUMBER;
    v_userlist        pl_json := pl_json;
    v_total           NUMBER;

    CURSOR v_orge_cur IS
      SELECT *
        FROM (SELECT dfoe.org_employee_id,
                     dfe.employee_code,
                     dfe.employee_name,
                     dfe.phone,
                     dfe.email,
                     dfoe.is_master_organization,
                     rownum AS rowno
                FROM dfnd_employees dfe, dfnd_org_employees dfoe
               WHERE upper(dfe.employee_code) = upper(dfoe.employee_code)
                 AND dfoe.organization_id = v_organization_id
               ORDER BY dfoe.org_employee_id)
       WHERE rowno BETWEEN v_start_rownum AND v_end_rownum;
  BEGIN
    v_request         := json(p_request, 'OBJECT');
    v_organization_id := v_request.get('organizationId').get_string;
    v_page            := nvl(v_request.get('page').get_number, 1);
    v_size            := nvl(v_request.get('size').get_number, 25);
    IF v_page = 1 THEN
      v_start_rownum := v_page;
    ELSE
      v_start_rownum := (v_page - 1) * v_size;
    END IF;
    v_end_rownum := v_start_rownum + v_size;

    FOR v_orge IN v_orge_cur LOOP
      v_line := pl_json;
      v_line.set_value('userId', v_orge.org_employee_id);
      v_line.set_value('userCode', v_orge.employee_code);
      v_line.set_value('userName', v_orge.employee_name);
      v_line.set_value('userPhone', v_orge.phone);
      v_line.set_value('userEmail', v_orge.email);
      IF v_orge.is_master_organization = 'Y' THEN
        v_line.set_value('isMasterOrganization', TRUE);
      ELSE
        v_line.set_value('isMasterOrganization', FALSE);
      END IF;
      v_userlist.add_list_item('userList', v_line);
    END LOOP;
    SELECT COUNT(*) INTO v_total FROM dfnd_org_employees;
    v_response := v_userlist;
    v_response.set_value('totalEmp', v_total);
    x_response := v_response.to_json;
    /* EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_query_organization_emps;
  /*
  Procedure Name :
        proc_add_organization
    Description:
        更新当前组织信息
    Argument:
        p_request：  请求（json）
        x_response： 响应（json）
    History:
        1.00  2017-03-20  chenming Creation
  */
  PROCEDURE proc_update_organization(p_request CLOB, x_response OUT CLOB) IS
    v_api               VARCHAR2(100) := 'proc_update_organization';
    v_request           json;
    v_response          pl_json := pl_json;
    v_current_user      VARCHAR2(50); --获取当前用户
    v_organization_name VARCHAR2(100);
    v_organization_id   VARCHAR2(100);
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;

    v_organization_id   := v_request.get('organizationId').get_string;
    v_organization_name := v_request.get('organizationName').get_string;
    UPDATE dfnd_organizations do
       SET do.organization_id   = v_organization_id,
           do.organization_name = v_organization_name,
           do.last_updated_by   = v_current_user
     WHERE do.organization_id = v_organization_id;
    x_response := v_response.to_json;

    /*EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/

  END proc_update_organization;

  /*
  Procedure Name :
        proc_query_all_organizations
    Description:
         查询组织信息
    Argument:
        p_request：  请求（json）
        x_response： 响应（json）
    History:
        1.00  2017-03-20  chenming Creation
  */

  FUNCTION query_all(p_organization_id   VARCHAR2,
                     p_organization_name VARCHAR2) RETURN pl_json IS

    v_orglist pl_json := pl_json;
    v_temp    pl_json := pl_json;
    --v_total                  NUMBER := 0;
    v_organization_id        VARCHAR2(100);
    v_organization_code      VARCHAR2(100);
    v_organization_name      VARCHAR2(500);
    v_parent_organization_id VARCHAR2(100);

    --获取org_id这个组织下面的子组织数组
    CURSOR v_qurall_cur IS
      SELECT *
        FROM dfnd_organizations do
       WHERE do.parent_organization_id = p_organization_id;
    --ORDER BY do.order_num;
  BEGIN
    SELECT do.organization_id,
           do.organization_code,
           do.organization_name,
           do.parent_organization_id
      INTO v_organization_id,
           v_organization_code,
           v_organization_name,
           v_parent_organization_id
      FROM dfnd_organizations do
     WHERE do.organization_id = p_organization_id;
    v_orglist.set_value('organizationId', v_organization_id);
    v_orglist.set_value('organizationCode', v_organization_code);
    v_orglist.set_value('organizationName', v_organization_name);
    v_orglist.set_value('parentOrganizationId', v_parent_organization_id);
    v_orglist.set_value('parentOrganizationName', p_organization_name);

    FOR v_qurall IN v_qurall_cur LOOP
      v_temp := query_all(v_qurall.organization_id, v_organization_name);
      v_orglist.add_list_item('childOrganizations', v_temp);
    END LOOP;

    RETURN v_orglist;
  END query_all;

  PROCEDURE proc_query_all_organizations(p_request  CLOB,
                                         x_response OUT CLOB) IS
    v_api               VARCHAR2(100) := 'proc_query_all_organizations';
    v_response          pl_json := pl_json;
    v_temp              pl_json;
    v_orglist           pl_json := pl_json;
    v_organization_id   VARCHAR2(100);
    v_organization_name VARCHAR2(500);
  BEGIN
    SELECT do.organization_id, do.organization_name
      INTO v_organization_id, v_organization_name
      FROM dfnd_organizations do
     WHERE do.parent_organization_id IS NULL;
    v_temp := query_all(v_organization_id, v_organization_name);
    v_orglist.set_value('orgList', v_temp);
    x_response := v_orglist.to_json;
    /*  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_query_all_organizations;

  /*
  Procedure Name :
        proc_save_org_employees
    Description:
        保存组织的分配人员信息
    Argument:
        p_request：  请求（json）
        x_response： 响应（json）
    History:
        1.00  2017-0４-2８  skycloud.wang Creation
  */
  PROCEDURE proc_save_org_employees(p_request CLOB, x_response OUT CLOB) IS
    v_request                json;
    v_response               pl_json := pl_json;
    v_user_list              json_list;
    v_user                   json;
    v_is_master_organization VARCHAR2(10);
    v_current_user           VARCHAR2(50); --获取当前用户
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;

    v_user_list := json_list(v_request.path('userList'));
    FOR i IN 1 .. v_user_list.count LOOP
      v_user := json(v_user_list.get(i));
      IF v_user.get('isMasterOrganization') IS NULL THEN
        v_is_master_organization := 'N';
      ELSIF v_user.get('isMasterOrganization').get_bool THEN
        v_is_master_organization := 'Y';
      ELSE
        v_is_master_organization := 'N';
      END IF;

      UPDATE dfnd_org_employees foe
         SET foe.is_master_organization = v_is_master_organization,
             foe.last_updated_by        = v_current_user
       WHERE foe.organization_id = v_user.get('organizationId').get_string
         AND upper(foe.employee_code) = upper(v_user.get('userCode').get_string);
    END LOOP;

    x_response := v_response.to_json;
  END proc_save_org_employees;

END dfnd_organization_pkg;

/

