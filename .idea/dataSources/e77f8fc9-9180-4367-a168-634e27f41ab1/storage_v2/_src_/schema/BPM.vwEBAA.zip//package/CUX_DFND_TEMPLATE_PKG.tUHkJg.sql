create package     cux_dfnd_template_pkg is

  -- Author  : CZB
  -- Created : 2017/11/6 9:29:08
  -- Purpose :

  procedure generate_template_post_data(p_document_id   in number,
                                        p_template_code in varchar2,
                                        x_out_flag      out varchar2,
                                        x_out_json      out clob);

  /*

  获取所有的表单配置信息（包括审批历史）

  */
  procedure proc_query_form_field_config(p_request  in clob,
                                         x_response out clob);
  procedure query_template_detail(p_request in clob, x_response out clob);
  /*

  获取模板列表

  */
  procedure proc_get_template_list(p_request in clob, x_response out clob);
     /*

  获取模板参数示例

  */
  procedure proc_get_template_sample(p_request in clob, x_response out clob);

  /*
  删除模板
  */
  procedure proc_del_template(p_request in clob, x_response out clob);

  /*
  保存模板配置
  */
  procedure proc_update_template(p_request in clob, x_response out clob);


end cux_dfnd_template_pkg;

/

