create PACKAGE BODY     dbpm_document_sequences_pkg IS

  /*==================================================
  Copyright (C) Deloitte Consulting(Shanghai) Co. Ltd.
             AllRights Reserved
  ==================================================*/
  /*==================================================
  Program Name:
      dbpm_document_sequences_pkg
  Description:
      This program provide public API to perform:
        通用单据编号
  History:
      1.00  2017-05-12  skycloud.wang  Creation
  ==================================================*/

  --获取消息，可以不在开发员职责里面定义
  FUNCTION proc_get_message(p_message_code IN VARCHAR2) RETURN VARCHAR2 IS
    l_message VARCHAR2(400);
  BEGIN
    IF l_message = p_message_code OR l_message IS NULL THEN
      IF p_message_code = 'SEQ_TYPE_NOB_BE_NULL' THEN
        l_message := '单据类型不能为空。';
      ELSIF p_message_code = 'SEQ_START_NOT_BE_GREATER' THEN
        l_message := '开始序列号不能比结束序列号小。';
      ELSIF p_message_code = 'SEQ_POSITIVE_INT_REQUIRED' THEN
        l_message := '开始序列号和结束序列号必须都为正整数。';
      ELSIF p_message_code = 'SEQ_SEQUENCE_OVERFLOW' THEN
        l_message := '序列号超过最大数了。';
      ELSIF p_message_code = 'SEQ_SEQUENCE_LOCKED' THEN
        l_message := '序列号锁定，请稍候重试。';
      END IF;
    END IF;
    RETURN l_message;
  END proc_get_message;

  --取得条码的下一个流水号
  PROCEDURE proc_get_sequence(x_next_sequence  OUT NUMBER, --下一个序列号
                              x_return_message OUT NOCOPY VARCHAR2, --错误消息
                              p_document_type  IN VARCHAR2, --单据类型
                              p_date_code      IN VARCHAR2 -- 日期编码
                              ) IS

    l_start_sequence NUMBER;
    l_end_sequence   NUMBER;
    resour_busy EXCEPTION;
    PRAGMA EXCEPTION_INIT(resour_busy, -00054);

  BEGIN

    --序列类型不能为空
    IF p_document_type IS NULL THEN
      x_return_message := proc_get_message('SEQ_TYPE_NOB_BE_NULL');
      RETURN;
    END IF;

    --验证完参数，再执行
    SELECT dds.start_sequence, dds.end_sequence, dds.next_sequence
      INTO l_start_sequence, l_end_sequence, x_next_sequence
      FROM BPM.dbpm_document_sequences dds
     WHERE dds.document_type = p_document_type
       AND nvl(dds.date_code, 'NONE') = nvl(p_date_code, 'NONE')
       FOR UPDATE OF dds.next_sequence NOWAIT;

    IF l_start_sequence > x_next_sequence THEN
      x_next_sequence := l_start_sequence;
    END IF;

    IF x_next_sequence > l_end_sequence THEN
      x_return_message := proc_get_message('SEQ_SEQUENCE_OVERFLOW');
      RETURN;
    END IF;

    UPDATE BPM.dbpm_document_sequences dds
       SET dds.next_sequence = x_next_sequence + 1
     WHERE dds.document_type = p_document_type;

  EXCEPTION
    WHEN no_data_found THEN
      x_next_sequence := 1;
      UPDATE BPM.dbpm_document_sequences dds
         SET dds.start_sequence = 1,
             dds.next_sequence  = x_next_sequence + 1,
             dds.date_code      = p_date_code
       WHERE dds.document_type = p_document_type;
    WHEN resour_busy THEN
      x_return_message := proc_get_message('SEQ_SEQUENCE_LOCKED');
  END proc_get_sequence;

  --取下一单据号
PROCEDURE proc_get_doc_number(p_document_type   IN VARCHAR2, --单据类型
                              x_document_number OUT VARCHAR2, --单据编号
                              x_return_message  OUT NOCOPY VARCHAR2 --错误消息
                              ) IS
  v_next_sequence NUMBER;
  v_seq_length    NUMBER;
  v_prefix        VARCHAR2(30);
  v_suffix        VARCHAR2(30);
  /*    v_is_clear_day   VARCHAR2(30) := 'N';
  v_is_clear_month VARCHAR2(30) := 'N';
  v_is_clear_year  VARCHAR2(30) := 'N';*/
  v_date_code     VARCHAR2(30);
  v_clear_flag    varchar2(100);
  v_document_type VARCHAR2(4000);
BEGIN
  v_document_type := p_document_type;
  BEGIN
    SELECT /*dds.is_clear_day,
                         dds.is_clear_month,
                         dds.is_clear_year,*/
     dds.clear_flag, dds.sequence_length, dds.prefix, dds.suffix
      INTO /*v_is_clear_day,
           v_is_clear_month,
           v_is_clear_year,*/ v_clear_flag,
           v_seq_length,
           v_prefix,
           v_suffix
      FROM BPM.dbpm_document_sequences dds
     WHERE dds.document_type = v_document_type;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      v_document_type := 'REQ';
      SELECT dds.clear_flag, dds.sequence_length, dds.prefix, dds.suffix
        INTO v_clear_flag, v_seq_length, v_prefix, v_suffix
        FROM BPM.dbpm_document_sequences dds
       WHERE dds.document_type = v_document_type;
  END;
  /*    IF v_is_clear_day = 'Y' THEN
    v_date_code := to_char(SYSDATE, 'YYYYMMDD');
  ELSIF v_is_clear_month = 'Y' THEN
    v_date_code := to_char(SYSDATE, 'YYYYMM');
  ELSIF v_is_clear_year = 'Y' THEN
    v_date_code := to_char(SYSDATE, 'YYYY');
  ELSE
    v_date_code := '';
  END IF;*/
  IF v_clear_flag = 'DAY' THEN
    v_date_code := to_char(SYSDATE, 'YYYYMMDD');
  ELSIF v_clear_flag = 'MONTH' THEN
    v_date_code := to_char(SYSDATE, 'YYYYMM');
  ELSIF v_clear_flag = 'YEAR' THEN
    v_date_code := to_char(SYSDATE, 'YYYY');
  ELSE
    v_date_code := '';
  END IF;

  proc_get_sequence(x_next_sequence  => v_next_sequence,
                    x_return_message => x_return_message,
                    p_document_type  => v_document_type,
                    p_date_code      => v_date_code);

  IF x_return_message IS NOT NULL THEN
    RETURN;
  END IF;
  x_document_number := v_prefix || v_date_code ||
                       lpad(v_next_sequence, v_seq_length, '0') || v_suffix;

EXCEPTION
  WHEN OTHERS THEN
    x_return_message := SQLERRM;
END proc_get_doc_number;

END dbpm_document_sequences_pkg;

/

