create function     str2numList123( p_string in varchar2 ) return
          varTableType
           as
           v_str long default p_string || ',';
           v_n number;
           v_data varTableType := varTableType();
           begin
           loop
          v_n := to_number(instr( v_str, ',' ));
          exit when (nvl(v_n,0) = 0);
          v_data.extend;
          v_data( v_data.count ) := ltrim(rtrim(substr(v_str,1,v_n-1)));
          v_str := substr( v_str, v_n+1 );
          end loop;
          dbms_output.put_line(v_data(1));
          return v_data;
          end;

/

