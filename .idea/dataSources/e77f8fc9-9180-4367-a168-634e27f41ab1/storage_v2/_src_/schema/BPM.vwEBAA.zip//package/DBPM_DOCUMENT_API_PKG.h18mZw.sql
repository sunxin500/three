create PACKAGE dbpm_document_api_pkg IS

  /*==================================================
  Procedure/Function Name :
      proc_create_document_data
  Description:
      This function perform:
      保存表单数据，需要判断是新建还更新
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-07  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_create_document_data(p_request CLOB, x_response OUT CLOB);

  /*
  * 进入表单详细时，初始化数据
  */
  PROCEDURE proc_init_form_detail(p_request CLOB, x_response OUT CLOB);

  /*
  * 进入表单详细时，初始化第三方数据
  */
  PROCEDURE proc_init_form_detail_ext(p_request CLOB, x_response OUT CLOB);

END dbpm_document_api_pkg;

/

