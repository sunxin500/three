create PACKAGE     dbpm_process_admins_pkg IS

  /*==================================================
  Procedure/Function Name :
      proc_query_admins
  Description:
      This function perform:
      查询员工信息（用户名，用户Code，部门名，部门ID）
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-09-29  张俊强~  Creation
  ==================================================*/
  PROCEDURE proc_query_emp_org(p_request  IN CLOB,
                               x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_query_admins
  Description:
      This function perform:
      查询Admin信息
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-09-29  张俊强~  Creation
  ==================================================*/
  PROCEDURE proc_query_admins(p_request  IN CLOB,
                              x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_insert_admins
  Description:
      This function perform:
      插入员工信息到管理员表中去
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-09-29  张俊强~  Creation
  ==================================================*/
  PROCEDURE proc_insert_admins(p_request  IN CLOB,
                               x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_delete_admins
  Description:
      This function perform:
      删除一条管理员信息
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-09-29  张俊强~  Creation
  ==================================================*/
  PROCEDURE proc_delete_admins(p_request  IN CLOB,
                               x_response OUT CLOB);



END dbpm_process_admins_pkg;

/

