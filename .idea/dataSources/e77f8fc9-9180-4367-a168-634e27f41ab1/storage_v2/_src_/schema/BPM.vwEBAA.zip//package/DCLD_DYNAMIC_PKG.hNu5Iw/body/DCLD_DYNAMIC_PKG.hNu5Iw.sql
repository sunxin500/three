create PACKAGE BODY     dcld_dynamic_pkg IS

  /*==================================================
  Procedure/Function Name :
      proc_query_dynamic_list
  Description:
      This function perform:
      查询所有动态（我的动态和我好友的动态）
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-03-13  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_query_dynamic_list(p_request CLOB, x_response OUT CLOB) IS
    v_request         json;
    v_response        pl_json := pl_json;
    v_current_user    VARCHAR2(50); --获取当前用户
    v_dynamic_json    pl_json;
    v_dynamic_detail  pl_json;
    v_dynamic_comment pl_json;
    v_dynamic_id      NUMBER;
    v_query_model     VARCHAR2(100);
    v_sql             VARCHAR2(4000);
    cur_dynamic       SYS_REFCURSOR;
    v_dynamic         dcld_dynamic%ROWTYPE;
    v_count           NUMBER := 0;

    CURSOR v_dynamic_comment_cur IS
      SELECT ddc.*
        FROM dcld_dynamic_comment ddc
       WHERE ddc.dynamic_id = v_dynamic_id;
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;

    v_query_model := nvl(v_request.get('queryModel').get_string, 'ALL');
    IF v_query_model = 'ALL' THEN
      -- 全部动态
      v_sql := 'SELECT dd.* FROM dcld_dynamic dd, dcld_my_frineds dmf WHERE dd.owner = dmf.friend_user_code AND dmf.my_user_code = ''' ||
               v_current_user || '''';
    ELSIF v_query_model = 'MY' THEN
      -- 我的动态
      v_sql := 'SELECT dd.* FROM dcld_dynamic dd where dd.owner = ''' ||
               v_current_user || '''';
    ELSIF v_query_model = 'COLLECT' THEN
      -- 收藏动态
      v_sql := 'SELECT dd.* FROM dcld_dynamic dd, dcld_dynamic_collect ddc WHERE dd.dynamic_id = ddc.dynamic_id AND ddc.user_code = ''' ||
               v_current_user || '''';
    END IF;

    OPEN cur_dynamic FOR v_sql;
    LOOP
      FETCH cur_dynamic
        INTO v_dynamic;
      EXIT WHEN cur_dynamic%NOTFOUND;
      v_count          := v_count + 1;
      v_dynamic_json   := pl_json;
      v_dynamic_detail := pl_json;
      v_dynamic_json.set_value('id', v_dynamic.dynamic_id);
      v_dynamic_json.set_value('created', v_dynamic.created_by);
      v_dynamic_json.set_value('avatar', ' ');
      v_dynamic_json.set_value('content', v_dynamic.content);
      v_dynamic_json.set_value('datetime',
                               to_char(v_dynamic.creation_date,
                                       'YYYY-MM-DD HH24:MI:SS'));
      v_dynamic_detail.set_value('collection', v_dynamic.collect_count);
      v_dynamic_detail.set_value('like', v_dynamic.praise_count);
      v_dynamic_detail.set_value('comment', v_dynamic.comment_count);
      v_dynamic_detail.set_value('forwarding', ' '); -- TODO
      v_dynamic_json.set_value('detail', v_dynamic_detail);

      v_dynamic_id := v_dynamic.dynamic_id;
      FOR v_comment IN v_dynamic_comment_cur LOOP
        v_dynamic_comment := pl_json;
        v_dynamic_comment.set_value('id', v_comment.comment_id);
        v_dynamic_comment.set_value('from', v_comment.reply_from);
        v_dynamic_comment.set_value('to', v_comment.reply_to);
        v_dynamic_comment.set_value('content', v_comment.content);
        v_dynamic_comment.set_value('datetime',
                                    to_char(v_comment.creation_date,
                                            'YYYY-MM-DD HH24:MI:SS'));
        v_dynamic_json.add_list_item('reply', v_dynamic_comment);
      END LOOP;
      v_response.add_list_item('data', v_dynamic_json);
    END LOOP;
    v_response.set_value('count', v_count);
    x_response := v_response.to_json;
  END proc_query_dynamic_list;

  /*==================================================
  Procedure/Function Name :
      proc_add_dynamic
  Description:
      This function perform:
      发起动态
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-03-13  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_add_dynamic(p_request CLOB, x_response OUT CLOB) IS
    v_api          VARCHAR2(100) := 'proc_add_dynamic';
    v_request      json;
    v_response     pl_json := pl_json;
    v_current_user VARCHAR2(50); --获取当前用户
    v_content      CLOB;
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;

    v_content := v_request.get('content').get_string;

    INSERT INTO dcld_dynamic
      (dynamic_id, owner, content, created_by, last_updated_by)
    VALUES
      (dcld_dynamic_s.nextval,
       v_current_user,
       v_content,
       v_current_user,
       v_current_user);
    x_response := v_response.to_json;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;
  END proc_add_dynamic;

  /*==================================================
  Procedure/Function Name :
      proc_add_dynamic_comment
  Description:
      This function perform:
      发起动态评论
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-03-15  chenming  Creation
  ==================================================*/
  PROCEDURE proc_add_dynamic_comment(p_request CLOB, x_response OUT CLOB) IS
    v_api          VARCHAR2(100) := 'proc_add_dynamic_comment';
    v_request      json;
    v_response     pl_json := pl_json;
    v_current_user VARCHAR2(50); --获取当前用户
    v_content      CLOB;
    v_reply_to     VARCHAR(100);
    v_dynamic_id   NUMBER;
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;

    v_content := v_request.get('content').get_string;
    IF v_request.get('replyTo') IS NOT NULL THEN
      v_reply_to := v_request.get('replyTo').get_string;
    END IF;

    v_dynamic_id := v_request.get('dynamicId').get_number;
    INSERT INTO dcld_dynamic_comment
      (comment_id, dynamic_id, reply_from, content, reply_to)
    VALUES
      (dcld_dynamic_comment_s.nextval,
       v_dynamic_id,
       v_current_user,
       v_content,
       v_reply_to);
    x_response := v_response.to_json;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;
  END proc_add_dynamic_comment;

  /*==================================================
  Procedure/Function Name :
      proc_dynamic_praise
  Description:
      This function perform:
      给动态点赞
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-03-13  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_dynamic_praise(p_request CLOB, x_response OUT CLOB) IS
    v_api          VARCHAR2(100) := 'proc_dynamic_praise';
    v_request      json;
    v_response     pl_json := pl_json;
    v_current_user VARCHAR2(50); --获取当前用户
    v_dynamic_id   NUMBER;
    v_count        NUMBER;
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;

    v_dynamic_id := v_request.get('dynamicId').get_number;
    SELECT COUNT(1)
      INTO v_count
      FROM dcld_dynamic_praise ddp
     WHERE ddp.dynamic_id = v_dynamic_id
       AND ddp.user_code = v_current_user;

    IF v_count = 0 THEN
      INSERT INTO dcld_dynamic_praise
        (dynamic_id, user_code, created_by, last_updated_by)
      VALUES
        (v_dynamic_id, v_current_user, v_current_user, v_current_user);
      UPDATE dcld_dynamic dd
         SET dd.praise_count = dd.praise_count + 1
       WHERE dd.dynamic_id = v_dynamic_id;
    ELSE
      DELETE FROM dcld_dynamic_praise ddp
       WHERE ddp.dynamic_id = v_dynamic_id
         AND ddp.user_code = v_current_user;
      UPDATE dcld_dynamic dd
         SET dd.praise_count = dd.praise_count - 1
       WHERE dd.dynamic_id = v_dynamic_id;
    END IF;

    x_response := v_response.to_json;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;
  END proc_dynamic_praise;

  /*==================================================
  Procedure/Function Name :
      proc_dynamic_collect
  Description:
      This function perform:
      收藏动态
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-03-13  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_dynamic_collect(p_request CLOB, x_response OUT CLOB) IS
    v_api          VARCHAR2(100) := 'proc_dynamic_collect';
    v_request      json;
    v_response     pl_json := pl_json;
    v_current_user VARCHAR2(50); --获取当前用户
    v_dynamic_id   NUMBER;
    v_count        NUMBER;
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;

    v_dynamic_id := v_request.get('dynamicId').get_number;
    SELECT COUNT(1)
      INTO v_count
      FROM dcld_dynamic_collect ddc
     WHERE ddc.dynamic_id = v_dynamic_id
       AND ddc.user_code = v_current_user;

    IF v_count = 0 THEN
      INSERT INTO dcld_dynamic_collect
        (dynamic_id, user_code, created_by, last_updated_by)
      VALUES
        (v_dynamic_id, v_current_user, v_current_user, v_current_user);
      UPDATE dcld_dynamic dd
         SET dd.collect_count = dd.collect_count + 1
       WHERE dd.dynamic_id = v_dynamic_id;
    ELSE
      DELETE FROM dcld_dynamic_collect ddc
       WHERE ddc.dynamic_id = v_dynamic_id
         AND ddc.user_code = v_current_user;
      UPDATE dcld_dynamic dd
         SET dd.collect_count = dd.praise_count - 1
       WHERE dd.dynamic_id = v_dynamic_id;
    END IF;

    x_response := v_response.to_json;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;
  END proc_dynamic_collect;

END dcld_dynamic_pkg;

/

