create package body     dbpm_expire_rule_pkg is

  /*
    获得需要执行预警的实例
  */
  procedure get_instances_for_warning(p_remark in varchar2) is
    ---找出有预警规则的流程
    cursor v_processid_cur is
      select distinct t.process_code, t.rule_uuid, t.deloy_day
        from dbpm_process_expire_rule t
       where t.start_time < sysdate
         and t.end_time > sysdate
         and t.status = 'Y'
            --and t.param_name = 'DELOY_DAY'
         and t.rule_type = 'INSTANCE';
    -- 找出所有需要执行预警的实例
    cursor v_instances_cur is
      select t.instance_id,
             t.rule_type,
             t.taskid,
             t.expire_type,
             t.rule_uuid
        from dbpm_expire_rule_execute_todo t
       where t.rule_type = 'INSTANCE';
    v_deloy_day        number;
    v_instanceid       varchar2(100);
    v_email_title      varchar2(200);
    v_email_content    varchar2(4000);
    v_email_recipients varchar2(200);
    v_before_day       number;
    v_after_day        number;
    v_warning_num      number;
    v_warning_dur      number;
    v_flag             number;
  begin

    --删除全部前实例
    delete from dbpm_expire_rule_execute_todo d
     where d.rule_type = 'INSTANCE';
    --  and d.processcode = v_process.process_code;
    for v_process in v_processid_cur loop
      begin
        --查找超期前天数
        select t.param_value
          into v_before_day
          from dbpm_process_expire_rule t
         where t.process_code = v_process.process_code
           and t.rule_type = 'INSTANCE'
           and t.param_name = 'BEFORE_DELOY_DAY';
        --同步符合超期前规则的实例
        insert into dbpm_expire_rule_execute_todo
          (id,
           rule_uuid,
           rule_type,
           instance_id,
           taskid,
           status,
           remark,
           object_version_number,
           creation_date,
           created_by,
           processcode,
           beforeday,
           start_time,
           expire_type)
          select dbpm_expire_rule_todo_s.nextval,
                 v_process.rule_uuid,
                 'INSTANCE',
                 t.instance_id,
                 '',
                 'NEW',
                 p_remark,
                 1,
                 sysdate,
                 'weblogic',
                 v_process.process_code,
                 round(v_process.deloy_day -
                       to_number(to_date(to_char(sysdate,
                                                 'yyyy-mm-dd hh24:mi:ss'),
                                         'yyyy-mm-dd hh24:mi:ss') -
                                 to_date(to_char(t.creation_date,
                                                 'yyyy-mm-dd hh24:mi:ss'),
                                         'yyyy-mm-dd hh24:mi:ss'))*1440,
                       0),
                 t.creation_date,
                 'PROCESS_INDUE_WARNING'
            from dbpm_ba_process_instance t
           where t.process_code = v_process.process_code
             and t.state = 1
             and (to_number(to_date(to_char(sysdate,
                                            'yyyy-mm-dd hh24:mi:ss'),
                                    'yyyy-mm-dd hh24:mi:ss') -
                            to_date(to_char(t.creation_date,
                                            'yyyy-mm-dd hh24:mi:ss'),
                                    'yyyy-mm-dd hh24:mi:ss'))*1440 between
                 v_process.deloy_day - v_before_day and
                 v_process.deloy_day);
      exception
        when no_data_found then
          --没有超期前规则配置
          null;
      end;
      --查找超期后天数
      begin
        select t.param_value
          into v_after_day
          from dbpm_process_expire_rule t
         where t.process_code = v_process.process_code
           and t.rule_type = 'INSTANCE'
           and t.param_name = 'AFTER_DELOY_DAY';
        --同步符合超期后规则的实例
        insert into dbpm_expire_rule_execute_todo
          (id,
           rule_uuid,
           rule_type,
           instance_id,
           taskid,
           status,
           remark,
           object_version_number,
           creation_date,
           created_by,
           processcode,
           afterday,
           start_time,
           expire_type)
          select dbpm_expire_rule_todo_s.nextval,
                 v_process.rule_uuid,
                 'INSTANCE',
                 t.instance_id,
                 '',
                 'NEW',
                 p_remark,
                 1,
                 sysdate,
                 'weblogic',
                 v_process.process_code,
                 round(to_number(to_date(to_char(sysdate,
                                                 'yyyy-mm-dd hh24:mi:ss'),
                                         'yyyy-mm-dd hh24:mi:ss') -
                                 to_date(to_char(t.creation_date,
                                                 'yyyy-mm-dd hh24:mi:ss'),
                                         'yyyy-mm-dd hh24:mi:ss'))*1440 -
                       v_process.deloy_day,
                       0),
                 t.creation_date,
                 'PROCESS_OVERDUE_WARNING'
            from dbpm_ba_process_instance t
           where t.process_code = v_process.process_code
             and t.state = 1
             and to_number(to_date(to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss'),
                                   'yyyy-mm-dd hh24:mi:ss') -
                           to_date(to_char(t.creation_date,
                                           'yyyy-mm-dd hh24:mi:ss'),
                                   'yyyy-mm-dd hh24:mi:ss'))*1440 >
                 v_process.deloy_day + v_after_day;
      exception
        when no_data_found then
          --没有超期后规则配置
          null;
      end;

    end loop;


    for v_instance in v_instances_cur loop

      select to_number(to_date(to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss'),
                               'yyyy-mm-dd hh24:mi:ss') -
                       to_date(to_char(max(dl.creation_date),
                                       'yyyy-mm-dd hh24:mi:ss'),
                               'yyyy-mm-dd hh24:mi:ss'))*1440
        into v_warning_dur
        from dbpm_expire_execute_log dl
       where dl.task_instanceid = v_instance.instance_id;

      select count(1)
        into v_warning_num
        from dbpm_expire_execute_log dl
       where dl.task_instanceid = v_instance.instance_id;

      select count(1)
        into v_flag
        from dbpm_process_expire_rule de
       where de.rule_uuid = v_instance.rule_uuid
         and rownum = 1
         and de.warning_dur < nvl(v_warning_dur,de.warning_dur+1)
         and de.warning_num > nvl(v_warning_num,0);
      if v_flag > 0 then
        get_warning_single_email_def(v_instance.instance_id,
                                     '',
                                     v_instance.expire_type,
                                     v_email_title,
                                     v_email_content,
                                     v_email_recipients);
        update dbpm_expire_rule_execute_todo t
           set t.email_title   = v_email_title,
               t.email_content = v_email_content,
               t.recipients    = v_email_recipients
         where t.instance_id = v_instance.instance_id
           and t.rule_type = 'INSTANCE';
      else
        delete from dbpm_expire_rule_execute_todo t
         where t.instance_id = v_instance.instance_id;
      end if;
    end loop;
  end get_instances_for_warning;
  /*
    获得需要执行预警的任务号
  */
  procedure get_tasks_for_warning(p_remark in varchar2) is
    cursor v_nodeid_cur is
      select distinct t.process_code,
                      t.node_id,

                      t.rule_uuid,
                      t.deloy_day
        from dbpm_process_expire_rule t
       where t.start_time < sysdate
         and t.end_time > sysdate
         and t.status = 'Y'
            --and t.param_name = 'DELOY_DAY'
         and t.rule_type = 'TASK';
    -- 找出所有需要执行预警的实例
    cursor v_tasks_cur is
      select t.instance_id,
             t.rule_type,
             t.taskid,
             t.expire_type,
             t.rule_uuid
        from dbpm_expire_rule_execute_todo t
       where t.rule_type = 'TASK';
    v_email_title      varchar2(200);
    v_email_content    varchar2(4000);
    v_email_recipients varchar2(200);
    v_before_day       number;
    v_after_day        number;
    v_warning_num      number;
    v_warning_dur      number;
    v_flag             number;
  begin
    for v_node in v_nodeid_cur loop
      --删除全部节点级别的待执行实例
      delete from dbpm_expire_rule_execute_todo dt
       where dt.node_id = v_node.node_id
         and dt.rule_type = 'TASK';
      begin
        select t.param_value
          into v_before_day
          from dbpm_process_expire_rule t
         where t.node_id = v_node.node_id
           and t.rule_type = 'TASK'
           and t.param_name = 'BEFORE_DELOY_DAY';
        ---同步超期前节点任务
        insert into dbpm_expire_rule_execute_todo
          (id,
           rule_uuid,
           rule_type,
           instance_id,
           taskid,
           status,
           remark,
           object_version_number,
           creation_date,
           created_by,
           node_id,
           beforeday,
           start_time,
           expire_type)
          select dbpm_expire_rule_todo_s.nextval,
                 v_node.rule_uuid,
                 'TASK',
                 wf.instanceid,
                 wf.taskid,
                 'NEW',
                 '',
                 1,
                 sysdate,
                 'weblogic',
                 dns.parent_id,
                 round(v_node.deloy_day -
                       to_number(to_date(to_char(sysdate,
                                                 'yyyy-mm-dd hh24:mi:ss'),
                                         'yyyy-mm-dd hh24:mi:ss') -
                                 to_date(to_char(wf.createddate,
                                                 'yyyy-mm-dd hh24:mi:ss'),
                                         'yyyy-mm-dd hh24:mi:ss'))*1440,
                       0),
                 wf.createddate,
                 'TASK_INDUE_WARNING'
            from wftask wf, dbpm_chain_nodes dns
           where (to_number(to_date(to_char(sysdate,
                                            'yyyy-mm-dd hh24:mi:ss'),
                                    'yyyy-mm-dd hh24:mi:ss') -
                            to_date(to_char(wf.createddate,
                                            'yyyy-mm-dd hh24:mi:ss'),
                                    'yyyy-mm-dd hh24:mi:ss'))*1440 between
                 v_node.deloy_day - v_before_day and v_node.deloy_day)
             and wf.hassubtask = 'F'
             and wf.state = 'ASSIGNED'
             and dns.node_id = wf.protectednumberattribute1
             and dns.parent_id = v_node.node_id;
      exception
        when no_data_found then
          --没有超期前规则配置
          null;
      end;
      --查找超期后天数
      begin
        select t.param_value
          into v_after_day
          from dbpm_process_expire_rule t
         where t.node_id = v_node.node_id
           and t.rule_type = 'TASK'
           and t.param_name = 'AFTER_DELOY_DAY';
        ---同步超期后节点任务
        insert into dbpm_expire_rule_execute_todo
          (id,
           rule_uuid,
           rule_type,
           instance_id,
           taskid,
           status,
           remark,
           object_version_number,
           creation_date,
           created_by,
           node_id,
           afterday,
           start_time,
           expire_type)
          select dbpm_expire_rule_todo_s.nextval,
                 v_node.rule_uuid,
                 'TASK',
                 wf.instanceid,
                 wf.taskid,
                 'NEW',
                 '',
                 1,
                 sysdate,
                 'weblogic',
                 dns.parent_id,
                 round(to_number(to_date(to_char(sysdate,
                                                 'yyyy-mm-dd hh24:mi:ss'),
                                         'yyyy-mm-dd hh24:mi:ss') -
                                 to_date(to_char(wf.createddate,
                                                 'yyyy-mm-dd hh24:mi:ss'),
                                         'yyyy-mm-dd hh24:mi:ss'))*1440 -
                       v_node.deloy_day,
                       0),
                 wf.createddate,
                 'TASK_OVERDUE_WARNING'
            from wftask wf, dbpm_chain_nodes dns
           where to_number(to_date(to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss'),
                                   'yyyy-mm-dd hh24:mi:ss') -
                           to_date(to_char(wf.createddate,
                                           'yyyy-mm-dd hh24:mi:ss'),
                                   'yyyy-mm-dd hh24:mi:ss'))*1440 >
                 v_node.deloy_day + v_after_day
             and wf.hassubtask = 'F'
             and wf.state = 'ASSIGNED'
             and dns.node_id = wf.protectednumberattribute1
             and dns.parent_id = v_node.node_id;
      exception
        when no_data_found then
          --没有超期后规则配置
          null;
      end;
    end loop;

    for v_task in v_tasks_cur loop

      select to_number(to_date(to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss'),
                               'yyyy-mm-dd hh24:mi:ss') -
                       to_date(to_char(max(dl.creation_date),
                                       'yyyy-mm-dd hh24:mi:ss'),
                               'yyyy-mm-dd hh24:mi:ss'))*1440
        into v_warning_dur
        from dbpm_expire_execute_log dl
       where dl.task_instanceid = v_task.taskid;

      select count(1)
        into v_warning_num
        from dbpm_expire_execute_log dl
       where dl.task_instanceid = v_task.taskid;

      select count(1)
        into v_flag
        from dbpm_process_expire_rule de
       where de.rule_uuid = v_task.rule_uuid
         and rownum = 1
         and de.warning_dur < nvl(v_warning_dur,de.warning_dur+1)
         and de.warning_num > nvl(v_warning_num,0);
      if v_flag > 0 then
        get_warning_single_email_def(v_task.instance_id,
                                     v_task.taskid,
                                     v_task.expire_type,
                                     v_email_title,
                                     v_email_content,
                                     v_email_recipients);
        update dbpm_expire_rule_execute_todo t
           set t.email_title   = v_email_title,
               t.email_content = v_email_content,
               t.recipients    = v_email_recipients,
               t.remark        = p_remark
         where t.taskid = v_task.taskid
           and t.rule_type = 'TASK';
      else
        delete from dbpm_expire_rule_execute_todo dt
         where dt.taskid = v_task.taskid;
      end if;
    end loop;
  end get_tasks_for_warning;
  /*
    同步预警任务
  */
  procedure sync_tasks_ins_for_warning is
    v_remark varchar2(200);
  begin
    v_remark := get_batch_data_time_mark;
    get_instances_for_warning(v_remark);
    get_tasks_for_warning(v_remark);
    update dbpm_expire_rule_execute_map t
       set t.status                = 'COMPLETED',
           t.updated_date          = sysdate,
           t.object_version_number = t.object_version_number + 1
     where t.status = 'NEW';
    insert into dbpm_expire_rule_execute_map
      (batch_mark, status, object_version_number)
    values
      (v_remark, 'NEW', 1);

  end sync_tasks_ins_for_warning;
  /*
  * 获取比较结果
  */

  function func_get_compare_result(p_data_type varchar2,
                                   p_operation varchar2,
                                   p_from_data varchar2,
                                   p_to_data   varchar2) return varchar2 is
    v_to_data varchar2(4000);
    v_count   number;
  begin
    if p_data_type = 'NUMBER' then
      if p_operation = '>' then
        if to_number(p_from_data) > to_number(p_to_data) then
          return 'Y';
        else
          return 'N';
        end if;
      elsif p_operation = '>=' then
        if to_number(p_from_data) >= to_number(p_to_data) then
          return 'Y';
        else
          return 'N';
        end if;
      elsif p_operation = '<' then
        if to_number(p_from_data) < to_number(p_to_data) then
          return 'Y';
        else
          return 'N';
        end if;
      elsif p_operation = '<=' then
        if to_number(p_from_data) <= to_number(p_to_data) then
          return 'Y';
        else
          return 'N';
        end if;
      elsif p_operation = '=' then
        if to_number(p_from_data) = to_number(p_to_data) then
          return 'Y';
        else
          return 'N';
        end if;
      elsif p_operation = '<>' then
        if to_number(p_from_data) <> to_number(p_to_data) then
          return 'Y';
        else
          return 'N';
        end if;
      end if;
    elsif p_data_type = 'VARCHAR' then
      if p_operation = '=' then
        if p_from_data = p_to_data then
          return 'Y';
        else
          return 'N';
        end if;
      elsif p_operation = '<>' then
        if p_from_data <> p_to_data then
          return 'Y';
        else
          return 'N';
        end if;
        ---增加对空值的判断 add by xiaoweri.yao  2019-2-26 begin
      elsif p_operation = 'IS' then
        select count(1) into v_count from dual where p_from_data is null;
        if v_count = 1 then
          return 'Y';
        else
          return 'N';
        end if;
      elsif p_operation = 'IS NOT' then
        select count(1)
          into v_count
          from dual
         where p_from_data is not null;
        if v_count = 1 then
          return 'Y';
        else
          return 'N';
        end if;
        ---增加对空值的判断 add by xiaoweri.yao 2019-2-26 end
      elsif p_operation = 'IN' then
        v_to_data := replace(p_to_data, '，', ',');
        for v_data in (select regexp_substr(v_to_data, '[^,]+', 1, rownum) sub_date
                         from dual
                       connect by rownum <=
                                  length(v_to_data) -
                                  length(replace(v_to_data, ',', '')) + 1) loop
          if trim(p_from_data) = trim(v_data.sub_date) then
            return 'Y';
          end if;
        end loop;
        return 'N';
        --update by xuy 20170715
        --comment: add (not in) 判断条件
      elsif trim(p_operation) = trim('NOTIN') then
        v_to_data := replace(p_to_data, '，', ',');
        for v_data in (select regexp_substr(v_to_data, '[^,]+', 1, rownum) sub_date
                         from dual
                       connect by rownum <=
                                  length(v_to_data) -
                                  length(replace(v_to_data, ',', '')) + 1) loop
          if trim(p_from_data) = trim(v_data.sub_date) then
            return 'N';
          end if;
        end loop;
        return 'Y';
      elsif p_operation = 'LIKE' then
        if instr(p_from_data, p_to_data) > 0 then
          return 'Y';
        else
          return 'N';
        end if;
      end if;
    end if;
    return 'N';
  end func_get_compare_result;

  /*
   获得预警邮件内容
  */
  procedure get_warning_single_email_def(p_instanceid       in varchar2,
                                         p_taskid           in varchar2,
                                         p_email_type       in varchar2,
                                         x_email_title      out varchar2,
                                         x_email_content    out varchar2,
                                         x_email_recipients out varchar2) is

    v_email_title      varchar2(1000);
    v_email_content    varchar2(4000);
    v_email_recipients varchar2(100);
    v_recipients_type  varchar2(100);
    v_process_name     varchar2(2000);
    v_process_code     varchar2(100);
    v_applier_code     varchar2(100);
    v_apply_name       varchar2(100);
    v_node_id          number;
    v_content_clob     clob;
    v_email            json;
    v_body             varchar2(4000);
    v_title            varchar2(4000);
    v_templates        json_list;
    v_params           json_list;
    v_param            json;
    v_template         json;
    v_process_title    varchar2(100);
    v_parammapcode     varchar2(4000);
    v_paramtype        varchar2(4000);
    v_paramcode        varchar2(4000);
    v_param_value      varchar2(100);
    v_formkey          varchar2(100);
    v_after_day        varchar2(100);
    v_node_name        varchar2(100);
    v_process_owner    varchar2(100);
    v_approver         varchar2(100);
  begin
    select t.instance_creator,
           t.process_code,
           t.process_form_info,
           t.process_form_id
      into v_applier_code, v_process_code, v_process_title, v_formkey
      from cux_bpm_all_instance t
     where t.instance_id = p_instanceid;
    --and dt.rule_type=p_email_type;
    select nvl(dt.process_name, dp.process_name), dp.process_owner
      into v_process_name, v_process_owner
      from dbpm_process dp, dbpm_process_tl dt
     where dp.process_code = v_process_code
       and dp.process_id = dt.process_id(+)
       and dt.locale = 'zh_CN';
    begin
      select nvl(dn.english_name, dn.employee_code)
        into v_apply_name
        from dfnd_employees dn
       where lower(dn.employee_code) = lower(v_applier_code);
    exception
      when no_data_found then
        v_apply_name := '申请人信息不全';
    end;
    begin
      if p_taskid is not null then
        --节点级别模板
        select wf.protectednumberattribute1, wa.assignee
          into v_node_id, v_approver
          from wftask wf, wfassignee wa
         where wf.taskid = p_taskid
           and wf.taskid = wa.taskid;
        select dt.afterday
          into v_after_day
          from dbpm_expire_rule_execute_todo dt
         where dt.taskid = p_taskid;
        if v_node_id > 0 then
          select t.content, t.recipients, t.recipients_type, dcn.node_name
            into v_content_clob,
                 v_email_recipients,
                 v_recipients_type,
                 v_node_name
            from dbpm_nodes_email_map t, dbpm_chain_nodes dcn
           where t.node_id = dcn.parent_id
             and t.send_stage = p_email_type
             and dcn.node_id = v_node_id;
        else
          --申请人节点的待办
          select t.content, t.recipients, t.recipients_type, dpn.node_name
            into v_content_clob,
                 v_email_recipients,
                 v_recipients_type，v_node_name
            from dbpm_nodes_email_map t,
                 dbpm_process_nodes   dpn,
                 dbpm_process         dp
           where dp.process_code = v_process_code
             and dp.process_id = dpn.process_id
             and t.send_stage = p_email_type
             and t.node_id = dpn.node_id
             and dpn.order_num = 1;
        end if;
      else
        select round(dt.afterday/1440,2)
          into v_after_day
          from dbpm_expire_rule_execute_todo dt
         where dt.instance_id = p_instanceid
           and dt.rule_type = 'INSTANCE';

        --取流程级别的模板
        begin
          select dpm.content, dpm.recipients, dpm.recipients_type
            into v_content_clob, v_email_recipients, v_recipients_type
            from dbpm_process_email_map dpm, dbpm_process dp
           where dp.process_id = dpm.process_id
             and dpm.send_stage = p_email_type
             and dp.process_code = v_process_code;
        exception
          when no_data_found then
            return;
        end;
      end if;
    end;
    --初始化收件人
    if v_recipients_type = 'PARAM' then
      --  v_email_recipients := v_applier_code;
      select (case v_email_recipients
               when 'APPLYER' then
                v_applier_code
               when 'APPROVER' then
                v_approver
               when 'PROCESSOWNER' then
                v_process_owner
             end)
        into v_email_recipients
        from dual;
    end if;
    ---初始化邮件模板内容
    v_email     := json(v_content_clob);
    v_templates := json_list(v_email.get('template'));
    v_params    := json_list(v_email.get('params'));
    for i in 1 .. v_templates.count loop
      v_template := json(v_templates.get(i));
      if v_template.get_string('locale') = 'zh_CN' then
        v_body  := v_template.get_string('body');
        v_title := v_template.get_string('title');
        for k in 1 .. v_params.count loop
          v_param        := json(v_params.get(k));
          v_parammapcode := v_param.get_string('paramMapCode');
          v_paramcode    := v_param.get_string('paramCode');
          select (case v_parammapcode
                   when 'PROCESSNAME' then
                    v_process_name
                   when 'APPLYER' then
                    v_applier_code
                   when 'PROCESSTITLE' then
                    v_process_title
                   when 'APPLYERNAME' then
                    v_apply_name
                   when 'AFTERDAY' then
                    v_after_day
                   when 'INSTANCEID' then
                    p_instanceid
                   when 'NODENAME' then
                    v_node_name
                 end)
            into v_param_value
            from dual;
          if v_param_value is not null then
            v_body  := replace(v_body, v_paramcode, v_param_value);
            v_title := replace(v_title, v_paramcode, v_param_value);
          end if;
        end loop;
      end if;
    end loop;
    x_email_title      := v_title;
    x_email_content    := v_body;
    x_email_recipients := v_email_recipients;

  end get_warning_single_email_def;
  /*
   获得批量预警邮件内容
  */

  procedure get_warning_batch_email_def(p_email_type in varchar2,
                                        x_remark     out varchar2,
                                        x_emails     out dbpm_email_tbl) is

    --  v_recipients varchar2(200);
    v_email  dbpm_email_rec;
    v_emails dbpm_email_tbl := dbpm_email_tbl();
    v_index  number := 1;
    --一次调度是给50个人发邮件
    cursor v_recipients_cur(p_remark varchar2) is
      select v.recipients
        from (select dt.recipients
                from dbpm_expire_rule_execute_todo dt
               where dt.remark = p_remark
                 and dt.expire_type = p_email_type
                -- and dt.status = 'NEW'
               group by dt.recipients) v
       where rownum < 50;
    cursor v_instance_cur(p_recipients varchar2, p_remark varchar2) is
      select *
        from dbpm_expire_rule_execute_todo t
       where t.expire_type = p_email_type
         --and t.status = 'NEW'
         and t.recipients = p_recipients
         and t.remark = p_remark;
    v_email_body  clob := '';
    v_email_title varchar2(4000) := '';
    v_remark      varchar2(1000);
    v_subremark   varchar2(1000);

  begin
    --找出当前时间戳
    select tt.batch_mark
      into v_remark
      from dbpm_expire_rule_execute_map tt
     where tt.status = 'NEW';
    for v_recipient in v_recipients_cur(v_remark) loop
      for v_instance in v_instance_cur(v_recipient.recipients, v_remark) loop

        v_email_body  := v_email_body || v_instance.email_content;
        v_email_title := v_instance.email_title;
       /* update dbpm_expire_rule_execute_todo t
           set t.status = 'COMPLETED'
         where t.id = v_instance.id;*/
      end loop;
      v_email                  := dbpm_email_rec(null,
                                                 null,
                                                 null,
                                                 null,
                                                 null);
      v_email.email_recipients := v_recipient.recipients;
      v_email.email_title      := v_email_title;
      v_email.email_body       := v_email_body;
      v_subremark              := get_batch_data_time_mark;
      v_email.batch_remark     := v_subremark;
      /* insert into dbpm_expire_execute_log
        (log_type,
         log_info,
         log_content,
         log_relater,
         remark,
         object_version_number,
         creation_date,
         created_by,
         task_type,
         sub_remark)
      values
        ('sendEmail',
         v_email_title,
         v_email_body,
         v_recipient.recipients,
         v_remark,
         1,
         sysdate,
         'weblogic',
         p_email_type,
         v_subremark);*/
      v_emails.extend();
      v_emails(v_index) := v_email;
      v_index := v_index + 1;
    end loop;
    x_emails := v_emails;
    x_remark:=v_remark;
  end get_warning_batch_email_def;

  /*
  * 获取动态参数值
  */
  function func_get_process_param_value(p_business_param     dbpm_business_param_tbl,
                                        p_process_param_code varchar2)
    return varchar2 is
    v_param dbpm_business_param_rec;
  begin
    for i in 1 .. p_business_param.count loop
      v_param := p_business_param(i);
      if v_param.paramkey = p_process_param_code then
        return v_param.paramvalue;
      end if;
    end loop;

    return null;
  end func_get_process_param_value;

  /*
  * 更新上一批次任务状态，生成下一批次标志
  */
  procedure update_execute_log_status(p_remark      in varchar2,
                                      p_waring_type in varchar2,
                                      p_instanceid  in varchar2,
                                      x_remark      out varchar2) is
    v_remark     varchar2(200);
    v_batch_date date;
  begin

    /* update DBPM_EXPIRE_EXECUTE_LOG t
      set t.instanceid = p_instanceid，t.update_date = sysdate
    where t.sub_remark = p_remark;*/
    insert into dbpm_expire_execute_log
      (remark,
       task_type,
       task_instanceid,
       audit_instanceid,
       creation_date,
       created_by)
      select p_remark,
             p_waring_type,
             decode(instr(p_waring_type, 'TASK'),
                    0,
                    dt.instance_id,
                    dt.taskid),
             p_instanceid,
             sysdate,
             'weblogic'
        from dbpm_expire_rule_execute_todo dt
       where dt.remark = p_remark
         and dt.expire_type = p_waring_type;
    x_remark := p_remark;
  end update_execute_log_status;
  /***************************************************************************************
  * * * * * * *  根据当前时间生成一个时间标志供批量维护状态使用以提升性能* * * * * * * * * * * * * *
  ***************************************************************************************/
  function get_batch_data_time_mark return varchar2 as
    v_time_mark varchar2(20);
  begin
    select (to_char(systimestamp, 'YYYYMMDDHH24MISSFF6')) v_time_mark
      into v_time_mark
      from dual;
    return v_time_mark;
  end get_batch_data_time_mark;
  /*
  * 获得当前的remark
  */
  procedure get_cur_remark(x_remark out varchar2) is
    v_remark varchar2(100);
  begin
    select tt.batch_mark
      into v_remark
      from dbpm_expire_rule_execute_map tt
     where tt.status = 'NEW';
    x_remark := v_remark;
  end get_cur_remark;
end dbpm_expire_rule_pkg;

/

