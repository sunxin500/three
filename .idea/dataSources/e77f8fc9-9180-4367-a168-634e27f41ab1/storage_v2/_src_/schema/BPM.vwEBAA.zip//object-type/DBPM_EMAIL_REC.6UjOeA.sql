create TYPE     "DBPM_EMAIL_REC" force
                                             IS OBJECT
(
  batch_remark  VARCHAR2(200), --批次号
  email_title   VARCHAR2(2000), -- 邮件标题
  email_body   clob,--邮件内容
 email_recipients  VARCHAR2(4000),--收件人
  attr VARCHAR2(2000) -- 扩展属性
)

/

