create PACKAGE     dfnd_address_list_pkg IS

  /*==================================================
  Procedure/Function Name :
      proc_query_address_list
  Description:
      This function perform:
      查询通讯录接口
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-03-13  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_query_address_list(p_request CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_get_all_address_list
  Description:
      This function perform:
      查询全部人员的通讯录接口
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-03-13  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_get_all_address_list(p_request CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_add_friend
  Description:
      This function perform:
      加好友，如果已经是好友，不加
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-03-14  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_add_friend(p_request CLOB, x_response OUT CLOB);

END dfnd_address_list_pkg;

/

