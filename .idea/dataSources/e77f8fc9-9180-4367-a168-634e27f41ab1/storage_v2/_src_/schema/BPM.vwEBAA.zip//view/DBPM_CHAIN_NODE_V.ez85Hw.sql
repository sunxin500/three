create view DBPM_CHAIN_NODE_V as
SELECT dp.process_code,dp.process_name,dac.chain_id,dac.chain_name,dcn.node_id,dcn.node_name FROM dbpm_process dp,dbpm_approval_chain dac,dbpm_chain_nodes dcn WHERE dac.chain_id = dcn.chain_id AND dp.process_id = dac.process_id
ORDER BY dp.process_code,dac.chain_id,dcn.node_id
/

