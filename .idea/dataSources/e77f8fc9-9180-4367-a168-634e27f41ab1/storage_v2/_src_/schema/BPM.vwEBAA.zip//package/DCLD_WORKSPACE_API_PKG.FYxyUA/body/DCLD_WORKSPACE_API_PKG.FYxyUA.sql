create PACKAGE BODY     dcld_workspace_api_pkg IS

  /*==================================================
  Procedure Name :
      proc_notice_publish
  Description:
      发布通知公告
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2016-11-25  Kerry.Wu  Creation
  Sample output:
         标准输出
  ==================================================*/
  PROCEDURE proc_notice_publish(p_request IN CLOB, x_response OUT CLOB) IS
    v_api           VARCHAR2(30) := 'proc_notice_publish';
    v_current_user  VARCHAR2(50); --获取当前用户
    v_list          json_list;
    v_list_assignee json_list;
    v_title         VARCHAR2(100);
    v_notice_id     NUMBER := dcld_notices_s.nextval;
    v_notice_type   VARCHAR2(50);
    v_content       CLOB;
    v_scope         VARCHAR2(50) := '';
    v_assignee      VARCHAR2(100);
    v_value_json    json;
    v_response      pl_json := pl_json;
    v_request       json;
    v_all           VARCHAR2(30);
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;

    v_list        := json_list(v_request.get('scopes'));
    v_title       := v_request.get('title').get_string;
    v_content     := v_request.get('content').get_string;
    v_notice_type := v_request.get('notice_type').get_string;

    FOR l_index IN 1 .. v_list.count LOOP
      v_value_json := json(v_list.get(l_index));
      v_scope      := v_value_json.get('scope').get_string;
      IF v_scope = 'ALL' THEN
        v_all := 'ALL';

      ELSE
        v_list_assignee := json_list(v_value_json.get('assigner'));
        FOR l_index_ass IN 1 .. v_list_assignee.count LOOP
          v_assignee := v_list_assignee.get(l_index_ass).get_string;
          INSERT INTO dcld_notice_assignees
            (assignee_id,
             assignee_type,
             assignee,
             object_version_number,
             creation_date,
             created_by,
             last_updated_by,
             last_update_date,
             notice_id)
          VALUES
            (dcld_notice_assignees_s.nextval,
             v_scope,
             v_assignee,
             1,
             SYSDATE,
             v_current_user,
             v_current_user,
             SYSDATE,
             v_notice_id);
        END LOOP;
      END IF;
    END LOOP;

    INSERT INTO dcld_notices
      (notice_id,
       title,
       content,
       notice_type,
       scope,
       object_version_number,
       creation_date,
       created_by,
       last_updated_by,
       last_update_date)
    VALUES
      (v_notice_id,
       v_title,
       v_content,
       v_notice_type,
       v_all,
       1,
       SYSDATE,
       v_current_user,
       v_current_user,
       SYSDATE);

    x_response := v_response.to_json;
 /* EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口||' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_notice_publish;

  /*==================================================
  Procedure Name :
      proc_notice_query
  Description:
      自己能看到的通知公告
  Argument:
      p_request  请求（JSON）
      x_response 相应（JSON）
  History:
      1.00  2016-11-25  Kerry.Wu  Creation
  ==================================================*/
  PROCEDURE proc_notice_query(p_request IN CLOB, x_response OUT CLOB) IS
    v_api          VARCHAR2(30) := 'proc_notice_query';
    v_current_user VARCHAR2(50);
    v_notice_type  VARCHAR2(100) := '';
    v_notice_id    NUMBER;
    v_line_json    pl_json := pl_json;
    v_json         pl_json := pl_json;
    v_response     pl_json := pl_json;
    v_request      json;
    v_total        NUMBER;
    v_page         NUMBER;
    v_size         NUMBER;
    CURSOR v_notice_cur IS --cursor
      SELECT *
        FROM (SELECT a.*, rownum row_num
                FROM (SELECT t.title,
                             t.content,
                             t.notice_type,
                             t.notice_id,
                             t.creation_date,
                             t.created_by,
                             (CASE
                               WHEN EXISTS
                                (SELECT 1
                                       FROM dcld_notice_history h
                                      WHERE h.from_source = t.notice_type
                                        AND h.from_source_id = t.notice_id
                                        AND h.user_code = v_current_user) THEN
                                'N'
                               ELSE
                                'Y'
                             END) is_new
                        FROM dcld_notices t
                       WHERE t.scope = 'ALL'
                      UNION ALL
                      SELECT t.title,
                             t.content,
                             t.notice_type,
                             t.notice_id,
                             t.creation_date,
                             t.created_by,
                             (CASE
                               WHEN EXISTS
                                (SELECT 1
                                       FROM dcld_notice_history h
                                      WHERE h.from_source = t.notice_type
                                        AND h.from_source_id = t.notice_id
                                        AND h.user_code = v_current_user) THEN
                                'N'
                               ELSE
                                'Y'
                             END) is_new
                        FROM dcld_notices t, dcld_notice_assignees a
                       WHERE t.notice_id = a.notice_id
                         AND a.assignee_type = 'USER'
                         AND a.assignee = v_current_user
                      UNION ALL
                      SELECT t.title,
                             t.content,
                             t.notice_type,
                             t.notice_id,
                             t.creation_date,
                             t.created_by,
                             (CASE
                               WHEN EXISTS
                                (SELECT 1
                                       FROM dcld_notice_history h
                                      WHERE h.from_source = t.notice_type
                                        AND h.from_source_id = t.notice_id
                                        AND h.user_code = v_current_user) THEN
                                'N'
                               ELSE
                                'Y'
                             END) is_new
                        FROM dcld_notices          t,
                             dcld_notice_assignees a,
                             dbpm_role_members     r
                       WHERE t.notice_id = a.notice_id
                         AND a.assignee_type = 'ROLE'
                         AND a.assignee = r.role_id
                         AND r.member_code = v_current_user
                       ORDER BY is_new DESC, creation_date DESC) a) b
       WHERE b.row_num BETWEEN (v_page - 1) * v_size AND v_page * v_size;

  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;

    v_page := nvl(v_request.get('page').get_number, 1);
    v_size := nvl(v_request.get('size').get_number, 20);
    SELECT COUNT(1) --total
      INTO v_total
      FROM (SELECT t.notice_id
              FROM dcld_notices t
             WHERE t.scope = 'ALL'
            UNION ALL
            SELECT t.notice_id
              FROM dcld_notices t, dcld_notice_assignees a
             WHERE t.notice_id = a.notice_id
               AND a.assignee_type = 'USER'
               AND a.assignee = v_current_user
            UNION ALL
            SELECT t.notice_id
              FROM dcld_notices          t,
                   dcld_notice_assignees a,
                   dbpm_role_members     r
             WHERE t.notice_id = a.notice_id
               AND a.assignee_type = 'ROLE'
               AND a.assignee = r.role_id
               AND r.member_code = v_current_user);
    v_json.set_value('total', v_total);

    FOR v_notice_row IN v_notice_cur LOOP
      v_line_json   := pl_json;
      v_notice_id   := v_notice_row.notice_id;
      v_notice_type := v_notice_row.notice_type;

      v_line_json.set_value('title', v_notice_row.title);
      v_line_json.set_value('content', v_notice_row.content);
      v_line_json.set_value('notice_type', v_notice_type);
      v_line_json.set_value('notice_id', v_notice_id);
      v_line_json.set_value('creation_date', v_notice_row.creation_date);
      v_line_json.set_value('created_by', v_notice_row.created_by);
      v_line_json.set_value('new', v_notice_row.is_new);
      v_json.add_list_item('list', v_line_json);
    END LOOP;
    x_response := v_json.to_json;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口||' || v_api || '错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;
  END proc_notice_query;

  /*==================================================
  Procedure Name :
      proc_set_doc_readead
  Description:
      设置 消息公共/系统消息/待办 是否已读
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2016-11-25  Kerry.Wu  Creation
  ==================================================*/
  PROCEDURE proc_set_doc_readead(p_request IN CLOB, x_response OUT CLOB) IS
    v_api          VARCHAR2(100) := 'proc_set_doc_readead';
    v_source       VARCHAR2(100);
    v_source_id    NUMBER;
    v_cnt          NUMBER;
    v_response     pl_json := pl_json;
    v_request      json;
    v_current_user VARCHAR2(100);
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;

    v_source    := v_request.get('source').get_string;
    v_source_id := v_request.get('source_id').get_number;
    SELECT COUNT(1)
      INTO v_cnt
      FROM dcld_notice_history t
     WHERE t.from_source = v_source
       AND t.from_source_id = v_source_id;
    IF v_cnt = 0 THEN
      INSERT INTO dcld_notice_history
        (history_id,
         from_source,
         from_source_id,
         user_code,
         created_by,
         last_updated_by)
      VALUES
        (dcld_notice_history_s.nextval,
         v_source,
         v_source_id,
         v_current_user,
         v_current_user,
         v_current_user);
    END IF;
    x_response := v_response.to_json;
  /*EXCEPTION
    WHEN OTHERS THEN
      v_response.fail('接口||' || v_api || '错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END;

  /*==================================================
  Procedure Name :
      proc_query_all_process
  Description:
      查询流程信息
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2016-12-09  Kerry.Wu  Creation
  ==================================================*/
  PROCEDURE proc_query_all_process(p_request IN CLOB, x_response OUT CLOB) IS
    v_api          VARCHAR2(30) := 'proc_query_all_process';
    v_response     pl_json := pl_json;
    v_request      json;
    v_line_json    pl_json := pl_json;
    v_json         pl_json := pl_json;
    v_total        NUMBER;
    v_process_type VARCHAR2(50);
    v_process_name VARCHAR2(150);
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_process_type := dcld_comm_pkg.get_filter_value('process_type', v_request);
    v_process_name := dcld_comm_pkg.get_filter_value('process_name', v_request);

    SELECT COUNT(1)
      INTO v_total
      FROM dbpm_process t
     WHERE nvl(t.process_name, 'NL') LIKE '%' || v_process_name || '%'
       AND nvl(t.process_type, 'NL') =
           nvl(v_process_type, nvl(t.process_type, 'NL'));
    v_json.set_value('total', v_total); --total
    FOR v_process_row IN (SELECT t.process_code,
                                 t.process_name,
                                 t.process_type,
                                 t.description,
                                 t.enabled_flag
                            FROM dbpm_process t
                           WHERE nvl(t.process_name, 'NL') LIKE
                                 '%' || v_process_name || '%'
                             AND nvl(t.process_type, 'NL') =
                                 nvl(v_process_type,
                                     nvl(t.process_type, 'NL'))) LOOP
      v_line_json := pl_json;
      v_line_json.set_value('process_code', v_process_row.process_code);
      v_line_json.set_value('process_name', v_process_row.process_name);
      v_line_json.set_value('process_type', v_process_row.process_type);
      v_line_json.set_value('description', v_process_row.description);
      v_line_json.set_value('enabled_flag', v_process_row.enabled_flag);
      v_json.add_list_item('list', v_line_json);
    END LOOP;
    x_response := v_json.to_json;
/*  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口||' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_query_all_process;
  /*==================================================
  Procedure Name :
      proc_user_favorite_process_query
  Description:
      查询用户常用的 常用业务,或常用导航
  Argument:
      p_request：  请求（json）
      x_response： 响应（json）
  History:
      1.00  2016-12-09  Kerry.Wu  Creation
  ==================================================*/
  PROCEDURE proc_query_favorite_business(p_request  IN CLOB,
                                         x_response OUT CLOB) IS
    v_api          VARCHAR2(30) := 'proc_query_favorite_business';
    v_current_user VARCHAR2(50);
    v_line_json    pl_json := pl_json;
    v_json         pl_json := pl_json;
    v_response     pl_json := pl_json;
    v_request      json;
    v_space_type   VARCHAR2(50);
    v_total        NUMBER;
    CURSOR v_process_cur IS
      SELECT v.weight,
             v.process_code,
             v.process_name,
             v.process_type,
             v.description,
             v.enabled_flag,
             v.business_url
        FROM dcld_workspace_user_favorite_v v
       WHERE v.user_code = v_current_user
         AND v.space_type = v_space_type;
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;

    v_space_type := v_request.get('space_type').get_string;
    SELECT COUNT(1)
      INTO v_total
      FROM dcld_workspace_user_favorite_v v
     WHERE v.user_code = v_current_user
       AND v.space_type = v_space_type;
    v_json.set_value('total', v_total);
    FOR v_process_row IN v_process_cur LOOP
      v_line_json := pl_json;
      v_line_json.set_value('weight', v_process_row.weight);
      v_line_json.set_value('process_code', v_process_row.process_code);
      v_line_json.set_value('process_name', v_process_row.process_name);
      v_line_json.set_value('process_type', v_process_row.process_type);
      v_line_json.set_value('description', v_process_row.description);
      v_line_json.set_value('enabled_flag', v_process_row.enabled_flag);
      v_line_json.set_value('business_url', v_process_row.business_url);
      v_json.add_list_item('list', v_line_json);
    END LOOP;
    x_response := v_json.to_json;
/*  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口||' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_query_favorite_business;

  PROCEDURE proc_get_user_workspace_data(p_request  IN CLOB,
                                         x_response OUT CLOB) IS
    v_request      json;
    v_response     pl_json := pl_json;
    v_current_user VARCHAR2(50);
    v_todo         NUMBER;
    v_apply        NUMBER;
    v_title        VARCHAR2(300);
    v_copyright    VARCHAR2(500);
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;

    v_title     := '上海得帆信息技术有限公司';
    v_copyright := '上海得帆信息技术有限公司版权所有';
    --获取待办
    SELECT COUNT(1)
      INTO v_todo
      FROM dbpm_task_assignees t
     WHERE t.assignee = v_current_user;
    --获取我的申请
    SELECT COUNT(1)
      INTO v_apply
      FROM dbpm_tasks t
     WHERE t.created_by = v_current_user;
    v_response.set_value('logo', 'http://definesys.vicp.cc');
    v_response.set_value('title', v_title);
    v_response.set_value('todo', v_todo);
    v_response.set_value('apply', v_apply);
    v_response.set_value('copyright', v_copyright);
    x_response := v_response.to_json;
  END;
  /*==================================================
  Procedure/Function Name :
      proc_add_quick_navigation
  Description:
      This function perform:
      添加快捷导航
  History:
      1.00  2017-03-16  chenming  Creation
  ==================================================*/
  PROCEDURE proc_add_quick_navigation(p_request CLOB, x_response OUT CLOB) IS
    v_api          VARCHAR2(100) := 'proc_add_quick_navigation';
    v_request      json;
    v_response     pl_json := pl_json;
    v_current_user VARCHAR2(50); --获取当前用户
    v_menu_id      NUMBER;
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;

    IF v_request.get('menuId') IS NOT NULL THEN
      v_menu_id := v_request.get('menuId').get_number;
    END IF;
    INSERT INTO dcld_quick_navigation
      (navigation_id, menu_id, user_code)
    VALUES
      (dcld_quick_navigation_s.nextval, v_menu_id, v_current_user);
    x_response := v_response.to_json;
/*  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_add_quick_navigation;

  /*==================================================
  Procedure/Function Name :
      proc_delete_quick_navigation
  Description:
      This function perform:
      删除快捷导航
  History:
      1.00  2017-03-16  chenming  Creation
  ==================================================*/
  PROCEDURE proc_delete_quick_navigation(p_request  CLOB,
                                         x_response OUT CLOB) IS
    v_api          VARCHAR2(100) := 'proc_delete_quick_navigation';
    v_request      json;
    v_response     pl_json := pl_json;
    v_current_user VARCHAR2(500); --获取当前用户
    v_menu_id      NUMBER;
  BEGIN
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;

    v_menu_id := v_request.get('menuId').get_number;
    DELETE FROM dcld_quick_navigation WHERE menu_id = v_menu_id;
    x_response := v_response.to_json;
 /* EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_delete_quick_navigation;
END dcld_workspace_api_pkg;

/

