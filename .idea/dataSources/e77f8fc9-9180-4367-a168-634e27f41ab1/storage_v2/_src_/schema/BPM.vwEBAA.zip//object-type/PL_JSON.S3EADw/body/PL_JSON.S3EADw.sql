create TYPE BODY "PL_JSON" IS

  CONSTRUCTOR FUNCTION pl_json RETURN SELF AS RESULT IS
  BEGIN
    code      := 'SUCCESS';
    atom_list := json_atom_set();
    datatype  := 'OBJECT';
    RETURN;
  END;

  MEMBER PROCEDURE set_value(p_name IN VARCHAR2, p_value IN VARCHAR2) IS
    v_text VARCHAR2(4000);
  BEGIN
    IF p_value IS NOT NULL THEN
      atom_list.extend(1);
      v_text := p_value; ----modified by jianfeng 2017/09/02 转移制表符
      IF instr(v_text, chr(92)) > 0 THEN
        v_text := REPLACE(v_text, chr(92), '\\');
      END IF;
      IF instr(v_text, '"') > 0 THEN
        v_text := REPLACE(v_text, '"', '\"');
      END IF;
      --modified by jianfeng 2017/09/02 转移制表符
      IF instr(v_text, chr(9)) > 0 THEN
        v_text := REPLACE(v_text, chr(9), '');
      END IF;
      IF instr(v_text, chr(10)) > 0 THEN
        v_text := REPLACE(v_text, chr(10), '');
      END IF;
      atom_list(atom_list.count) := json_atom(p_name, v_text);
    END IF;
  END;

  MEMBER PROCEDURE set_value(p_name IN VARCHAR2, p_value IN NUMBER) IS
  BEGIN
    IF p_value IS NOT NULL THEN
      atom_list.extend(1);
      atom_list(atom_list.count) := json_atom(p_name, p_value);
    END IF;
  END;

  MEMBER PROCEDURE set_value(p_name IN VARCHAR2, p_value IN BOOLEAN) IS
  BEGIN
    IF p_value IS NOT NULL THEN
      atom_list.extend(1);
      atom_list(atom_list.count) := json_atom(p_name, p_value);
    END IF;
  END;

  MEMBER PROCEDURE set_value(p_name IN VARCHAR2, p_value IN DATE) IS
  BEGIN
    IF p_value IS NOT NULL THEN
      atom_list.extend(1);
      atom_list(atom_list.count) := json_atom(p_name, p_value);
    END IF;
  END;

  MEMBER PROCEDURE set_value(p_name IN VARCHAR2, p_value IN CLOB) IS
    v_text CLOB; --migrate by xiaowei.yao 20170412
  BEGIN
    IF p_value IS NOT NULL THEN
      atom_list.extend(1);
      --  atom_list(atom_list.count) := json_atom(p_name, p_value);
      v_text := p_value;
      IF instr(v_text, '"') > 0 THEN
        v_text := REPLACE(v_text, '"', '\"');
      END IF;
      IF instr(v_text, chr(10)) > 0 THEN
        v_text := REPLACE(v_text, chr(10), '');
      END IF;
      --modified by jianfeng 2017/09/02 转移制表符
      IF instr(v_text, chr(9)) > 0 THEN
        v_text := REPLACE(v_text, chr(9), '');
      END IF;
      IF instr(v_text, chr(13)) > 0 THEN
        v_text := REPLACE(v_text, chr(13), '');
      END IF;
      atom_list(atom_list.count) := json_atom(p_name, v_text);

    END IF;
  END;

  MEMBER PROCEDURE set_value(p_name IN VARCHAR2, p_value IN pl_json) IS
  BEGIN
    IF p_value IS NOT NULL THEN
      atom_list.extend(1);
      atom_list(atom_list.count) := json_atom(p_name,
                                              p_value.to_data_json,
                                              'OBJECT');
    END IF;
  END;

  --update by xiaowei.yao 20181022 修改json串过长的bug
  MEMBER PROCEDURE set_value(p_name IN VARCHAR2, p_value IN json) IS
    v_clob CLOB;
  BEGIN
    IF p_value IS NOT NULL THEN
      atom_list.extend(1);
      dbms_lob.createtemporary(v_clob, false);
      p_value.to_clob(v_clob);
      /*   atom_list(atom_list.count) := json_atom(p_name,
                                                  p_value.to_char,
                                                  'OBJECT');
      */
      atom_list(atom_list.count) := json_atom(p_name, v_clob, 'OBJECT');

    END IF;
  END;
  --update by Echo.zeng 2018-03-02
  MEMBER PROCEDURE set_value(p_name IN VARCHAR2, p_value IN json_list) IS
  BEGIN
    IF p_value IS NOT NULL THEN
      atom_list.extend(1);
      atom_list(atom_list.count) := json_atom(p_name,
                                              p_value.to_char,
                                              'OBJECT');

    END IF;
  END;

  MEMBER PROCEDURE set_object(p_name IN VARCHAR2, p_value IN pl_json) IS
  BEGIN
    IF p_value IS NOT NULL THEN
      atom_list.extend(1);
      atom_list(atom_list.count) := json_atom(p_name,
                                              p_value.to_data_json,
                                              'OBJECT');
    END IF;
  END;

  MEMBER PROCEDURE set_data_type(p_type IN VARCHAR2) IS
  BEGIN
    datatype := p_type;
  END;

  MEMBER PROCEDURE add_list_item(p_name IN VARCHAR2, p_value IN pl_json) IS
    l_index NUMBER := -1;
  BEGIN
    FOR i IN 1 .. atom_list.count LOOP
      IF p_name = atom_list(i).obj_name THEN
        l_index := i;
        EXIT;
      END IF;
    END LOOP;
    IF l_index = -1 THEN
      atom_list.extend(1);
      atom_list(atom_list.count) := json_atom(p_name,
                                              p_value.to_data_json,
                                              'ARRAY');
    ELSE
      atom_list(l_index).append(',');
      atom_list(l_index).append(p_value.to_data_json);
    END IF;
  END;

  MEMBER PROCEDURE add_list_item(p_name IN VARCHAR2, p_value IN json_list) IS
    l_index NUMBER := -1;
  BEGIN
    FOR i IN 1 .. atom_list.count LOOP
      IF p_name = atom_list(i).obj_name THEN
        l_index := i;
        EXIT;
      END IF;
    END LOOP;
    IF l_index = -1 THEN
      atom_list.extend(1);
      atom_list(atom_list.count) := json_atom(p_name,
                                              p_value.to_char,
                                              'ARRAY');
    ELSE
      atom_list(l_index).append(',');
      atom_list(l_index).append(p_value.to_char);
    END IF;
  END;

  MEMBER PROCEDURE add_list_item(p_value IN pl_json) IS
    l_index NUMBER := -1;
    p_name  VARCHAR2(50) := 'JSON_ARRAY';
  BEGIN
    FOR i IN 1 .. atom_list.count LOOP
      IF p_name = atom_list(i).obj_name THEN
        l_index := i;
        EXIT;
      END IF;
    END LOOP;
    IF l_index = -1 THEN
      atom_list.extend(1);
      atom_list(atom_list.count) := json_atom(p_name,
                                              p_value.to_data_json,
                                              'ARRAY');
    ELSE
      atom_list(l_index).append(',');
      atom_list(l_index).append(p_value.to_data_json);
    END IF;
  END;

  MEMBER PROCEDURE set_dev_msg(p_dev_msg IN VARCHAR2) IS
  BEGIN
    devmsg := p_dev_msg;
  END;

  MEMBER PROCEDURE set_user_msg(p_user_msg IN CLOB) IS
  BEGIN
    usermsg := p_user_msg;
  END;

  MEMBER PROCEDURE set_msg(p_dev_msg IN VARCHAR2, p_user_msg IN VARCHAR2) IS
  BEGIN
    devmsg  := p_dev_msg;
    usermsg := p_user_msg;
  END;
  MEMBER PROCEDURE fail(p_user_msg IN VARCHAR2) IS
  BEGIN
    code    := 'FAIELD';
    usermsg := p_user_msg;
  END;
  MEMBER PROCEDURE fail(p_dev_msg IN VARCHAR2, p_user_msg IN VARCHAR2) IS

  BEGIN
    code    := 'FAIELD';
    devmsg  := p_dev_msg;
    usermsg := p_user_msg;
  END;

  MEMBER FUNCTION to_data_json RETURN CLOB IS
    l_json   CLOB;
    v_buffer VARCHAR2(32767);
  BEGIN
    dbms_lob.createtemporary(l_json, TRUE);
    l_json := '{';
    /*    IF datatype = 'ARRAY' AND atom_list.count <= 1 THEN
      l_json := '';
    END IF;*/
    --处理
    IF datatype = 'ARRAY' AND atom_list.count = 1 AND atom_list(1)
      .obj_name = 'JSON_ARRAY' THEN
      l_json := '';
    END IF;
    IF datatype = 'ARRAY' AND atom_list.count = 0 THEN
      l_json := '';
    END IF;

    FOR i IN 1 .. atom_list.count LOOP
      IF i <> 1 THEN
        pl_json_pkg.append_text(l_json, v_buffer, ',');
      END IF;
      IF atom_list(i).obj_name <> 'JSON_ARRAY' THEN
        pl_json_pkg.append_text(l_json,
                                v_buffer,
                                '"' || atom_list(i).obj_name || '":');
      END IF;

      IF atom_list(i).obj_type = 'ARRAY' THEN
        pl_json_pkg.append_text(l_json, v_buffer, '[');
      END IF;
      IF atom_list(i).obj_value IS NOT NULL THEN
        pl_json_pkg.append_text(l_json, v_buffer, atom_list(i).obj_value);
      ELSE
        pl_json_pkg.append_clob(l_json, v_buffer, atom_list(i).obj_clob);
      END IF;
      IF atom_list(i).obj_type = 'ARRAY' THEN
        pl_json_pkg.append_text(l_json, v_buffer, ']');
      END IF;
    END LOOP;
    IF datatype != 'ARRAY' OR atom_list.count > 1 THEN
      pl_json_pkg.append_text(l_json, v_buffer, '}');
    END IF;
    IF length(l_json) = 0 OR l_json IS NULL THEN
      IF datatype = 'ARRAY' THEN
        pl_json_pkg.append_text(l_json, v_buffer, '[]');
      ELSE
        pl_json_pkg.append_text(l_json, v_buffer, '{}');
      END IF;
    END IF;
    pl_json_pkg.write_append(l_json, v_buffer);
    RETURN l_json;
  END;

  MEMBER FUNCTION to_json RETURN CLOB IS
    l_json CLOB;
    l_list BOOLEAN := FALSE;
  BEGIN
    dbms_lob.createtemporary(l_json, TRUE);
    l_json := '{';
    l_json := l_json || '"code":"' || code || '"';

    IF devmsg IS NOT NULL THEN
      l_json := l_json || ',"devMsg":"' || devmsg || '"';
    END IF;

    IF usermsg IS NOT NULL THEN
      l_json := l_json || ',"userMsg":"' || usermsg || '"';
    END IF;

    IF code = 'FAIELD' THEN
      GOTO process_end;
    END IF;

    l_json := l_json || ',"data":';
    IF datatype = 'ARRAY' OR
       (atom_list.count = 1 AND atom_list(1).obj_type = 'ARRAY') THEN
      l_list := TRUE;
    ELSE
      l_json := l_json || '{';
    END IF;

    FOR i IN 1 .. atom_list.count LOOP
      IF i <> 1 THEN
        l_json := l_json || ',';
      END IF;
      IF l_list = FALSE THEN
        l_json := l_json || '"';
        l_json := l_json || atom_list(i).obj_name;
        l_json := l_json || '":';
      END IF;

      IF atom_list(i).obj_type = 'ARRAY' THEN
        l_json := l_json || '[';
      END IF;
      IF atom_list(i).obj_value IS NOT NULL THEN

        l_json := l_json || atom_list(i).obj_value;
      ELSE
        l_json := l_json || atom_list(i).obj_clob;
        --dbms_lob.append(l_json, atom_list(i).obj_clob);
      END IF;
      IF atom_list(i).obj_type = 'ARRAY' THEN
        l_json := l_json || ']';
      END IF;
    END LOOP;
    IF l_list = FALSE THEN
      l_json := l_json || '}';
    ELSIF atom_list.count = 0 THEN
      l_json := l_json || '[]';
    END IF;

    <<process_end>>
    l_json := l_json || '}';
    RETURN l_json;
  END;

END;

/

