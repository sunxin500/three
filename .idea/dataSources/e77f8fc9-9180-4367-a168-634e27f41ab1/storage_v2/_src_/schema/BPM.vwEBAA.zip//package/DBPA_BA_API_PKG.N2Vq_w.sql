create package     dbpa_ba_api_pkg is
  --可以用
  -- author  : xiaowei.yao
  -- created : 2018/8/21 10:22:02
  -- purpose :
  /*==================================================
  procedure/function name :
      proc_plat_processcountsbygroup
  description:
      this function perform:
      获取各个系统的流程数量


  history:
      1.00  2018-08-21    xiaowei.yao
  ==================================================*/
  procedure proc_plat_processcountsbygroup(p_request  in clob,
                                           x_response out clob);

  -- author  : han.wu
  -- created : 2018/8/22 14:11:00
  -- purpose :
  /*==================================================
  procedure/function name :
      proc_plat_processexceptionnum
  description:
      this function perform:
      用来展示系统流程异常实例量


  history:
      1.00  2018-08-22    han.wu
  ==================================================*/
  procedure proc_plat_insexceptioncounts(p_request  in clob,
                                         x_response out clob);
  --可以用

  -- created : 2018/8/22 14:11:00 zexiang.pan
  --updated :2018/8/9/1  xiaowei.yao
  -- purpose :
  /*==================================================
  procedure/function name :
      proc_plat_processexceptionnum
  description:
      this function perform:
     获取各个系统的流程详情


  history:
      1.00  2018-08-22   zexiang.pan
  ==================================================*/
  procedure proc_plat_processdetailbygroup(p_request  in clob,
                                           x_response out clob);
  --可以用
  -- author  : zexiang.pan
  -- created : 2018/8/22 14:11:00
  -- purpose :
  /*==================================================
  procedure/function name :
      proc_plat_processexceptionnum
  description:
      this function perform:
     获取各个系统的实例总数和所有系统的实例总数


  history:
      1.00  2018-08-22   zexiang.pan
  ==================================================*/
  procedure proc_plat_inscountsbygroup(p_request  in clob,
                                       x_response out clob);

  -- 可以用
  -- author  : zexiang.pan
  -- created : 2018/8/22 14:11:00
  -- purpose :
  /*==================================================
  procedure/function name :
      proc_plat_processexceptionnum
  description:
      this function perform:
     获取各个流程中的实例总数


  history:
      1.00  2018-08-22   zexiang.pan
  ==================================================*/
  procedure proc_plat_processinsbysum(p_request  in clob,
                                      x_response out clob);
  /*==================================================
  procedure/function name :
      proc_plat_processexceptionnum
  description:
      this function perform:
     获取各个流程平均运行时间


  history:
      1.00  2018-08-25  xiaowei.yao
  ==================================================*/
  procedure proc_plat_processrunavgdura(p_request  in clob,
                                        x_response out clob);

  -- author  : wh_
  -- created : 2018/8/23 15:43:57
  -- purpose :
  /*==================================================
    procedure/function name :
      proc_plat_processexceptionnum
  description:
      this function perform:
      用来展示系统流程异常实例量

  history:
      1.00  2018-08-23    han.wu
  ==================================================*/
  procedure proc_plat_instanceexceptionnum(p_request  in clob,
                                           x_response out clob);

  /*==================================================
    procedure/function name :
      proc_plat_processsysteminfo
  description:
      this function perform:
      获取所有系统信息

  history:
      1.00  2018-08-23    han.wu
  ==================================================*/
  procedure proc_plat_systemlist(p_request in clob, x_response out clob);

  /*==================================================
    procedure/function name :
      proc_plat_processinformation
  description:
      this function perform:
      获取所有流程信息

  history:
      1.00  2018-08-24    han.wu
  ==================================================*/
  procedure proc_plat_processlist(p_request in clob, x_response out clob);

  /*==================================================
    procedure/function name :
      proc_plat_processinformation
  description:
      this function perform:
      获取流程节点平均运行时间

  history:
      1.00  2018-08-29    zexiang,pan
  ==================================================*/
  procedure proc_plat_processnodeavgdura(p_request  in clob,
                                         x_response out clob);
  /*==================================================
    procedure/function name :
      proc_plat_processinformation
  description:
      this function perform:
      通过code获取名字
  history:
      1.00  2018-9-04   xiaowei.yao
  ==================================================*/
  function fun_getname_bycode(p_code varchar2, p_type varchar2)
    return varchar2;
  /*==================================================
    procedure/function name :
      proc_get_processinnodes
  description:
      this function perform:
       获取所有流程下面的节点
  history:
      1.00  2018-9-12   zexiang.pan
  ==================================================*/
  procedure proc_plat_nodelist(p_request in clob, x_response out clob);
  /*==================================================
    procedure/function name :
    procedure proc_plat_processactivitavgrun
      proc_plat_
  description:
      this function perform:
      获取流程审批人平均运行时间

  history:
      1.00  2018-08-29    zexiang,pan
  ==================================================*/
  procedure proc_plat_processactivitavgrun(p_request  in clob,
                                           x_response out clob);
  /*==================================================
    procedure/function name :
    procedure proc_plat_processupandlowcount
      proc_plat_
  description:
      this function perform:
      获取流程上升效率数和降低效率数

  history:
      1.00  2018-09-15    zexiang,pan
  ==================================================*/
  procedure proc_plat_processupandlowcount(p_request  in clob,
                                           x_response out clob);

end dbpa_ba_api_pkg;

/

