create view DFND_LOOKUP_VALUES_V as
SELECT 1 lookup_id,
       'DF_STAGE_DAS_EIS' lookup_type,
       'DS-EIS值列表' lookup_name,
       'DS-EIS值列表' lookup_description,
       1.lookup_value_id,
       'eis/DB/Fusion' lookup_code,
       1 display_sequence,
       'eis/DB/Fusion' meaning,
       null tag,
       null description
  FROM dual
union all
SELECT 2 lookup_id,
       'DF_STAGE_DAS_LOG_STATUS' lookup_type,
       'DS-接口调用状态' lookup_name,
       'DS-接口调用状态' lookup_description,
       2.lookup_value_id,
       'FAILURE' lookup_code,
       1 display_sequence,
       '失败' meaning,
       null tag,
       null description
  FROM dual
union all
SELECT 2 lookup_id,
       'DF_STAGE_DAS_LOG_STATUS' lookup_type,
       'DS-接口调用状态' lookup_name,
       'DS-接口调用状态' lookup_description,
       3.lookup_value_id,
       'SUCCESS' lookup_code,
       2 display_sequence,
       '成功' meaning,
       null tag,
       null description
  FROM dual
union all
SELECT 2 lookup_id,
       'DF_STAGE_DAS_LOG_STATUS' lookup_type,
       'DS-接口调用状态' lookup_name,
       'DS-接口调用状态' lookup_description,
       4.lookup_value_id,
       'FOLDER' lookup_code,
       3 display_sequence,
       '目录' meaning,
       null tag,
       null description
  FROM dual
union all
SELECT 2 lookup_id,
       'DF_STAGE_DAS_LOG_STATUS' lookup_type,
       'DS-接口调用状态' lookup_name,
       'DS-接口调用状态' lookup_description,
       5.lookup_value_id,
       'PROJECT' lookup_code,
       4 display_sequence,
       '项目' meaning,
       null tag,
       null description
  FROM dual
/

