create package     DBPM_PROCESS_AUTH_PKG is

  -- Author  : XJL
  -- Created : 2018/1/8 15:45:23
  -- Purpose : 流程权限分配
  ----migrate by xiaowei.yao 20180411
  /*==================================================
  Procedure/Function Name :
      proc_get_process_auth
  Description:
      This function perform:
      查询流程权限列表
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-01-08  jinglun.xu   Creation
  ==================================================*/
  PROCEDURE proc_get_process_auth(p_request CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_get_process_auth_group
  Description:
      This function perform:
      查询流程权限组列表
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-01-10  jinglun.xu   Creation
  ==================================================*/
  PROCEDURE proc_get_process_auth_group(p_request  CLOB,
                                        x_response OUT CLOB);
  /*==================================================
  Procedure/Function Name :
      proc_save_process_auth_group
  Description:
      This function perform:
      保存流程权限组
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-01-10  jinglun.xu   Creation
  ==================================================*/
  PROCEDURE proc_save_process_auth_group(p_request  CLOB,
                                         x_response OUT CLOB);
  /*==================================================
  Procedure/Function Name :
      proc_save_process_auth
  Description:
      This function perform:
      保存流程权限
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-02-05  jinglun.xu   Creation
  ==================================================*/
  PROCEDURE proc_save_process_auth(p_request CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_del_process_auth_group
  Description:
      This function perform:
      删除流程权限组
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-01-10  jinglun.xu   Creation
  ==================================================*/
  PROCEDURE proc_del_process_auth_group(p_request  CLOB,
                                        x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_get_process_auth_relation
  Description:
      This function perform:
      查询流程权限组配置
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-02-07  jinglun.xu   Creation
  ==================================================*/
  PROCEDURE proc_get_auth_relation(p_request CLOB, x_response OUT CLOB);
  /*==================================================
  Procedure/Function Name :
      proc_del_process_auth_relation
  Description:
      This function perform:
      查询流程权限组配置
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-02-07  jinglun.xu   Creation
  ==================================================*/
  PROCEDURE proc_del_auth_relation(p_request CLOB, x_response OUT CLOB);
  /*==================================================
  Procedure/Function Name :
      proc_save_process_auth_relation
  Description:
      This function perform:
      查询流程权限组配置
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-02-07  jinglun.xu   Creation
  ==================================================*/
  PROCEDURE proc_save_auth_relation(p_request CLOB, x_response OUT CLOB);
  /*  \*==================================================
  Procedure/Function Name :
      proc_save_role_param
  Description:
      This function perform:
      保存流程权限组角色参数
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-03-06  jinglun.xu   Creation
  ==================================================*\
  PROCEDURE proc_save_role_param(p_request CLOB, x_response OUT CLOB);*/
  /*
  * 根据参数化角色获取审批人
  */
  FUNCTION proc_get_auth_role_param(p_relation_id  NUMBER,
                                    p_current_user varchar2) RETURN VARCHAR2;

end DBPM_PROCESS_AUTH_PKG;

/

