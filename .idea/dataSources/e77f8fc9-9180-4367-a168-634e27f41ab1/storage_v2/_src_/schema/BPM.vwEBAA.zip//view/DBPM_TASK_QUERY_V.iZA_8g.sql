create view DBPM_TASK_QUERY_V as
SELECT task.task_id,
       task.task_number,
       task.title,
       task.status,
       proc.process_name,
       proc.process_code,
       proc.process_type,
       task.creation_date,
       task.created_by,
       emp.employee_name AS created_name
  FROM dbpm_tasks task, dbpm_process proc, dfnd_employees emp
 WHERE task.process_id = proc.process_id(+)
   AND upper(task.created_by) = upper(emp.employee_code)
/

