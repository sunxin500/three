create package body     DBPM_PROCESS_AUTH_PKG is

  /*==================================================
  Procedure/Function Name :
      proc_get_process_auth
  Description:
      This function perform:
      查询流程权限列表
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-01-08  jinglun.xu  Creation
  ==================================================*/
  PROCEDURE proc_get_process_auth(p_request CLOB, x_response OUT CLOB) is
    v_request           json;
    v_response          pl_json := pl_json;
    v_auth              pl_json := pl_json;
    v_group             pl_json := pl_json;
    v_array             pl_json := pl_json;
    v_group_id          number;
    v_group_name        VARCHAR2(500);
    v_comments          VARCHAR2(4000);
    v_total             NUMBER := 0;
    v_size              NUMBER := 200;
    v_page              NUMBER := 1;
    v_auth_meaning      varchar2(4000);
    v_auth_type_meaning VARCHAR2(4000);
    v_auth_code         VARCHAR2(500);
    --查询条件
    v_filter json;
    v_desc   varchar2(1000);

    --排序参数
    v_sort_col varchar2(100);
    v_sort     json;
    cursor v_process_auth_cur is
      SELECT *
        FROM (SELECT v.*, rownum cnt
                FROM (select *
                        from (SELECT COUNT(1) over(PARTITION BY 1) total,
                                     t.*,
                                     dcld_comm_pkg.get_lookup_meaning('PROCESS_AUTH_TYPE',T.auth_type,v_request.locale)
                                     auth_type_meaning,
                                     decode(t.auth_type,
                                            'PERSON',
                                            (select nvl(fe.full_name,fe.employee_name)
                                               from dfnd_employees fe
                                              where upper(fe.employee_code) =
                                                    upper(t.auth_code)),
                                            'ORG',
                                            (select fo.organization_name
                                               from dfnd_organizations fo
                                              where fo.organization_code =
                                                    t.auth_code
                                               and rownum =1),
                                            null) auth_meaning
                                from dbpm_process_auth t
                               where t.group_id = v_group_id) tt
                       where INSTR(NVL(tt.auth_code, 'NL'),
                                   NVL(v_auth_code, NVL(tt.auth_code, 'NL'))) > 0
                         and INSTR(NVL(tt.auth_type_meaning, 'NL'),
                                   NVL(v_auth_type_meaning,
                                       NVL(tt.auth_type_meaning, 'NL'))) > 0
                         and INSTR(NVL(tt.auth_meaning, 'NL'),
                                   NVL(v_auth_meaning,
                                       NVL(tt.auth_meaning, 'NL'))) > 0
                       ORDER BY decode(v_sort_col,
                                       'auth_code_desc',
                                       tt.auth_code,
                                       'auth_type_desc',
                                       tt.auth_type) DESC,
                                decode(v_sort_col,
                                       'auth_code_asc',
                                       tt.auth_code,
                                       'auth_type_asc',
                                       tt.auth_type) ASC,
                                tt.auth_id desc) v
               WHERE rownum <= v_page * v_size)
       WHERE cnt > (v_page - 1) * v_size;
  begin
    v_request  := json(p_request, 'OBJECT');
    v_group_id := v_request.get_number('groupId');
    IF v_request.exist('page') THEN
      v_page := v_request.get_number('page');
    END IF;
    IF v_request.exist('size') THEN
      v_size := v_request.get_number('size');
    END IF;
    /*    if v_request.exist('searchField') then
      v_filter    := json(v_request.get('searchField'));
      v_auth_code := v_filter.get_string('authCode');
    end if;*/
    v_auth_code         := dcld_comm_pkg.get_filter_value('authCode',
                                                          v_request);
    v_auth_type_meaning := dcld_comm_pkg.get_filter_value('authTypeMeaning',
                                                          v_request);
    v_auth_meaning      := dcld_comm_pkg.get_filter_value('authMeaning',
                                                          v_request);
    if v_request.exist('sort') then
      v_sort     := json(v_request.get('sort'));
      v_sort_col := v_sort.get_string('value');
      v_sort_col := v_sort_col || '_' || v_sort.get_string('order');
    end if;
    --获取权限组信息
    begin
      select t.group_name, nvl(t.comments, '')
        into v_group_name, v_comments
        from dbpm_process_auth_group t
       where t.group_id = v_group_id;
      v_group.set_value('groupName', v_group_name);
      v_group.set_value('comments', v_comments);
    exception
      when others then
        --v_response.fail('获取权限组数据失败！');
        v_response.fail(DCLD_COMM_PKG.func_get_err_msg('DCLD-00011',
                                                       v_request.locale));
        x_response := v_response.to_json;
    end;
    for c_process_auth_cur in v_process_auth_cur loop
      v_auth := pl_json;
      v_auth.set_value('authId', c_process_auth_cur.auth_id);
      v_auth.set_value('authType', c_process_auth_cur.auth_type);
      v_auth.set_value('authTypeMeaning',
                       c_process_auth_cur.auth_type_meaning);
      v_auth.set_value('authCode', c_process_auth_cur.auth_code);
      v_auth.set_value('authMeaning', c_process_auth_cur.auth_meaning);
      /* if c_process_auth_cur.auth_type = 'PERSON' then
        select fe.full_name
          into v_auth_meaning
          from dfnd_employees fe
         where fe.employee_code = c_process_auth_cur.auth_code;
        v_auth.set_value('authMeaning', v_auth_meaning);
      end if;
      if c_process_auth_cur.auth_type = 'ORG' then
        select fo.organization_name
          into v_auth_meaning
          from dfnd_organizations fo
         where fo.organization_id = c_process_auth_cur.auth_code;
        v_auth.set_value('authMeaning', v_auth_meaning);
      end if;*/
      /*      v_auth.set_value('processCode', c_process_auth_cur.process_code);
      v_auth.set_value('processName', c_process_auth_cur.process_name);*/
      v_total := c_process_auth_cur.total;
      v_array.add_list_item(v_auth);
    end loop;
    v_array.set_data_type('ARRAY');
    v_response.set_value('total', v_total);
    v_response.set_value('authList', v_array);
    x_response := v_response.to_json;
  end proc_get_process_auth;
  /*==================================================
  Procedure/Function Name :
      proc_get_process_auth_group
  Description:
      This function perform:
      查询流程权限组列表
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-01-10  jinglun.xu   Creation
  ==================================================*/
  PROCEDURE proc_get_process_auth_group(p_request  CLOB,
                                        x_response OUT CLOB) is
    v_request   json;
    v_response  pl_json := pl_json;
    v_auth_list pl_json := pl_json;
    v_array     pl_json := pl_json;
    v_group     pl_json := pl_json;
    --分页
    v_total NUMBER := 0;
    v_size  number := 20;
    v_page  number := 1;
    --查询条件
    v_filter     json;
    v_desc       varchar2(1000);
    v_group_name varchar2(100);
    v_group_code varchar2(1000);
    v_all        varchar2(4000);
    --排序参数
    v_sort_col varchar2(100);
    v_sort     json;

    cursor v_auth_group_cur is
      SELECT *
        FROM (SELECT v.*, rownum cnt
                FROM (SELECT COUNT(1) OVER(PARTITION BY 1) TOTAL, t.*
                        from dbpm_process_auth_group t
                       where INSTR(NVL(t.group_name, 'NL'),
                                   NVL(v_group_name, NVL(t.group_name, 'NL'))) > 0
                         AND INSTR(NVL(t.group_code, 'NL'),
                                   NVL(v_group_code, NVL(t.group_code, 'NL'))) > 0
                         AND INSTR(NVL(t.comments, 'NL'),
                                   NVL(v_desc, NVL(t.comments, 'NL'))) > 0
                       ORDER BY decode(v_sort_col,
                                       'group_name_desc',
                                       t.group_name,
                                       'group_code_desc',
                                       t.group_code) DESC,
                                decode(v_sort_col,
                                       'group_name_asc',
                                       t.group_name,
                                       'group_code_asc',
                                       t.group_code) ASC,
                                t.group_id desc) v
               WHERE rownum <= v_page * v_size)
       WHERE cnt > (v_page - 1) * v_size;

    cursor v_lov_auth_group_cur is
      SELECT *
        FROM (SELECT v.*, rownum cnt
                FROM (SELECT COUNT(1) OVER(PARTITION BY 1) TOTAL, t.*
                        from dbpm_process_auth_group t
                       where INSTR(NVL(t.group_name, 'NL'),
                                   NVL(v_all, NVL(t.group_name, 'NL'))) > 0
                          or INSTR(NVL(t.group_code, 'NL'),
                                   NVL(v_all, NVL(t.group_code, 'NL'))) > 0
                          or INSTR(NVL(t.comments, 'NL'),
                                   NVL(v_all, NVL(t.comments, 'NL'))) > 0
                       ORDER BY decode(v_sort_col,
                                       'group_name_desc',
                                       t.group_name,
                                       'group_code_desc',
                                       t.group_code) DESC,
                                decode(v_sort_col,
                                       'group_name_asc',
                                       t.group_name,
                                       'group_code_asc',
                                       t.group_code) ASC,
                                t.group_id desc) v
               WHERE rownum <= v_page * v_size)
       WHERE cnt > (v_page - 1) * v_size;
  begin
    v_request := json(p_request, 'OBJECT');
    if v_request.exist('page') then
      v_page := v_request.get_number('page');
    end if;
    if v_request.exist('size') then
      v_size := v_request.get_number('size');
    end if;
    /*   if v_request.exist('searchField') then
      v_filter     := json(v_request.get('searchField'));
      v_desc       := v_filter.get_string('comments');
      v_group_name := v_filter.get_string('groupName');
      v_group_code := v_filter.get_string('groupCode');
    end if;*/
    v_desc       := dcld_comm_pkg.get_filter_value('comments', v_request);
    v_group_name := dcld_comm_pkg.get_filter_value('groupName', v_request);
    v_group_code := dcld_comm_pkg.get_filter_value('groupCode', v_request);
    --如果传入参数为all，则表明是lov
    v_all := dcld_comm_pkg.get_filter_value('all', v_request);
    if v_request.exist('sort') then
      v_sort     := json(v_request.get('sort'));
      v_sort_col := v_sort.get_string('value');
      v_sort_col := v_sort_col || '_' || v_sort.get_string('order');
    end if;

    if v_all is null then
      for c_auth_group_cur in v_auth_group_cur loop
        v_group := pl_json;
        v_group.set_value('groupId', c_auth_group_cur.group_id);
        v_group.set_value('groupName', c_auth_group_cur.group_name);
        v_group.set_value('groupCode', c_auth_group_cur.group_code);
        v_group.set_value('comments', c_auth_group_cur.comments);
        v_group.set_value('creationDate', c_auth_group_cur.creation_date);
        v_total := c_auth_group_cur.total;
        v_array.add_list_item(v_group);
      end loop;
    else
      for c_auth_group_cur in v_lov_auth_group_cur loop
        v_group := pl_json;
        v_group.set_value('groupId', c_auth_group_cur.group_id);
        v_group.set_value('groupName', c_auth_group_cur.group_name);
        v_group.set_value('groupCode', c_auth_group_cur.group_code);
        v_group.set_value('comments', c_auth_group_cur.comments);
        v_group.set_value('creationDate', c_auth_group_cur.creation_date);
        v_total := c_auth_group_cur.total;
        v_array.add_list_item(v_group);
      end loop;
    end if;
    v_array.set_data_type('ARRAY');
    v_response.set_value('authList', v_array);
    v_response.set_value('total', v_total);
    x_response := v_response.to_json;
  end proc_get_process_auth_group;

  /*==================================================
  Procedure/Function Name :
      proc_save_process_auth_group
  Description:
      This function perform:
      保存流程权限组
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-01-10  jinglun.xu   Creation
  ==================================================*/
  PROCEDURE proc_save_process_auth_group(p_request  CLOB,
                                         x_response OUT CLOB) is
    v_request    json;
    v_response   pl_json := pl_json;
    v_auth_list  json_list;
    v_auth       json;
    v_group_id   number;
    v_auth_id    number;
    v_space_id   varchar2(200);
    v_group_name varchar2(500);
    v_comments   varchar2(4000);
    v_auth_type  varchar2(100);
    v_auth_code  varchar2(200);
    v_process_id number;
    v_group_code varchar2(200);
    v_count      number;
  begin
    v_request    := json(p_request, 'OBJECT');
    v_group_id   := v_request.get_number('groupId');
    v_group_name := v_request.get_string('groupName');
    v_comments   := v_request.get_string('comments');
    v_space_id   := v_request.get_string('spaceId');
    v_group_code := v_request.get_string('groupCode');
    if v_group_id is null then
      --新增权限信息
      select count(*)
        into v_count
        from dbpm_process_auth_group t
       where t.group_code = v_group_code;
      if v_count <> 0 then
        --v_response.fail('权限组编码不唯一！');
        v_response.fail(DCLD_COMM_PKG.func_get_err_msg('DCLD-00012',
                                                       v_request.locale));
        x_response := v_response.to_json;
        return;
      end if;
      v_group_id := dbpm_process_auth_group_s.nextval;
      insert into dbpm_process_auth_group
        (group_id, group_name, comments, space_id, group_code)
      values
        (v_group_id, v_group_name, v_comments, v_space_id, v_group_code);
      /*  if v_request.exist('authList') then
        v_auth_list := json_list(v_request.get('authList'));
        for i in 1 .. v_auth_list.count loop
          v_auth := json(v_auth_list.get(i));
          if v_auth.count <> 0 then
            v_auth_type  := v_auth.get_string('authType');
            v_auth_code  := v_auth.get_string('authCode');
            v_process_id := v_auth.get_number('processId');
            insert into dbpm_process_auth
              (auth_id, auth_type, auth_code, group_id)
            values
              (dbpm_process_auth_s.nextval,

               v_auth_type,
               v_auth_code,
               v_group_id);
          end if;
        end loop;
      end if;*/
    else
      --更新权限信息
      update dbpm_process_auth_group t
         set t.group_name = v_group_name, t.comments = v_comments
       where t.group_id = v_group_id;
      /*      if v_request.exist('authList') then
        v_auth_list := json_list(v_request.get('authList'));
        delete from dbpm_process_auth t where t.group_id = v_group_id;
        for i in 1 .. v_auth_list.count loop
          v_auth := json(v_auth_list.get(i));
          if v_auth.count <> 0 then
            v_auth_id    := v_auth.get_number('authId');
            v_auth_type  := v_auth.get_string('authType');
            v_auth_code  := v_auth.get_string('authCode');
            v_process_id := v_auth.get_number('processId');
            insert into dbpm_process_auth
              (auth_id, auth_type, auth_code, group_id)
            values
              (v_auth_id,

               v_auth_type,
               v_auth_code,
               v_group_id);
          end if;
        end loop;
      end if;*/
    end if;

    v_response.set_value('groupId', v_group_id);
    x_response := v_response.to_json;
  end proc_save_process_auth_group;
  /*==================================================
  Procedure/Function Name :
      proc_save_process_auth
  Description:
      This function perform:
      保存流程权限
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-02-05  jinglun.xu   Creation
  ==================================================*/
  PROCEDURE proc_save_process_auth(p_request CLOB, x_response OUT CLOB) is
    v_request    json;
    v_response   pl_json := pl_json;
    v_auth_list  json_list;
    v_auth       json;
    v_group_id   number;
    v_auth_id    number;
    v_group_name varchar2(500);
    v_comments   varchar2(4000);
    v_auth_type  varchar2(100);
    v_auth_code  varchar2(200);
    v_process_id number;
  begin
    v_request   := json(p_request, 'OBJECT');
    v_group_id  := v_request.get_number('groupId');
    v_auth_id   := v_request.get_number('authId');
    v_auth_type := v_request.get_string('authType');
    v_auth_code := v_request.get_string('authCode');
    if v_auth_id is null then
      --新增权限信息
      v_auth_id := dbpm_process_auth_s.nextval;
      insert into dbpm_process_auth
        (auth_id, auth_type, auth_code, group_id)
      values
        (dbpm_process_auth_s.nextval, v_auth_type, v_auth_code, v_group_id);
    else
      --更新权限信息
      update dbpm_process_auth t
         set t.auth_type = v_auth_type, t.auth_code = v_auth_code
       where t.auth_id = v_auth_id;
    end if;
    v_response.set_value('authId', v_auth_id);
    x_response := v_response.to_json;
  end proc_save_process_auth;

  /*==================================================
  Procedure/Function Name :
      proc_del_process_auth_group
  Description:
      This function perform:
      删除流程权限组
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-01-10  jinglun.xu   Creation
  ==================================================*/
  PROCEDURE proc_del_process_auth_group(p_request  CLOB,
                                        x_response OUT CLOB) is
    v_request  json;
    v_response pl_json := pl_json;
    v_group_id NUMBER;
    v_auth_id  number;
  begin
    v_request  := json(p_request, 'OBJECT');
    v_group_id := v_request.get_number('groupId');
    v_auth_id  := v_request.get_number('authId');
    if v_group_id is not null then
      delete from dbpm_process_auth_group t where t.group_id = v_group_id;
      delete from dbpm_process_auth t where t.group_id = v_group_id;
    end if;
    if v_auth_id is not null then
      delete from dbpm_process_auth t where t.auth_id = v_auth_id;
    end if;
    x_response := v_response.to_json;
  end proc_del_process_auth_group;
  /*==================================================
  Procedure/Function Name :
      proc_get_process_auth_relation
  Description:
      This function perform:
      查询流程权限组配置
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-02-07  jinglun.xu   Creation
  ==================================================*/
  PROCEDURE proc_get_auth_relation(p_request CLOB, x_response OUT CLOB) is
    v_request           json;
    v_response          pl_json := pl_json;
    v_process_id        NUMBER;
    v_array             pl_json := pl_json;
    v_role_parm_list    pl_json := pl_json;
    v_relation          pl_json := pl_json;
    v_auth_code         varchar2(200);
    v_relation_list     pl_json := pl_json;
    v_auth_code_meaning varchar2(2000);
    --分页
    v_total NUMBER := 0;
    v_size  number := 20;
    v_page  number := 1;
    --查询条件
    v_filter     json;
    v_desc       varchar2(1000);
    v_group_name varchar2(100);
    v_group_code varchar2(1000);
    --排序参数
    v_sort_col varchar2(100);
    v_sort     json;
    --权限角色参数
    v_role_parm   pl_json;
    v_relation_id number;
    cursor v_role_parm_cur is
      select t2.role_id,
             t2.param_id,
             t2.param_name,
             '' param_value,
             '' operation_type,
             '' get_value_type
        from (select dr.role_id
                from dbpm_roles dr, dbpm_process_group_realtion dp
               where dr.role_code = dp.auth_code
                 and dp.realtion_id = v_relation_id) t1,
             dbpm_role_params t2
       where t2.role_id = t1.role_id
         and t2.param_id not in
             ((select t.param_id
                from dbpm_roles                  dr,
                     DBPM_AUTH_ROLE_PARAM_VALUE  t,
                     dbpm_process_group_realtion dp
               where dr.role_code = dp.auth_code
                 and t.realtion_id = dp.realtion_id
                 and t2.param_id = t.param_id
                 and dp.realtion_id = v_relation_id))
      union all (select dr.role_id,
                        t.param_id,
                        drp.param_name,
                        t.param_value,
                        t.operation_type,
                        t.get_value_type
                   from dbpm_role_params            drp,
                        dbpm_roles                  dr,
                        DBPM_AUTH_ROLE_PARAM_VALUE  t,
                        dbpm_process_group_realtion dp
                  where dr.role_code = dp.auth_code
                    and t.param_id = drp.param_id
                    and t.realtion_id = dp.realtion_id
                    and dp.realtion_id = v_relation_id);
    cursor v_relation_cur is
      SELECT *
        FROM (SELECT v.*, rownum cnt
                FROM (SELECT COUNT(1) OVER(PARTITION BY 1) TOTAL,
                             t.*,
                             dcld_comm_pkg.get_lookup_meaning('AUTH_RELATION_TYPE',T.auth_type,v_request.locale)
                              relation_meaning
                        from dbpm_process_group_realtion t
                       where t.process_id = v_process_id
                         and INSTR(NVL(t.auth_code, 'NL'),
                                   NVL(v_auth_code, NVL(t.auth_code, 'NL'))) > 0

                       ORDER BY decode(v_sort_col,
                                       'auth_code_desc',
                                       t.auth_code,
                                       'auth_type_desc',
                                       t.auth_type) DESC,
                                decode(v_sort_col,

                                       'auth_code_asc',
                                       t.auth_code,
                                       'auth_type_asc',
                                       t.auth_type) ASC,
                                t.realtion_id desc) v
               WHERE rownum <= v_page * v_size)
       WHERE cnt > (v_page - 1) * v_size;
  begin
    v_request    := json(p_request, 'OBJECT');
    v_process_id := v_request.get_number('processId');
    if v_request.exist('page') then
      v_page := v_request.get_number('page');
    end if;
    if v_request.exist('size') then
      v_size := v_request.get_number('size');
    end if;
    if v_request.exist('searchField') then
      v_filter    := json(v_request.get('searchField'));
      v_auth_code := v_filter.get_string('authCode');
    end if;
    if v_request.exist('sort') then
      v_sort     := json(v_request.get('sort'));
      v_sort_col := v_sort.get_string('value');
      v_sort_col := v_sort_col || '_' || v_sort.get_string('order');
    end if;
    for c_relation_cur in v_relation_cur loop
      v_relation       := pl_json;
      v_role_parm_list := pl_json;
      v_relation_id    := c_relation_cur.realtion_id;
      begin
        if c_relation_cur.auth_type = 'ROLE' then
          select dr.role_name
            into v_auth_code_meaning
            from dbpm_roles dr
           where dr.role_code = c_relation_cur.auth_code;
          for c_role_parm_cur in v_role_parm_cur loop
            v_role_parm := pl_json;
            v_role_parm.set_value('paramId', c_role_parm_cur.param_id);
            v_role_parm.set_value('paramName', c_role_parm_cur.param_name);
            v_role_parm.set_value('operationType',
                                  c_role_parm_cur.operation_type);
            v_role_parm.set_value('paramValue',
                                  c_role_parm_cur.param_value);
            v_role_parm.set_value('getValueType',
                                  c_role_parm_cur.get_value_type);
            v_role_parm_list.add_list_item(v_role_parm);
          end loop;
          v_role_parm_list.set_data_type('ARRAY');
        end if;
        if c_relation_cur.auth_type = 'GROUP' then
          select t.group_name
            into v_auth_code_meaning
            from dbpm_process_auth_group t
           where t.group_code = c_relation_cur.auth_code;
        end if;
      exception
        when no_data_found then
          continue;
      end;
      v_relation.set_value('realtionId', c_relation_cur.realtion_id);
      v_relation.set_value('processId', c_relation_cur.process_id);
      v_relation.set_value('authCode', c_relation_cur.auth_code);
      /* if c_relation_cur.auth_type = 'ROLE' then
        select dr.role_name
          into v_auth_code_meaning
          from dbpm_roles dr
         where dr.role_code = c_relation_cur.auth_code;
      end if;
      if c_relation_cur.auth_type = 'GROUP' then
        select t.group_name
          into v_auth_code_meaning
          from dbpm_process_auth_group t
         where t.group_code = c_relation_cur.auth_code;
      end if;*/
      v_relation.set_value('paramList', v_role_parm_list);
      v_relation.set_value('authCodeMeaning', v_auth_code_meaning);
      v_relation.set_value('authType', c_relation_cur.auth_type);
      v_relation.set_value('authTypeMeaning',
                           c_relation_cur.relation_meaning);

      v_total := c_relation_cur.total;
      v_array.add_list_item(v_relation);
    end loop;
    v_array.set_data_type('ARRAY');

    v_response.set_value('total', v_total);
    v_response.set_value('authList', v_array);
    x_response := v_response.to_json;
    RETURN;
  end proc_get_auth_relation;
  /*==================================================
  Procedure/Function Name :
      proc_del_process_auth_relation
  Description:
      This function perform:
      删除流程权限组配置
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-02-07  jinglun.xu   Creation
  ==================================================*/
  PROCEDURE proc_del_auth_relation(p_request CLOB, x_response OUT CLOB) is
    v_request     json;
    v_response    pl_json := pl_json;
    v_realtion_id NUMBER;

  begin
    v_request     := json(p_request, 'OBJECT');
    v_realtion_id := v_request.get_number('realtionId');
    delete from dbpm_process_group_realtion t
     where t.realtion_id = v_realtion_id;
    x_response := v_response.to_json;
  end proc_del_auth_relation;
  /*==================================================
  Procedure/Function Name :
      proc_save_process_auth_relation
  Description:
      This function perform:
      保存流程权限组配置
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-02-07  jinglun.xu   Creation
  ==================================================*/
  PROCEDURE proc_save_auth_relation(p_request CLOB, x_response OUT CLOB) is
    v_request     json;
    v_response    pl_json := pl_json;
    v_realtion_id NUMBER;
    v_process_id  number;
    v_auth_type   varchar2(200);
    v_auth_code   varchar2(200);
    v_count       number;
    v_param_list  json_list;
    v_param       jSOn;
  begin
    v_request     := json(p_request, 'OBJECT');
    v_realtion_id := v_request.get_number('realtionId');
    v_process_id  := v_request.get_number('processId');
    v_auth_code   := v_request.get_string('authCode');
    v_auth_type   := v_request.get_string('authType');
    if v_realtion_id is null then
      /* select count(1)
        into v_count
        from dbpm_process_group_realtion t
       where t.auth_code = v_auth_code
         and t.process_id = v_process_id;
      if v_count <> 0 then
        --v_response.fail('授权重复，请重新选择！');
        v_response.fail(DCLD_COMM_PKG.func_get_err_msg('DCLD-00013',
                                                       v_request.locale));
        x_response := v_response.to_json;
        return;
      end if;*/
      v_realtion_id := dbpm_process_group_realtion_s.nextval;
      insert into dbpm_process_group_realtion
        (realtion_id, process_id, auth_code, auth_type)
      values
        (v_realtion_id, v_process_id, v_auth_code, v_auth_type);
    else
      select count(1)
        into v_count
        from dbpm_process_group_realtion t
       where t.auth_code = v_auth_code
         and t.process_id = v_process_id
         and t.realtion_id <> v_realtion_id;
      if v_count <> 0 then
        --v_response.fail('授权重复，请重新选择！');
        v_response.fail(DCLD_COMM_PKG.func_get_err_msg('DCLD-00013',
                                                       v_request.locale));
        x_response := v_response.to_json;
        return;
      end if;
      update dbpm_process_group_realtion t
         set t.auth_code = v_auth_code, t.auth_type = v_auth_type
       where t.realtion_id = v_realtion_id;
    end if;
    if v_request.exist('paramList') then
      delete from DBPM_AUTH_ROLE_PARAM_VALUE t
       where t.realtion_id = v_realtion_id;
      v_param_list := json_list(v_request.path('paramList'));
      FOR k IN 1 .. v_param_list.count LOOP
        v_param := json(v_param_list.get(k));
        if v_param.get_string('getValueType') is not null and
           v_param.get_string('operationType') is not null then
          insert into DBPM_AUTH_ROLE_PARAM_VALUE
            (REALTION_ID,
             PARAM_ID,
             PARAM_VALUE,
             GET_VALUE_TYPE,
             OPERATION_TYPE)
          values
            (v_realtion_id,
             v_param.get_number('paramId'),
             v_param.get_string('paramValue'),
             v_param.get_string('getValueType'),
             v_param.get_string('operationType'));
        end if;
      end loop;

    end if;
    x_response := v_response.to_json;
  end proc_save_auth_relation;

  /* \*==================================================
  Procedure/Function Name :
      proc_save_role_param
  Description:
      This function perform:
      保存流程权限组角色参数
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-03-06  jinglun.xu   Creation
  ==================================================*\
  PROCEDURE proc_save_role_param(p_request CLOB, x_response OUT CLOB) is
    v_request        json;
    v_response       pl_json := pl_json;
    v_param_list     json_list;
    v_param          jSOn;
    v_realtion_id    NUMBER;
    v_process_id     number;
    v_param_id       number;
    v_operation_type VARCHAR2(100);
    v_param_value    VARCHAR2(4000);
    v_get_value_type VARCHAR2(4000);
    v_count          number;
  begin
    v_request     := json(p_request, 'OBJECT');
    v_realtion_id := v_request.get_number('realtionId');
    delete from DBPM_AUTH_ROLE_PARAM_VALUE t
     where t.realtion_id = v_realtion_id;
    if v_request.exist('paramList') then
      v_param_list := json_list(v_request.path('paramList'));
      FOR k IN 1 .. v_param_list.count LOOP
        v_param := json(v_param_list.get(k));
        insert into DBPM_AUTH_ROLE_PARAM_VALUE
          (REALTION_ID,
           PARAM_ID,
           PARAM_VALUE,
           GET_VALUE_TYPE,
           OPERATION_TYPE)
        values
          (v_realtion_id,
           v_param.get_number('paramId'),
           v_param.get_string('paramValue'),
           v_param.get_string('getValueType'),
           v_param.get_string('operationType'));
      end loop;

    end if;
    x_response := v_response.to_json;
  end proc_save_role_param;*/
  /*
  * 根据参数化角色获取审批人
  */
  FUNCTION proc_get_auth_role_param(p_relation_id  NUMBER,
                                    p_current_user varchar2) RETURN VARCHAR2 IS
    TYPE role_member_cursor_type IS REF CURSOR; -- 动态游标
    v_role_member_cursor role_member_cursor_type;
    v_role_code          VARCHAR2(100);
    v_member_code        VARCHAR2(100);
    -- 节点审批角色
    CURSOR v_node_role_cur IS
      SELECT *
        FROM BPM.dbpm_process_group_realtion dnr
       WHERE dnr.realtion_id = p_relation_id
         and dnr.auth_type = 'ROLE';
    -- 角色成员（包含参数）
    /*CURSOR v_role_member_cur(p_role_code VARCHAR2, p_node_id NUMBER) IS
    SELECT dr.role_code, drm.member_code
      FROM BPM.dbpm_roles              dr,
           BPM.dbpm_role_members       drm,
           BPM.dbpm_role_params        drp,
           BPM.dbpm_role_member_params drmp
     WHERE dr.role_id = drm.role_id
       AND dr.role_id = drp.role_id
       AND drp.param_id = drmp.param_id
       AND drp.role_id = dr.role_id
       AND drmp.member_id = drm.member_id
       AND drmp.param_value =
           dbpm_core_pkg.func_get_node_role_param_value(p_node_id,
                                                        dr.role_code,
                                                        drp.param_id,
                                                        p_document_id,
                                                        p_business_param)
       AND dr.role_code = p_role_code;*/

    v_role_id        VARCHAR2(100);
    v_role_has_param VARCHAR2(10);
    v_sql            VARCHAR2(4000);
    v_where          VARCHAR2(4000);
    v_operation_type VARCHAR2(100);
    v_param_value    VARCHAR2(4000);
    x_approvers      VARCHAR2(4000);
    v_count          number;
  BEGIN
    -- 1. 获取审批节点配置的业务角色
    FOR v_node_role IN v_node_role_cur LOOP
      SELECT dr.role_id
        INTO v_role_id
        FROM BPM.dbpm_roles dr
       WHERE dr.role_code = v_node_role.auth_code;

      -- 2. 获取角色成员
      /*   IF v_role_has_param = 'Y' THEN*/
      -- 循环参数
      v_sql := 'SELECT member_code FROM dbpm_role_members drm WHERE drm.role_id = ''' ||
               v_role_id || ''' ';
      --判断是否有角色参数
      select count(1)
        into v_count
        from DBPM_AUTH_ROLE_PARAM_VALUE adr
       where adr.realtion_id = p_relation_id;
      if v_count = 0 then
        RETURN 'Y';
      end if;
      FOR v_node_role_param IN (SELECT *
                                  FROM dbpm_role_params drp
                                 WHERE drp.role_id = v_role_id) LOOP
        -- 拿到角色成员参数值，拿到配置的参数值
        v_operation_type := null;
        v_param_value    := null;
        begin
          select adr.operation_type, adr.param_value
            into v_operation_type, v_param_value
            from DBPM_AUTH_ROLE_PARAM_VALUE adr
           where adr.realtion_id = p_relation_id
             and adr.param_id = v_node_role_param.param_id;
        exception
          when no_data_found then
            continue;
        end;
        /*  v_operation_type := dbpm_core_pkg.func_get_node_role_param_ope(p_node_id,
                                                                       v_node_role.business_role,
                                                                       v_node_role_param.param_id,
                                                                       p_document_id,
                                                                       p_business_param);
        v_param_value    := dbpm_core_pkg.func_get_node_role_param_value(p_node_id,
                                                                         v_node_role.business_role,
                                                                         v_node_role_param.param_id,
                                                                         p_document_id,
                                                                         p_business_param);*/
        -- 设置只校验 param value 不等于 空的情况下  modify by chenzhibin
        IF (v_operation_type = '=' OR v_operation_type = '>' OR
           v_operation_type = '<' OR v_operation_type = '>=' OR
           v_operation_type = '<=' OR v_operation_type = '<>') and
           v_operation_type is not null and v_param_value is not null THEN
          -- 从members表中过滤出符合条件的人员
          v_where := v_sql || 'AND EXISTS ' ||
                     '(SELECT 1 FROM dbpm_role_member_params drmp ' ||
                     'WHERE drmp.member_id = drm.member_id ' ||
                     'AND drmp.param_id = ' || v_node_role_param.param_id || ' ' ||
                     'AND drmp.param_value' || v_operation_type || '''' ||
                     v_param_value || ''') ';
        ELSIF v_operation_type = 'IN' and v_operation_type is not null and
              v_param_value is not null THEN
          v_where := v_sql || 'AND EXISTS ' ||
                     '(SELECT 1 FROM dbpm_role_member_params drmp ' ||
                     'WHERE drmp.member_id = drm.member_id ' ||
                     'AND drmp.param_id = ' || v_node_role_param.param_id || ' ' ||
                     'AND instr(''' || v_param_value ||
                     ''',drmp.param_value) > 0)';
        ELSIF v_operation_type = 'LIKE' and v_operation_type is not null and
              v_param_value is not null THEN
          v_where := v_sql || 'AND EXISTS ' ||
                     '(SELECT 1 FROM dbpm_role_member_params drmp ' ||
                     'WHERE drmp.member_id = drm.member_id ' ||
                     'AND drmp.param_id = ' || v_node_role_param.param_id || ' ' ||
                     'AND instr(drmp.param_value, ''' || v_param_value ||
                     ''') > 0)';
        END IF;
        -- modify by chenzhibin  end
      END LOOP;

      v_sql := v_where || 'and member_code =''' || p_current_user || '''';

      -- 2.1 如果包含角色参数的，需计算角色参数值，然后过滤角色成员
      OPEN v_role_member_cursor FOR v_sql;
      LOOP
        FETCH v_role_member_cursor
          INTO v_member_code;
        EXIT WHEN v_role_member_cursor%NOTFOUND;
        x_approvers := x_approvers || v_member_code;
      END LOOP;
      CLOSE v_role_member_cursor;

    -- 2.1 如果包含角色参数的，需计算角色参数值，然后过滤角色成员
    /*FOR v_role_member IN v_role_member_cur(v_node_role.business_role,
                                                                                                                           p_node_id) LOOP
                                                                                      x_approvers := x_approvers || v_role_member.member_code || ',';
                                                                                    END LOOP;*/
    /*     ELSE
                                                                                    -- 2.2 如果不包含角色参数的，直接取角色成员
                                                                                    FOR v_role_member IN (SELECT *
                                                                                                            FROM BPM.dbpm_role_members drm
                                                                                                           WHERE drm.role_id = v_role_id) LOOP
                                                                                      x_approvers := x_approvers || v_role_member.member_code || ',';
                                                                                    END LOOP;
                                                                                  END IF;*/
    END LOOP;
    IF x_approvers IS NULL THEN
      RETURN 'N';
    ELSE
      RETURN 'Y';
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN 'failed';
  END proc_get_auth_role_param;
end DBPM_PROCESS_AUTH_PKG;

/

