create view FND_EMPLOYEES as
select t.EMPLOYEE_ID emp_id,t.EMPLOYEE_NAME emp_displayname ,t.EMAIL emp_email from  fnd_employees@df_fnd_dblink t
/

