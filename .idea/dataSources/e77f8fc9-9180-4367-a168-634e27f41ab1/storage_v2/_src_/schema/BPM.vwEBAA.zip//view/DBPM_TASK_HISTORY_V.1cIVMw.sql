create view DBPM_TASK_HISTORY_V as
SELECT history.history_id,
       history.document_id,
       history.approver_code,
       history.approver_name
  FROM dbpm_approval_history history
/

