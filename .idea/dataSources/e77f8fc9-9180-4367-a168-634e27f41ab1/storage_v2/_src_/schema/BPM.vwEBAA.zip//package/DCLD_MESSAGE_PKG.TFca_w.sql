create PACKAGE     dcld_message_pkg IS
  /*==================================================
  Procedure/Function Name :
      proc_query_sys_msg_list
  Description:
      This function perform:
      查询系统消息列表
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-03-17  chenming  Creation
  ==================================================*/
  PROCEDURE proc_query_sys_msg_list(p_request CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_add_sys_msg
  Description:
      This function perform:
      新增系统消息
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-03-17  chenming  Creation
  ==================================================*/
  PROCEDURE proc_add_sys_msg(p_request CLOB, x_response OUT CLOB);

  /*==================================================
  Procedure/Function Name :
      proc_read_sys_msg
  Description:
      This function perform:
      阅读系统消息
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-03-17  chenming  Creation
  ==================================================*/
  PROCEDURE proc_read_sys_msg(p_request CLOB, x_response OUT CLOB);

  --插入服务日志
  PROCEDURE proc_add_service_log(p_UUID            in varchar2,
                               p_INSTANCE_ID           in varchar2,
                               p_NODE_ID             in NUMBER,
                               p_SERVICE_ID     in NUMBER,
                               p_SERVICE_URL in varchar2,
                               p_CONTENT_TYPE         in varchar2,
                               p_REQUEST_CONTENT         in varchar2,
                               p_REQUEST_DATE         in varchar2,
                               p_RESPONSE_CONTENT         in varchar2,
                               p_RESPONSE_DATE         in varchar2,
                               p_ERROR_LOG         in varchar2,
                               p_response_code    in number,
                               p_ATTRIBUTE1         in varchar2,
                               p_ATTRIBUTE2         in varchar2,
                               p_ATTRIBUTE3         in varchar2,
                               p_ATTRIBUTE4         in varchar2,
                               p_ATTRIBUTE5         in varchar2,
                               p_result             out varchar2);

END dcld_message_pkg;

/

