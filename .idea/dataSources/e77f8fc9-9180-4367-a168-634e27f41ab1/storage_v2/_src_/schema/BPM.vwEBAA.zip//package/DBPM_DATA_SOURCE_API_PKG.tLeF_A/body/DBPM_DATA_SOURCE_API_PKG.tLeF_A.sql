create PACKAGE BODY     dbpm_data_source_api_pkg IS

  /*==================================================
  Procedure/Function Name :
      proc_query_data_source
  Description:
      This function perform:
      查询数据字典
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-05-03  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_query_data_sources(p_request IN CLOB, x_response OUT CLOB) IS
    v_response       pl_json := pl_json;
    v_datasouce_json pl_json;
    v_request        json;
    v_current_user   VARCHAR2(50);
    v_status         VARCHAR2(10);
    --分页
    v_total NUMBER := 0;
    v_size  number := 50;
    v_page  number := 1;
    --查询条件
    v_filter json;
    v_desc   varchar2(1000);
    v_code   varchar2(100);
    v_name   varchar2(1000);
    --排序参数
    v_sort_col varchar2(100);
    v_sort     json;
    v_spaceId  number;
    CURSOR v_datasource_cur IS
      SELECT *
        FROM (SELECT v.*, rownum cnt
                FROM (SELECT COUNT(1) OVER(PARTITION BY 1) TOTAL, dds.*
                        FROM dbpm_data_source dds
                       WHERE INSTR(NVL(DDS.DATA_SOURCE_CODE, 'NL'),
                                   NVL(v_code, NVL(DDS.DATA_SOURCE_CODE, 'NL'))) > 0
                         AND INSTR(NVL(DDS.DATA_SOURCE_NAME, 'NL'),
                                   NVL(v_name, NVL(DDS.DATA_SOURCE_NAME, 'NL'))) > 0
                         AND INSTR(NVL(DDS.DESCRIPTION, 'NL'),
                                   NVL(v_desc, NVL(DDS.DESCRIPTION, 'NL'))) > 0
                      -- and dds.space_id=decode(dds.data_source_type,'System',dds.space_id,'Custom',nvl(v_spaceId,dds.space_id))
                      --   and dds.space_id=dds.space_id
                       ORDER BY decode(v_sort_col,
                                       'data_source_code_desc',
                                       dds.data_source_code,
                                       'data_source_name_desc',
                                       dds.data_source_name,
                                       'description_desc',
                                       dds.description,
                                       'data_source_type_name_desc',
                                       dds.data_source_type) DESC,
                                decode(v_sort_col,
                                       'data_source_code_asc',
                                       dds.data_source_code,
                                       'data_source_name_asc',
                                       dds.data_source_name,
                                       'description_asc',
                                       dds.description,
                                       'data_source_type_name_asc',
                                       dds.data_source_type) ASC,
                                creation_date desc) v
               WHERE rownum <= v_page * v_size)
       WHERE cnt > (v_page - 1) * v_size;

  BEGIN
    select count(1) into v_size from dbpm_data_source;
    v_request      := json(p_request, 'OBJECT');
    v_current_user := v_request.username;

    if v_request.exist('page') then
      v_page := v_request.get_number('page');
    end if;
    if v_request.exist('size') then
      v_size := v_request.get_number('size');
    end if;

    v_spaceId := v_request.get_number('spaceId');

    v_desc := dcld_comm_pkg.get_filter_value('description', v_request);
    v_code := dcld_comm_pkg.get_filter_value('dataSourceCode', v_request);
    v_name := dcld_comm_pkg.get_filter_value('dataSourceName', v_request);
    /* if v_request.exist('filter') then
      v_filter := json(v_request.get('filter'));
      v_desc   := v_filter.get_string('description');
      v_code   := v_filter.get_string('dataSourceCode');
      v_name   := v_filter.get_string('dataSourceName');
    end if;*/
    if v_request.exist('sort') then
      v_sort     := json(v_request.get('sort'));
      v_sort_col := v_sort.get_string('value');
      v_sort_col := v_sort_col || '_' || v_sort.get_string('order');
    end if;

    FOR v_datasource IN v_datasource_cur LOOP
      v_total          := v_datasource.total;
      v_datasouce_json := pl_json;
      v_datasouce_json.set_value('dataSourceCode',
                                 v_datasource.data_source_code);
      v_datasouce_json.set_value('dataSourceName',
                                 v_datasource.data_source_name);
      v_datasouce_json.set_value('description', v_datasource.description);
      v_datasouce_json.set_value('dataSourceType',
                                 v_datasource.data_source_type);
      v_datasouce_json.set_value('dataSourceTypeName',
                                 dcld_comm_pkg.get_data_source_value('DataSourceType',
                                                                     v_datasource.data_source_type,
                                                                     v_request.locale));
      /*v_datasouce_json.set_value('dataSourceSql',
      v_datasource.data_source_sql);*/
      v_response.add_list_item('dataSourceList', v_datasouce_json);
    END LOOP;

    v_response.set_value('total', v_total);
    x_response := v_response.to_json;
  END proc_query_data_sources;

  /*==================================================
  Procedure/Function Name :
      proc_save_datasource
  Description:
      This function perform:
      保存数据字典，需要判断是新增还是修改
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-20  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_save_data_source(p_request IN CLOB, x_response OUT CLOB) IS
    v_api             VARCHAR2(30) := 'proc_save_data_source';
    v_request         json;
    v_response        pl_json := pl_json;
    v_datasource_code VARCHAR2(100);
    v_current_user    VARCHAR2(50);
    v_count           NUMBER;
    v_is_new          varchar2(10);
    v_spaceId         number;
  BEGIN
    v_request         := json(p_request, 'OBJECT');
    v_current_user    := v_request.username;
    v_datasource_code := v_request.get('dataSourceCode').get_string;
    v_is_new          := v_request.get_string('isNew');
    v_spaceId         := v_request.get_number('spaceId');
    --查询是否存在该数据
    SELECT COUNT(1)
      INTO v_count
      FROM dbpm_data_source t
     WHERE t.data_source_code = v_datasource_code;
    if v_is_new is null then
      v_is_new := 'N';
    end if;
    IF v_count = 0 and v_is_new = 'Y' THEN
      INSERT INTO dbpm_data_source
        (data_source_code,
         data_source_name,
         data_source_type,
         --data_source_sql,
         description,
         status,
         created_by,
         last_updated_by,
         space_id)
      VALUES
        (v_datasource_code,
         v_request.get    ('dataSourceName'    ).get_string,
         v_request.get    ('dataSourceType'    ).get_string,
         --v_request.get    ('dataSourceSql'    ).get_string,
         v_request.get ('description' ).get_string,
         'Y',
         v_current_user,
         v_current_user,
         v_spaceId);
    ELSif v_is_new = 'N' and v_count <> 0 then
      UPDATE dbpm_data_source dds
         SET dds.data_source_name = v_request.get('dataSourceName').get_string,
             --dds.data_source_sql  = v_request.get('dataSourceSql').get_string,
             dds.description = v_request.get('description').get_string,

             dds.object_version_number = dds.object_version_number + 1,
             dds.last_updated_by       = v_current_user
       WHERE dds.data_source_code = v_datasource_code;
    END IF;

    x_response := v_response.to_json;
    /* EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_save_data_source;

  /*==================================================
  Procedure/Function Name :
      proc_del_datasource
  Description:
      This function perform:
      删除数据字典
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-20  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_del_data_source(p_request IN CLOB, x_response OUT CLOB) IS
    v_api             VARCHAR2(30) := 'proc_del_datasource';
    v_request         json;
    v_response        pl_json := pl_json;
    v_datasource_code VARCHAR2(100);
    v_count           NUMBER := 0;
  BEGIN
    v_request         := json(p_request, 'OBJECT');
    v_datasource_code := v_request.get('dataSourceCode').get_string;

    SELECT COUNT(1)
      INTO v_count
      FROM dbpm_data_source_values ddsv
     WHERE ddsv.data_source_code = v_datasource_code;

    IF v_count > 0 THEN
      --v_response.fail('数据字典下存在数据值，不能删除，请确认！');
      v_response.fail(DCLD_COMM_PKG.func_get_err_msg('DCLD-00004',
                                                     v_request.locale));
      x_response := v_response.to_json;
      RETURN;
    END IF;

    DELETE FROM dbpm_data_source dss
     WHERE dss.data_source_code = v_datasource_code;
    x_response := v_response.to_json;
    /*  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_del_data_source;

  /*==================================================
  Procedure/Function Name :
      proc_query_data_source_values
  Description:
      This function perform:
      动态查询数据源的值
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-11  chenming  Creation
  ==================================================*/
  PROCEDURE proc_query_data_source_values(p_request  CLOB,
                                          x_response OUT CLOB) IS
    v_api              VARCHAR2(100) := 'proc_query_data_source_values';
    v_request          json;
    v_response         pl_json := pl_json;
    v_line             pl_json;
    v_data_source_code VARCHAR2(100);
    v_data_value_list  json_list;
    v_data_value       pl_json;
    v_sql              VARCHAR2(4000);
    v_outer_sql        varchar2(1000);
    v_filter_sql       varchar2(1000);
    v_cnt              number;
    v_value_code       VARCHAR2(1000);
    v_value_name       VARCHAR2(1000);
    TYPE ref_cursor_type IS REF CURSOR;
    v_data_source ref_cursor_type;
    --分页参数
    v_total          NUMBER := 0;
    v_size           number := 20;
    v_page           number := 1;
    v_search_content varchar2(1000);
    v_is_divide      varchar2(20) := 'Y'; --是否分页标记
    --管理数据源de搜索参数
    v_code   varchar2(1000);
    v_name   varchar2(1000);
    v_filter json;
    --排序参数
    v_sort_col varchar2(100);
    v_sort     json;
    --是否多列匹配
    v_is_all varchar2(10);

    CURSOR v_normal_cursor IS
      SELECT *
        FROM (SELECT v.*, rownum cnt
                FROM (SELECT count(1) over(partition by 1) total,
                             dsv.data_source_code,
                             dsv.value_code,
                             nvl(dcld_comm_pkg.func_get_sys_msg(dsv.value_code,
                                                                v_request.locale,
                                                                dsv.data_source_code),
                                 dsv.value_name) value_name,
                             dsv.status,
                             dsv.display_seq
                        FROM dbpm_data_source_values dsv
                       WHERE dsv.data_source_code = v_data_source_code
                         AND INSTR(NVL(DSV.VALUE_NAME, 'NL'),
                                   NVL(v_name, NVL(DSV.VALUE_NAME, 'NL'))) > 0
                         AND INSTR(NVL(DSV.VALUE_CODE, 'NL'),
                                   NVL(v_code, NVL(DSV.VALUE_CODE, 'NL'))) > 0
                       ORDER BY decode(v_sort_col,
                                       'value_code_desc',
                                       dsv.value_code,
                                       'value_name_desc',
                                       dsv.value_name,
                                       'display_seq_desc',
                                       dsv.display_seq) DESC,
                                decode(v_sort_col,
                                       'value_code_asc',
                                       dsv.value_code,
                                       'value_name_asc',
                                       dsv.value_name,
                                       'display_seq_asc',
                                       dsv.display_seq) ASC,
                                dsv.display_seq) v
               WHERE rownum <= v_page * v_size)
       WHERE cnt > (v_page - 1) * v_size;
    CURSOR v_lov_cursor IS
      SELECT *
        FROM (SELECT v.*, rownum cnt
                FROM (SELECT count(1) over(partition by 1) total,
                             dsv.data_source_code,
                             dsv.value_code,
                             dsv.value_name,
                             dsv.status,
                             dsv.display_seq
                        FROM dbpm_data_source_values dsv
                       WHERE dsv.data_source_code = v_data_source_code
                         AND (INSTR(NVL(DSV.VALUE_NAME, 'NL'),
                                    NVL(v_name, NVL(DSV.VALUE_NAME, 'NL'))) > 0 OR
                             INSTR(NVL(DSV.VALUE_CODE, 'NL'),
                                    NVL(v_code, NVL(DSV.VALUE_CODE, 'NL'))) > 0)
                       ORDER BY decode(v_sort_col,
                                       'value_code_desc',
                                       dsv.value_code,
                                       'value_name_desc',
                                       dsv.value_name,
                                       'display_seq_desc',
                                       dsv.display_seq) DESC,
                                decode(v_sort_col,
                                       'value_code_asc',
                                       dsv.value_code,
                                       'value_name_asc',
                                       dsv.value_name,
                                       'display_seq_asc',
                                       dsv.display_seq) ASC,
                                dsv.display_seq) v
               WHERE rownum <= v_page * v_size)
       WHERE cnt > (v_page - 1) * v_size;

  BEGIN
    v_request          := json(p_request, 'OBJECT');
    v_data_source_code := v_request.get('dataSourceCode').get_string;
    --分页处理
    if v_request.exist('page') then
      v_page := v_request.get_number('page');
    end if;
    if v_request.exist('size') then
      v_size := v_request.get_number('size');
    end if;
    if v_request.exist('sort') then
      v_sort     := json(v_request.get('sort'));
      v_sort_col := v_sort.get_string('value');
      v_sort_col := v_sort_col || '_' || v_sort.get_string('order');
    end if;

    IF dcld_comm_pkg.get_filter_value('all', v_request) IS NOT NULL THEN
      v_name   := dcld_comm_pkg.get_filter_value('all', v_request);
      v_code   := v_name;
      v_is_all := 'Y';
    ELSE
      v_code := dcld_comm_pkg.get_filter_value('valueCode', v_request);
      v_name := dcld_comm_pkg.get_filter_value('valueName', v_request);
    END IF;

    v_response.set_value('dataSourceCode', v_data_source_code);
    begin

      SELECT dds.data_source_sql
        INTO v_sql
        FROM dbpm_data_source dds
       WHERE dds.data_source_code = v_data_source_code;
    exception
      when NO_DATA_FOUND then
        --v_response.fail('数据字典中不存在编码为' || v_data_source_code || '的数据，请检查！');
        v_response.fail(DCLD_COMM_PKG.func_get_err_msg('DCLD-00005',
                                                       v_request.locale,
                                                       v_data_source_code));
        x_response := v_response.to_json;
    end;

    --判断是否是sql数据
    IF v_sql IS NOT NULL THEN
      v_sql       := ' SELECT COUNT(1) OVER(PARTITION BY 1) TOTAL,t.* FROM (' ||
                     v_sql || ') t ';
      v_outer_sql := 'SELECT * FROM (SELECT v.*, rownum cnt FROM ( ';
      v_sql       := v_outer_sql || v_sql;
      --判断是否多列匹配查询
      if v_is_all = 'Y' then
        v_filter_sql := ' WHERE (INSTR(NVL(t.VALUE_NAME,''NL''),NVL(:1,NVL(t.VALUE_NAME,''NL'')))>0
       OR INSTR(NVL(t.VALUE_CODE,''NL''),NVL(:2,NVL(t.VALUE_CODE,''NL'')))>0 ) ';
      else
        v_filter_sql := ' WHERE INSTR(NVL(t.VALUE_NAME,''NL''),NVL(:1,NVL(t.VALUE_NAME,''NL'')))>0
       AND INSTR(NVL(t.VALUE_CODE,''NL''),NVL(:2,NVL(t.VALUE_CODE,''NL'')))>0 ';
      end if;
      v_sql       := v_sql || v_filter_sql;
      v_outer_sql := ') v  WHERE rownum <= ' || (v_page * v_size) ||
                     ') WHERE cnt > ' || ((v_page - 1) * v_size);
      v_sql       := v_sql || v_outer_sql;
      OPEN v_data_source FOR v_sql
        USING v_name, V_code;
      LOOP
        FETCH v_data_source
          INTO v_total, v_value_code, v_value_name, v_cnt;
        EXIT WHEN v_data_source%NOTFOUND;
        v_data_value := pl_json;
        v_data_value.set_value('valueCode', v_value_code);
        v_data_value.set_value('valueName', v_value_name);
        v_response.add_list_item('valueList', v_data_value);
      END LOOP;
      close v_data_source;
    ELSE
      if v_is_all = 'Y' then
        FOR v_value IN v_lov_cursor LOOP
          v_data_value := pl_json;

          v_total := v_value.total;
          v_data_value.set_value('dataSourceCode',
                                 v_value.data_source_code);
          v_data_value.set_value('valueCode', v_value.value_code);
          v_data_value.set_value('valueName', v_value.value_name);
          v_data_value.set_value('status', v_value.status);
          v_data_value.set_value('displaySeq', v_value.display_seq);
          v_response.add_list_item('valueList', v_data_value);
        END LOOP;
      else
        FOR v_value IN v_normal_cursor LOOP
          v_data_value := pl_json;

          v_total := v_value.total;
          v_data_value.set_value('dataSourceCode',
                                 v_value.data_source_code);
          v_data_value.set_value('valueCode', v_value.value_code);
          v_data_value.set_value('valueName', v_value.value_name);
          v_data_value.set_value('status', v_value.status);
          v_data_value.set_value('displaySeq', v_value.display_seq);
          v_response.add_list_item('valueList', v_data_value);
        END LOOP;
      end if;
    END IF;
    v_response.set_value('total', v_total);
    x_response := v_response.to_json;
  END proc_query_data_source_values;

  /*==================================================
  Procedure/Function Name :
      proc_save_datasource_value
  Description:
      This function perform:
      保存数据字典值信息，需要判断是新增还是修改
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-20  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_save_data_source_value(p_request  IN CLOB,
                                        x_response OUT CLOB) IS
    v_api             VARCHAR2(100) := 'proc_save_datasource_value';
    v_request         json;
    v_response        pl_json := pl_json;
    v_current_user    VARCHAR2(50);
    v_datasource_code VARCHAR2(400);
    v_value_code      VARCHAR2(400);
    v_count           NUMBER := 0;
    v_is_new          varchar2(10);
  BEGIN
    v_request         := json(p_request, 'OBJECT');
    v_current_user    := v_request.username;
    v_datasource_code := v_request.get('dataSourceCode').get_string;
    v_value_code      := v_request.get('valueCode').get_string;
    v_is_new          := v_request.get_string('isNew');
    SELECT COUNT(1)
      INTO v_count
      FROM dbpm_data_source_values dssv
     WHERE dssv.value_code = v_value_code
       AND dssv.data_source_code = v_datasource_code;
    if v_is_new IS NULL THEN
      v_is_new := 'N';
    END if;
    IF v_count = 0 and v_is_new = 'Y' THEN
      INSERT INTO dbpm_data_source_values
        (data_source_code,
         value_code,
         value_name,
         status,
         display_seq,
         created_by,
         last_updated_by)
      VALUES
        (v_datasource_code,
         v_value_code,
         v_request.get    ('valueName'    ).get_string,
         'Y',
         v_request.get    ('displaySeq'    ).get_number,
         v_current_user,
         v_current_user);
    elsif v_is_new = 'N' and v_count <> 0 then
      UPDATE dbpm_data_source_values dssv
         SET dssv.value_name            = v_request.get('valueName').get_string,
             dssv.display_seq           = v_request.get('displaySeq').get_number,
             dssv.last_updated_by       = v_current_user,
             dssv.object_version_number = dssv.object_version_number + 1
       WHERE dssv.value_code = v_value_code
         AND dssv.data_source_code = v_datasource_code;
    END IF;

    x_response := v_response.to_json;
  END proc_save_data_source_value;

  /*==================================================
  Procedure/Function Name :
      proc_del_datasource_value
  Description:
      This function perform:
      删除数据字典的值明细
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2017-04-20  skycloud.wang  Creation
  ==================================================*/
  PROCEDURE proc_del_data_source_value(p_request  IN CLOB,
                                       x_response OUT CLOB) IS
    v_api             VARCHAR2(30) := 'proc_del_datasource_value';
    v_request         json;
    v_response        pl_json := pl_json;
    v_datasource_code VARCHAR2(400);
    v_value_code      VARCHAR2(400);
  BEGIN
    v_request         := json(p_request, 'OBJECT');
    v_datasource_code := v_request.get('dataSourceCode').get_string;
    v_value_code      := v_request.get('valueCode').get_string;
    DELETE FROM dbpm_data_source_values dssv
     WHERE dssv.data_source_code = v_datasource_code
       AND dssv.value_code = v_value_code;
    x_response := v_response.to_json;
    /*  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;*/
  END proc_del_data_source_value;

  /*
  * 根据value_code获取value_name
  */
  FUNCTION get_data_value_name(p_data_source_code VARCHAR2,
                               p_data_value_code  VARCHAR2) RETURN VARCHAR2 IS
    v_sql VARCHAR2(4000);
    TYPE ref_cursor_type IS REF CURSOR;
    v_data_source ref_cursor_type;
    v_value_code  VARCHAR2(1000);
    v_value_name  VARCHAR2(1000);
  BEGIN
    IF p_data_source_code IS NULL OR p_data_value_code IS NULL THEN
      v_value_name := p_data_value_code;
      RETURN v_value_name;
    END IF;
    SELECT dds.data_source_sql
      INTO v_sql
      FROM dbpm_data_source dds
     WHERE dds.data_source_code = p_data_source_code;
    IF v_sql IS NOT NULL THEN
      OPEN v_data_source FOR v_sql;
      LOOP
        FETCH v_data_source
          INTO v_value_code, v_value_name;
        EXIT WHEN v_data_source%NOTFOUND;
        IF v_value_code = p_data_value_code THEN
          RETURN v_value_name;
        END IF;
      END LOOP;
      close v_data_source;
    ELSE
      begin
        SELECT dsv.value_name
          INTO v_value_name
          FROM dbpm_data_source_values dsv
         WHERE dsv.data_source_code = p_data_source_code
           AND dsv.value_code = p_data_value_code;
      exception
        when no_data_found then
          v_value_name := p_data_value_code;
      end;
    END IF;
    RETURN v_value_name;
    --ADD by wlj
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      v_value_name := '';
      RETURN v_value_name;
  END get_data_value_name;

  /*==================================================
  Procedure/Function Name :
      func_get_all_data_source_value
  Description:
      This function perform:
      获取数据源的值
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-02-06  wlj  Creation
  ==================================================*/
  function func_get_all_data_source_value(p_data_source_code varchar2)
    return varchar2 is
    v_data_source_name varchar2(4000);
    v_sql              varchar2(4000);
    v_value_code       varchar2(100);
    v_value_name       varchar2(2000);
    TYPE ref_cursor_type IS REF CURSOR;
    v_data_source ref_cursor_type;
  begin
    IF p_data_source_code IS NULL THEN
      v_data_source_name := p_data_source_code;
      RETURN v_data_source_name;
    END IF;

    SELECT dds.data_source_sql
      INTO v_sql
      FROM dbpm_data_source dds
     WHERE dds.data_source_code = p_data_source_code;

    IF v_sql IS NOT NULL THEN
      OPEN v_data_source FOR v_sql;
      LOOP
        FETCH v_data_source
          INTO v_value_code, v_value_name;
        EXIT WHEN v_data_source%NOTFOUND;
        if v_data_source_name is null then
          v_data_source_name := v_value_name;
        else
          v_data_source_name := v_data_source_name || ',' || v_value_name;
        end if;
      END LOOP;
      close v_data_source;
    ELSE
      begin
        SELECT LISTAGG(dsv.value_name, ',') WITHIN GROUP(ORDER BY dsv.value_code)
          into v_data_source_name
          FROM dbpm_data_source_values dsv
         WHERE dsv.data_source_code = p_data_source_code;
      exception
        when no_data_found then
          v_data_source_name := p_data_source_code;
      end;
    END IF;
    return v_data_source_name;
  EXCEPTION
    WHEN no_data_found THEN
      v_data_source_name := '';
      RETURN v_data_source_name;
  end;

END dbpm_data_source_api_pkg;

/

