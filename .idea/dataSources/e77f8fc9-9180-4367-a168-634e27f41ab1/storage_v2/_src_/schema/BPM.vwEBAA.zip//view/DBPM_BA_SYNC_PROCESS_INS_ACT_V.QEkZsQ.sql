create view DBPM_BA_SYNC_PROCESS_INS_ACT_V as
select x1.start_query_id,
       x1.end_query_id,
       x1.activity_id,
       x1.activity_code,
       x1.activity_name,
       x1.fault_type,
       x1.taskid,
       x1.updatedby,
       x1.instance_id,
       x1.flow_id,
       x1.start_time,
       x1.end_time,
       x1.process_id,
       'custom' data_source
  from (select v.start_query_id,
               v.end_query_id,
               dbpa.activity_id,
               dbpa.activity_code,
               dbpa.activity_name,
               v.fault_type,
               v.start_time,
               v.end_time,
               dbpa.process_id,
               v.component_instance_id instance_id,
               v.flow_id,
               v.scope_id,
               wf.taskid,
               wf.updatedby
          from bpm_ba_audit_query_v     v,
               dbpm_ba_process_activity dbpa,
               wftask                   wf,
               cux_bpm_all_instance     ca
         where v.scope_id = wf.parentcomponentinstrefid(+)
           and v.activity_name='USER_TASK'
           and v.component_type='BPMN'
           and wf.instanceid = ca.instance_id
           and dbpa.process_code = ca.process_code
           and decode(wf.compositename,
                      'GpmsoverseaProcess',
                      wf.protectedformattribute1,
                      nvl((select dns.node_name
                            from dbpm_chain_nodes dns
                           where dns.node_id = wf.protectednumberattribute1),
                          wf.activityname)) = dbpa.activity_name
           and wf.parentcomponentinstrefid is not null
           and wf.hassubtask = 'F') x1
/

