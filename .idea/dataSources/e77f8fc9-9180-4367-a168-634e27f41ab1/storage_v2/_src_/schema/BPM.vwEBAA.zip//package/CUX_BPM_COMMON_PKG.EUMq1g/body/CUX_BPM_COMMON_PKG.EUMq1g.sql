create package body "CUX_BPM_COMMON_PKG" is
  -- 2020-03-17 11:52:42
  --数据插入类方法

  /**
       通用插入审批历史的方法
  **/

  function create_approve_history(p_his_type              in varchar2,
                                  p_his_comment_detail    in varchar2,
                                  p_his_creator_id        in varchar2,
                                  p_his_approve_node      in varchar2,
                                  p_his_approve_operation in varchar2,
                                  p_his_process_code      in varchar2,
                                  p_his_form_id           in varchar2,
                                  p_instance_id           in varchar2)
    return number as
    v_seq_id number;
  begin
    select cux_bpm_approve_history_seq.nextval into v_seq_id from dual;
  
    insert into cux_bpm_approve_history
      (his_id,
       his_comment_detail,
       his_creator,
       his_create_time,
       his_approve_node,
       his_approve_operation,
       his_type,
       process_name,
       process_form_id,
       object_version_number,
       created_by,
       creation_date,
       last_updated_by,
       last_update_date,
       instance_id)
    values
      (v_seq_id,
       p_his_comment_detail,
       p_his_creator_id,
       sysdate,
       p_his_approve_node,
       p_his_approve_operation,
       p_his_type,
       p_his_process_code,
       p_his_form_id,
       1,
       p_his_creator_id,
       sysdate,
       p_his_creator_id,
       sysdate,
       p_instance_id);
  
    return 1;
  exception
    when others then
      --cux_bpm_logger.error(p_log_type =>  ,p_log_info => );
      return - 1;
  end;

  /**
       通用插入审批历史的方法 - 基于taskid
  **/

  function create_approve_his_by_taskid(p_his_type              in varchar2,
                                        p_his_comment_detail    in varchar2,
                                        p_his_creator_id        in varchar2,
                                        p_his_approve_node      in varchar2,
                                        p_his_approve_operation in varchar2,
                                        p_his_taskid            in varchar2)
    return number as
  
    v_seq_id          number;
    v_process_code    varchar2(100);
    v_process_formid  varchar2(100);
    v_instance_id     varchar2(100);
    his_instanceid    varchar2(100);
    his_activity_node varchar2(2000);
  begin
    --1、根据taskid得到 processcode processformid;
    begin
      select t.instanceid, nvl(t.protectedformattribute1, t.activityname)
        into his_instanceid, his_activity_node
        from wftask t
       where t.taskid = p_his_taskid;
    
      select ai.process_code, ai.process_form_id, ai.instance_id
        into v_process_code, v_process_formid, v_instance_id
        from cux_bpm_all_instance ai
       where ai.instance_id = his_instanceid;
    
    exception
      when no_data_found then
        cux_bpm_logger.error('HISTORY_CREATE_ERR',
                             p_his_taskid || ' 任务对应流程没有注册实例信息，无法插入审批历史。');
        return - 1;
    end;
  
    select cux_bpm_approve_history_seq.nextval into v_seq_id from dual;
  
    insert into cux_bpm_approve_history
      (his_id,
       his_comment_detail,
       his_creator,
       his_create_time,
       his_approve_node,
       his_approve_operation,
       his_type,
       process_name,
       process_form_id,
       object_version_number,
       created_by,
       creation_date,
       last_updated_by,
       last_update_date,
       his_taskid,
       instance_id)
    values
      (v_seq_id,
       p_his_comment_detail,
       p_his_creator_id,
       sysdate,
       his_activity_node,
       p_his_approve_operation,
       p_his_type,
       v_process_code,
       v_process_formid,
       1,
       p_his_creator_id,
       sysdate,
       p_his_creator_id,
       sysdate,
       p_his_taskid,
       v_instance_id);
  
    return 1;
  exception
    when others then
      --cux_bpm_logger.error(p_log_type =>  ,p_log_info => );
      return - 1;
  end;

  --流程注册

  function register_instance(p_instance_id       in varchar2,
                             p_process_code      in varchar2,
                             p_process_form_id   in varchar2,
                             p_requester_id      in varchar2,
                             p_approve_node      in varchar2,
                             p_process_desc      in varchar2,
                             p_requester_comment in varchar2) return number as
    v_ins_id        number;
    v_record_exists number;
    v_his_res       number;
  begin
    select cux_bpm_all_instance_seq.nextval into v_ins_id from dual;
  
    --同一流程、表单、实例编号不允许多次插入；
  
    select count(ins.instance_id)
      into v_record_exists
      from cux_bpm_all_instance ins
     where ins.instance_id = p_instance_id;
    --and ins.process_code = 
    --and ins.process_form_id = ; 
  
    if 0 = v_record_exists then
      --插入
      insert into cux_bpm_all_instance
        (instance_id,
         instance_creator,
         process_form_info,
         instance_status,
         process_code,
         process_form_id,
         process_number)
      values
        (p_instance_id,
         p_requester_id,
         p_process_desc,
         'PROCESSING',
         p_process_code,
         p_process_form_id,
         p_instance_id);
    
      v_his_res := cux_bpm_common_pkg.create_approve_history(p_his_type           => 'REQUEST',
                                                             p_his_comment_detail => p_requester_comment
                                                             
                                                            ,
                                                             p_his_creator_id        => p_requester_id,
                                                             p_his_approve_node      => p_approve_node,
                                                             p_his_approve_operation => 'REQUEST',
                                                             p_his_process_code     
                                                             
                                                                   => p_process_code,
                                                             p_his_form_id           => p_process_form_id,
                                                             p_instance_id           => p_instance_id);
    
      return 1;
      --else
      --已存在
    end if;
  
    return 0; --已注册过该实例信息；
  exception
    when others then
      return - 1;
  end register_instance;

  --流程结束时调用的ws接口，修改流程状态为完成；

  procedure finish_instance_status(p_instance_id in varchar2) as
  begin
    update cux_bpm_all_instance ins
       set ins.instance_status = 'COMPLETED'
     where ins.instance_id = p_instance_id;
  
  end finish_instance_status;

  --------数据查询类方法
  /**
      获取用户待办数量 ： get_user_task_count 
  **/

  function get_user_task_count(p_emp_id    in varchar2,
                               p_sql_query in varchar2) return number is
    v_task_count number := 0;
    v_sql_count  varchar2(2000) := '';
  begin
    v_sql_count := 'SELECT COUNT(1)
        FROM CUX_BPM_USER_TASK_V V,CUX_BPM_ALL_INSTANCE INS
       WHERE V.ASSIGNEE = LOWER(''' || p_emp_id ||
                   ''')  AND V.INSTANCE_ID = INS.INSTANCE_ID ' ||
                   p_sql_query; --去掉lower函数  update by xuy 2017-11-09
    execute immediate v_sql_count
      into v_task_count;
    return v_task_count;
  end get_user_task_count;

  function get_task_url(p_sys_code in varchar2,
                        p_form_url in varchar2,
                        p_paras    in varchar2,
                        p_task_id  in varchar2,
                        p_form_key in varchar2) return varchar2 is
  
    v_task_url varchar2(4000) := '';
    v_form_url varchar2(4000) := '';
    v_ins      varchar2(4000);
  begin
    --todo
    v_form_url := p_form_url;
    --获取历史表单的url地址--update by xiaowei.yao 20181209 如果url里没有问号，则加上。
    if instr(v_form_url, '?') = 0 then
      v_form_url := v_form_url || '?';
    else
      v_form_url := v_form_url || '&';
    end if;
  
    select wf.instanceid
      into v_ins
      from wftask wf
     where wf.taskid = p_task_id;
  
    if p_paras is null then
      v_task_url := v_form_url || 'taskId=' || p_task_id || '&formKey=' ||
                    p_form_key || '&instanceId=' || v_ins ||
                    '&type=ASSIGNED' || '&param=' || p_paras;
    else
      v_task_url := v_form_url || 'taskId=' || p_task_id || '&formKey=' ||
                    p_form_key || '&instanceId=' || v_ins ||
                    '&type=ASSIGNED' || '&param=' || p_paras;
    end if;
    --配置的url本身就以http/www 开头，不需要根据系统编码取host：port
  
    if instr(lower(v_task_url), 'http') <> 0 then
      return v_task_url;
    elsif instr(lower(v_task_url), 'www') <> 0 then
      return 'http://' || v_task_url;
    else
      --todo 根据系统编码获取相对基本路径
      -- v_task_url := 'http://portaltest.smec.com:8888' || v_task_url;
      return v_task_url;
    end if;
  
  end;

  /**
   获取已办的表单地址
  **/

  function get_his_form_url(p_sys_code in varchar2,
                            p_form_url in varchar2,
                            p_paras    in varchar2,
                            p_ins_id   in varchar2,
                            p_form_key in varchar2,
                            p_type     in varchar2) return varchar2 is
    v_task_url varchar2(4000) := '';
    v_form_url varchar2(4000) := '';
  begin
    v_form_url := p_form_url;
    --获取历史表单的url地址--update by xiaowei.yao 20181209 如果url里没有问号，则加上。
    if instr(v_form_url, '?') = 0 then
      v_form_url := v_form_url || '?';
    else
      v_form_url := v_form_url || '&';
    end if;
  
    if p_paras is null  then
      v_task_url := v_form_url || 'instanceId=' || p_ins_id || '&formKey=' ||
                    p_form_key || '&type=' || p_type || '&param=' ||
                    p_paras;
    else
      v_task_url := v_form_url || 'instanceId=' || p_ins_id || '&formKey=' ||
                    p_form_key || '&type=' || p_type || '&param=' ||
                    p_paras;
    end if;
    --配置的url本身就以http/www 开头，不需要根据系统编码取host：port
  
    if instr(lower(v_task_url), 'http') <> 0 then
      return v_task_url;
    elsif instr(lower(v_task_url), 'www') <> 0 then
      return 'http://' || v_task_url;
    else
      --todo 根据系统编码获取相对基本路径
      v_task_url := 'http://portaltest.smec.com:8888' || v_task_url;
      return v_task_url;
    end if;
  
  end;

  /**
   获取已发起流程的发起表单url地址
  **/

  function get_request_form_url(p_instance_id in varchar2,
                                p_form_key    in varchar2) return varchar2 is
    v_task_url varchar2(4000) := '';
    v_param    varchar2(4000);
  begin
    --1、获取baseurl；
    begin
      select w.protectedtextattribute5, w.protectedtextattribute6
        into v_task_url, v_param
        from (select a.*, rownum index_num
                from (select wf.*
                        from wftask wf
                       where wf.instanceid = p_instance_id
                         and wf.assigneddate is not null
                       order by wf.assigneddate desc) a) w
      --update by xiaowei.yao 20180402 升序改成降序
       where w.index_num = 1;
    
    exception
      when no_data_found then
        return 'http://pagenotfound.com';
    end;
    --2、从常规流程中查找url
    --获取历史表单的url地址
    --v_task_url := 'http://portaltest.haier.net:8888/webcenter?taskId=' || p_task_id;
    --v_task_url := v_task_url || '?formKey=' || p_form_key || '&type=REQ';
  
    v_task_url := v_task_url || '?' || v_param || '&formKey=' || p_form_key ||
                  '&type=REQ';
  
    --配置的url本身就以http/www 开头，不需要根据系统编码取host：port
  
    if instr(lower(v_task_url), 'http') <> 0 then
      return v_task_url;
    elsif instr(lower(v_task_url), 'www') <> 0 then
      return 'http://' || v_task_url;
    else
      --todo 根据系统编码获取相对基本路径
      v_task_url := 'http://portaltest.smec.com:8888' || v_task_url;
      return v_task_url;
    end if;
  
  end;

  /**
      获取用户待办信息 ： getallusertask 
  **/

  procedure get_all_user_tasks(p_emp_id            in varchar2,
                               p_orderby           in varchar2,
                               p_isasc             in varchar2,
                               p_idisplaystart     in number,
                               p_getidisplaylength in number,
                               p_sql_query         in varchar2,
                               p_count             out number,
                               p_tasklist_cur      out tasklist_cur) is
  
    v_sql         varchar2(4000) := '';
    v_count       number := 0;
    v_start_index number := 0;
    v_end_index   number := 0;
    v_locale      varchar2(100) := 'zh_CN';
  begin
    --todo xxx
    v_count := cux_bpm_common_pkg.get_user_task_count(p_emp_id, p_sql_query);
    p_count := v_count;
    -- -1 表示从头开始
    if p_idisplaystart > v_count then
      return;
    elsif p_idisplaystart <= -1 then
      v_start_index := 1;
    else
      v_start_index := p_idisplaystart; --从提供的下标开始，不从0开始；
    end if;
  
    -- -1 表示到结束；
  
    if -1 = p_getidisplaylength then
      v_end_index := v_count;
    elsif v_start_index + p_getidisplaylength - 1 <= v_count then
      v_end_index := v_start_index + p_getidisplaylength - 1;
    else
      v_end_index := v_count;
    end if;
  
    --先排序再分页
    --1、根据参数定义sql，关键在于拼接sql；
  
    v_sql := 'SELECT TASKID,INSTANCE_ID,TITLE,CREATEUSERNAME,CREATEDISPLAYNAME,CREATEDATETIME,TASKURL,TASK_DESC,TASKASSIGNTIME,BUSINESS_SYSTEM_CODE,FORMCODE,PROCESS_CODE,cux_bpm_common_pkg.get_node_tl_value(PROCESS_CODE,''' ||
             v_locale ||
             ''',TASKID,ACTIVITYNAME) ACTIVITYNAME ,WORKFLOWPATTERN,COMPOSITEINSTANCEID FROM (SELECT  ROWNUM INDEX_NUM,VV.* FROM ( SELECT V.*,INS.PROCESS_CODE FROM CUX_BPM_USER_TASK_V V,CUX_BPM_ALL_INSTANCE INS WHERE V.ASSIGNEE =  ''' ||
             lower(p_emp_id) || ''' AND V.INSTANCE_ID = INS.INSTANCE_ID ' || --去掉lower函数  update by xuy 2017-11-09
             p_sql_query || ' ORDER BY ' || p_orderby || ' ' || p_isasc || -- comment by erick 2017-02-22(update by xuy 2017-09-11)
             ' ) VV ) WHERE INDEX_NUM >= ' || v_start_index ||
             ' AND  INDEX_NUM <= ' || v_end_index;
  
    --cux_bpm_logger.info('GET_ALL_USER_TASKS', v_sql);
  
    open p_tasklist_cur for v_sql;
  
    return;
  end get_all_user_tasks;

  

  /***************************************************************************************
  * * * * * * * * * * * * * * * * 根据instance_id获取到当前待办的上一个审批人  * * * * * * * * *
  ***************************************************************************************/

  function get_task_from_userid(p_instance_id in varchar2) return varchar2 as
    v_from_user_id varchar2(30);
  begin
    select h.his_creator
      into v_from_user_id
    --, i.process_code, i.process_form_id
      from cux_bpm_all_instance i, cux_bpm_approve_history h
     where i.instance_id = p_instance_id
       and i.process_code = h.process_name
       and i.process_form_id = h.process_form_id
       and rownum = 1
     order by h.his_id desc;
  
    return v_from_user_id;
  exception
    when others then
      return 'weblogic';
  end get_task_from_userid;

  /*
            分割所得到的group组
  
  */

  procedure divide_groups(p_input_groups in varchar2,
                          p_user_list    out userlist) as
    v_comma number;
    v_flag  number := 1;
  begin
    v_comma := instr(p_input_groups, ',', v_flag);
    if v_comma > 0 then
      while v_comma > 0 loop
        p_user_list(p_user_list.count + 1) := substr(p_input_groups,
                                                     v_flag,
                                                     v_comma - v_flag);
      
        v_flag  := v_comma + 1;
        v_comma := instr(p_input_groups, ',', v_flag);
      end loop;
    
      p_user_list(p_user_list.count + 1) := substr(p_input_groups,
                                                   v_flag,
                                                   length(p_input_groups) -
                                                   v_flag + 1);
    
    else
      p_user_list(p_user_list.count + 1) := substr(p_input_groups,
                                                   v_flag,
                                                   length(p_input_groups) -
                                                   v_flag + 1);
    end if;
    --v_comma=0的情况
  
  end;

  function get_users_by_grouplist(v_group_list in userlist) return varchar2 as
    v_user_id   varchar2(1000); --最后的返回user list的字符串
    v_user_list userlist; --临时的user list
    v_isexsit   number := 1; --标记一个user是否已经存在user list  1表示不存在    0表示已存在
  begin
    --遍历从group list中获得user list
    for i in 1 .. v_group_list.count loop
      declare
        v_temp_id varchar2(500);
        --取得所有该 group底下的user 
        cursor v_user_cursor is
          select fgum.member_user_id
            from fnd_group_user_members fgum
           where fgum.group_id = v_group_list(i);
      
      begin
        open v_user_cursor;
        loop
          fetch v_user_cursor
            into v_temp_id;
          exit when v_user_cursor%notfound;
          --查询是否该条记录已经存在于列表中,如果不存在则添加到列表
          for i in 1 .. v_user_list.count loop
            if v_user_list(i) = v_temp_id then
              v_isexsit := 0;
            end if;
          end loop;
        
          if v_isexsit = 1 then
            v_user_list(v_user_list.count + 1) := v_temp_id;
          end if;
        
        end loop;
      
      end;
    end loop;
    --将user list中的数据变成一串
  
    for i in 1 .. v_user_list.count loop
      v_user_id := v_user_id || v_user_list(i) || ',';
    end loop;
    -- 此处去掉最后一个多余的逗号
  
    v_user_id := substr(v_user_id, 1, length(v_user_id) - 1);
    return v_user_id;
  end;

  function get_all_mem_groups(p_root_group in varchar2,
                              p_groups     in varchar2) return varchar2 as
    v_groups varchar2(4444);
  begin
    v_groups := p_groups;
    if v_groups is null then
      v_groups := p_root_group || ',';
      --为了避免组名匹配时出现 testgroup12 中 匹配testgourp1 成功的情况，以,结尾区分
    end if;
    for tmp_mems in (select mem.member_id
                       from fnd_group_members mem
                      where mem.group_id = p_root_group
                        and mem.member_type = 'GROUP') loop
      --dbms_output.put_line(tmp_mems.member_id);
      declare
        v_index number;
      begin
        select instr(v_groups, tmp_mems.member_id || ',', 1)
          into v_index
          from dual;
      
        dbms_output.put_line(v_groups || ' ' || tmp_mems.member_id || ', ' ||
                             v_index);
      
        if v_index = 0 then
          --不存在，迭代
          v_groups := v_groups || tmp_mems.member_id || ',';
          v_groups := get_all_mem_groups(tmp_mems.member_id, v_groups);
        end if;
      
      end;
    end loop;
  
    return v_groups;
  end get_all_mem_groups;

  /**
      根据流程编码获取待办并进行分页 
  **/

  procedure get_user_tasks_process_code(p_emp_id            in varchar2,
                                        p_orderby           in varchar2,
                                        p_isasc             in varchar2,
                                        p_idisplaystart     in number,
                                        p_getidisplaylength in number,
                                        p_process_code      in varchar2,
                                        p_sql_query         in varchar2,
                                        p_count             out number,
                                        p_tasklist_cur      out tasklist_cur) is
  
    v_sql  varchar2(4000) := '';
    v_sql2 varchar2(4000) := '';
    --v_orderby     varchar2(50) := '';
    --v_isasc       varchar2(4) := 'ASC';
    v_count       number := 0;
    v_start_index number := 0;
    v_end_index   number := 0;
  begin
    v_sql2 := 'SELECT COUNT(1)
        FROM CUX_BPM_USER_TASK_V V,CUX_BPM_ALL_INSTANCE INS
       WHERE V.ASSIGNEE = LOWER(''' || p_emp_id ||
              ''')  
       AND INS.PROCESS_CODE IN (' || p_process_code || ')  
       AND V.INSTANCE_ID = INS.INSTANCE_ID(+) ' || p_sql_query; --去掉lower函数  update by xuy 2017-11-09
  
    execute immediate v_sql2
      into v_count;
    p_count := v_count;
    --dbms_output.put_line(v_sql2);
  
    -- -1 表示从头开始
    if p_idisplaystart > v_count then
      return;
    elsif p_idisplaystart <= -1 then
      v_start_index := 1;
    else
      v_start_index := p_idisplaystart; --从提供的下标开始，不从0开始；
    end if;
  
    -- -1 表示到结束；
  
    if -1 = p_getidisplaylength then
      v_end_index := v_count;
    elsif v_start_index + p_getidisplaylength - 1 <= v_count then
      v_end_index := v_start_index + p_getidisplaylength - 1;
    else
      v_end_index := v_count;
    end if;
  
    --先排序再分页
    --1、根据参数定义sql，关键在于拼接sql；
  
    v_sql := 'SELECT TASKID,INSTANCE_ID,TITLE,CREATEUSERNAME,CREATEDISPLAYNAME,CREATEDATETIME,TASKURL,TASK_DESC,TASKASSIGNTIME,''BPM'' TASKSOURCE,BUSINESS_SYSTEM_CODE,FORMCODE,PROCESS_CODE,ACTIVITYNAME,WORKFLOWPATTERN,COMPOSITEINSTANCEID FROM (SELECT  ROWNUM INDEX_NUM,VV.* FROM ( SELECT V.*,INS.PROCESS_CODE FROM CUX_BPM_USER_TASK_V V,CUX_BPM_ALL_INSTANCE INS WHERE V.ASSIGNEE =  ''' ||
             lower(p_emp_id) || ''' ' || p_sql_query ||
             ' AND V.INSTANCE_ID = INS.INSTANCE_ID(+) AND INS.PROCESS_CODE IN (' ||
             p_process_code || ')' || ' ORDER BY ' || p_orderby || ' ' ||
             p_isasc || --remove comment by xuy 20170911
             ' ) VV ) WHERE INDEX_NUM >= ' || v_start_index ||
             ' AND  INDEX_NUM <= ' || v_end_index;
  
    --dbms_output.put_line(v_sql);
  
    cux_bpm_logger.info('get_user_tasks_process_code', v_sql);
    open p_tasklist_cur for v_sql;
  
    return;
  end get_user_tasks_process_code;

  /**
       插入审批历史的方法 - 基于instanceid
  **/

  procedure create_his_by_instanceid(p_his_type              in varchar2,
                                     p_his_comment_detail    in varchar2,
                                     p_his_approve_node      in varchar2,
                                     p_his_approve_operation in varchar2,
                                     p_his_instanceid        in varchar2,
                                     p_his_creator           in varchar2) is
    v_seq_id         number;
    v_process_code   varchar2(100);
    v_process_formid varchar2(100);
  begin
    --1、根据taskid得到 processcode processformid,creator;
    begin
      select ins.process_code, ins.process_form_id
        into v_process_code, v_process_formid
        from cux_bpm_all_instance ins
       where ins.instance_id = p_his_instanceid;
    
    exception
      when no_data_found then
        cux_bpm_logger.error('CREATE_HIS_BY_INSTANCEID',
                             p_his_instanceid ||
                             ' 任务对应流程没有注册实例信息，无法插入审批历史。');
    end;
  
    select cux_bpm_approve_history_seq.nextval into v_seq_id from dual;
  
    insert into cux_bpm_approve_history
      (his_id,
       his_comment_detail,
       his_creator,
       his_create_time,
       his_approve_node,
       his_approve_operation,
       his_type,
       process_name,
       process_form_id,
       object_version_number,
       created_by,
       creation_date,
       last_updated_by,
       last_update_date,
       his_taskid,
       instance_id)
    values
      (v_seq_id,
       p_his_comment_detail,
       p_his_creator,
       sysdate,
       p_his_approve_node,
       p_his_approve_operation,
       p_his_type,
       v_process_code,
       v_process_formid,
       1,
       p_his_creator,
       sysdate,
       p_his_creator,
       sysdate,
       '',
       p_his_instanceid);
    --修改实例状态   
  
    update cux_bpm_all_instance t
       set t.instance_status = 'TERMINATED'
     where t.instance_id = p_his_instanceid;
  
  exception
    when others then
      cux_bpm_logger.error('CREATE_HIS_BY_INSTANCEID',
                           dbms_utility.format_error_backtrace ||
                           dbms_utility.format_error_stack);
  end create_his_by_instanceid;

  procedure get_approve_history(p_instance_id in varchar2,
                                p_locale      in varchar2,
                                p_history_cur out approvelist_cur) is
  
    type t_instance_id is table of varchar2(50);
    v_instance_id   t_instance_id := t_instance_id();
    v_instance_coll varchar2(100) := '''' || p_instance_id || '''';
    v_sql           varchar2(4000);
    v_locale        varchar2(50);
    v_sys_code      varchar2(300);
    v_process_code  varchar2(300);
    v_tl_type       varchar2(300);
  begin
    --语言编号为空
   
  
    if v_sys_code is null then
      v_sys_code := 'SCI';
    end if;
    --获取对应实例id所在流的调用其他流程的实例id
    select distinct instanceid
      bulk collect
      into v_instance_id
      from cux_bpm_all_task_v
     where compositeinstanceid =
           (select distinct compositeinstanceid
              from cux_bpm_all_task_v
             where instanceid = p_instance_id)
       and instanceid <> p_instance_id;
  
    --拼接为查询in语句需要的格式
  
    for i in 1 .. v_instance_id.count loop
      v_instance_coll := v_instance_coll || ',''' || v_instance_id(i) || '''';
    end loop;
  
    v_sql := 'select *
    from (SELECT decode(T.HIS_COMMENT_DETAIL,''提报申请'','''',T.HIS_COMMENT_DETAIL) HIS_COMMENT_DETAIL,
                 T.HIS_CREATOR,
                 (SELECT EMPLOYEE.EMP_DISPLAYNAME
                    FROM FND_EMPLOYEES EMPLOYEE
                   WHERE LOWER(EMPLOYEE.EMP_ID) = LOWER(T.HIS_CREATOR)
                     AND ROWNUM = 1) HIS_CREATOR_NAME,
                 T.HIS_CREATE_TIME,
                cux_bpm_common_pkg.get_node_tl_value(''' ||
             v_process_code || ''',''' || p_locale ||
             ''',T.HIS_TASKID,T.HIS_APPROVE_NODE) HIS_APPROVE_NODE,
                 NVL(cux_bpm_common_pkg.get_tl_value(NULL,''' ||
             v_sys_code || ''',''' || p_locale ||
             ''',''approveOperation'',T.HIS_APPROVE_OPERATION),T.HIS_APPROVE_OPERATION) HIS_APPROVE_OPERATION,
                 T.PROCESS_FORM_ID,
                 NVL(cux_bpm_common_pkg.get_tl_value(NULL,''' ||
             v_sys_code || ''',''' || p_locale ||
             ''',''hisType'',T.HIS_TYPE),T.HIS_TYPE) HIS_TYPE,
                 T.HIS_TASKID,
                 T.INSTANCE_ID,
                 INS.PROCESS_FORM_INFO TITLE,
                 INS.PROCESS_CODE,
                 NVL(cux_bpm_common_pkg.get_tl_value(NULL,''' ||
             v_sys_code || ''',''' || p_locale ||
             ''',''instanceStatus'',INS.INSTANCE_STATUS),INS.INSTANCE_STATUS) INSTANCE_STATUS,
                 TASK.WORKFLOWPATTERN,
                 TASK.COMPOSITEINSTANCEID
            FROM CUX_BPM_APPROVE_HISTORY T,
                 CUX_BPM_ALL_INSTANCE    INS,
                 CUX_BPM_ALL_TASK_V      TASK
           WHERE T.INSTANCE_ID IN (' || v_instance_coll || ')
             AND INS.INSTANCE_ID = T.INSTANCE_ID
             AND T.HIS_TASKID = TASK.TASKID(+)
           ORDER BY HIS_CREATE_TIME ASC)
  UNION ALL
  select *
    from (SELECT '''' HIS_COMMENT_DETAIL,
                 V.ASSIGNEE HIS_CREATOR,
                 V.ASSIGNEE_NAME HIS_CREATOR_NAME,
                 V.TASKASSIGNTIME HIS_CREATE_TIME,
               cux_bpm_common_pkg.get_node_tl_value(''' ||
             v_process_code || ''',''' || p_locale ||
             ''',V.TASKID,V.ACTIVITYNAME) HIS_APPROVE_NODE,
                 (case v.hisApproveOperation
                   when ''SUBMIT'' then
                    NVL(cux_bpm_common_pkg.get_tl_value(NULL,''' ||
             v_sys_code || ''',''' || p_locale ||
             ''',''approveOperation'',v.hisApproveOperation),''等待确认'')
                   when ''RETURN'' then
                    NVL(cux_bpm_common_pkg.get_tl_value(NULL,''' ||
             v_sys_code || ''',''' || p_locale ||
             ''',''approveOperation'',v.hisApproveOperation),''等待重新提交'')
                   else
                    NVL(cux_bpm_common_pkg.get_tl_value(NULL,''' ||
             v_sys_code || ''',''' || p_locale ||
             ''',''approveOperation'',''ASSIGNED''),''等待审批'')
                 end) HIS_APPROVE_OPERATION,
                 V.PROCESS_FORM_ID PROCESS_FORM_ID,
                 NVL(cux_bpm_common_pkg.get_tl_value(NULL,''' ||
             v_sys_code || ''',''' || p_locale ||
             ''',''hisType'',''PROCESSING''),''PROCESSING'') HIS_TYPE,
                 V.TASKID HIS_TASKID,
                 V.INSTANCE_ID,
                 V.TITLE TITLE,
                 I.PROCESS_CODE,
                 NVL(cux_bpm_common_pkg.get_tl_value(NULL,''' ||
             v_sys_code || ''',''' || p_locale ||
             ''',''instanceStatus'',I.INSTANCE_STATUS),I.INSTANCE_STATUS) INSTANCE_STATUS,
                 V.WORKFLOWPATTERN,
                 V.COMPOSITEINSTANCEID
            FROM CUX_BPM_USER_TASK_V V, CUX_BPM_ALL_INSTANCE I
           WHERE V.INSTANCE_ID IN (' || v_instance_coll || ')
             AND V.INSTANCE_ID = I.INSTANCE_ID
           ORDER BY HIS_CREATE_TIME ASC)';
  
    open p_history_cur for v_sql;
  
  end get_approve_history;

  /***************************************************************************************
  * * * * * * * * * * * * * * * * 获取对应单据的审批历史，包括待办* * * * * * * * *
  ***************************************************************************************/

  procedure get_approve_history_by_doc(p_form_id     in varchar2,
                                       p_instance_id in varchar2,
                                       p_locale      in varchar2,
                                       p_history_cur out docapprovelist_cur) is
    v_sql varchar2(4000);
  begin
    v_sql := 'select *
    from (SELECT decode(T.HIS_COMMENT_DETAIL,''提报申请'','''',T.HIS_COMMENT_DETAIL) HIS_COMMENT_DETAIL,
                 T.HIS_CREATOR,
                 (SELECT EMPLOYEE.EMP_DISPLAYNAME
                    FROM FND_EMPLOYEES EMPLOYEE
                   WHERE LOWER(EMPLOYEE.EMP_ID) = LOWER(T.HIS_CREATOR)
                     AND ROWNUM = 1) HIS_CREATOR_NAME,
                 T.HIS_CREATE_TIME,T.HIS_APPROVE_NODE  HIS_APPROVE_NODE,
                 T.HIS_APPROVE_OPERATION HIS_APPROVE_OPERATION,
                 T.PROCESS_FORM_ID,
                 T.HIS_TYPE HIS_TYPE,
                 T.HIS_TASKID,
                 T.INSTANCE_ID,
                 TASK.TITLE TITLE,
                 INS.PROCESS_CODE,
                 INS.INSTANCE_STATUS  INSTANCE_STATUS,
                 TASK.WORKFLOWPATTERN,
                 TASK.COMPOSITEINSTANCEID
            FROM CUX_BPM_APPROVE_HISTORY T,
                 CUX_BPM_ALL_INSTANCE    INS,
                 CUX_BPM_ALL_TASK_V      TASK
           WHERE T.INSTANCE_ID = ''' || p_instance_id || '''
             AND INS.INSTANCE_ID = T.INSTANCE_ID
             and TASK.FORM_KEY_ID=''' || p_form_id || '''
             AND T.HIS_TASKID = TASK.TASKID(+)
           ORDER BY HIS_CREATE_TIME ASC)
  UNION ALL
  select *
    from (SELECT '''' HIS_COMMENT_DETAIL,
                 V.ASSIGNEE HIS_CREATOR,
                 V.ASSIGNEE_NAME HIS_CREATOR_NAME,
                 V.TASKASSIGNTIME HIS_CREATE_TIME,V.ACTIVITYNAME  HIS_APPROVE_NODE,
                 (case v.hisApproveOperation
                   when ''SUBMIT'' then
                    ''等待确认''
                   when ''RETURN'' then
                    ''等待重新提交''
                   else
                    ''等待审批''
                 end ) HIS_APPROVE_OPERATION,
                 V.PROCESS_FORM_ID PROCESS_FORM_ID,
                 ''PROCESSING'' HIS_TYPE,
                 V.TASKID HIS_TASKID,
                 V.INSTANCE_ID,
                 V.TITLE TITLE,
                 I.PROCESS_CODE,
                 I.INSTANCE_STATUS  INSTANCE_STATUS,
                 V.WORKFLOWPATTERN,
                 V.COMPOSITEINSTANCEID
            FROM CUX_BPM_USER_TASK_V V, CUX_BPM_ALL_INSTANCE I
           WHERE V.INSTANCE_ID = ''' || p_instance_id || '''
             AND V.INSTANCE_ID = I.INSTANCE_ID
             and V.PROCESS_FORM_ID=''' || p_form_id || '''
           ORDER BY HIS_CREATE_TIME ASC)';
    dbms_output.put_line(v_sql);
    
    cux_bpm_logger.info('GET_ALL_history', v_sql);
    open p_history_cur for v_sql;
  end get_approve_history_by_doc;
  function get_user_displayname(p_usercode in varchar2) return varchar2 is
    v_user_displayname varchar2(300) := '';
  begin
    begin
      --从员工表从获取名称
      select emp.emp_displayname
        into v_user_displayname
        from fnd_employees emp
       where emp.emp_id = p_usercode;
    
      return v_user_displayname;
    exception
      when others then
        v_user_displayname := '';
        return '';
    end;
    --若员工表获取不到，从同步中间表获取名称
    /*begin
       select emp.fullname
         into v_user_displayname
         from bpm_t_idm.t_idm_user emp
        where emp.usercode = p_usercode and rownum =1;
    exception
       when others then
        v_user_displayname :='';
    end;
       return v_user_displayname;*/
  end;

  /**
  *  获取国际化值
     p_process_code  流程编号
     p_sys_code  系统编号
     p_locale    语言编号
     p_tl_type   国际化类型
     p_tl_key    国际化关键字
  
     x_tl_data   国际化数据
  **/

  function get_tl_value(p_process_code in varchar2,
                        p_sys_code     in varchar2,
                        p_locale       in varchar2,
                        p_tl_type      in varchar2,
                        p_tl_key       in varchar2) return varchar2 is
  
    v_defualt      varchar2(30) := 'ALL';
    v_process_code varchar2(300);
    v_sys_code     varchar2(300);
    v_locale       varchar2(300);
    x_tl_data      varchar2(2000);
  begin
    if p_process_code is null then
      v_process_code := v_defualt;
    else
      v_process_code := p_process_code;
    end if;
  
    if p_sys_code is null then
      v_sys_code := v_defualt;
    else
      v_sys_code := p_sys_code;
    end if;
  
    if p_locale is null then
      v_locale := 'zh_CN';
    else
      v_locale := p_locale;
    end if;
  
    select max(t.tl_data)
      into x_tl_data
      from cux_bpm_process_tl t
     where t.process_code = v_process_code
       and t.sys_code = v_sys_code
       and t.locale = v_locale
       and t.tl_type = p_tl_type
       and t.tl_key = p_tl_key;
  
    return x_tl_data;
  exception
    when others then
      return '';
  end get_tl_value;
  /*
  获得节点的国际化值
  */

  function get_node_tl_value(p_process_code in varchar2,
                             p_locale       in varchar2,
                             p_task_id      in varchar2,
                             p_approve_node in varchar2) return varchar2 is
  
    v_defualt      varchar2(30) := 'ALL';
    v_process_code varchar2(300);
    v_sys_code     varchar2(300);
    v_locale       varchar2(300) := 'zh_CN';
    x_tl_data      varchar2(2000);
    v_node_id      number;
    v_count        number;
  begin
    if p_locale is not null then
      v_locale := p_locale;
    end if;
    begin
      select wf.protectednumberattribute1
        into v_node_id
        from wftask wf
       where wf.taskid = p_task_id;
    
    exception
      when no_data_found then
        v_node_id := 0;
    end;
  
    if v_node_id < 1 then
      ----注册流程节点
      null;
      if x_tl_data is null then
        return p_approve_node;
      else
        return x_tl_data;
      end if;
    else
      null;
      if x_tl_data is null then
        return p_approve_node;
      else
        return x_tl_data;
      end if;
    end if;
  
  exception
    when others then
      return p_approve_node;
  end get_node_tl_value;

  /***************************************************************************************
  * * * * * * * * * * * * * * * *分页获取已办、已发起信息* * * * * * * * *
  ***created by xiaowei.yao 2020-03-09
  ***************************************************************************************/

  procedure get_done_submit_task(p_emp_id            in varchar2,
                                 p_orderby           in varchar2,
                                 p_isasc             in varchar2,
                                 p_his_type          in varchar2,
                                 p_sql_query         in varchar2,
                                 p_idisplaystart     in number,
                                 p_getidisplaylength in number,
                                 p_count             out number,
                                 p_approvelist_cur   out approvelist_cur) is
  
    v_sql         varchar2(4000) := '';
    v_count       number := 0;
    v_start_index number := 0;
    v_end_index   number := 0;
    v_sql_count   varchar2(2000) := '';
    v_locale      varchar2(200) := 'zh_CN';
  begin
    --获取结果数量
    if p_his_type = 'REQUEST' then
      v_sql_count := 'SELECT count(1)
          FROM (SELECT DISTINCT HIS.HIS_ID
                  FROM CUX_BPM_APPROVE_HISTORY HIS, CUX_BPM_ALL_INSTANCE INS
                 WHERE HIS.INSTANCE_ID = INS.INSTANCE_ID
                   AND HIS.HIS_TYPE = ''REQUEST''' ||
                     p_sql_query || ' 
                   and lower(HIS.HIS_CREATOR) = LOWER(''' ||
                     p_emp_id || '''))';
    else
      v_sql_count := 'SELECT COUNT(1)
          FROM (SELECT DISTINCT HIS.HIS_ID
                  FROM CUX_BPM_ALL_INSTANCE    INS,
                       CUX_BPM_APPROVE_HISTORY HIS,
                       CUX_BPM_ALL_TASK_V      WFT
                 WHERE HIS.HIS_TASKID = WFT.TASKID
                   AND HIS.HIS_TYPE = ''APPROVE''' ||
                     p_sql_query || '
                   AND WFT.INSTANCEID = INS.INSTANCE_ID
                   AND LOWER(HIS.HIS_CREATOR) = LOWER(''' ||
                     p_emp_id || '''))';
    end if;
  
    execute immediate v_sql_count
      into v_count;
    p_count := v_count;
    -- -1 表示从头开始
    if p_idisplaystart > v_count then
      return;
    elsif p_idisplaystart <= -1 then
      v_start_index := 1;
    else
      v_start_index := p_idisplaystart; --从提供的下标开始，不从0开始；
    end if;
  
    -- -1 表示到结束；
  
    if -1 = p_getidisplaylength then
      v_end_index := v_count;
    elsif v_start_index + p_getidisplaylength - 1 <= v_count then
      v_end_index := v_start_index + p_getidisplaylength - 1;
    else
      v_end_index := v_count;
    end if;
  
    --先排序再分页
  
    if p_his_type = 'REQUEST' then
      v_sql := 'SELECT cux_bpm_common_pkg.get_node_tl_value(PROCESS_CODE,''' ||
               v_locale ||
               ''',HIS_TASKID,HIS_APPROVE_NODE) HIS_APPROVE_NODE,
         HIS_APPROVE_OPERATION,
         decode(HIS_COMMENT_DETAIL,''提报申请'','''',HIS_COMMENT_DETAIL) HIS_COMMENT_DETAIL,
         HIS_CREATE_TIME,
         HIS_CREATOR,
         (SELECT EMPLOYEE.EMP_DISPLAYNAME
            FROM FND_EMPLOYEES EMPLOYEE
           WHERE LOWER(EMPLOYEE.EMP_ID) = LOWER(HIS_CREATOR)
             AND ROWNUM = 1) HIS_CREATOR_NAME,
         PROCESS_FORM_ID,
         HIS_TASKID,
         HIS_TYPE,
         PROCESS_CODE,
         PROCESS_FORM_INFO,
         INSTANCE_STATUS,
         INSTANCE_ID,
         CUX_BPM_COMMON_PKG.GET_REQUEST_FORM_URL(INSTANCE_ID, PROCESS_FORM_ID) FORM_URL
    FROM (SELECT V.* ,ROWNUM INDEX_NUM 
           FROM (SELECT DISTINCT HIS.*,
                       INS.INSTANCE_STATUS,INS.PROCESS_CODE,INS.PROCESS_FORM_INFO
                  FROM CUX_BPM_APPROVE_HISTORY HIS, CUX_BPM_ALL_INSTANCE INS
                 WHERE HIS.INSTANCE_ID = INS.INSTANCE_ID
                   AND HIS.HIS_TYPE = ''REQUEST''
                   AND LOWER(HIS.HIS_CREATOR) = ''' ||
               lower(p_emp_id) || '''' || p_sql_query || '
                   ORDER BY ' || p_orderby || ' ' || p_isasc ||
               ') V)
   WHERE INDEX_NUM >= ' || v_start_index ||
               ' AND  INDEX_NUM <= ' || v_end_index;
    else
      v_sql := 'SELECT HIS_APPROVE_NODE,
         HIS_APPROVE_OPERATION,
         HIS_COMMENT_DETAIL,
         HIS_CREATE_TIME,
         HIS_CREATOR,
         (SELECT EMPLOYEE.EMP_DISPLAYNAME
            FROM FND_EMPLOYEES EMPLOYEE
           WHERE LOWER(EMPLOYEE.EMP_ID) = LOWER(HIS_CREATOR)
             AND ROWNUM = 1) HIS_CREATOR_NAME,
         PROCESS_FORM_ID,
         HIS_TASKID,
         HIS_TYPE,
         PROCESS_CODE,
        title PROCESS_FORM_INFO,
         INSTANCE_CREATOR,
         INSTANCE_CREATOR_NAME,
         to_char(instance_creation_date,''yyyy-mm-dd hh24:mi:ss'') instance_creation_date,
         INSTANCE_STATUS,
         INSTANCE_ID,
         CUX_BPM_COMMON_PKG.GET_HIS_FORM_URL(BUSINESS_SYSTEM_CODE,
                                             FORM_URL,
                                             FORM_PARASPATTERN,
                                             INSTANCE_ID,
                                             FORM_KEY_ID,
                                             OUTCOME) FORM_URL,
         OUTCOME,
         WORKFLOWPATTERN,
         COMPOSITEINSTANCEID
         FROM (SELECT V.*, ROWNUM INDEX_NUM
                FROM(SELECT DISTINCT HIS.*,
                            WFT.BUSINESS_SYSTEM_CODE,WFT.FORM_URL,WFT.FORM_PARASPATTERN,WFT.FORM_KEY_ID,WFT.OUTCOME,INS.INSTANCE_CREATOR,cux_bpm_common_pkg.get_user_name(INS.INSTANCE_CREATOR) INSTANCE_CREATOR_NAME,
                            ci.creation_date instance_creation_date,INS.INSTANCE_STATUS,wft.title,INS.PROCESS_CODE,WFT.WORKFLOWPATTERN,WFT.COMPOSITEINSTANCEID
                       FROM CUX_BPM_ALL_INSTANCE INS,
                            CUX_BPM_APPROVE_HISTORY HIS,
                            CUX_BPM_ALL_TASK_V      WFT,
                            cube_instance  ci
                      WHERE HIS.HIS_TASKID = WFT.TASKID
                        AND HIS.HIS_TYPE = ''APPROVE''
                        AND WFT.INSTANCEID = INS.INSTANCE_ID
                        AND INS.INSTANCE_ID = ci.cikey
                        AND LOWER(HIS.HIS_CREATOR) = ''' ||
               lower(p_emp_id) || '''' || p_sql_query || '
                      ORDER BY ' || p_orderby || ' ' ||
               p_isasc || ') V)
    WHERE INDEX_NUM >= ' || v_start_index ||
               ' AND  INDEX_NUM <= ' || v_end_index;
    end if;
  
    
    --cux_bpm_logger.info('GET_DONE_SUBMIT_TASK', v_sql);
    open p_approvelist_cur for v_sql;
  
    return;
  end get_done_submit_task;

  /***************************************************************************************
  * * * * * * * * * * * * * * * * 撤回插入审批历史的方法 - 基于instanceid
  * * * * * created by xiaowei.yao 2020-03-09* * * *
  ***************************************************************************************/

  function create_withrown_his(p_user              in varchar2,
                               p_task_id           in varchar2,
                               p_comment           in varchar2,
                               p_approve_operation in varchar2,
                               p_instanceid        in varchar2) return number as
  
    v_seq_id       number;
    v_count        number;
    v_approve_node varchar2(4000);
    v_process_name varchar2(100);
    v_form_id      varchar2(100);
    v_his_type     varchar2(100) := 'APPROVE';
    v_task_id      varchar2(100);
    v_node_id      number; --add by xiaowei.yao 20180706
  begin
    cux_bpm_logger.info('xxx',
                        'user:' || p_user || ',task_id:' || p_task_id ||
                        ',comment:' || p_comment || ',approve_operation:' ||
                        p_approve_operation || ',instanceId:' ||
                        p_instanceid);
  
    select wf.protectednumberattribute1
      into v_node_id
      from wftask wf
     where wf.instanceid = p_instanceid
       and rownum = 1
       and wf.protectednumberattribute1 <> 0
     order by wf.updateddate desc; --查出当前节点
  
    select cux_bpm_approve_history_seq.nextval into v_seq_id from dual;
  
    if p_instanceid is not null and p_user is not null then
      select count(1)
        into v_count
        from cux_bpm_all_instance t
       where lower(instance_creator) = lower(p_user)
         and t.instance_id = p_instanceid;
    
      if v_count > 0 then
        --发起人撤回
        select his.his_approve_node, his.process_name, his.process_form_id
          into v_approve_node, v_process_name, v_form_id
          from cux_bpm_approve_history his
         where his.instance_id = p_instanceid
           and lower(his.his_creator) = lower(p_user)
           and his.his_type = 'REQUEST';
        --插入审批历史   
      
        insert into cux_bpm_approve_history
          (his_id,
           his_comment_detail,
           his_creator,
           his_create_time,
           his_approve_node,
           his_approve_operation,
           his_type,
           process_name,
           process_form_id,
           object_version_number,
           created_by,
           creation_date,
           last_updated_by,
           last_update_date,
           his_taskid,
           instance_id)
        values
          (v_seq_id,
           p_comment,
           p_user,
           sysdate,
           v_approve_node,
           p_approve_operation,
           v_his_type,
           v_process_name,
           v_form_id,
           1,
           p_user,
           sysdate,
           p_user,
           sysdate,
           v_node_id,
           p_instanceid);
      
      else
        if p_task_id is null then
          --没有传入task id
          select his.his_approve_node,
                 his.process_name,
                 his.process_form_id,
                 his.his_taskid
            into v_approve_node, v_process_name, v_form_id, v_task_id
            from cux_bpm_approve_history his
           where his.instance_id = p_instanceid
             and lower(his.his_creator) = lower(p_user)
             and his.his_type = 'APPROVE'
             and his.his_approve_operation != 'WITHROWN'
             and rownum = 1;
        
        else
          --传入了task id
          select his.his_approve_node,
                 his.process_name,
                 his.process_form_id
            into v_approve_node, v_process_name, v_form_id
            from cux_bpm_approve_history his
           where his.instance_id = p_instanceid
             and his.his_taskid = p_task_id;
        
          v_task_id := p_task_id;
        end if;
        --插入审批历史   
      
        insert into cux_bpm_approve_history
          (his_id,
           his_comment_detail,
           his_creator,
           his_create_time,
           his_approve_node,
           his_approve_operation,
           his_type,
           process_name,
           process_form_id,
           object_version_number,
           created_by,
           creation_date,
           last_updated_by,
           last_update_date,
           his_taskid,
           instance_id)
        values
          (v_seq_id,
           p_comment,
           p_user,
           sysdate,
           v_approve_node,
           p_approve_operation,
           v_his_type,
           v_process_name,
           v_form_id,
           1,
           p_user,
           sysdate,
           p_user,
           sysdate,
           -- v_task_id,
           v_node_id, --保存节点id
           p_instanceid);
      
      end if;
    
    else
      cux_bpm_logger.error(p_log_type => 'WITHROWN_HISTORY_CREATE_ERR',
                           p_log_info => p_instanceid ||
                                         ' 撤回写入审批历史失败,instanceId和工号不能同时为空');
      return - 1;
    end if;
  
    commit;
    return 1;
  exception
    when others then
      cux_bpm_logger.error(p_log_type => 'WITHROWN_HISTORY_CREATE_ERR',
                           p_log_info => p_instanceid || ' 撤回写入审批历史失败！');
      return - 1;
  end create_withrown_his;
  /***************************************************************************************
  * * * * * * * * * * * * * * * * 修改审批意见 * * * * *
   * * created by xiaowei.yao 2020-03-09* *
  ***************************************************************************************/

  function update_task_comment(p_task_id in varchar2,
                               p_user    in varchar2,
                               p_comment in varchar2) return varchar2 as
  
    v_result            varchar2(10) := 'N';
    v_seq_id            number;
    v_approve_operation varchar2(100) := 'UPDATE_COMMENT';
    v_his_type          varchar2(100) := 'APPROVE';
    cursor v_apr_his_cur is
      select t.his_creator,
             t.his_approve_node,
             t.process_name,
             t.process_form_id,
             t.his_type,
             t.instance_id,
             get_user_name(t.his_creator) his_creator_name
        from cux_bpm_approve_history t
       where lower(t.his_creator) = lower(p_user)
         and t.his_taskid = p_task_id
         and t.his_approve_operation != 'WITHROWN';
  
  begin
    --非空判断
    if p_task_id is not null and p_comment is not null then
      --用原来的task信息
      for v_apr_his_cur_row in v_apr_his_cur loop
        select cux_bpm_approve_history_seq.nextval into v_seq_id from dual;
      
        insert into cux_bpm_approve_history
          (his_id,
           his_comment_detail,
           his_creator,
           his_create_time,
           his_approve_node,
           his_approve_operation,
           his_type,
           process_name,
           process_form_id,
           object_version_number,
           created_by,
           creation_date,
           last_updated_by,
           last_update_date,
           his_taskid,
           instance_id)
        values
          (v_seq_id,
           p_comment,
           p_user,
           sysdate,
           v_apr_his_cur_row.his_approve_node,
           v_approve_operation,
           v_his_type,
           v_apr_his_cur_row.process_name,
           v_apr_his_cur_row.process_form_id,
           1,
           p_user,
           sysdate,
           p_user,
           sysdate,
           p_task_id,
           v_apr_his_cur_row.instance_id);
      
      end loop;
    
      v_result := 'Y';
    end if;
  
    return v_result;
  exception
    when others then
      cux_bpm_logger.error(p_log_type => 'UPDATE_TASK_COMMENT_ERR',
                           p_log_info => 'user:' || p_user || ' 修改taskId为' ||
                                         p_task_id || '的审批意见失败,原因:\n' ||
                                         sqlerrm);
    
      return v_result;
  end update_task_comment;

  /**
  *  获取用户名称
     p_user_code  工号
  
     return       名称
     created by xiaowei.yao 2020-03-09
  **/

  function get_user_name(p_user_code in varchar2) return varchar2 as
    x_user_name varchar2(300);
  begin
    if p_user_code is not null then
      select max(fe.emp_displayname)
        into x_user_name
        from fnd_employees fe
       where lower(fe.emp_id) = lower(p_user_code)
         and rownum = 1;
    
      if x_user_name is null then
        x_user_name := p_user_code;
      end if;
    end if;
  
    return x_user_name;
  exception
    when others then
      cux_bpm_logger.error('get_user_name', sqlerrm);
      return x_user_name;
  end get_user_name;

  /**
  *  根据instanceid批量获取当前审批人
     p_instance_ids  多个实例号用,隔开
  
     return       实例号对应的当前审批人
     created by xiaowei.yao 2020-03-09
  **/

  procedure proc_get_approvers_by_ins(p_instance_ids in varchar2,
                                      x_approve_cur  out approvelist_cur) is
  begin
    if p_instance_ids is not null then
      open x_approve_cur for 'select distinct t.instanceid ,ass.assignee user_code,cux_bpm_common_pkg.get_user_name(ass.assignee) user_name
    from wftask t, wfassignee ass
   where t.taskid = ass.taskid
     and t.state = ''ASSIGNED''
     and t.hassubtask = ''F''
     and t.instanceid in (' || p_instance_ids || ')';
    
    else
      raise_application_error(-20001, 'instanceId为空');
    end if;
  end proc_get_approvers_by_ins;

  
  /**
  *  获取用户名称
     p_user_code  工号
  
     return       名称
  **/

  /***************************************************************************************
  * * * * * * * * * * * * * * * * 插入抓取实例的审批历史* * * * * * * * *
  ***************************************************************************************/

  function create_grab_instance_his(p_user              in varchar2,
                                    p_comment           in varchar2,
                                    p_approve_operation in varchar2,
                                    p_instanceid        in varchar2)
    return number is
    v_seq_id         number;
    v_process_code   varchar2(100);
    v_process_formid varchar2(100);
  begin
    --1、根据taskid得到 processcode processformid,creator;
    begin
      select ins.process_code, ins.process_form_id
        into v_process_code, v_process_formid
        from cux_bpm_all_instance ins
       where ins.instance_id = p_instanceid;
    
    exception
      when no_data_found then
        cux_bpm_logger.error('create_grab_instance_his',
                             p_instanceid || ' 任务对应流程没有注册实例信息，无法插入审批历史。');
    end;
  
    select cux_bpm_approve_history_seq.nextval into v_seq_id from dual;
  
    insert into cux_bpm_approve_history
      (his_id,
       his_comment_detail,
       his_creator,
       his_create_time,
       his_approve_node,
       his_approve_operation,
       his_type,
       process_name,
       process_form_id,
       object_version_number,
       created_by,
       creation_date,
       last_updated_by,
       last_update_date,
       his_taskid,
       instance_id)
    values
      (v_seq_id,
       p_comment,
       p_user,
       sysdate,
       '闭环',
       p_approve_operation,
       'GRABINS',
       v_process_code,
       v_process_formid,
       1,
       p_user,
       sysdate,
       p_user,
       sysdate,
       '',
       p_instanceid);
  
    return v_seq_id;
  end create_grab_instance_his;

end cux_bpm_common_pkg;
/

