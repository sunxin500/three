create package     CUX_EXT_SYS_PKG is

  -- Author  : WLJ
  -- Created : 2018/6/14 0:37:35
  -- Purpose : 提供给外部系统调用

  /*==================================================
  Procedure/Function Name :
      proc_save_mob_data
  Description:
      This function perform:
      关联单据/维护移动端数据
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-06-14  wlj   Creation
  ==================================================*/
  PROCEDURE proc_save_mob_data(p_request CLOB, x_response OUT CLOB);

end CUX_EXT_SYS_PKG;

/

