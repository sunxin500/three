create view DCLD_DATA_VALUE_V as
select ds.data_source_code,
       ds.data_source_name,
       ds.status           ds_status,
       dsv.value_code,
       dsv.value_name,
       dsv.status          dsv_status,
       dsv.display_seq     seq
  from dbpm_data_source ds, dbpm_data_source_values dsv
 where ds.data_source_code = dsv.data_source_code
/

