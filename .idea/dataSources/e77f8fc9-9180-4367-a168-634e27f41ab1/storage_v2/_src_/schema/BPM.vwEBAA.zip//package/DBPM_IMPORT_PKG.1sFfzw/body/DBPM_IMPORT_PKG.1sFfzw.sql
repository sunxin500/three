create package body     dbpm_import_pkg is

  /*==================================================
  Procedure/Function Name :
      func_export_process
  Description:
      This function perform:
      导出对应的流程
  Argument:
     p_process_id：流程id
  History:
      1.00  2019-04-21  xiaowei.yao  Creation
  ==================================================*/
  FUNCTION func_export_process(p_process_id NUMBER) RETURN CLOB IS
    v_response              CLOB;
    v_process               pl_json := pl_json;
    v_process_code          VARCHAR2(100);
    v_process_name          VARCHAR2(50);
    v_description           VARCHAR2(100);
    v_process_type          VARCHAR2(100);
    v_enabled_flag          VARCHAR2(5);
    v_space_code            VARCHAR2(100);
    v_is_shared             varchar2(100);
    v_role_json             pl_json;
    v_param_json            pl_json;
    v_process_node          pl_json;
    v_process_param         pl_json;
    v_node_chain            pl_json;
    v_node_role             pl_json;
    v_node_role_param_value pl_json;
    v_approval_chain        pl_json;
    v_chain_node            pl_json;
    v_chain_node_tl         pl_json;
    v_chain_rule            pl_json;
    v_process_tl            pl_json;
    v_auth_relation         pl_json;
    v_param_id              NUMBER;
    v_dynamic_user          pl_json;
    v_dynamic_value_type    varchar2(100);
    v_dynamic_value         varchar2(100);

    --流程节点
    CURSOR v_process_nodes_cur IS
      SELECT dpn.*, dns.node_name backNodeName
        FROM dbpm_process_nodes dpn, dbpm_process_nodes dns
       WHERE dpn.process_id = p_process_id
         and dpn.back_node_id = dns.node_id(+)
       order by dpn.order_num asc;
    cursor v_process_nodes_tl_cur(p_node_id number) is
      select *
        from dbpm_process_nodes_tl t
       where t.node_id = p_node_id
       order by t.node_id asc;
    --流程参数
    CURSOR v_process_params_cur IS
      SELECT *
        FROM dbpm_process_params dpp
       WHERE dpp.process_id = p_process_id
       order by dpp.param_id asc;
    --流程节点角色
    CURSOR v_node_roles_cur(p_node_id NUMBER) IS
      SELECT *
        FROM dbpm_node_roles dnr
       WHERE dnr.node_id = p_node_id
         and dnr.node_from_type = 'ProcessNode'
       order by dnr.node_role_id asc;
    --流程角色参数
    CURSOR v_node_role_param_values_cur(p_node_role_id NUMBER) IS
      SELECT dnrpv.*,
             drp.param_name,
             drp.order_num,
             drp.role_id,
             drp.status,
             drp.data_source_code,
             (select dr.role_code
                from dbpm_roles dr
               where dr.role_id = drp.role_id) role_code,
             COUNT(1) over(PARTITION BY 1) role_count
        FROM dbpm_node_role_param_value dnrpv, DBPM_ROLE_PARAMS drp
       WHERE dnrpv.node_role_id = p_node_role_id
         and drp.param_id = dnrpv.param_id
       order by dnrpv.node_role_id asc;
    --流程审批链
    CURSOR v_approval_chains_cur IS
      SELECT *
        FROM dbpm_approval_chain dac
       WHERE dac.process_id = p_process_id
         and nvl(dac.is_deleted, 'N') <> 'Y'
       order by dac.chain_id asc;
    --流程审批链节点
    CURSOR v_chain_nodes_cur(p_chain_id NUMBER) IS
      SELECT dcn.*, dns.node_name backNodeName
        FROM dbpm_chain_nodes dcn, dbpm_process_nodes dns
       WHERE dcn.chain_id = p_chain_id
         and dcn.is_deleted = 'N'
         and dcn.back_node_id = dns.node_id(+)
       order by dcn.node_id asc;
    --审批节点状态值表
    CURSOR v_chain_node_status_cur(p_node_id NUMBER) IS
      SELECT *
        FROM dbpm_nodes_businessdata dcnt
       WHERE dcnt.node_id = p_node_id;

    --审批节点多语言表
    CURSOR v_chain_node_tls_cur(p_node_id NUMBER) IS
      SELECT *
        FROM dbpm_chain_nodes_tl dcnt
       WHERE dcnt.node_id = p_node_id;
    --流程多语言
    CURSOR v_process_tl_cur IS
      SELECT *
        FROM dbpm_process_tl dpt
       WHERE dpt.process_id = p_process_id;
    --流程绑定服务
    /* cursor v_process_service_cur is select * from dbpm_process_service_map t
    where */
    --流程审批规则
    CURSOR v_chain_rules_cur(p_chain_id NUMBER) IS
      SELECT * FROM dbpm_chain_rules dcr WHERE dcr.chain_id = p_chain_id;
    CURSOR v_role_cur(p_node_id NUMBER) IS
      SELECT dnr.*, dr.role_id, dr.role_name
        FROM dbpm_node_roles dnr, dbpm_roles dr
       WHERE dnr.business_role = dr.role_code
         AND dnr.node_id = p_node_id
         AND dnr.node_from_type = 'ChainNode';
    -- 审批角色参数
    CURSOR v_param_cur(p_node_role_id NUMBER) IS
      SELECT dnrp.*,
             drp.param_name,
             drp.order_num,
             drp.role_id,
             drp.status,
             drp.data_source_code,
             (select dr.role_code
                from dbpm_roles dr
               where dr.role_id = drp.role_id) role_code,
             COUNT(1) over(PARTITION BY 1) role_count
        FROM dbpm_node_role_param_value dnrp,
             dbpm_node_roles            dnr,
             dbpm_role_params           drp
       WHERE dnrp.node_role_id = dnr.node_role_id
         AND dnr.node_from_type = 'ChainNode'
         AND dnrp.param_id = drp.param_id
         AND dnrp.node_role_id = p_node_role_id;
    CURSOR v_chain_cur(p_node_id NUMBER, p_process_id NUMBER) IS
      SELECT dac.chain_id,
             dac.chain_name,
             (CASE
               WHEN dnc.chain_id IS NULL THEN
                'N'
               ELSE
                'Y'
             END) is_checked
        FROM dbpm_node_chains dnc, dbpm_approval_chain dac
       WHERE dnc.node_id(+) = p_node_id
         AND dnc.chain_id(+) = dac.chain_id
         AND dac.process_id = p_process_id
         AND dnc.node_from_type(+) = 'ProcessNode'
         AND dac.chain_type = 'SubChain';
    --  动态用户
    cursor v_dynamic_user_cur(p_node_id number) is
      select t.dynamic_value, t.get_value_type
        from DBPM_DYNAMIC_APPROVERS t
       where t.node_id = p_node_id;
    ---动态用户的规则
    cursor v_common_rule_cur(p_node_id number) is
      select * from cux_bpm_common_rule t where t.node_id = p_node_id;

    --审批链规则
    cursor v_chain_tree_cur(p_chain_id number) is
      select dt.*
        from dbpm_chain_rules_tree dt
       where dt.chain_id = p_chain_id;

    v_selected_users varchar2(4000);
    --流程权限关联
    cursor v_auth_relation_cur is
      select *
        from dbpm_process_group_realtion t
       where t.process_id = p_process_id;

    ---动态用户
    cursor v_dync_users_cur(p_node_id number) is

      select * from cux_bpm_common_rule t where t.node_id = p_node_id;
    v_todo_flag         varchar2(1000);
    v_form_url          varchar2(1000);
    v_process_owner     varchar2(1000);
    v_auto_approve_flag varchar2(1000);
    v_org_type          varchar2(1000);
    v_node_it           pl_json;
    v_node_status       pl_json;
    v_dy                pl_json;
    v_docsys_code       varchar2(1000);
  BEGIN
    SELECT dp.process_code,
           dp.process_name,
           dp.description,
           dp.process_type,
           dp.enabled_flag,
           (select ds.space_code
              from dbpm_spaces ds
             where ds.space_id = dp.space_id),
           dp.is_shared,
           dp.cux_org_type,
           dp.cux_auto_approve_flag,
           dp.process_owner,
           dp.todo_flag,
           dp.form_url,
           dp.doc_sys_code
      INTO v_process_code,
           v_process_name,
           v_description,
           v_process_type,
           v_enabled_flag,
           v_space_code,
           v_is_shared,
           v_org_type,
           v_auto_approve_flag,
           v_process_owner,
           v_todo_flag,
           v_form_url,
           v_docsys_code
      FROM dbpm_process dp
     WHERE dp.process_id = p_process_id;
    v_process.set_value('processCode', v_process_code);
    v_process.set_value('processName', v_process_name);
    v_process.set_value('description', v_description);
    v_process.set_value('processType', v_process_type);
    v_process.set_value('enabledFlag', v_enabled_flag);
    v_process.set_value('spaceCode', v_space_code);
    v_process.set_value('isShared', v_is_shared);
    v_process.set_value('todoFlag', v_todo_flag);
    v_process.set_value('formUrl', v_form_url);
    v_process.set_value('autoApproveFlag', v_auto_approve_flag);
    v_process.set_value('cuxOrgType', v_org_type);
    v_process.set_value('docsys', v_docsys_code);
    --流程多多语言
    FOR v_process_tls IN v_process_tl_cur LOOP
      v_process_tl := pl_json;
      v_process_tl.set_value('processId', v_process_tls.process_id);
      v_process_tl.set_value('locale', v_process_tls.locale);
      v_process_tl.set_value('processName', v_process_tls.process_name);
      v_process_tl.set_value('description', v_process_tls.description);
      v_process.add_list_item('processTlList', v_process_tl);
    end loop;
    FOR v_process_nodes IN v_process_nodes_cur LOOP
      v_process_node := pl_json;
      v_process_node.set_value('nodeId', v_process_nodes.node_id);
      v_process_node.set_value('processId', v_process_nodes.process_id);
      v_process_node.set_value('nodeName', v_process_nodes.node_name);
      v_process_node.set_value('nodeType', v_process_nodes.node_type);
      v_process_node.set_value('orderNum', v_process_nodes.order_num);
      v_process_node.set_value('objectVersionNumber',
                               v_process_nodes.object_version_number);
      v_process_node.set_value('approverType',
                               v_process_nodes.approver_type);
      v_process_node.set_value('nodeFormUrl', v_process_nodes.node_formurl);
      v_process_node.set_value('email_flag', v_process_nodes.email_flag);
      v_process_node.set_value('backNodeId', v_process_nodes.back_node_id);
      v_process_node.set_value('backNodeName',
                               v_process_nodes.backnodename);
      IF v_process_nodes.is_required = 'Y' THEN
        v_process_node.set_value('isRequired', TRUE);
      ELSE
        v_process_node.set_value('isRequired', FALSE);
      END IF;
      IF v_process_nodes.is_auto_approve = 'Y' THEN
        --add by wlj
        v_process_node.set_value('isAutoApprove', TRUE);
      ELSE
        v_process_node.set_value('isAutoApprove', FALSE);
      END IF;
      if v_process_nodes.approver_type = 'StaticUser' then
        begin
          select t.dynamic_value
            into v_selected_users
            from dbpm_dynamic_approvers t
           where t.node_id = v_process_nodes.node_id
             and t.get_value_type = 'STATIC';
        exception
          when others then
            v_selected_users := '';
        end;
        v_process_node.set_value('approverUsers', v_selected_users);
      end if;

      FOR v_node_roles IN v_node_roles_cur(v_process_nodes.node_id) LOOP
        v_node_role := pl_json;
        v_node_role.set_value('nodeRoleId', v_node_roles.node_role_id);
        v_node_role.set_value('nodeId', v_node_roles.node_id);
        v_node_role.set_value('businessRole', v_node_roles.business_role);
        v_node_role.set_value('nodeFromType', v_node_roles.node_from_type);
        v_node_role.set_value('customRoleName',
                              v_node_roles.custom_role_name);
        FOR v_node_role_param_values IN v_node_role_param_values_cur(v_node_roles.node_role_id) LOOP
          v_node_role_param_value := pl_json;
          v_node_role_param_value.set_value('nodeRoleId',
                                            v_node_role_param_values.node_role_id);
          v_node_role_param_value.set_value('paramId',
                                            v_node_role_param_values.param_id);
          --新增导出角色数据

          v_node_role_param_value.set_value('paramName',
                                            v_node_role_param_values.param_name);
          v_node_role_param_value.set_value('orderNum',
                                            v_node_role_param_values.order_num);
          v_node_role_param_value.set_value('roleId',
                                            v_node_role_param_values.role_id);
          v_node_role_param_value.set_value('roleCode',
                                            v_node_role_param_values.role_code);
          v_node_role_param_value.set_value('status',
                                            v_node_role_param_values.status);
          v_node_role_param_value.set_value('dataSourceCode',
                                            v_node_role_param_values.data_source_code);

          v_node_role_param_value.set_value('paramValue',
                                            v_node_role_param_values.param_value);
          v_node_role_param_value.set_value('getValueType',
                                            v_node_role_param_values.get_value_type);
          v_node_role_param_value.set_value('operationType',
                                            v_node_role_param_values.operation_type);
          v_node_role_param_value.set_value('roleCount',
                                            v_node_role_param_values.role_count);
          v_node_role.add_list_item('nodeRoleParamValueList',
                                    v_node_role_param_value);
        END LOOP;
        v_process_node.add_list_item('nodeRolesList', v_node_role);

      END LOOP;
      ---节点国际化值
      for v_node_it_cur in v_process_nodes_tl_cur(v_process_nodes.node_id) loop
        v_node_it := pl_json;
        v_node_it.set_value('locale', v_node_it_cur.locale);
        v_node_it.set_value('lang', v_node_it_cur.node_name);
        v_node_it.set_value('nodeid', v_node_it_cur.node_id);
        v_process_node.add_list_item('nodeItlList', v_node_it);
      end loop;
      ---节点国际化值
      for v_status in v_chain_node_status_cur(v_process_nodes.node_id) loop
        v_node_status := pl_json;
        v_node_status.set_value('businessCode', v_status.business_code);
        v_node_status.set_value('businessName', v_status.business_name);
        v_node_status.set_value('businessContent',
                                v_status.business_content);
        v_node_status.set_value('nodeid', v_status.node_id);
        v_process_node.add_list_item('nodeStatus', v_node_status);
      end loop;

      if v_process_nodes.approver_type = 'DynamicUser' then
        v_dynamic_user := pl_json;
        begin
          select nvl(t.dynamic_value, ''), nvl(t.get_value_type, '')
            into v_dynamic_value, v_dynamic_value_type
            from DBPM_DYNAMIC_APPROVERS t
           where t.node_id = v_process_nodes.node_id;
        exception
          when no_data_found then
            v_dynamic_value      := '';
            v_dynamic_value_type := '';
        end;
        for v_dny in v_dync_users_cur(v_process_nodes.node_id) loop
          v_dy := pl_json;
          v_dy.set_value('rule', v_dny.rule_expression);
          v_dy.set_value('approverList', v_dny.rule_value);
          v_dynamic_user.add_list_item('sqlUsers', v_dy);
        end loop;
        v_dynamic_user.set_value('getValueType', v_dynamic_value_type);
        v_dynamic_user.set_value('dynamicValue', v_dynamic_value);
        v_process_node.set_value('dynamicUser', v_dynamic_user);
      end if;

      FOR v_chain IN v_chain_cur(v_process_nodes.node_id, p_process_id) LOOP
        v_node_chain := pl_json;
        v_node_chain.set_value('chainId', v_chain.chain_id);
        v_node_chain.set_value('chainName', v_chain.chain_name);
        IF v_chain.is_checked = 'Y' THEN
          v_node_chain.set_value('isChecked', TRUE);
        ELSE
          v_node_chain.set_value('isChecked', FALSE);
        END IF;
        v_process_node.add_list_item('nodeChains', v_node_chain);
      END LOOP;
      v_process.add_list_item('processNodeLists', v_process_node);
    END LOOP;
    FOR v_process_params IN v_process_params_cur LOOP
      v_process_param := pl_json;
      v_process_param.set_value('paramId', v_process_params.param_id);
      v_process_param.set_value('processId', v_process_params.process_id);
      v_process_param.set_value('paramCode', v_process_params.param_code);
      v_process_param.set_value('paramName', v_process_params.param_name);
      v_process_param.set_value('paramType', v_process_params.param_type);
      v_process.add_list_item('processParamLists', v_process_param);
    END LOOP;
    FOR v_approval_chains IN v_approval_chains_cur LOOP
      v_approval_chain := pl_json;
      v_approval_chain.set_value('chainId', v_approval_chains.chain_id);
      v_approval_chain.set_value('spaceId', v_approval_chains.space_id);
      v_approval_chain.set_value('chainName', v_approval_chains.chain_name);
      v_approval_chain.set_value('chainType', v_approval_chains.chain_type);
      v_approval_chain.set_value('processId', v_approval_chains.process_id);
      v_approval_chain.set_value('organizationId',
                                 v_approval_chains.organization_id);
      v_approval_chain.set_value('version', v_approval_chains.version);
      v_approval_chain.set_value('from_chainId',
                                 v_approval_chains.from_chain_id);
      v_approval_chain.set_value('status', v_approval_chains.status);
      ----审批链规则
      FOR v_chain_roles IN v_chain_rules_cur(v_approval_chains.chain_id) LOOP
        v_chain_rule := pl_json;
        v_chain_rule.set_value('ruleId', v_chain_roles.rule_id);
        v_chain_rule.set_value('chainId', v_chain_roles.chain_id);
        v_chain_rule.set_value('paramName', v_chain_roles.param_name);
        v_chain_rule.set_value('paramMeaning', v_chain_roles.param_meaning);
        v_chain_rule.set_value('paramType', v_chain_roles.param_type);
        v_chain_rule.set_value('operationType',
                               v_chain_roles.operation_type);
        v_chain_rule.set_value('paramValue', v_chain_roles.param_value);
        v_chain_rule.set_value('getValueType',
                               v_chain_roles.get_value_type);
        v_chain_rule.set_value('ruleUuid', v_chain_roles.rule_uuid);
        v_approval_chain.add_list_item('chainRulesLists', v_chain_rule);
      END LOOP;
      --审批链树形规则
      for v_chain_tree in v_chain_tree_cur(v_approval_chains.chain_id) loop
        v_chain_rule := pl_json;
        v_chain_rule.set_value('chainId', v_chain_tree.chain_id);
        v_chain_rule.set_value('chainName', v_chain_tree.chain_name);
        if v_chain_tree.chain_rule_tree is not null then

          v_chain_rule.set_value('chainTreeRule',
                                 json_list(v_chain_tree.chain_rule_tree));
        end if;

        v_chain_rule.set_value('organizationId',
                               v_chain_tree.organization_id);
        v_chain_rule.set_value('processId', v_chain_tree.process_id);
        v_chain_rule.set_value('spaceId', v_chain_tree.space_id);
        v_chain_rule.set_value('status', v_chain_tree.status);
        v_approval_chain.add_list_item('chainTreeRules', v_chain_rule);
      end loop;
      FOR v_chain_nodes IN v_chain_nodes_cur(v_approval_chains.chain_id) LOOP
        v_chain_node := pl_json;

        v_chain_node.set_value('nodeId', v_chain_nodes.node_id);
        v_chain_node.set_value('chainId', v_chain_nodes.chain_id);
        v_chain_node.set_value('nodeName', v_chain_nodes.node_name);
        v_chain_node.set_value('nodeType', v_chain_nodes.node_type);
        v_chain_node.set_value('orderNum', v_chain_nodes.order_num);
        v_chain_node.set_value('approverType', v_chain_nodes.approver_type);
        v_chain_node.set_value('isAutoApprove',
                               v_chain_nodes.is_auto_approve);
        v_chain_node.set_value('isRequired', v_chain_nodes.is_required);
        v_chain_node.set_value('parentId', v_chain_nodes.parent_id);
        v_chain_node.set_value('backNodeId', v_chain_nodes.back_node_id);
        v_chain_node.set_value('backNodeName', v_chain_nodes.backnodename);

        FOR v_role IN v_role_cur(v_chain_nodes.node_id) LOOP
          v_role_json := pl_json;
          v_role_json.set_value('roleId', v_role.role_id);
          v_role_json.set_value('roleCode', v_role.business_role);
          v_role_json.set_value('roleName', v_role.role_name);
          v_role_json.set_value('nodeFromType', v_role.node_from_type);
          v_role_json.set_value('customRoleName', v_role.custom_role_name);
          FOR v_param IN v_param_cur(v_role.node_role_id) LOOP
            v_param_json := pl_json;
            v_param_json.set_value('nodeRoleId', v_param.node_role_id);
            v_param_json.set_value('paramId', v_param.param_id);
            --新增导出角色数据

            v_param_json.set_value('paramName', v_param.param_name);
            v_param_json.set_value('orderNum', v_param.order_num);
            v_param_json.set_value('roleId', v_param.role_id);
            v_param_json.set_value('roleCode', v_param.role_code);
            v_param_json.set_value('status', v_param.status);
            v_param_json.set_value('dataSourceCode',
                                   v_param.data_source_code);
            v_param_json.set_value('roleCount', v_param.role_count);
            v_param_json.set_value('paramValue', v_param.param_value);
            v_param_json.set_value('getValueType', v_param.get_value_type);
            v_param_json.set_value('operationType', v_param.operation_type);
            v_role_json.add_list_item('paramList', v_param_json);
          END LOOP;

          v_chain_node.add_list_item('businessRoles', v_role_json);
        END LOOP;

        if v_chain_nodes.approver_type = 'DynamicUser' then
          v_dynamic_user := pl_json;
          begin
            select nvl(t.dynamic_value, ''), nvl(t.get_value_type, '')
              into v_dynamic_value, v_dynamic_value_type
              from DBPM_DYNAMIC_APPROVERS t
             where t.node_id = v_chain_nodes.node_id;
          exception
            when no_data_found then
              v_dynamic_value      := '';
              v_dynamic_value_type := '';
          end;
          for v_dny in v_dync_users_cur(v_chain_nodes.node_id) loop
            v_dy := pl_json;
            v_dy.set_value('rule', v_dny.rule_expression);
            v_dy.set_value('approverList', v_dny.rule_value);
            v_dynamic_user.add_list_item('sqlUsers', v_dy);
          end loop;
          v_dynamic_user.set_value('getValueType', v_dynamic_value_type);
          v_dynamic_user.set_value('dynamicValue', v_dynamic_value);
          v_chain_node.set_value('dynamicUser', v_dynamic_user);
        end if;
        if v_chain_nodes.approver_type = 'StaticUser' then
          begin
            select t.dynamic_value
              into v_selected_users
              from dbpm_dynamic_approvers t
             where t.node_id = v_chain_nodes.node_id
               and t.get_value_type = 'STATIC';
          exception
            when others then
              v_selected_users := '';
          end;
          v_chain_node.set_value('approverUsers', v_selected_users);
        end if;
        v_approval_chain.add_list_item('chainNodeLists', v_chain_node);
      END LOOP;
      v_process.add_list_item('approvalChainLists', v_approval_chain);
    END LOOP;
    RETURN v_process.to_data_json;
  END func_export_process;

  /*==================================================
  Procedure/Function Name :
      func_import_process
  Description:
      This function perform:
      导入对应的流程
  Argument:
     p_process_content ：流程的相关信息
  History:
      1.00  2019-04-21  xiaowei.yao  Creation
  ==================================================*/
  procedure proc_import_process(p_request CLOB, x_response out clob) IS
    v_request                json;
    v_response               pl_json := pl_json;
    v_process_node           json;
    v_data                   json;
    v_process_nodes          json_list;
    v_process_relation_list  json_list;
    v_node_roles             json_list;
    v_approval_chains        json_list;
    v_chain_nodes            json_list;
    v_node_role_param_values json_list;
    v_chain_rules            json_list;
    v_process_params         json_list;
    v_chain_node_tls         json_list;
    v_process_tls            json_list;
    v_chain_role_nodes       json_list;
    v_parm_lists             json_list;
    v_process_param          json;
    v_parm_list              json;
    v_process_tl             json;
    v_node_role              json;
    v_chain_role_node        json;
    v_node_role_param_value  json;
    v_dynamic_User           json;
    v_approval_chain         json;
    v_chain_node             json;
    v_chain_node_tl          json;
    v_chain_rule             json;
    v_process_relation       json;
    v_username               varchar2(100);
    v_process_code           VARCHAR2(100);
    v_role_id                VARCHAR2(100);
    v_process_name           VARCHAR2(50);
    v_description            VARCHAR2(100);
    v_process_type           VARCHAR2(100);
    v_enabled_flag           VARCHAR2(5);
    v_space_id               VARCHAR2(100);
    v_space_Code             VARCHAR2(100);
    v_temp_role              VARCHAR2(200);
    v_is_shared              varchar2(100);
    v_PARAM_ID               number;
    v_role_node_id           number;
    v_space_count            number;
    v_process_id             number;
    v_node_id                number;
    v_node_role_id           number;
    v_temp_role_id           number;
    v_chain_id               number;
    v_chain_node_id          number;
    v_is_role                number; --判断是否有角色数据信息
    v_isProcess              number; --流程编码是否冲突
    v_role_count             number; --流程角色参数数量
    v_relation_count         number;
    v_content_tree           clob;
    v_cux_org_type           varchar2(100);
    v_auto_approve_flag      varchar2(100);
    v_process_owner          varchar2(100);
    v_todo_flag              varchar2(100);
    v_form_url               varchar2(100);
    v_sqlUsers               json_list;
    v_sqluser                json;
    v_res                    varchar2(32767 byte);
    v_processnode_itls       json_list;
    v_processnode_itl        json;
    v_nodestatus             json_list;
    v_sta                    json;
    v_parentId               number;
    v_backNodeId             number;
    v_backNodeName           varchar2(100);
    v_chain_node_back_id     number;
    v_docsys_code            varchar2(100);
  BEGIN

    -- v_res :=func_export_process(12037);

    v_data     := json(p_request, 'OBJECT');
    v_username := v_data.username;
    --dbpm_process dp 流程基本信息
    v_process_code      := v_data.get_string('processCode');
    v_process_name      := v_data.get_string('processName');
    v_description       := v_data.get_string('description');
    v_process_type      := v_data.get_string('processType');
    v_enabled_flag      := v_data.get_string('enabledFlag');
    v_space_Code        := v_data.get_string('spaceCode');
    v_auto_approve_flag := v_data.get_string('autoApproveFlag');
    v_cux_org_type      := v_data.get_string('cuxOrgType');
    v_process_owner     := v_data.get_string('processOwner');
    v_todo_flag         := v_data.get_string('todoFlag');
    v_form_url          := v_data.get_string('formUrl');
    v_docsys_code       := v_data.get_string('docsys');

    --验证spce空间是否配置
    begin
      select ds.space_id
        into v_space_id
        from dbpm_spaces ds
       where ds.space_code = v_space_Code;
    exception
      when no_data_found then
        v_response.fail('空间不存在！');
        x_response := v_response.to_json;
        return;
    end;
    select count(1)
      into v_space_count
      from dbpm_administrators da
     where upper(da.user_code) = upper(v_username)
       and da.admin_type = 'SuperAdmin';
    if v_space_count = 0 then
      select count(1)
        into v_space_count
        from dbpm_administrators da, dbpm_spaces ds
       where upper(da.user_code) = upper(v_username)
         and da.space_id = ds.space_id
         and ds.space_code = v_space_Code;
      if v_space_count = 0 then
        --v_response.fail('当前用户空间与该流程空间不符！');
        v_response.fail(DCLD_COMM_PKG.func_get_err_msg('DCLD-00003',
                                                       v_request.locale));
        x_response := v_response.to_json;
        return;
      end if;
    end if;
    v_is_shared := v_data.get_string('isShared');
    --判断是否已存在流程编码,流程版本升级
    insert into dbpm_process_reversion
      select * from dbpm_process dp where dp.process_code = v_process_code;
    delete from dbpm_process dp where dp.process_code = v_process_code;
    select count(1)
      into v_isProcess
      from dbpm_process dp
     where dp.process_code = v_process_code;
    if v_isProcess = 0 then
      v_process_id := dbpm_process_s.nextval;
      insert into dbpm_process
        (process_id,
         process_code,
         process_name,
         description,
         process_type,
         enabled_flag,
         space_id,
         is_shared,
         cux_auto_approve_flag,
         process_owner,
         cux_org_type,
         todo_flag,
         form_url,
         doc_sys_code)
      values
        (v_process_id,
         v_process_code,
         v_process_name,
         v_description,
         v_process_type,
         v_enabled_flag,
         v_space_id,
         v_is_shared,
         v_auto_approve_flag,
         v_process_owner,
         v_cux_org_type,
         v_todo_flag,
         v_form_url,
         v_docsys_code);
      --流程发起权限
      if v_data.exist('authRelation') then
        v_process_relation_list := json_list(v_data.get('authRelation'));
        for a in 1 .. v_process_relation_list.count loop
          v_process_relation := json(v_process_relation_list.get(a));
          if v_process_relation.get_string('authType') = 'GROUP' then
            select count(1)
              into v_relation_count
              from dbpm_process_auth_group t
             where t.group_code = v_process_relation.get_string('authCode');
            if v_relation_count = 0 then
              v_response.fail('缺少权限组' ||
                              v_process_relation.get_string('authCode') ||
                              '数据!');
              x_response := v_response.to_json;
              rollback;
              return;
            end if;
            insert into dbpm_process_group_realtion
              (realtion_id, process_id, auth_code, auth_type)
            values
              (dbpm_process_group_realtion_s.nextval,
               v_process_id,
               v_process_relation.get_string('authCode'),
               v_process_relation.get_string('authType'));
          end if;
          if v_process_relation.get_string('authType') = 'ROLE' then
            select count(1)
              into v_relation_count
              from DBPM_ROLES t
             where t.role_code = v_process_relation.get_string('authCode');
            if v_relation_count = 0 then
              v_response.fail('缺少角色权限组' ||
                              v_process_relation.get_string('authCode') ||
                              '数据!');
              x_response := v_response.to_json;
              rollback;
              return;
            end if;
            insert into dbpm_process_group_realtion
              (realtion_id, process_id, auth_code, auth_type)
            values
              (dbpm_process_group_realtion_s.nextval,
               v_process_id,
               v_process_relation.get_string('authCode'),
               v_process_relation.get_string('authType'));
          end if;
        end loop;
      end if;
      if v_data.exist('processNodeLists') then
        v_process_nodes := json_list(v_data.get('processNodeLists'));
        FOR i IN 1 .. v_process_nodes.count LOOP
          v_process_node := json(v_process_nodes.get(i));
          --dbpm_process_nodes dpn 节点配置信息

          v_node_id      := dbpm_process_nodes_s.nextval;
          v_backNodeId   := v_process_node.get_number('backNodeId');
          v_backNodeName := v_process_node.get_string('backNodeName');
          --求出退回的节点
          if v_backNodeId > 1 then
            select dns.node_id
              into v_backNodeId
              from dbpm_process_nodes dns
             where dns.process_id = v_process_id
               and dns.node_name = v_backNodeName;
          end if;
          insert into dbpm_process_nodes
            (node_id,
             process_id,
             node_name,
             node_type,
             order_num,
             approver_type,
             is_auto_approve,
             is_required,
             back_node_id,
             node_formurl)
          values
            (v_node_id,
             v_process_id,
             v_process_node.get_string('nodeName'),
             v_process_node.get_string('nodeType'),
             v_process_node.get_number('orderNum'),
             v_process_node.get_string('approverType'),
             v_process_node.get_string('isAutoApprove'),
             v_process_node.get_string('isRequired'),
             v_backNodeId,
             v_process_node.get_string('nodeFormUrl'));

          if v_process_node.get_string('approverType') = 'StaticUser' and
             v_process_node.get_string('approverUsers') is not null then
            insert into dbpm_dynamic_approvers
              (approver_id,
               node_id,
               dynamic_value,
               get_value_type,
               operation_type,
               creation_date,
               created_by,
               last_updated_by,
               last_update_date)
            values
              (dbpm_dynamic_approvers_s.nextval,
               v_node_id,
               v_process_node.get_string('approverUsers'),
               'STATIC',
               '=',
               sysdate,
               v_username,
               v_username,
               sysdate);
          end if;
          if v_process_node.get_string('approverType') = 'DynamicUser' and
             v_process_node.exist('dynamicUser') then
            v_dynamic_User := json(v_process_node.get('dynamicUser'));
            if v_dynamic_User.get_string('dynamicValue') is not null then
              insert into dbpm_dynamic_approvers
                (approver_id,
                 node_id,
                 dynamic_value,
                 get_value_type,
                 operation_type,
                 creation_date,
                 created_by,
                 last_updated_by,
                 last_update_date)
              values
                (DBPM_DYNAMIC_APPROVERS_s.Nextval,
                 v_node_id,
                 v_dynamic_User.get_string('dynamicValue'),
                 v_dynamic_User.get_string('getValueType'),
                 '=',
                 sysdate,
                 v_username,
                 v_username,
                 sysdate);
            end if;
            if v_dynamic_User.get_string('getValueType') = 'SQL' then
              v_sqlUsers := json_list(v_dynamic_User.get('sqlUsers'));
              for i in 1 .. v_sqlUsers.count loop
                v_sqluser := json(v_sqlUsers.get(i));
                insert into cux_bpm_common_rule
                  (node_id,
                   rule_expression,
                   rule_value,
                   priority,
                   creation_date,
                   created_by,
                   last_updated_by,
                   last_update_date,
                   common_rule_id)
                values
                  (v_node_id,
                   v_sqluser.get_string('rule'),
                   v_sqluser.get_string('approverList'),
                   1,
                   sysdate,
                   v_username,
                   v_username,
                   sysdate,
                   cux_bpm_common_rule_s.nextval);
              end loop;
            end if;

          end if;
          ---节点国际化值
          if v_process_node.exist('nodeItlList') then
            v_processnode_itls := json_list(v_process_node.get('nodeItlList'));
            for i in 1 .. v_processnode_itls.count loop
              v_processnode_itl := json(v_processnode_itls.get(i));
              insert into dbpm_process_nodes_tl
                (node_id,
                 locale,
                 node_name,
                 creation_date,
                 object_version_number,
                 last_updated_by,
                 last_update_date)
              values
                (v_node_id,
                 v_processnode_itl.get_string('locale'),
                 v_processnode_itl.get_string('lang'),
                 sysdate,
                 1,
                 v_username,
                 sysdate);
            end loop;
          end if;
          --节点状态值
          if v_process_node.exist('nodeStatus') then
            v_nodestatus := json_list(v_process_node.get('nodeStatus'));
            for i in 1 .. v_nodestatus.count loop
              v_sta := json(v_nodestatus.get(i));
              insert into dbpm_nodes_businessdata
                (id,
                 node_id,
                 business_code,
                 business_name,
                 business_content,
                 object_version_number,
                 creation_date,
                 created_by,
                 last_updated_by,
                 last_update_date)
              values
                (dbpm_nodes_businessdata_s.nextval,
                 v_node_id,
                 v_sta.get_string('businessCode'),
                 v_sta.get_string('businessName'),
                 v_sta.get_string('businessContent'),
                 1,
                 sysdate,
                 v_username,
                 v_username,
                 sysdate);
            end loop;
          end if;
          if v_process_node.exist('nodeRolesList') then
            v_node_roles := json_list(v_process_node.get('nodeRolesList'));
            FOR o IN 1 .. v_node_roles.count LOOP
              v_node_role := json(v_node_roles.get(o));
              --dbpm_node_roles dnr  节点审批角色
              select count(1)
                into v_is_role
                from DBPM_ROLES dr
               where dr.role_code = v_node_role.get_string('businessRole');
              if v_is_role <> 0 then

                v_node_role_id := dbpm_node_roles_s.nextval;
                insert into dbpm_node_roles
                  (node_role_id,
                   node_id,
                   business_role,
                   node_from_type,
                   custom_role_name)
                values
                  (v_node_role_id,
                   v_node_id,
                   v_node_role.get_string('businessRole'),
                   v_node_role.get_string('nodeFromType'),
                   v_node_role.get_string('customRoleName'));
              else
                v_response.fail('缺少角色' ||
                                v_node_role.get_string('businessRole') ||
                                '数据!');
                x_response := v_response.to_json;
                rollback;
                return;
              end if;
              if v_node_role.exist('nodeRoleParamValueList') then
                v_node_role_param_values := json_list(v_node_role.get('nodeRoleParamValueList'));
                FOR p IN 1 .. v_node_role_param_values.count LOOP
                  v_node_role_param_value := json(v_node_role_param_values.get(p));
                  --dbpm_node_role_param_value dnrpv  节点角色规则
                  --校验导入角色数据 并查询角色ID
                  begin
                    select dr.role_id
                      into v_role_id
                      from dbpm_roles dr
                     where dr.role_code =
                           v_node_role_param_value.get_string('roleCode');
                  exception
                    when no_data_found then

                      v_response.fail('缺少' ||
                                      v_chain_role_node.get_string('roleCode') ||
                                      '角色数据！');
                      x_response := v_response.to_json;
                      rollback;
                      return;
                  end;
                  --角色参数数量校验
                  select count(*)
                    into v_role_count
                    from DBPM_ROLE_PARAMS rp
                   where rp.role_id = v_role_id;
                  if v_role_count <>
                     v_node_role_param_value.get_string('roleCount') then
                    v_response.fail(v_node_role.get_string('businessRole') ||
                                    '角色参数数量与导入环境不一致！');
                    x_response := v_response.to_json;
                    rollback;
                    return;
                  end if;
                  --新增角色参数
                  begin
                    select rp.param_id
                      into v_PARAM_ID
                      from DBPM_ROLE_PARAMS rp
                     where rp.role_id = v_role_id
                       and rp.param_name =
                           v_node_role_param_value.get_string('paramName')
                       and rp.status =
                           v_node_role_param_value.get_string('status');

                  exception
                    when no_data_found then
                      v_response.fail(v_node_role.get_string('businessRole') ||
                                      '角色参数与导入环境不一致！');
                      x_response := v_response.to_json;
                      rollback;
                      return;
                  end;
                  --新增节点角色参数
                  insert into dbpm_node_role_param_value
                    (node_role_id,
                     param_id,
                     param_value,
                     get_value_type,
                     operation_type)
                  values
                    (v_node_role_id,
                     v_PARAM_ID,
                     v_node_role_param_value.get_string('paramValue'),
                     v_node_role_param_value.get_string('getValueType'),
                     v_node_role_param_value.get_string('operationType'));
                END LOOP;
              end if;
            END LOOP;
          end if;
        END LOOP;
      end if;
      if v_data.exist('processParamLists') then
        v_process_params := json_list(v_data.get('processParamLists'));
        --dbpm_process_params dpp 流程参数
        FOR j IN 1 .. v_process_params.count LOOP
          v_process_param := json(v_process_params.get(j));
          insert into dbpm_process_params
            (param_id, process_id, param_code, param_name, param_type)
          values
            (dbpm_process_params_s.nextval,
             v_process_id,
             v_process_param.get_string('paramCode'),
             v_process_param.get_string('paramName'),
             v_process_param.get_string('paramType'));
        END LOOP;
      end if;
      --流程多多语言
      if v_data.exist('processTlList') then
        v_process_tls := json_list(v_data.get('processTlList'));
        FOR x IN 1 .. v_process_tls.count LOOP
          v_process_tl := json(v_process_tls.get(x));
          insert into dbpm_process_tl
            (process_id, locale, process_name, description)
          values
            (v_process_id,
             v_process_tl.get_string('locale'),
             v_process_tl.get_string('processName'),
             v_process_tl.get_string('description'));
        END LOOP;
      end if;
      if v_data.exist('approvalChainLists') then
        v_approval_chains := json_list(v_data.get('approvalChainLists'));
        FOR k IN 1 .. v_approval_chains.count LOOP
          v_approval_chain := json(v_approval_chains.get(k));
          --dbpm_approval_chain dac 审批链信息
          v_chain_id := dbpm_approval_chain_s.nextval;
          insert into dbpm_approval_chain
            (chain_id,
             chain_name,
             chain_type,
             process_id,
             organization_id,
             version,
             from_chain_id,
             status,
             space_id)
          values
            (v_chain_id,
             v_approval_chain.get_string('chainName'),
             v_approval_chain.get_string('chainType'),
             v_process_id,
             v_approval_chain.get_string('organizationId'),
             1,
             1,
             v_approval_chain.get_string('status'),
             v_space_id);
          if v_approval_chain.exist('chainRulesLists') then
            v_chain_rules := json_list(v_approval_chain.get('chainRulesLists'));
            FOR l IN 1 .. v_chain_rules.count LOOP
              v_chain_rule := json(v_chain_rules.get(l));
              --dbpm_chain_rules dcr 审批链规则
              insert into dbpm_chain_rules
                (rule_id,
                 chain_id,
                 param_name,
                 param_meaning,
                 param_type,
                 operation_type,
                 param_value,
                 get_value_type,
                 rule_uuid)
              values
                (dbpm_chain_rules_s.nextval,
                 v_chain_id,
                 v_chain_rule.get_string('paramName'),
                 v_chain_rule.get_string('paramMeaning'),
                 v_chain_rule.get_string('paramType'),
                 v_chain_rule.get_string('operationType'),
                 v_chain_rule.get_string('paramValue'),
                 v_chain_rule.get_string('getValueType'),
                 v_chain_rule.get_string('ruleUuid'));
            END LOOP;
          end if;
          if v_approval_chain.exist('chainTreeRules') then
            v_chain_rules := json_list(v_approval_chain.get('chainTreeRules'));
            FOR l IN 1 .. v_chain_rules.count LOOP
              v_chain_rule := json(v_chain_rules.get(l));
              if v_chain_rule.get('chainTreeRule') is not null THEN
                dbms_lob.createtemporary(v_content_tree, false);
                json_list(v_chain_rule.get('chainTreeRule')).to_clob(v_content_tree);
              end if;
              -- v_chain_rule.ge
              --dbpm_chain_rules dcr 审批链规则
              insert into dbpm_chain_rules_tree
                (chain_id,
                 chain_rule_tree,
                 chain_name,
                 chain_type,
                 process_id,
                 organization_id,
                 from_chain_id,
                 status,
                 is_deleted,
                 space_id)
              values
                (v_chain_id,
                 v_content_tree,
                 v_chain_rule.get_string('chainName'),
                 'Custom',
                 v_process_id,
                 v_chain_rule.get_string('organizationId'),
                 '',
                 v_chain_rule.get_string('status'),
                 'N',
                 v_space_id);
            END LOOP;
          end if;
          if v_approval_chain.exist('chainNodeLists') then
            v_chain_nodes := json_list(v_approval_chain.get('chainNodeLists'));
            FOR b IN 1 .. v_chain_nodes.count LOOP
              v_chain_node    := json(v_chain_nodes.get(b));
              v_chain_node_id := dbpm_chain_nodes_s.nextval;
              --求出父亲节点ID
              select dn.node_id
                into v_parentId
                from dbpm_process_nodes dn, dbpm_approval_chain dc
               where dc.chain_id = v_chain_id
                 and dc.process_id = dn.process_id
                 and dn.node_name = v_chain_node.get_string('nodeName');

              --dbpm_chain_nodes dcn 审批链节点
              --求出退回节点
              v_chain_node_back_id := v_chain_node.get_number('backNodeId');
              if v_chain_node_back_id > 1 then
                begin
                  select dn.node_id
                    into v_chain_node_back_id
                    from dbpm_process_nodes dn, dbpm_approval_chain dc
                   where dc.chain_id = v_chain_id
                     and dc.process_id = dn.process_id
                     and dn.node_name =
                         v_chain_node.get_string('backNodeName');
                exception
                  when no_data_found then
                    v_response.fail('审批链：' ||
                                    v_chain_rule.get_string('chainName') ||
                                    ',审批节点：' ||
                                    v_chain_node.get_string('nodeName') ||
                                    ' 缺少退回节点');
                    x_response := v_response.to_json;
                    rollback;
                    return;
                end;
              end if;
              insert into dbpm_chain_nodes
                (node_id,
                 chain_id,
                 node_name,
                 node_type,
                 order_num,
                 approver_type,
                 is_auto_approve,
                 is_required,
                 parent_id,
                 back_node_id)
              values
                (v_chain_node_id,
                 v_chain_id,
                 v_chain_node.get_string('nodeName'),
                 v_chain_node.get_string('nodeType'),
                 v_chain_node.get_number('orderNum'),
                 v_chain_node.get_string('approverType'),
                 v_chain_node.get_string('isAutoApprove'),
                 v_chain_node.get_string('isRequired'),
                 v_parentId,
                 v_chain_node_back_id);

              if v_chain_node.get_string('approverType') = 'StaticUser' and
                 v_chain_node.get_string('approverUsers') is not null then
                insert into dbpm_dynamic_approvers
                  (approver_id,
                   node_id,
                   dynamic_value,
                   get_value_type,
                   operation_type,
                   creation_date,
                   created_by,
                   last_updated_by,
                   last_update_date)
                values
                  (dbpm_dynamic_approvers_s.nextval,
                   v_chain_node_id,
                   v_chain_node.get_string('approverUsers'),
                   'STATIC',
                   '=',
                   sysdate,
                   v_username,
                   v_username,
                   sysdate);
              end if;
              if v_chain_node.get_string('approverType') = 'DynamicUser' and
                 v_chain_node.exist('dynamicUser') then
                v_dynamic_User := json(v_chain_node.get('dynamicUser'));
                if v_dynamic_User.get_string('dynamicValue') is not null then
                  insert into dbpm_dynamic_approvers
                    (approver_id,
                     node_id,
                     dynamic_value,
                     get_value_type,
                     operation_type,
                     creation_date,
                     created_by,
                     last_updated_by,
                     last_update_date)
                  values
                    (DBPM_DYNAMIC_APPROVERS_s.Nextval,
                     v_chain_node_id,
                     v_dynamic_User.get_string('dynamicValue'),
                     v_dynamic_User.get_string('getValueType'),
                     '=',
                     sysdate,
                     v_username,
                     v_username,
                     sysdate);
                end if;
                if v_dynamic_User.get_string('getValueType') = 'SQL' then
                  v_sqlUsers := json_list(v_dynamic_User.get('sqlUsers'));
                  for i in 1 .. v_sqlUsers.count loop
                    v_sqluser := json(v_sqlUsers.get(i));
                    insert into cux_bpm_common_rule
                      (node_id,
                       rule_expression,
                       rule_value,
                       priority,
                       creation_date,
                       created_by,
                       last_updated_by,
                       last_update_date,
                       common_rule_id)
                    values
                      (v_chain_node_id,
                       v_sqluser.get_string('rule'),
                       v_sqluser.get_string('approverList'),
                       1,
                       sysdate,
                       v_username,
                       v_username,
                       sysdate,
                       cux_bpm_common_rule_s.nextval);
                  end loop;
                end if;

              end if;

              if v_chain_node.exist('chainNodeTlLists') then
                v_chain_node_tls := json_list(v_chain_node.get('chainNodeTlLists'));
                FOR n IN 1 .. v_chain_node_tls.count LOOP
                  v_chain_node_tl := json(v_chain_node_tls.get(n));
                  --dbpm_chain_nodes_tl dcnt 审批链节点角色
                  insert into dbpm_chain_nodes_tl
                    (node_id, locale, node_name)
                  values
                    (v_chain_node_id,
                     v_chain_node_tl.get_string('locale'),
                     v_chain_node_tl.get_string('nodeName'));
                END LOOP;
              end if;
              if v_chain_node.exist('businessRoles') then
                v_chain_role_nodes := json_list(v_chain_node.get('businessRoles'));
                FOR o IN 1 .. v_chain_role_nodes.count LOOP
                  v_chain_role_node := json(v_chain_role_nodes.get(o));
                  --dbpm_node_roles dnr  节点审批角色
                  select count(1)
                    into v_is_role
                    from DBPM_ROLES dr
                   where dr.role_code =
                         v_chain_role_node.get_string('roleCode');
                  if v_is_role <> 0 then

                    v_node_role_id := dbpm_node_roles_s.nextval;
                    insert into dbpm_node_roles
                      (node_role_id,
                       node_id,
                       business_role,
                       node_from_type,
                       custom_role_name)
                    values
                      (v_node_role_id,
                       v_chain_node_id,
                       v_chain_role_node.get_string('roleCode'),
                       v_chain_role_node.get_string('nodeFromType'),
                       v_chain_role_node.get_string('customRoleName'));
                  else
                    v_response.fail('审批链缺少' ||
                                    v_chain_role_node.get_string('roleCode') ||
                                    '角色数据！！');
                    x_response := v_response.to_json;
                    rollback;
                    return;
                  end if;
                  if v_chain_role_node.exist('paramList') then
                    v_parm_lists := json_list(v_chain_role_node.get('paramList'));
                    FOR p IN 1 .. v_parm_lists.count LOOP
                      v_parm_list := json(v_parm_lists.get(p));
                      --dbpm_node_role_param_value dnrpv  节点角色规则
                      --校验导入角色数据 并查询角色ID
                      begin
                        select dr.role_id
                          into v_role_id
                          from dbpm_roles dr
                         where dr.role_code =
                               v_chain_role_node.get_string('roleCode');
                      exception
                        when no_data_found then

                          v_response.fail('审批链缺少' ||
                                          v_chain_role_node.get_string('roleCode') ||
                                          '角色数据！');
                          x_response := v_response.to_json;
                          rollback;
                          return;
                      end;
                      --角色参数数量校验
                      select count(*)
                        into v_role_count
                        from DBPM_ROLE_PARAMS rp
                       where rp.role_id = v_role_id;
                      if v_role_count <>
                         v_parm_list.get_string('roleCount') then
                        v_response.fail(v_chain_role_node.get_string('roleCode') ||
                                        '角色参数数量与导入环境不一致！');
                        x_response := v_response.to_json;
                        rollback;
                        return;
                      end if;
                      --新增角色参数
                      begin
                        select rp.param_id
                          into v_PARAM_ID
                          from DBPM_ROLE_PARAMS rp
                         where rp.role_id = v_role_id
                           and rp.param_name =
                               v_parm_list.get_string('paramName')
                           and rp.status = v_parm_list.get_string('status');

                      exception
                        when no_data_found then
                          v_response.fail(v_chain_role_node.get_string('roleCode') ||
                                          '角色参数与导入环境不一致！');
                          x_response := v_response.to_json;
                          rollback;
                          return;
                      end;
                      begin
                        --新增节点角色参数
                        insert into dbpm_node_role_param_value
                          (node_role_id,
                           param_id,
                           param_value,
                           get_value_type,
                           operation_type)
                        values
                          (v_node_role_id,
                           v_PARAM_ID,
                           v_parm_list.get_string('paramValue'),
                           v_parm_list.get_string('getValueType'),
                           v_parm_list.get_string('operationType'));
                      exception
                        when others then
                          v_response.fail(v_chain_role_node.get_string('roleCode') ||
                                          '角色参数与导入环境不一致！');
                          x_response := v_response.to_json;
                          rollback;
                          return;
                      end;
                    END LOOP;
                  end if;
                END LOOP;

              end if;
            END LOOP;
          end if;
        END LOOP;
      end if;
    else
      v_response.fail('已存在此流程编码！');
      x_response := v_response.to_json;
      rollback;
      return;
    end if;
    v_response.set_value('processId', v_process_id);
    x_response := v_response.to_json;
  END proc_import_process;
end dbpm_import_pkg;

/

