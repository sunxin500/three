create view DBPM_OBPM_INSTANCES_V as
SELECT wt.instanceid,
       wt.protectednumberattribute1 node_id,
       (CASE
         WHEN wt.outcome IS NOT NULL THEN
          wt.approvers
         ELSE
          replace(wt.assignees,',user','')
       END) assignee,
       (SELECT de.employee_name
             FROM dfnd_employees de
            WHERE upper(de.employee_code) =
            upper(CASE
               WHEN wt.outcome IS NOT NULL THEN
                wt.approvers
               ELSE
                replace(wt.assignees,',user','')
             END)
        ) display_name,
       to_char(wt.assigneddate,'YYYY-MM-DD hh24:mi:ss') assign_date,
       to_char(wt.enddate,'YYYY-MM-DD hh24:mi:ss') approve_date,
       nvl(wt.outcome, wt.state) state,
       wt.taskid,
       wt.tasknumber,
       (SELECT max(wth.fromuser)
          FROM wftaskhistory wth
         WHERE wth.taskid = wt.taskid AND wth.substate = 'REASSIGNED'
        ) authorizer,
        wt.hassubtask,
        wt.updatedby,
        wt.outcome,
        wt.customattributestring1 uuid,
        ---  wt.protectedtextattribute7 old_users,
       nvl(wt.protectedtextattribute9, wt.protectedtextattribute7) old_users,
        wt.protectedtextattribute8 now_users
  FROM wftask wt
       --  WHERE wt.hassubtask = 'F'
         -- AND wt.updatedby <> 'workflowsystem'
--AND wt.instanceid = 2151655; --2151891

/

