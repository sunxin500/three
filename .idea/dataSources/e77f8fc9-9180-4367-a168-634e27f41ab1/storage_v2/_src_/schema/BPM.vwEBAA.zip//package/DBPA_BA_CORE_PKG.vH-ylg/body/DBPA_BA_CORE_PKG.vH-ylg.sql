create PACKAGE BODY     "DBPA_BA_CORE_PKG" is

  -- Author  : Echo.Zeng
  -- Created : 2018-01-11 09:00:00
  /*==================================================
  Procedure/Function Name :
      proc_plat_query_poc_counts
  Description:
      This function perform:
      获取各个系统的流程数量

  Argument:
     p_request      请求json
      {
          "user": "weblogic",
          "data":
          {
              "systemCode": ["HMQM", "GEMS"],
              "startDate": "2017-12-01 00:00:00",
              "endDate": "2018-01-01 00:00:00"
          }
      }
     x_response     响应json
      {
          "code": "SUCCESS",
          "data":
          {
              "systems": [
              {
                  "systemId": 1001,
                  "systemCode": "HMQM",
                  "systemName": "HMQM",
                  "processCount": 5000
              },
              {
                  "systemId": 1002,
                  "systemCode": "GEMS",
                  "systemName": "全球费用管理系统",
                  "processCount": 12000
              }]
          }
      }
  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  procedure proc_plat_query_poc_counts(p_request  IN CLOB,
                                       x_response OUT CLOB) is
    v_request     json;
    v_response    pl_json := pl_json;
    v_sys_code_ls json_list;
    v_str         varchar2(4000);
    v_sys_str     varchar2(4000);
    v_date_format varchar2(30);
    v_value_code  varchar2(30);
    v_start_date  varchar2(30);
    v_end_date    varchar2(30);
    v_process_cur refcur;
    v_item        pl_json;
    v_system_id   dfnd_app.system_id%TYPE;
    v_system_code dfnd_app.system_code%TYPE;
    v_system_name dfnd_app.system_name%TYPE;
    v_counts      number;
  begin
    v_request     := json(p_request, 'OBJECT');
    v_sys_code_ls := json_list(v_request.path('systemCode'));
    v_start_date  := v_request.get('startDate').get_string;
    v_end_date    := v_request.get('endDate').get_string;
    --获取日期格式
    if v_request.get('date_format') is null then
      v_value_code := 'default';
    else
      v_value_code := v_request.get('date_format').get_string;
    end if;
    begin
      v_date_format := func_get_data_value('oracle_date_format',
                                           v_value_code);
    exception
      when others then
        v_response.fail('查询日期格式值出错，请稍后再试');
        x_response := v_response.to_json;
        return;
    end;
    if func_check_date(v_start_date, v_end_date, v_date_format) then
      if v_sys_code_ls is not null and v_sys_code_ls.count > 0 then
        v_sys_str := 'da.system_code in (select system
  from table(pljson_table.json_table(''' || p_request || ''',
                                     pljson_varray(''data.systemCode''),
                                     pljson_varray(''system''))))';
      else
        v_sys_str := '1 = 1';
      end if;
      --v_str := v_sys_code_ls.to_char();
      v_str := 'select max(system_id) system_id,system_code,max(system_name) system_name,count(1) as counts
         from (select distinct da.system_id,
             da.system_code,
             da.system_name,
             dp.process_code
        from dbpm_ba_process dp, dfnd_app da
       where dp.system_id = da.system_id
         and dp.creation_date >= trunc(to_date(:1,:2),''DD'') and
            dp.creation_date < trunc(to_date(:3,:4),''DD'')+1
         and ' || v_sys_str || ')
       group by system_code';
      dbms_output.put_line(v_str);
      open v_process_cur for v_str
        using v_start_date, v_date_format, v_end_date, v_date_format;
      loop
        fetch v_process_cur
          into v_system_id, v_system_code, v_system_name, v_counts;
        exit when v_process_cur%notfound;
        v_item := pl_json;
        v_item.set_value('systemId', v_system_id);
        v_item.set_value('systemCode', v_system_code);
        v_item.set_value('systemName', v_system_name);
        v_item.set_value('processCount', v_counts);
        v_response.add_list_item('systems', v_item);
      end loop;
      close v_process_cur;
    else
      v_response.fail('非法日期格式，请重新输入');
    end if;
    x_response := v_response.to_json;
  exception
    when others then
      v_response.fail('获取数据失败，请稍后再试');
      x_response := v_response.to_json;
  end proc_plat_query_poc_counts;

  /*==================================================
  Procedure/Function Name :
      proc_plat_ins_counts
  Description:
      This function perform:
      获取各个系统的实例数量

  Argument:
     p_request      请求json
      {
          "user": "weblogic",
          "data":
          {
              "systemCode": ["HMQM", "GEMS"],
              "state": ["completed", "runing", "error"]
              "startDate": "2017-12-01",
              "endDate": "2018-01-01"
          }
      }
     x_response     响应json
        {
          "code": "SUCCESS",
          "data": {
            "systems": [{
                "systemId": 1001,
                "systemCode": "HMQM",
                "systemName": "HMQM",
                "instanceCount": [{
                    "code": "completed",
                    "count": 1000
                  }, {
                    "code": "runing",
                    "count": 1000
                  }, {
                    "code": "error",
                    "count": 1000
                  }
                ]
              }, {
                "systemId": 1002,
                "systemCode": "GEMS",
                "systemName": "全球费用管理系统",
                "instanceCount": [{
                    "code": "completed",
                    "count": 1000
                  }, {
                    "code": "runing",
                    "count": 1000
                  }, {
                    "code": "error",
                    "count": 1000
                  }
                ]
              }
            ]
          }
        }

  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  procedure proc_plat_ins_counts(p_request IN CLOB, x_response OUT CLOB) is
    v_request     json;
    v_response    pl_json := pl_json;
    v_sys_code_ls json_list;
    v_ls          json_list;
    v_state_ls    json_list;
    v_date_format varchar2(30);
    v_value_code  varchar2(30);
    v_start_date  varchar2(30);
    v_end_date    varchar2(30);
    v_item        pl_json;
    v_state_item  pl_json;
    v_state_name  varchar2(30);
    v_system_id   dfnd_app.system_id%TYPE;
    v_system_code dfnd_app.system_code%TYPE;
    v_system_name dfnd_app.system_name%TYPE;
    v_count       number;
    v_state       varchar2(30);
    v_state_str   varchar2(300);
  begin
    v_request     := json(p_request, 'OBJECT');
    v_sys_code_ls := json_list(v_request.path('systemCode'));
    v_state_ls    := json_list(v_request.path('state'));
    if v_sys_code_ls.count = 0 then
      v_ls := json_dyn.executeList('select t.system_code from dfnd_app t
 where t.status = ''Y''');
      for v_i in 1 .. v_ls.count loop
        v_sys_code_ls.append(json(v_ls.get(v_i)).get_string('SYSTEM_CODE'));
        dbms_output.put_line(json(v_ls.get(v_i)).get_string('SYSTEM_CODE'));
      end loop;
    end if;
    v_start_date := v_request.get('startDate').get_string;
    v_end_date   := v_request.get('endDate').get_string;
    --获取日期格式
    if v_request.get('date_format') is null then
      v_value_code := 'default';
    else
      v_value_code := v_request.get('date_format').get_string;
    end if;
    begin
      v_date_format := func_get_data_value('oracle_date_format',
                                           v_value_code);
    exception
      when others then
        v_response.fail('查询日期格式值出错，请稍后再试');
        x_response := v_response.to_json;
        return;
    end;
    --检查日期格式
    if func_check_date(v_start_date, v_end_date, v_date_format) then
      --循环系统
      for i in 1 .. v_sys_code_ls.count loop
        select max(t.system_id), max(t.system_code), max(t.system_name)
          into v_system_id, v_system_code, v_system_name
          from dfnd_app t
         where t.status = 'Y'
           and t.system_code = v_sys_code_ls.get(i).get_string;
        if v_system_id is not null then
          v_item := pl_json;
          v_item.set_value('systemId', v_system_id);
          v_item.set_value('systemCode', v_system_code);
          v_item.set_value('systemName', v_system_name);
          --循环状态
          if v_state_ls is null or v_state_ls.count <= 0 then
            v_state_ls.append('completed');
            v_state_ls.append('runing');
            v_state_ls.append('error');
          end if;
          for j in 1 .. v_state_ls.count loop
            v_state := v_state_ls.get(j).get_string;
            if v_state = 'runing' then
              v_state_str := 'and t.state = 1';
            elsif v_state = 'completed' then
              v_state_str := 'and t.state = 5';
            else
              v_state_str := 'and t.state not in (1,5)';
            end if;
            begin
              execute immediate 'select count(1) from dbpm_ba_process_instance t
           where t.system_code = :0
             ' || v_state_str || '
             and t.creation_date between
                 to_date(:1, :2) and
                 to_date(:3, :4)
           group by t.system_code'
                into v_count
                using v_sys_code_ls.get(i).get_string, v_start_date, v_date_format, v_end_date, v_date_format;
            exception
              when NO_DATA_FOUND then
                v_count := 0;
            end;
            v_state_item := pl_json;
            v_state_item.set_value('code', v_state_ls.get(j).get_string);
            if v_state_ls.get(j).get_string = 'runing' then
              v_state_name := '正在运行';
            elsif v_state_ls.get(j).get_string = 'completed' then
              v_state_name := '已完成';
            elsif v_state_ls.get(j).get_string = 'error' then
              v_state_name := '异常';
            end if;
            v_state_item.set_value('name', v_state_name);
            v_state_item.set_value('count', v_count);
            v_item.add_list_item('instanceCounts', v_state_item);
          end loop;
          v_response.add_list_item('systems', v_item);
        end if;
      end loop;
    else
      v_response.fail('非法日期格式，请重新输入');
    end if;
    x_response := v_response.to_json;
    /*exception
    when others then
      v_response.fail('获取数据失败，请稍后再试');
      x_response := v_response.to_json;*/
  end proc_plat_ins_counts;

  /*==================================================
  Procedure/Function Name :
      proc_plat_ins_counts_group
  Description:
      This function perform:
      获取单个系统在时间区间内的实例数量
      1. 如果选择小时，则维度取小时，传入时间段是某一天
      2. 如果选择天，则维度取天，传入时间段是多少天
      3. 如果选择周，则维度按周，传入时间段是多少天，每周一到周日算一周
      4、如果选择月，则按月统计，每月1号到月底

  Argument:
     p_request      请求json
      {
          "user": "weblogic",
          "data":
          {
              "systemCode": "HMQM",
              "state": ["completed", "runing", "error"],
              "group": "day",
              "startDate": "2017-12-01",
              "endDate": "2018-12-01"
          }

      }
     x_response     响应json
          {
            "code": "SUCCESS",
            "data": {
              "dimensionName": "月",
              "dimensionCode": "mon",
              "dimensionValues": [{
                  "dimensionValue": "1",
                  "instanceCount": [{
                      "code": "completed",
                      "count": 1000
                    }, {
                      "code": "runing",
                      "count": 1000
                    }, {
                      "code": "error",
                      "count": 1000
                    }
                  ]
                }, {
                  "dimensionValue": "2",
                  "instanceCount": [{
                      "code": "completed",
                      "count": 1000
                    }, {
                      "code": "runing",
                      "count": 1000
                    }, {
                      "code": "error",
                      "count": 1000
                    }
                  ]
                }
              ]
            }
          }
  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  procedure proc_plat_ins_counts_group(p_request  IN CLOB,
                                       x_response OUT CLOB) IS
    v_request     json;
    v_response    pl_json := pl_json;
    v_state_ls    json_list;
    v_group       varchar2(30);
    v_group_ls    json_list;
    v_group_obj   json;
    v_date_format varchar2(30);
    v_value_code  varchar2(30);
    v_start_date  varchar2(30);
    v_end_date    varchar2(30);
    v_item        pl_json;
    v_state_item  pl_json;
    v_state_name  varchar2(30);
    v_system_id   dfnd_app.system_id%TYPE;
    v_system_code dfnd_app.system_code%TYPE;
    v_system_name dfnd_app.system_name%TYPE;
    v_count       number;
    v_state       varchar2(30);
    v_state_str   varchar2(1000);
  begin
    v_request     := json(p_request, 'OBJECT');
    v_state_ls    := json_list(v_request.path('state'));
    v_system_code := v_request.get('systemCode').get_string;
    v_group       := v_request.get('group').get_string;
    if v_system_code is null then
      v_response.fail('系统编号为空，请重新输入');
      x_response := v_response.to_json;
      return;
    end if;
    v_start_date := v_request.get('startDate').get_string;
    v_end_date   := v_request.get('endDate').get_string;
    --获取日期格式
    if v_request.get('date_format') is null then
      v_value_code := 'default';
    else
      v_value_code := v_request.get('date_format').get_string;
    end if;
    begin
      v_date_format := func_get_data_value('oracle_date_format',
                                           v_value_code);
    exception
      when others then
        v_response.fail('查询日期格式值出错，请稍后再试');
        x_response := v_response.to_json;
        return;
    end;
    --检查日期格式
    if func_check_date(v_start_date, v_end_date, v_date_format) then
      select t.system_id, t.system_code, t.system_name
        into v_system_id, v_system_code, v_system_name
        from dfnd_app t
       where t.status = 'Y'
         and t.system_code = v_system_code;
      v_response.set_value('systemId', v_system_id);
      v_response.set_value('systemCode', v_system_code);
      v_response.set_value('systemName', v_system_name);
      v_response.set_value('dimensionName',
                           func_get_data_value('date_groups', v_group));
      v_response.set_value('dimensionCode', v_group);
      v_group_ls := func_get_date_group(v_group,
                                        v_start_date,
                                        v_end_date,
                                        v_date_format);

      --循环组
      for i in 1 .. v_group_ls.count loop
        v_item      := pl_json;
        v_group_obj := json(v_group_ls.get(i));
        v_item.set_value('dimensionValue', v_group_obj.get_string('name'));
        --循环状态
        if v_state_ls is null or v_state_ls.count <= 0 then
          v_state_ls.append('completed');
          v_state_ls.append('runing');
          v_state_ls.append('error');
        end if;
        for i in 1 .. v_state_ls.count loop
          v_state := v_state_ls.get(i).get_string;
          if v_state = 'runing' then
            v_state_str := 'and t.state = 1';
          elsif v_state = 'completed' then
            v_state_str := 'and t.state = 5';
          else
            v_state_str := 'and t.state not in (1,5)';
          end if;
          begin
            execute immediate 'select count(1)
            from dbpm_ba_process_instance t
           where t.system_code = :0
             ' || v_state_str || '
             and t.creation_date >= to_date(:1,:2) and t.creation_date < to_date(:3,:4)'
              into v_count
              using v_system_code, v_group_obj.get_string('startDate'), v_date_format, v_group_obj.get_string('endDate'), v_date_format;
          exception
            when NO_DATA_FOUND then
              v_count := 0;
          end;
          v_state_item := pl_json;
          v_state_item.set_value('code', v_state_ls.get(i).get_string);
          if v_state_ls.get(i).get_string = 'runing' then
            v_state_name := '正在运行';
          elsif v_state_ls.get(i).get_string = 'completed' then
            v_state_name := '已完成';
          elsif v_state_ls.get(i).get_string = 'error' then
            v_state_name := '异常';
          end if;
          v_state_item.set_value('name', v_state_name);
          v_state_item.set_value('count', v_count);
          v_item.add_list_item('instanceCounts', v_state_item);
        end loop;
        v_response.add_list_item('dimensionValues', v_item);
      end loop;
    else
      v_response.fail('非法日期格式，请重新输入');
    end if;
    x_response := v_response.to_json;
    /*exception
    when others then
      v_response.fail('获取数据失败，请稍后再试');
      x_response := v_response.to_json;*/
  end proc_plat_ins_counts_group;

  /*==================================================
  Procedure/Function Name :
      proc_plat_systems
  Description:
      This function perform:
      获取系统的详细信息
      1. 如果传空，表示获取所有的系统
      2.支持批量查询

  Argument:
     p_request      请求json
        {
            "user": "weblogic",
            "data":
            {
                "systemCode": ["HMQM"],
                "status": "Y",
                "pageNo": 1,
                "size": 10
            }

        }
     x_response     响应json
        {
          "code": "SUCCESS",
          "data": {
            "systems": [{
                "systemId": 1001,
                "systemCode": "HMQM",
                "systemName": "HMQM",
                "industry": "690",
                "systemDesc": "",
                "status": "N",
                "creationDate": "2017-12-29",
                "createdBy": "weblogic",
                "updateDate": "2017-12-29",
                "updatedBy": "weblogic",
              }, {
                "systemId": 1001,
                "systemCode": "HMQM",
                "systemName": "HMQM",
                "industry": "690",
                "systemDesc": "",
                "status": "Y",
                "creationDate": "2017-12-29",
                "createdBy": "weblogic",
                "updateDate": "2017-12-29",
                "updatedBy": "weblogic",
              }
            ],
            "total": "10",
            "pageNo": "-1"
          }
        }
  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  procedure proc_plat_systems(p_request IN CLOB, x_response OUT CLOB) is
    v_request       json;
    v_response      pl_json := pl_json;
    v_item          pl_json;
    v_sys_code_ls   json_list;
    v_str           varchar2(4000);
    v_sys_str       varchar2(4000);
    v_page_str      varchar2(100);
    v_system_cur    refcur;
    v_page_no       number;
    v_size          number;
    v_system_id     dfnd_app.system_id%TYPE;
    v_system_code   dfnd_app.system_code%TYPE;
    v_system_name   dfnd_app.system_name%TYPE;
    v_industry      dfnd_app.industry%TYPE;
    v_system_desc   dfnd_app.system_desc%TYPE;
    v_status        dfnd_app.status%TYPE;
    v_creation_date varchar2(30);
    v_created_by    dfnd_app.created_by%TYPE;
    v_update_date   varchar2(30);
    v_updated_by    dfnd_app.updated_by%TYPE;
    v_total         number;
    v_rn            number;
    v_total_str     varchar2(1000);
  begin
    v_request     := json(p_request, 'OBJECT');
    v_sys_code_ls := json_list(v_request.get('systemCode'));
    v_status      := v_request.get('status').get_string;
    v_page_no     := v_request.get('pageNo').get_number;
    v_size        := v_request.get('size').get_number;
    --非空判断
    if v_status is not null and v_page_no is not null and
       v_size is not null then
      --systemCode为null或者空集合表示查询全部
      if v_sys_code_ls is not null and v_sys_code_ls.count > 0 then
        v_sys_str := 't.system_code in (select system
  from table(pljson_table.json_table(''' || p_request || ''',
                                     pljson_varray(''data.systemCode''),
                                     pljson_varray(''system''))))';
        dbms_output.put_line(v_sys_str);
        v_total_str := 'select count(1) from dfnd_app t where ' ||
                       v_sys_str || ' and t.status = :0';
        execute immediate v_total_str
          into v_total
          using v_status;
      else
        v_sys_str := '1 = 1';
        select count(1) into v_total from dfnd_app t;
      end if;
      --v_size为-1表示查询所有的
      if v_size <> -1 then
        v_page_str := 'rownum <= ' || v_page_no || ' * ' || v_size;
      else
        v_page_str := '1 = 1';
      end if;
      v_str := 'select x.system_id,x.system_code,x.system_name,x.system_desc,x.status,x.creation_date,x.created_by,x.update_date,x.updated_by,x.industry,x.rn
  from (select t.system_id,
               t.system_code,
               t.system_name,
               t.system_desc,
               t.status,
               to_char(t.creation_date,''yyyy-mm-dd hh24:mi:ss'') creation_date,
               t.created_by,
               to_char(t.update_date,''yyyy-mm-dd hh24:mi:ss'') update_date,
               t.updated_by,
               t.industry,
               rownum as rn
          from dfnd_app t
         where ' || v_sys_str || '
           and ' || v_page_str || '
           and t.status = :0) x
 where rn > (:1 - 1) * :2';
      dbms_output.put_line(v_str);
      open v_system_cur for v_str
        using v_status, v_page_no, v_size;
      loop
        fetch v_system_cur
          into v_system_id,
               v_system_code,
               v_system_name,
               v_system_desc,
               v_status,
               v_creation_date,
               v_created_by,
               v_update_date,
               v_updated_by,
               v_industry,
               v_rn;
        exit when v_system_cur%notfound;
        v_item := pl_json;
        v_item.set_value('systemId', v_system_id);
        v_item.set_value('systemCode', v_system_code);
        v_item.set_value('systemName', v_system_name);
        v_item.set_value('industry', v_industry);
        v_item.set_value('systemDesc', v_system_desc);
        v_item.set_value('status', v_status);
        v_item.set_value('creationDate', v_creation_date);
        v_item.set_value('createdBy', v_created_by);
        v_item.set_value('updateDate', v_update_date);
        v_item.set_value('updatedBy', v_updated_by);
        v_item.set_value('rn', v_rn);
        v_response.add_list_item('systems', v_item);
      end loop;
      close v_system_cur;
      v_response.set_value('total', v_total);
      v_response.set_value('pageNo', v_page_no);
    else
      v_response.fail('参数不能为空，请重新输入');
    end if;
    x_response := v_response.to_json;
  end proc_plat_systems;

  /*==================================================
  Procedure/Function Name :
      proc_index_ins_counts_group
  Description:
      This function perform:
      主界面获取实例趋势

  Argument:
     p_request      请求json
      {
          "user": "weblogic",
          "data":
          {
              "systemCode": "",
              "state": ["completed", "runing", "error"]
              "startDate": "2017-12-01",
              "endDate": "2018-01-01"
          }
      }
     x_response     响应json

  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  procedure proc_index_ins_counts_group(p_request  IN CLOB,
                                        x_response OUT CLOB) is
    v_request     json;
    v_response    pl_json := pl_json;
    v_state_ls    json_list;
    v_group       varchar2(30);
    v_group_ls    json_list;
    v_group_obj   json;
    v_date_format varchar2(30);
    v_value_code  varchar2(30);
    v_start_date  varchar2(30);
    v_end_date    varchar2(30);
    v_item        pl_json;
    v_state_item  pl_json;
    v_state_name  varchar2(30);
    v_user        varchar2(300);
    v_system_code dfnd_app.system_code%TYPE;
    v_count       number;
    v_state       varchar2(30);
    v_state_str   varchar2(1000);
    v_syscode_str varchar2(1000);
    v_role        varchar2(30);
    cursor v_param_value_cur(p_user_code varchar2) is
      select dr.role_code,
             dr.role_name,
             drp.data_source_code,
             t.param_value,
             drp.param_name,
             drm.member_code
        from dbpm_role_member_params t,
             dbpm_role_params        drp,
             dbpm_role_members       drm,
             dbpm_roles              dr
       where t.param_id = drp.param_id
         and t.member_id = drm.member_id
         and drp.role_id = dr.role_id
         and drm.role_id = dr.role_id
         and dr.role_code = 'plat_admin'
         and lower(drm.member_code) = p_user_code;
  begin
    v_request  := json(p_request, 'OBJECT');
    v_state_ls := json_list(v_request.path('state'));
    v_user     := json(p_request).get('user').get_string;
    v_group    := v_request.get('group').get_string;

    v_start_date := v_request.get('startDate').get_string;
    v_end_date   := v_request.get('endDate').get_string;
    --获取日期格式
    if v_request.get('date_format') is null then
      v_value_code := 'default';
    else
      v_value_code := v_request.get('date_format').get_string;
    end if;
    begin
      v_date_format := func_get_data_value('oracle_date_format',
                                           v_value_code);
    exception
      when others then
        v_response.fail('查询日期格式值出错，请稍后再试');
        x_response := v_response.to_json;
        return;
    end;
    --检查日期格式
    if func_check_date(v_start_date, v_end_date, v_date_format) then
      v_response.set_value('dimensionName',
                           func_get_data_value('date_groups', v_group));
      v_response.set_value('dimensionCode', v_group);
      v_group_ls := func_get_date_group(v_group,
                                        v_start_date,
                                        v_end_date,
                                        v_date_format);

      --循环组
      for i in 1 .. v_group_ls.count loop
        v_item      := pl_json;
        v_group_obj := json(v_group_ls.get(i));
        v_item.set_value('dimensionValue', v_group_obj.get_string('name'));
        --循环状态
        if v_state_ls is null or v_state_ls.count <= 0 then
          v_state_ls.append('completed');
          v_state_ls.append('runing');
          v_state_ls.append('error');
        end if;
        for i in 1 .. v_state_ls.count loop
          v_state := v_state_ls.get(i).get_string;
          if v_state = 'runing' then
            v_state_str := 'and t.state = 1';
          elsif v_state = 'completed' then
            v_state_str := 'and t.state = 5';
          else
            v_state_str := 'and t.state not in (1,5)';
          end if;
          --判断角色
          for v_row in v_param_value_cur(v_user) loop
            if v_row.data_source_code = 'admin_type' then
              v_role := v_row.param_value;
            end if;
            if v_row.data_source_code = 'DbpmSysCode' then
              v_system_code := v_row.param_value;
            end if;
          end loop;
          if v_system_code is not null and v_system_code <> 'ALL' then
            v_syscode_str := 't.system_code = ''' || v_system_code || '''';
          else
            v_syscode_str := '1 = 1';
          end if;
          begin
            execute immediate 'select count(1)
            from dbpm_ba_process_instance t
           where ' || v_syscode_str || '
             ' || v_state_str || '
             and t.creation_date >= to_date(:1,:2) and t.creation_date < to_date(:3,:4)'
              into v_count
              using v_group_obj.get_string('startDate'), v_date_format, v_group_obj.get_string('endDate'), v_date_format;
          exception
            when NO_DATA_FOUND then
              v_count := 0;
          end;
          v_state_item := pl_json;
          v_state_item.set_value('code', v_state_ls.get(i).get_string);
          if v_state_ls.get(i).get_string = 'runing' then
            v_state_name := '正在运行';
          elsif v_state_ls.get(i).get_string = 'completed' then
            v_state_name := '已完成';
          elsif v_state_ls.get(i).get_string = 'error' then
            v_state_name := '异常';
          end if;
          v_state_item.set_value('name', v_state_name);
          v_state_item.set_value('count', v_count);
          v_item.add_list_item('instanceCounts', v_state_item);
        end loop;
        v_response.add_list_item('dimensionValues', v_item);
      end loop;
    else
      v_response.fail('非法日期格式，请重新输入');
    end if;
    x_response := v_response.to_json;
    /*exception
    when others then
      v_response.fail('获取数据失败，请稍后再试');
      x_response := v_response.to_json;*/
  end proc_index_ins_counts_group;

  /*==================================================
  Procedure/Function Name :
      proc_system_ins_counts
  Description:
      This function perform:
      获取单个系统的实例数量

  Argument:
     p_request      请求json
          {
              "user": "weblogic",
              "data":
              {
                  "systemCode": "HMQM",
                  "state": ["completed", "runing", "error"],
                  "startDate": "2017-12-29",
                  "endDate": "2017-12-31"

              }
          }
     x_response     响应json
                {
                  "code": "SUCCESS",
                  "data": {
                      "systemId": 12,
                      "systemCode": "SCI",
                      "systemName": "SCI",
                      "processes": [
                          {
                              "processCode": "王子",
                              "processName": "null",
                              "instanceCount": [
                                  {
                                      "code": "completed",
                                      "count": 0
                                  },
                                  {
                                      "code": "runing",
                                      "count": 0
                                  },
                                  {
                                      "code": "error",
                                      "count": 0
                                  }
                              ]
                          },
                          {
                              "processCode": "FQRP_KT",
                              "processName": "null",
                              "instanceCount": [
                                  {
                                      "code": "completed",
                                      "count": 0
                                  },
                                  {
                                      "code": "runing",
                                      "count": 18
                                  },
                                  {
                                      "code": "error",
                                      "count": 1
                                  }
                              ]
                          }
                      ]
                  }
              }

  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  procedure proc_system_ins_counts(p_request IN CLOB, x_response OUT CLOB) IS
    v_request     json;
    v_response    pl_json := pl_json;
    v_system_code varchar2(30);
    v_state_ls    json_list;
    v_date_format varchar2(30);
    v_value_code  varchar2(30);
    v_start_date  varchar2(30);
    v_end_date    varchar2(30);
    v_item        pl_json;
    v_state_item  pl_json;
    v_state_name  varchar2(30);
    v_user        varchar2(300);
    v_role        varchar2(30);
    v_au_sys_code varchar2(30);
    v_system_id   number;
    v_state       varchar2(30);
    v_state_str   varchar2(1000);
    v_count       number;
    v_system_name dfnd_app.system_name%TYPE;
    cursor v_param_value_cur(p_user_code varchar2) is
      select dr.role_code,
             dr.role_name,
             drp.data_source_code,
             t.param_value,
             drp.param_name,
             drm.member_code
        from dbpm_role_member_params t,
             dbpm_role_params        drp,
             dbpm_role_members       drm,
             dbpm_roles              dr
       where t.param_id = drp.param_id
         and t.member_id = drm.member_id
         and drp.role_id = dr.role_id
         and drm.role_id = dr.role_id
         and dr.role_code = 'plat_admin'
         and lower(drm.member_code) = p_user_code;

    cursor v_process_cur(p_system_code varchar2) is
      select distinct t.process_code,
                      t.process_name,
                      t.system_id,
                      t.system_code
        from dbpm_ba_process t, dbpm_ba_process_instance ins
       where t.process_code = ins.process_code
         and t.system_code = ins.system_code
         and ins.creation_date >= to_date(v_start_date, v_date_format)
         and ins.creation_date < to_date(v_end_date, v_date_format)
         and t.system_code = p_system_code;
  begin
    --获取参数
    v_request     := json(p_request, 'OBJECT');
    v_user        := json(p_request).get('user').get_string;
    v_system_code := v_request.get('systemCode').get_string;
    v_state_ls    := json_list(v_request.get('state'));
    v_start_date  := v_request.get('startDate').get_string;
    v_end_date    := v_request.get('endDate').get_string;
    --获取日期格式
    if v_request.get('date_format') is null then
      v_value_code := 'default';
    else
      v_value_code := v_request.get('date_format').get_string;
    end if;
    begin
      v_date_format := func_get_data_value('oracle_date_format',
                                           v_value_code);
    exception
      when others then
        v_response.fail('查询日期格式值出错，请稍后再试');
        x_response := v_response.to_json;
        return;
    end;
    if func_check_date(v_start_date, v_end_date, v_date_format) then
      --判断角色
      for v_row in v_param_value_cur(v_user) loop
        if v_row.data_source_code = 'admin_type' then
          v_role := v_row.param_value;
        end if;
        if v_row.data_source_code = 'DbpmSysCode' then
          v_au_sys_code := v_row.param_value;
        end if;
      end loop;
      --判断权限
      if (v_role = 'system' and v_system_code <> v_au_sys_code) or
         v_role = 'process' then
        v_response.fail('权限不足！');
        x_response := v_response.to_json;
        return;
      end if;
      --查询系统数据
      begin
        select t.system_id, t.system_code, t.system_name
          into v_system_id, v_system_code, v_system_name
          from dfnd_app t
         where t.system_code = v_system_code
           and t.status = 'Y';
      exception
        when others then
          v_response.fail('系统编号不存在，请重新输入！');
          x_response := v_response.to_json;
          return;
      end;
      v_response.set_value('systemId', v_system_id);
      v_response.set_value('systemCode', nvl(v_system_code, 'null'));
      v_response.set_value('systemName', nvl(v_system_name, 'null'));
      --遍历流程
      for v_process_cur_row in v_process_cur(v_system_code) loop
        v_item := pl_json;
        v_item.set_value('processCode',
                         nvl(v_process_cur_row.process_code, 'null'));
        v_item.set_value('processName',
                         nvl(v_process_cur_row.process_name, 'null'));
        --如果没有传状态，查询全部状态
        if v_state_ls is null or v_state_ls.count <= 0 then
          v_state_ls.append('completed');
          v_state_ls.append('runing');
          v_state_ls.append('error');
        end if;
        --遍历状态
        for i in 1 .. v_state_ls.count loop
          v_state := v_state_ls.get(i).get_string;
          if v_state = 'runing' then
            v_state_str := 'and t.state = 1';
          elsif v_state = 'completed' then
            v_state_str := 'and t.state = 5';
          else
            v_state_str := 'and t.state not in (1,5)';
          end if;
          begin
            execute immediate 'select count(1)
  from dbpm_ba_process_instance t
 where t.system_code = :0 and t.process_code = :1
             ' || v_state_str || '
             and t.creation_date >= to_date(:2,:3) and t.creation_date < to_date(:4,:5)'
              into v_count
              using v_system_code, v_process_cur_row.process_code, v_start_date, v_date_format, v_end_date, v_date_format;
          exception
            when NO_DATA_FOUND then
              v_count := 0;
          end;
          v_state_item := pl_json;
          v_state_item.set_value('code', v_state_ls.get(i).get_string);
          if v_state_ls.get(i).get_string = 'runing' then
            v_state_name := '正在运行';
          elsif v_state_ls.get(i).get_string = 'completed' then
            v_state_name := '已完成';
          elsif v_state_ls.get(i).get_string = 'error' then
            v_state_name := '异常';
          end if;
          v_state_item.set_value('name', v_state_name);
          v_state_item.set_value('count', v_count);
          v_item.add_list_item('instanceCounts', v_state_item);
        end loop;
        v_response.add_list_item('processes', v_item);
      end loop;
    else
      v_response.fail('非法日期格式，请重新输入');
    end if;
    x_response := v_response.to_json;
    /*exception
    when others then
      v_response.fail('获取数据失败，请稍后再试');
      x_response := v_response.to_json;*/
  end proc_system_ins_counts;

  /*==================================================
  Procedure/Function Name :
      proc_system_ins_counts_group
  Description:
      This function perform:
      获取单个系统的实例数量

  Argument:
     p_request      请求json
          {
              "user": "weblogic",
              "data":
              {
                  "systemCode": "HMQM",
                  "state": ["completed", "runing", "error"],
                  "startDate": "2017-12-29",
                  "endDate": "2017-12-31"

              }
          }
     x_response     响应json
                {
                  "code": "SUCCESS",
                  "data": {
                      "systemId": 12,
                      "systemCode": "SCI",
                      "systemName": "SCI",
                      "processes": [
                          {
                              "processCode": "王子",
                              "processName": "null",
                              "instanceCount": [
                                  {
                                      "code": "completed",
                                      "count": 0
                                  },
                                  {
                                      "code": "runing",
                                      "count": 0
                                  },
                                  {
                                      "code": "error",
                                      "count": 0
                                  }
                              ]
                          },
                          {
                              "processCode": "FQRP_KT",
                              "processName": "null",
                              "instanceCount": [
                                  {
                                      "code": "completed",
                                      "count": 0
                                  },
                                  {
                                      "code": "runing",
                                      "count": 18
                                  },
                                  {
                                      "code": "error",
                                      "count": 1
                                  }
                              ]
                          }
                      ]
                  }
              }

  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  procedure proc_system_ins_counts_group(p_request  IN CLOB,
                                         x_response OUT CLOB) is
    v_request      json;
    v_response     pl_json := pl_json;
    v_state_ls     json_list;
    v_group        varchar2(30);
    v_group_ls     json_list;
    v_group_obj    json;
    v_date_format  varchar2(30);
    v_value_code   varchar2(30);
    v_start_date   varchar2(30);
    v_end_date     varchar2(30);
    v_item         pl_json;
    v_state_item   pl_json;
    v_state_name   varchar2(30);
    v_process_code dbpm_ba_process.process_code%TYPE;
    v_process_name dbpm_ba_process.process_name%TYPE;
    v_system_code  dfnd_app.system_code%TYPE;
    v_system_name  dfnd_app.system_name%TYPE;
    v_count        number;
    v_state        varchar2(30);
    v_state_str    varchar2(300);
  begin
    v_request      := json(p_request, 'OBJECT');
    v_state_ls     := json_list(v_request.path('state'));
    v_process_code := v_request.get('processCode').get_string;
    v_group        := v_request.get('group').get_string;
    if v_process_code is null then
      v_response.fail('流程编号为空，请重新输入');
      x_response := v_response.to_json;
      return;
    end if;
    v_start_date := v_request.get('startDate').get_string;
    v_end_date   := v_request.get('endDate').get_string;
    --获取日期格式
    if v_request.get('date_format') is null then
      v_value_code := 'default';
    else
      v_value_code := v_request.get('date_format').get_string;
    end if;
    begin
      v_date_format := func_get_data_value('oracle_date_format',
                                           v_value_code);
    exception
      when others then
        v_response.fail('查询日期格式值出错，请稍后再试');
        x_response := v_response.to_json;
        return;
    end;
    --检查日期格式
    if func_check_date(v_start_date, v_end_date, v_date_format) then
      begin
        select distinct t.process_code,
                        t.process_name,
                        t.system_code,
                        da.system_name
          into v_process_code, v_process_name, v_system_code, v_system_name
          from dbpm_ba_process t, dfnd_app da
         where t.system_id = da.system_id
           and da.status = 'Y'
           and t.process_code = v_process_code;
      exception
        when others then
          v_response.fail('流程编号错误，请重新输入');
          x_response := v_response.to_json;
      end;
      v_response.set_value('processCode', v_process_code);
      v_response.set_value('processName', v_process_name);
      v_response.set_value('systemCode', v_system_code);
      v_response.set_value('systemName', v_system_name);
      v_response.set_value('dimensionName',
                           func_get_data_value('date_groups', v_group));
      v_response.set_value('dimensionCode', v_group);
      v_group_ls := func_get_date_group(v_group,
                                        v_start_date,
                                        v_end_date,
                                        v_date_format);

      --循环组
      for i in 1 .. v_group_ls.count loop
        v_item      := pl_json;
        v_group_obj := json(v_group_ls.get(i));
        v_item.set_value('dimensionValue', v_group_obj.get_string('name'));
        --循环状态
        if v_state_ls is null or v_state_ls.count <= 0 then
          v_state_ls.append('completed');
          v_state_ls.append('runing');
          v_state_ls.append('error');
        end if;
        for i in 1 .. v_state_ls.count loop
          v_state := v_state_ls.get(i).get_string;
          if v_state = 'runing' then
            v_state_str := 'and t.state = 1';
          elsif v_state = 'completed' then
            v_state_str := 'and t.state = 5';
          else
            v_state_str := 'and t.state not in (1,5)';
          end if;
          begin
            execute immediate 'select count(1)
            from dbpm_ba_process_instance t
           where t.process_code = :0
             ' || v_state_str || '
             and t.creation_date >= to_date(:1,:2) and t.creation_date < to_date(:3,:4)'
              into v_count
              using v_process_code, v_group_obj.get_string('startDate'), v_date_format, v_group_obj.get_string('endDate'), v_date_format;
          exception
            when NO_DATA_FOUND then
              v_count := 0;
          end;
          v_state_item := pl_json;
          v_state_item.set_value('code', v_state_ls.get(i).get_string);
          if v_state_ls.get(i).get_string = 'runing' then
            v_state_name := '正在运行';
          elsif v_state_ls.get(i).get_string = 'completed' then
            v_state_name := '已完成';
          elsif v_state_ls.get(i).get_string = 'error' then
            v_state_name := '异常';
          end if;
          v_state_item.set_value('name', v_state_name);
          v_state_item.set_value('count', v_count);
          v_item.add_list_item('instanceCounts', v_state_item);
        end loop;
        v_response.add_list_item('dimensionValues', v_item);
      end loop;
    else
      v_response.fail('非法日期格式，请重新输入');
    end if;
    x_response := v_response.to_json;
    /*exception
    when others then
      v_response.fail('获取数据失败，请稍后再试');
      x_response := v_response.to_json;*/
  end proc_system_ins_counts_group;

  /*==================================================
  Procedure/Function Name :
      proc_system_process_durtime
  Description:
      This function perform:
      获取单个系统的实例数量

  Argument:
     p_request      请求json
          {
              "user": "weblogic",
              "data":
                  {
                      "systemCode": "HMQM",
                      "startDate": "2017-12-01",
                      "endDate": "2017-12-01"
                  }
          }
     x_response     响应json
                {
                    "code": "SUCCESS",
                    "data":
                    {
                        "process": [
                        {
                            "processId": 1001,
                            "processCode": "BI_KT",
                            "processName": "DMC报表权限申请流程",
                            "duringTime": [
                            {
                                "code": "avg",
                                "count": 500
                            },
                            {
                                "code": "max",
                                "count": 1000
                            }]
                        },
                        {
                            "processId": 1001,
                            "processCode": "BI_KT",
                            "processName": "DMC报表权限申请流程",
                            "duringTime": [
                            {
                                "code": "avg",
                                "count": 500
                            },
                            {
                                "code": "max",
                                "count": 1000
                            }]
                        }]
                    }
                }
  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  procedure proc_system_process_durtime(p_request  IN CLOB,
                                        x_response OUT CLOB) is
    v_request     json;
    v_response    pl_json := pl_json;
    v_date_format varchar2(30);
    v_value_code  varchar2(30);
    v_start_date  varchar2(30);
    v_end_date    varchar2(30);
    v_item        pl_json;
    v_json        json := json();
    v_group_ls    json_list := json_list();
    v_group_item  pl_json;
    v_group       varchar2(30);
    v_group_name  varchar2(300);
    v_user        varchar2(300);
    v_role        varchar2(30);
    v_au_sys_code varchar2(30);
    v_system_id   dfnd_app.system_id%TYPE;
    v_system_code dfnd_app.system_code%TYPE;
    v_system_name dfnd_app.system_name%TYPE;
    v_during_time number;
    cursor v_param_value_cur(p_user_code varchar2) is
      select dr.role_code,
             dr.role_name,
             drp.data_source_code,
             t.param_value,
             drp.param_name,
             drm.member_code
        from dbpm_role_member_params t,
             dbpm_role_params        drp,
             dbpm_role_members       drm,
             dbpm_roles              dr
       where t.param_id = drp.param_id
         and t.member_id = drm.member_id
         and drp.role_id = dr.role_id
         and drm.role_id = dr.role_id
         and dr.role_code = 'plat_admin'
         and lower(drm.member_code) = p_user_code;

  cursor v_process_cur(p_system_code varchar2) is
    select distinct t.process_code,
                    t.process_name,
                    t.system_id,
                    t.system_code
      from dbpm_ba_process t, dbpm_ba_process_instance ins
     where t.process_code = ins.process_code
     and t.system_code = ins.system_code
     and ins.modify_date >= to_date(v_start_date, v_date_format)
     and ins.modify_date < to_date(v_end_date, v_date_format)
     and ins.state = 5
     and t.system_code = p_system_code;
  begin
    --获取参数
    v_request     := json(p_request, 'OBJECT');
    v_user        := json(p_request).get('user').get_string;
    v_system_code := v_request.get('systemCode').get_string;
    v_start_date  := v_request.get('startDate').get_string;
    v_end_date    := v_request.get('endDate').get_string;
    --获取日期格式
    if v_request.get('date_format') is null then
      v_value_code := 'default';
    else
      v_value_code := v_request.get('date_format').get_string;
    end if;
    begin
      v_date_format := func_get_data_value('oracle_date_format',
                                           v_value_code);
    exception
      when others then
        v_response.fail('查询日期格式值出错，请稍后再试');
        x_response := v_response.to_json;
        return;
    end;
    if func_check_date(v_start_date, v_end_date, v_date_format) then
      --判断角色
      for v_row in v_param_value_cur(v_user) loop
        if v_row.data_source_code = 'admin_type' then
          v_role := v_row.param_value;
        end if;
        if v_row.data_source_code = 'DbpmSysCode' then
          v_au_sys_code := v_row.param_value;
        end if;
      end loop;
      --判断权限
      if (v_role = 'system' and v_system_code <> v_au_sys_code) or
         v_role = 'process' then
        v_response.fail('权限不足！');
        x_response := v_response.to_json;
        return;
      end if;
      --查询系统数据
      begin
        select t.system_id, t.system_code, t.system_name
          into v_system_id, v_system_code, v_system_name
          from dfnd_app t
         where t.system_code = v_system_code
           and t.status = 'Y';
      exception
        when others then
          v_response.fail('系统编号不存在，请重新输入！');
          x_response := v_response.to_json;
          return;
      end;
      v_response.set_value('systemId', v_system_id);
      v_response.set_value('systemCode', nvl(v_system_code, 'null'));
      v_response.set_value('systemName', nvl(v_system_name, 'null'));
      --遍历流程
      for v_process_cur_row in v_process_cur(v_system_code) loop
        v_item := pl_json;
        v_item.set_value('processCode',
                         nvl(v_process_cur_row.process_code, 'null'));
        v_item.set_value('processName',
                         nvl(v_process_cur_row.process_name, 'null'));
        --如果没有传状态，查询全部状态
        if v_group_ls is null or v_group_ls.count <= 0 then
          v_json.put('name', '最大时间');
          v_json.put('code', 'max');
          v_group_ls.append(v_json.to_json_value);
          v_json.put('name', '平均时间');
          v_json.put('code', 'avg');
          v_group_ls.append(v_json.to_json_value);
        end if;
        --遍历状态
        for i in 1 .. v_group_ls.count loop
          v_json       := json(v_group_ls.get(i));
          v_group      := v_json.get('code').get_string;
          v_group_name := v_json.get('name').get_string;
          begin
            execute immediate 'select round(' || v_group ||
                              '(to_number(to_date(to_char(t.modify_date, ''yyyy-mm-dd hh24:mi:ss''),
                             ''yyyy-mm-dd hh24:mi:ss'') -
                     to_date(to_char(t.creation_date,
                                     ''yyyy-mm-dd hh24:mi:ss''),
                             ''yyyy-mm-dd hh24:mi:ss''))),2) during_time
  from dbpm_ba_process_instance t
 where t.process_code = :0
  and t.state = 5
 and t.modify_date >= to_date(:1,:2)
 and t.modify_date < to_date(:3,:4)'
              into v_during_time
              using v_process_cur_row.process_code, v_start_date, v_date_format, v_end_date, v_date_format;
          exception
            when NO_DATA_FOUND then
              v_during_time := 0;
          end;
          v_group_item := pl_json;
          v_group_item.set_value('code', v_group);
          v_group_item.set_value('name', v_group_name);
          v_group_item.set_value('count', nvl(v_during_time, 0));
          v_item.add_list_item('duringTimes', v_group_item);
        end loop;
        v_response.add_list_item('processes', v_item);
      end loop;
    else
      v_response.fail('非法日期格式，请重新输入');
    end if;
    x_response := v_response.to_json;
    /*exception
    when others then
      v_response.fail('获取数据失败，请稍后再试');
      x_response := v_response.to_json;*/
  end proc_system_process_durtime;

  /*==================================================
  Procedure/Function Name :
      proc_system_duringtime_group
  Description:
      This function perform:
      获取单个系统的实例数量

  Argument:
     p_request      请求json
          {
              "user": "weblogic",
              "data":
                {
                  "processCode":"WEB-KT",
                  "group":"year",
                  "startDate":"2017-12-01",
                  "endDate":"2018-01-25"
                }

          }
     x_response     响应json
              {
                  "code": "SUCCESS",
                  "data": {
                      "processCode": "WEB-KT",
                      "systemId": 12,
                      "systemCode": "SCI",
                      "systemName": "SCI",
                      "dimensionName": "年",
                      "dimensionCode": "year",
                      "dimensionValues": [
                          {
                              "dimensionValue": "2017",
                              "duringTime": [
                                  {
                                      "code": "max",
                                      "name": "最大时间",
                                      "count": 4.99
                                  },
                                  {
                                      "code": "avg",
                                      "name": "平均时间",
                                      "count": 0.15
                                  }
                              ]
                          },
                          {
                              "dimensionValue": "2018",
                              "duringTime": [
                                  {
                                      "code": "max",
                                      "name": "最大时间",
                                      "count": 19.73
                                  },
                                  {
                                      "code": "avg",
                                      "name": "平均时间",
                                      "count": 2.99
                                  }
                              ]
                          }
                      ]
                  }
              }
  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  procedure proc_system_duringtime_group(p_request  IN CLOB,
                                         x_response OUT CLOB) is
    v_request      json;
    v_response     pl_json := pl_json;
    v_group        varchar2(30);
    v_type_ls      json_list := json_list();
    v_type         varchar2(30);
    v_type_name    varchar2(300);
    v_group_ls     json_list := json_list();
    v_group_obj    json;
    v_date_format  varchar2(30);
    v_value_code   varchar2(30);
    v_start_date   varchar2(30);
    v_end_date     varchar2(30);
    v_item         pl_json;
    v_type_item    pl_json;
    v_process_code dbpm_ba_process.process_code%TYPE;
    v_process_name dbpm_ba_process.process_name%TYPE;
    v_system_id    dfnd_app.system_id%TYPE;
    v_system_code  dfnd_app.system_code%TYPE;
    v_system_name  dfnd_app.system_name%TYPE;
    v_json         json := json();
    v_during_time  number;
  begin
    v_request      := json(p_request, 'OBJECT');
    v_process_code := v_request.get('processCode').get_string;
    v_group        := v_request.get('group').get_string;
    --v_type_ls     := json_list(v_request.path('type'));
    if v_process_code is null then
      v_response.fail('流程编号为空，请重新输入');
      x_response := v_response.to_json;
      return;
    end if;
    v_start_date := v_request.get('startDate').get_string;
    v_end_date   := v_request.get('endDate').get_string;
    --获取日期格式
    if v_request.get('date_format') is null then
      v_value_code := 'default';
    else
      v_value_code := v_request.get('date_format').get_string;
    end if;
    begin
      v_date_format := func_get_data_value('oracle_date_format',
                                           v_value_code);
    exception
      when others then
        v_response.fail('查询日期格式值出错，请稍后再试');
        x_response := v_response.to_json;
        return;
    end;
    --检查日期格式
    if func_check_date(v_start_date, v_end_date, v_date_format) then
      begin
        select distinct t.process_code,
                        t.process_name,
                        t.system_id,
                        t.system_code,
                        da.system_name
          into v_process_code,
               v_process_name,
               v_system_id,
               v_system_code,
               v_system_name
          from dbpm_ba_process t, dfnd_app da
         where t.system_id = da.system_id
           and da.status = 'Y'
           and t.process_code = v_process_code;
      exception
        when others then
          v_response.fail('流程编号错误，请重新输入');
          x_response := v_response.to_json;
      end;
      v_response.set_value('processCode', v_process_code);
      v_response.set_value('processName',
                           nvl(v_process_name, v_process_code));
      v_response.set_value('systemCode', v_system_code);
      v_response.set_value('systemName', v_system_name);
      v_response.set_value('dimensionName',
                           func_get_data_value('date_groups', v_group));
      v_response.set_value('dimensionCode', v_group);
      v_group_ls := func_get_date_group(v_group,
                                        v_start_date,
                                        v_end_date,
                                        v_date_format);

      --循环组
      for i in 1 .. v_group_ls.count loop
        v_item      := pl_json;
        v_group_obj := json(v_group_ls.get(i));
        v_item.set_value('dimensionValue', v_group_obj.get_string('name'));
        --默认分组最大时间、平均时间
        if v_type_ls is null or v_type_ls.count <= 0 then
          v_json.put('name', '最大时间');
          v_json.put('code', 'max');
          v_type_ls.append(v_json.to_json_value);
          v_json.put('name', '平均时间');
          v_json.put('code', 'avg');
          v_type_ls.append(v_json.to_json_value);
        end if;
        --遍历类别
        for i in 1 .. v_type_ls.count loop
          v_json      := json(v_type_ls.get(i));
          v_type      := v_json.get('code').get_string;
          v_type_name := v_json.get('name').get_string;
          begin
            execute immediate 'select round(' || v_type ||
                              '(to_number(to_date(to_char(t.modify_date, ''yyyy-mm-dd hh24:mi:ss''),
                             ''yyyy-mm-dd hh24:mi:ss'') -
                     to_date(to_char(t.creation_date,
                                     ''yyyy-mm-dd hh24:mi:ss''),
                             ''yyyy-mm-dd hh24:mi:ss''))),2) during_time
  from dbpm_ba_process_instance t
 where t.process_code = :0
  and t.state = 5
 and t.modify_date >= to_date(:1,:2)
 and t.modify_date < to_date(:3,:4)'
              into v_during_time
              using v_process_code, v_group_obj.get_string('startDate'), v_date_format, v_group_obj.get_string('endDate'), v_date_format;
          exception
            when NO_DATA_FOUND then
              v_during_time := 0;
          end;
          v_type_item := pl_json;
          v_type_item.set_value('code', v_type);
          v_type_item.set_value('name', v_type_name);
          v_type_item.set_value('count', nvl(v_during_time, 0));
          v_item.add_list_item('duringTimes', v_type_item);
        end loop;
        v_response.add_list_item('dimensionValues', v_item);
      end loop;
    else
      v_response.fail('非法日期格式，请重新输入');
    end if;
    x_response := v_response.to_json;
    /*exception
    when others then
      v_response.fail('获取数据失败，请稍后再试');
      x_response := v_response.to_json;*/
  end proc_system_duringtime_group;

  /*==================================================
  Procedure/Function Name :
      proc_system_duringtime_group
  Description:
      This function perform:
      获取流程信息

  Argument:
     p_request      请求json
          {
              "user": "weblogic",
              "data":
                {
                    "systemCode":"GEMS",
                    "queryKey":"dada",
                    "pageNo":1,
                    "size":10
                }

          }
     x_response     响应json

  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  procedure proc_system_query_process(p_request  IN CLOB,
                                      x_response OUT CLOB) is
    v_request     json;
    v_response    pl_json := pl_json;
    v_system_code dfnd_app.system_code%TYPE;
    v_system_name dfnd_app.system_name%TYPE;
    v_query_key   varchar2(300);
    v_total       number;
    v_item        pl_json;
    v_page_no     number;
    v_size        number;
    cursor v_process_cur(p_system_code varchar2,
                         p_query_key   varchar2,
                         p_page_no     number,
                         p_size        number) is
      select x.process_code,
             nvl(x.process_name, x.process_code) process_name,
             x.rn
        from (select tmp.process_code, tmp.process_name, rownum rn
                from (select distinct t.process_code, t.process_name
                        from dbpm_ba_process t
                       where t.system_code = p_system_code
                         and (t.process_code like '%' || p_query_key || '%' or
                             t.process_name like '%' || p_query_key || '%')) tmp) x
       where x.rn > (p_page_no - 1) * p_size
         and x.rn <= p_page_no * p_size;
  begin
    v_request     := json(p_request, 'OBJECT');
    v_system_code := v_request.get('systemCode').get_string;
    v_query_key   := v_request.get('queryKey').get_string;
    v_page_no     := v_request.get('pageNo').get_number;
    v_size        := v_request.get('size').get_number;
    --查询总数
    select count(1)
      into v_total
      from (select distinct t.process_code, t.process_name
              from dbpm_ba_process t
             where t.system_code = v_system_code
               and (t.process_code like '%' || v_query_key || '%' or
                   t.process_name like '%' || v_query_key || '%'));
    --size为-1,pageNo为1查询所有
    if v_size = -1 and v_page_no = 1 then
      v_size := v_total;
    end if;
    if v_system_code is not null then
      select max(t.system_name)
        into v_system_name
        from dfnd_app t
       where t.system_code = v_system_code;
      v_response.set_value('systemCode', v_system_code);
      v_response.set_value('systemName', v_system_name);

      for v_process_cur_row in v_process_cur(v_system_code,
                                             v_query_key,
                                             v_page_no,
                                             v_size) loop
        v_item := pl_json;
        v_item.set_value('seq', v_process_cur_row.rn);
        v_item.set_value('processCode', v_process_cur_row.process_code);
        v_item.set_value('processName',
                         nvl(v_process_cur_row.process_name,
                             v_process_cur_row.process_code));
        v_response.add_list_item('processes', v_item);
      end loop;
      v_response.set_value('total', v_total);
      v_response.set_value('pageNo', v_page_no);
    else
      v_response.fail('systemCode不能为空，请重输入新');
    end if;
    x_response := v_response.to_json;
    /*exception
    when others then
      v_response.fail('获取数据失败，请稍后再试');
      x_response := v_response.to_json;*/
  end proc_system_query_process;

  /*==================================================
  Procedure/Function Name :
      proc_process_act_ins_counts
  Description:
      This function perform:
      获取单个系统的实例数量

  Argument:
     p_request      请求json
          {
            "code": "SUCCESS",
            "data": {
              "processCode": "BI_KT",
              "processName": "DMC报表分析平台",
              "activities": [{
                  "activityCode": "file_up",
                  "activityName": "审核文件上传",
                  "activityType": "task",
                  "instanceCounts": [{
                      "code": "completed",
                      "name": "已完成",
                      "count": 1000
                    }, {
                      "code": "runing",
                      "name": "已完成",
                      "count": 1000
                    }, {
                      "code": "error",
                      "name": "已完成",
                      "count": 1000
                    }
                  ]
                }, {
                  "activityCode": "file_up",
                  "activityName": "审核文件上传",
                  "activityType": "task",
                  "instanceCounts": [{
                      "code": "completed",
                      "name": "已完成",
                      "count": 1000
                    }, {
                      "code": "runing",
                      "name": "已完成",
                      "count": 1000
                    }, {
                      "code": "error",
                      "name": "已完成",
                      "count": 1000
                    }
                  ]
                }
              ]
            }
          }

  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  procedure proc_process_act_ins_counts(p_request  IN CLOB,
                                        x_response OUT CLOB) is
    v_request      json;
    v_response     pl_json := pl_json;
    v_process_code varchar2(30);
    v_system_code  varchar2(300);
    v_process_name varchar2(300);
    v_state_ls     json_list;
    v_date_format  varchar2(30);
    v_value_code   varchar2(30);
    v_start_date   varchar2(30);
    v_end_date     varchar2(30);
    v_item         pl_json;
    v_state_item   pl_json;
    v_state_name   varchar2(30);
    v_user         varchar2(300);
    v_role         varchar2(30);
    v_au_sys_code  varchar2(30);
    v_state        varchar2(30);
    v_state_str    varchar2(1000);
    v_count        number;
    cursor v_param_value_cur(p_user_code varchar2) is
      select dr.role_code,
             dr.role_name,
             drp.data_source_code,
             t.param_value,
             drp.param_name,
             drm.member_code
        from dbpm_role_member_params t,
             dbpm_role_params        drp,
             dbpm_role_members       drm,
             dbpm_roles              dr
       where t.param_id = drp.param_id
         and t.member_id = drm.member_id
         and drp.role_id = dr.role_id
         and drm.role_id = dr.role_id
         and dr.role_code = 'plat_admin'
         and lower(drm.member_code) = p_user_code;

    cursor v_act_cur(p_process_code varchar2, p_system_code varchar2) is
      select distinct t.process_code,
                      t.activity_code,
                      t.activity_type,
                      t.activity_name
        from dbpm_ba_process_activity t, dbpm_ba_process dbp
       where t.process_id = dbp.process_id
         and t.process_code = p_process_code
         and dbp.system_code = p_system_code
         and t.activity_type = 'USER_TASK';
  begin
    --获取参数
    v_request      := json(p_request, 'OBJECT');
    v_user         := json(p_request).get('user').get_string;
    v_process_code := v_request.get('processCode').get_string;
    v_system_code  := v_request.get('systemCode').get_string;
    v_state_ls     := json_list(v_request.get('state'));
    v_start_date   := v_request.get('startDate').get_string;
    v_end_date     := v_request.get('endDate').get_string;
    --获取日期格式
    if v_request.get('date_format') is null then
      v_value_code := 'default';
    else
      v_value_code := v_request.get('date_format').get_string;
    end if;
    begin
      v_date_format := func_get_data_value('oracle_date_format',
                                           v_value_code);
    exception
      when others then
        v_response.fail('查询日期格式值出错，请稍后再试');
        x_response := v_response.to_json;
        return;
    end;
    if func_check_date(v_start_date, v_end_date, v_date_format) then
      --判断角色
      for v_row in v_param_value_cur(v_user) loop
        if v_row.data_source_code = 'admin_type' then
          v_role := v_row.param_value;
        end if;
        if v_row.data_source_code = 'DbpmSysCode' then
          v_au_sys_code := v_row.param_value;
        end if;
      end loop;
      --判断权限
      if (v_role = 'system' and v_system_code <> v_au_sys_code) or
         v_role = 'process' then
        v_response.fail('权限不足！');
        x_response := v_response.to_json;
        return;
      elsif v_role = 'plat' then
        --全平台获取当前流程的系统
        select max(t.system_code)
          into v_au_sys_code
          from dbpm_ba_process t
         where t.process_code = v_process_code;
      end if;
      select count(1)
        into v_count
        from dbpm_ba_process t
       where t.system_code = v_system_code
         and t.process_code = v_process_code;
      if v_count <= 0 then
        v_response.fail('权限不足！');
        x_response := v_response.to_json;
        return;
      end if;
      --查询流程数据
      begin
        select x.process_name
          into v_process_name
          from (select nvl(t.process_name, t.process_code) process_name
                  from dbpm_ba_process t
                 where t.process_code = v_process_code
                 order by t.process_name) x
         where rownum = 1;
      exception
        when others then
          v_response.fail('流程编号不存在，请重新输入！');
          x_response := v_response.to_json;
          return;
      end;
      v_response.set_value('processCode', v_process_code);
      v_response.set_value('processName',
                           nvl(v_process_name, v_process_code));
      --遍历当前流程下的所有活动
      for v_act_cur_row in v_act_cur(v_process_code, v_au_sys_code) loop
        v_item := pl_json;
        v_item.set_value('activityCode', v_act_cur_row.activity_code);
        v_item.set_value('activityName',
                         nvl(v_act_cur_row.activity_name,
                             v_act_cur_row.activity_code));
        v_item.set_value('activityType', v_act_cur_row.activity_type);
        --如果没有传状态，查询全部状态
        if v_state_ls is null or v_state_ls.count <= 0 then
          v_state_ls.append('completed');
          v_state_ls.append('runing');
          v_state_ls.append('error');
        end if;
        --遍历状态
        for i in 1 .. v_state_ls.count loop
          v_state := v_state_ls.get(i).get_string;
          if v_state = 'runing' then
            v_state_str := 'and t.end_time is null and t.fault_type is null';
          elsif v_state = 'completed' then
            v_state_str := 'and t.end_time is not null and t.fault_type is null';
          else
            v_state_str := 'and t.fault_type is not null';
          end if;
          begin
            execute immediate 'select count(1)
  from dbpm_ba_process_instance_act t, dbpm_ba_process dbp
 where t.process_id = dbp.process_id
   and dbp.system_code = :0
   and dbp.process_code = :1
   and t.activity_code = :2
   ' || v_state_str || '
   and t.start_time >= to_date(:3,:4)
   and t.start_time < to_date(:5,:6)'
              into v_count
              using v_au_sys_code, v_process_code, v_act_cur_row.activity_code, v_start_date, v_date_format, v_end_date, v_date_format;
          exception
            when NO_DATA_FOUND then
              v_count := 0;
          end;
          v_state_item := pl_json;
          v_state_item.set_value('code', v_state);
          if v_state_ls.get(i).get_string = 'runing' then
            v_state_name := '正在运行';
          elsif v_state_ls.get(i).get_string = 'completed' then
            v_state_name := '已完成';
          elsif v_state_ls.get(i).get_string = 'error' then
            v_state_name := '异常';
          end if;
          v_state_item.set_value('name', v_state_name);
          v_state_item.set_value('count', v_count);
          v_item.add_list_item('instanceCounts', v_state_item);
        end loop;
        v_response.add_list_item('activities', v_item);
      end loop;
    else
      v_response.fail('非法日期格式，请重新输入');
    end if;
    x_response := v_response.to_json;
    /*exception
    when others then
      v_response.fail('获取数据失败，请稍后再试');
      x_response := v_response.to_json;*/
  end proc_process_act_ins_counts;

  /*==================================================
  Procedure/Function Name :
      proc_process_act_ins_counts
  Description:
      This function perform:
      获取单个系统的实例数量

  Argument:
     p_request      请求json
            {
                "user": "a0017702",
                "data":
                  {
                      "processCode": "BI_KT"
                      "activityCode": "fileUp",
                      "state": ["completed", "runing", "error"],
                      "group": "day",
                      "startDate": "2017-12-01",
                      "endDate": "2018-12-01"
                  }

            }
    p_response      响应json
                {
                  "code": "SUCCESS",
                  "data": {
                    "activityCode": "BI_KT",
                    "activityName": "",
                    "activityType": "DMC",
                    "processCode": "process",
                    "processName": "DMC报表权限申请流程",
                    "dimensionName": "月",
                    "dimensionCode": "mon",
                    "dimensionValues": [{
                      "dimensionValue": "1",
                      "instanceCounts": [{
                        "code": "completed",
                        "name": "已完成",
                        "count": 1000
                      }, {
                        "code": "runing",
                        "name": "进行中",
                        "count": 1000
                      }, {
                        "code": "error",
                        "name": "异常",
                        "count": 1000
                      }]
                    }, {
                      "dimensionValue": "2",
                      "instanceCounts": [{
                        "code": "completed",
                        "name": "已完成",
                        "count": 1000
                      }, {
                        "code": "runing",
                        "name": "进行中",
                        "count": 1000
                      }, {
                        "code": "error",
                        "name": "异常",
                        "count": 1000
                      }]
                    }]
                  }
                }
  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  procedure proc_proact_ins_counts_group(p_request  IN CLOB,
                                         x_response OUT CLOB) is
    v_request       json;
    v_response      pl_json := pl_json;
    v_state_ls      json_list;
    v_group         varchar2(30);
    v_group_ls      json_list;
    v_group_obj     json;
    v_date_format   varchar2(30);
    v_value_code    varchar2(30);
    v_start_date    varchar2(30);
    v_end_date      varchar2(30);
    v_item          pl_json;
    v_state_item    pl_json;
    v_state_name    varchar2(30);
    v_system_code   varchar2(300);
    v_process_code  dbpm_ba_process.process_code%TYPE;
    v_activity_code dbpm_ba_process_activity.activity_code%TYPE;
    v_activity_name dbpm_ba_process_activity.activity_name%TYPE;
    v_activity_type dbpm_ba_process_activity.activity_type%TYPE;
    v_process_name  dbpm_ba_process.process_name%TYPE;
    v_count         number;
    v_state         varchar2(30);
    v_state_str     varchar2(300);
    v_au_sys_code   varchar2(300);
    v_user          varchar2(100);
    v_role          varchar2(100);
    cursor v_param_value_cur(p_user_code varchar2) is
      select dr.role_code,
             dr.role_name,
             drp.data_source_code,
             t.param_value,
             drp.param_name,
             drm.member_code
        from dbpm_role_member_params t,
             dbpm_role_params        drp,
             dbpm_role_members       drm,
             dbpm_roles              dr
       where t.param_id = drp.param_id
         and t.member_id = drm.member_id
         and drp.role_id = dr.role_id
         and drm.role_id = dr.role_id
         and dr.role_code = 'plat_admin'
         and lower(drm.member_code) = p_user_code;
  begin
    v_request       := json(p_request, 'OBJECT');
    v_user          := json(p_request).get('user').get_string;
    v_state_ls      := json_list(v_request.path('state'));
    v_system_code   := v_request.get('systemCode').get_string;
    v_process_code  := v_request.get('processCode').get_string;
    v_activity_code := v_request.get('activityCode').get_string;
    v_group         := v_request.get('group').get_string;
    if v_process_code is null then
      v_response.fail('流程编号为空，请重新输入');
      x_response := v_response.to_json;
      return;
    end if;
    v_start_date := v_request.get('startDate').get_string;
    v_end_date   := v_request.get('endDate').get_string;
    --获取日期格式
    if v_request.get('date_format') is null then
      v_value_code := 'default';
    else
      v_value_code := v_request.get('date_format').get_string;
    end if;
    begin
      v_date_format := func_get_data_value('oracle_date_format',
                                           v_value_code);
    exception
      when others then
        v_response.fail('查询日期格式值出错，请稍后再试');
        x_response := v_response.to_json;
        return;
    end;
    --检查日期格式
    if func_check_date(v_start_date, v_end_date, v_date_format) then
      --判断角色
      for v_row in v_param_value_cur(v_user) loop
        if v_row.data_source_code = 'admin_type' then
          v_role := v_row.param_value;
        end if;
        if v_row.data_source_code = 'DbpmSysCode' then
          v_au_sys_code := v_row.param_value;
        end if;
      end loop;
      --判断权限
      if (v_role = 'system' and v_system_code <> v_au_sys_code) or
         v_role = 'process' then
        v_response.fail('权限不足！');
        x_response := v_response.to_json;
        return;
      elsif v_role = 'plat' then
        --全平台获取当前流程的系统
        select max(t.system_code)
          into v_au_sys_code
          from dbpm_ba_process t
         where t.process_code = v_process_code;
      end if;
      select count(1)
        into v_count
        from dbpm_ba_process_activity t, dbpm_ba_process dbp
       where t.process_id = dbp.process_id
         and dbp.system_code = v_system_code
         and t.process_code = v_process_code
         and t.activity_code = v_activity_code;
      if v_count <= 0 then
        v_response.fail('权限不足！');
        x_response := v_response.to_json;
        return;
      end if;
      begin
        select distinct t.activity_name, t.activity_type, dbp.process_name
          into v_activity_name, v_activity_type, v_process_name
          from dbpm_ba_process_activity t, dbpm_ba_process dbp
         where t.process_id = dbp.process_id
           and t.process_code = v_process_code
           and t.activity_code = v_activity_code
           and dbp.system_code = v_system_code;
      exception
        when others then
          v_response.fail('活动编号错误，请重新输入');
          x_response := v_response.to_json;
      end;
      v_response.set_value('activityCode', v_activity_code);
      v_response.set_value('activityName', v_activity_name);
      v_response.set_value('activityType', v_activity_type);
      v_response.set_value('processCode', v_process_code);
      v_response.set_value('processName', v_process_name);
      v_response.set_value('dimensionName',
                           func_get_data_value('date_groups', v_group));
      v_response.set_value('dimensionCode', v_group);
      v_group_ls := func_get_date_group(v_group,
                                        v_start_date,
                                        v_end_date,
                                        v_date_format);

      --循环组
      for i in 1 .. v_group_ls.count loop
        v_item      := pl_json;
        v_group_obj := json(v_group_ls.get(i));
        v_item.set_value('dimensionValue', v_group_obj.get_string('name'));
        --循环状态
        if v_state_ls is null or v_state_ls.count <= 0 then
          v_state_ls.append('completed');
          v_state_ls.append('runing');
          v_state_ls.append('error');
        end if;
        for i in 1 .. v_state_ls.count loop
          v_state := v_state_ls.get(i).get_string;
          if v_state = 'runing' then
            v_state_str := 'and t.end_time is null and t.fault_type is null';
          elsif v_state = 'completed' then
            v_state_str := 'and t.end_time is not null and t.fault_type is null';
          else
            v_state_str := 'and t.fault_type is not null';
          end if;
          begin
            execute immediate 'select count(1)
  from dbpm_ba_process_instance_act t, dbpm_ba_process dbp
 where t.process_id = dbp.process_id
   and dbp.system_code = :0
   and dbp.process_code = :1
   and t.activity_code = :2
   ' || v_state_str || '
   and t.start_time >= to_date(:3,:4)
   and t.start_time < to_date(:5,:6)'
              into v_count
              using v_system_code, v_process_code, v_activity_code, v_group_obj.get_string('startDate'), v_date_format, v_group_obj.get_string('endDate'), v_date_format;
          exception
            when NO_DATA_FOUND then
              v_count := 0;
          end;
          v_state_item := pl_json;
          v_state_item.set_value('code', v_state_ls.get(i).get_string);
          if v_state_ls.get(i).get_string = 'runing' then
            v_state_name := '正在运行';
          elsif v_state_ls.get(i).get_string = 'completed' then
            v_state_name := '已完成';
          elsif v_state_ls.get(i).get_string = 'error' then
            v_state_name := '异常';
          end if;
          v_state_item.set_value('name', v_state_name);
          v_state_item.set_value('count', v_count);
          v_item.add_list_item('instanceCounts', v_state_item);
        end loop;
        v_response.add_list_item('dimensionValues', v_item);
      end loop;
    else
      v_response.fail('非法日期格式，请重新输入');
    end if;
    x_response := v_response.to_json;
    /*exception
    when others then
      v_response.fail('获取数据失败，请稍后再试');
      x_response := v_response.to_json;*/
  end proc_proact_ins_counts_group;

  /*==================================================
  Procedure/Function Name :
      proc_process_act_duringtime
  Description:
      This function perform:
      获取单个系统的实例数量

  Argument:
     p_request      请求json
            {
                "user": "a0017702",
                "data":
                  {
                      "processCode": "BI_KT",
                      "startDate": "2017-12-29",
                      "endDate": "2017-12-31"
                  }
            }
    p_response      响应json
              {
                "code": "SUCCESS",
                "data": {
                  "processCode": "test",
                  "processName": "dada",
                  "activities": [{
                      "activityName": "审批文件上传",
                      "activityType": "task",
                      "duringTime": [{
                          "code": "avg",
                          "count": 1000
                        },
                        {
                          "code": "max",
                          "count": 1000
                        }
                      ]
                    },
                    {
                      "activityName": "审批文件上传",
                      "activityType": "task",
                      "duringTime": [{
                          "code": "avg",
                          "count": 1000
                        },
                        {
                          "code": "max",
                          "count": 1000
                        }
                      ]
                    }
                  ]
                }
              }
  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  procedure proc_process_act_duringtime(p_request  IN CLOB,
                                        x_response OUT CLOB) is
    v_request      json;
    v_response     pl_json := pl_json;
    v_date_format  varchar2(30);
    v_value_code   varchar2(30);
    v_start_date   varchar2(30);
    v_end_date     varchar2(30);
    v_item         pl_json;
    v_json         json := json();
    v_group_ls     json_list := json_list();
    v_group_item   pl_json;
    v_group        varchar2(30);
    v_group_name   varchar2(300);
    v_user         varchar2(300);
    v_role         varchar2(30);
    v_au_sys_code  varchar2(30);
    v_process_code dbpm_ba_process.process_code%TYPE;
    v_process_name dbpm_ba_process.process_name%TYPE;
    v_system_code  dfnd_app.system_code%TYPE;
    v_during_time  number;
    v_count        number;
    cursor v_param_value_cur(p_user_code varchar2) is
      select dr.role_code,
             dr.role_name,
             drp.data_source_code,
             t.param_value,
             drp.param_name,
             drm.member_code
        from dbpm_role_member_params t,
             dbpm_role_params        drp,
             dbpm_role_members       drm,
             dbpm_roles              dr
       where t.param_id = drp.param_id
         and t.member_id = drm.member_id
         and drp.role_id = dr.role_id
         and drm.role_id = dr.role_id
         and dr.role_code = 'plat_admin'
         and lower(drm.member_code) = p_user_code;

    cursor v_act_cur(p_process_code varchar2, p_system_code varchar2) is
      select distinct t.activity_code, t.activity_type, t.activity_name
        from dbpm_ba_process_activity t, dbpm_ba_process dbp
       where t.process_id = dbp.process_id
         and t.process_code = p_process_code
         and dbp.system_code = p_system_code
         and t.activity_type = 'USER_TASK';
  begin
    --获取参数
    v_request      := json(p_request, 'OBJECT');
    v_user         := json(p_request).get('user').get_string;
    v_process_code := v_request.get('processCode').get_string;
    v_system_code  := v_request.get('systemCode').get_string;
    v_start_date   := v_request.get('startDate').get_string;
    v_end_date     := v_request.get('endDate').get_string;
    --获取日期格式
    if v_request.get('date_format') is null then
      v_value_code := 'default';
    else
      v_value_code := v_request.get('date_format').get_string;
    end if;
    begin
      v_date_format := func_get_data_value('oracle_date_format',
                                           v_value_code);
    exception
      when others then
        v_response.fail('查询日期格式值出错，请稍后再试');
        x_response := v_response.to_json;
        return;
    end;
    if func_check_date(v_start_date, v_end_date, v_date_format) then
      --判断角色
      for v_row in v_param_value_cur(v_user) loop
        if v_row.data_source_code = 'admin_type' then
          v_role := v_row.param_value;
        end if;
        if v_row.data_source_code = 'DbpmSysCode' then
          v_au_sys_code := v_row.param_value;
        end if;
      end loop;

      --判断权限
      if (v_role = 'system' and v_system_code <> v_au_sys_code) or
         v_role = 'process' then
        v_response.fail('权限不足！');
        x_response := v_response.to_json;
        return;
      elsif v_role = 'plat' then
        --全平台获取当前流程的系统
        select max(t.system_code)
          into v_au_sys_code
          from dbpm_ba_process t
         where t.process_code = v_process_code;
      end if;
      select count(1)
        into v_count
        from dbpm_ba_process t
       where t.system_code = v_system_code
         and t.process_code = v_process_code;
      if v_count <= 0 then
        v_response.fail('权限不足！');
        x_response := v_response.to_json;
        return;
      end if;
      --查询流程数据
      begin
        select x.process_name
          into v_process_name
          from (select nvl(t.process_name, t.process_code) process_name
                  from dbpm_ba_process t
                 where t.process_code = v_process_code
                 order by t.process_name) x
         where rownum = 1;
      exception
        when others then
          v_response.fail('流程编号不存在，请重新输入！');
          x_response := v_response.to_json;
          return;
      end;
      v_response.set_value('processCode', v_process_code);
      v_response.set_value('processName',
                           nvl(v_process_name, v_process_code));
      --遍历流程活动
      for v_act_cur_row in v_act_cur(v_process_code, v_au_sys_code) loop
        v_item := pl_json;
        v_item.set_value('activityCode', v_act_cur_row.activity_code);
        v_item.set_value('activityName',
                         nvl(v_act_cur_row.activity_name,
                             v_act_cur_row.activity_code));
        v_item.set_value('activityType', v_act_cur_row.activity_type);
        --如果没有传状态，查询全部状态
        if v_group_ls is null or v_group_ls.count <= 0 then
          v_json.put('name', '最大时间');
          v_json.put('code', 'max');
          v_group_ls.append(v_json.to_json_value);
          v_json.put('name', '平均时间');
          v_json.put('code', 'avg');
          v_group_ls.append(v_json.to_json_value);
        end if;
        --遍历状态
        for i in 1 .. v_group_ls.count loop
          v_json       := json(v_group_ls.get(i));
          v_group      := v_json.get('code').get_string;
          v_group_name := v_json.get('name').get_string;
          begin
            execute immediate 'select round(' || v_group ||
                              '(to_number(to_date(to_char(t.end_time, ''yyyy-mm-dd hh24:mi:ss''),
                             ''yyyy-mm-dd hh24:mi:ss'') -
                     to_date(to_char(t.start_time,
                                     ''yyyy-mm-dd hh24:mi:ss''),
                             ''yyyy-mm-dd hh24:mi:ss''))),2) during_time
  from dbpm_ba_process_instance_act t,dbpm_ba_process dbp
 where t.process_id = dbp.process_id
   and dbp.system_code = :0
   and dbp.process_code = :1
   and t.activity_code = :2
   and t.end_time >= to_date(:3,:4)
   and t.end_time < to_date(:5,:6)
   and t.end_time is not null
   group by system_code,process_code,activity_code'
              into v_during_time
              using v_au_sys_code, v_process_code, v_act_cur_row.activity_code, v_start_date, v_date_format, v_end_date, v_date_format;
          exception
            when NO_DATA_FOUND then
              v_during_time := 0;
          end;
          v_group_item := pl_json;
          v_group_item.set_value('code', v_group);
          v_group_item.set_value('name', v_group_name);
          v_group_item.set_value('count', nvl(v_during_time, 0));
          v_item.add_list_item('duringTimes', v_group_item);
        end loop;
        v_response.add_list_item('activities', v_item);
      end loop;
    else
      v_response.fail('非法日期格式，请重新输入');
    end if;
    x_response := v_response.to_json;
    /*exception
    when others then
      v_response.fail('获取数据失败，请稍后再试');
      x_response := v_response.to_json;*/
  end proc_process_act_duringtime;

  /*==================================================
  Procedure/Function Name :
      proc_process_act_dur_group
  Description:
      This function perform:
      获取单个系统的实例数量

  Argument:
     p_request      请求json
            {
                "user": "a0017702",
                "data":
                  {
                      "systemCode": "cccc"
                      "processCode": "BI_KT"
                      "activityCode": "fileUp",
                      "group": "day",
                      "startDate": "2017-12-01",
                      "endDate": "2018-12-01"
                  }
            }
    p_response      响应json
              {
                "code": "SUCCESS",
                "data": {
                  "activityCode": "BI_KT",
                  "activityName": "",
                  "activityType": "DMC",
                  "processCode": "process",
                  "processName": "DMC报表权限申请流程",
                  "dimensionName": "月",
                  "dimensionCode": "mon",
                  "dimensionValues": [{
                    "dimensionValue": "1",
                    "duringTimes": [{
                      "code": "max",
                      "name": "最大时间",
                      "count": 1000
                    }, {
                      "code": "avg",
                      "name": "平均时间",
                      "count": 1000
                    }]
                  }, {
                    "dimensionValue": "2",
                    "instanceCounts": [{
                      "code": "max",
                      "name": "最大时间",
                      "count": 1000
                    }, {
                      "code": "avg",
                      "name": "平均时间",
                      "count": 1000
                    }]
                  }]
                }
              }
  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  procedure proc_process_act_dur_group(p_request  IN CLOB,
                                       x_response OUT CLOB) is
    v_request       json;
    v_response      pl_json := pl_json;
    v_group         varchar2(30);
    v_group_ls      json_list := json_list();
    v_type_ls       json_list := json_list();
    v_type          varchar2(300);
    v_type_name     varchar2(300);
    v_group_obj     json;
    v_json          json := json();
    v_date_format   varchar2(30);
    v_value_code    varchar2(30);
    v_start_date    varchar2(30);
    v_end_date      varchar2(30);
    v_item          pl_json;
    v_type_item     pl_json;
    v_system_code   dfnd_app.system_code%TYPE;
    v_process_code  dbpm_ba_process.process_code%TYPE;
    v_activity_code dbpm_ba_process_activity.activity_code%TYPE;
    v_activity_name dbpm_ba_process_activity.activity_name%TYPE;
    v_activity_type dbpm_ba_process_activity.activity_type%TYPE;
    v_process_name  dbpm_ba_process.process_name%TYPE;
    v_during_time   number;
    v_au_sys_code   varchar2(300);
    v_user          varchar2(100);
    v_role          varchar2(100);
    v_count         number;
    cursor v_param_value_cur(p_user_code varchar2) is
      select dr.role_code,
             dr.role_name,
             drp.data_source_code,
             t.param_value,
             drp.param_name,
             drm.member_code
        from dbpm_role_member_params t,
             dbpm_role_params        drp,
             dbpm_role_members       drm,
             dbpm_roles              dr
       where t.param_id = drp.param_id
         and t.member_id = drm.member_id
         and drp.role_id = dr.role_id
         and drm.role_id = dr.role_id
         and dr.role_code = 'plat_admin'
         and lower(drm.member_code) = p_user_code;
  begin
    v_request       := json(p_request, 'OBJECT');
    v_system_code   := v_request.get('systemCode').get_string;
    v_process_code  := v_request.get('processCode').get_string;
    v_activity_code := v_request.get('activityCode').get_string;
    v_group         := v_request.get('group').get_string;
    if v_process_code is null then
      v_response.fail('流程编号为空，请重新输入');
      x_response := v_response.to_json;
      return;
    end if;
    v_start_date := v_request.get('startDate').get_string;
    v_end_date   := v_request.get('endDate').get_string;
    --获取日期格式
    if v_request.get('date_format') is null then
      v_value_code := 'default';
    else
      v_value_code := v_request.get('date_format').get_string;
    end if;
    begin
      v_date_format := func_get_data_value('oracle_date_format',
                                           v_value_code);
    exception
      when others then
        v_response.fail('查询日期格式值出错，请稍后再试');
        x_response := v_response.to_json;
        return;
    end;
    --检查日期格式
    if func_check_date(v_start_date, v_end_date, v_date_format) then
      --判断角色
      for v_row in v_param_value_cur(v_user) loop
        if v_row.data_source_code = 'admin_type' then
          v_role := v_row.param_value;
        end if;
        if v_row.data_source_code = 'DbpmSysCode' then
          v_au_sys_code := v_row.param_value;
        end if;
      end loop;
      --判断权限
      if (v_role = 'system' and v_system_code <> v_au_sys_code) or
         v_role = 'process' then
        v_response.fail('权限不足！');
        x_response := v_response.to_json;
        return;
      elsif v_role = 'plat' then
        --全平台获取当前流程的系统
        select max(t.system_code)
          into v_au_sys_code
          from dbpm_ba_process t
         where t.process_code = v_process_code;
      end if;
      select count(1)
        into v_count
        from dbpm_ba_process_activity t, dbpm_ba_process dbp
       where t.process_id = dbp.process_id
         and dbp.system_code = v_system_code
         and t.process_code = v_process_code
         and t.activity_code = v_activity_code;
      if v_count <= 0 then
        v_response.fail('权限不足！');
        x_response := v_response.to_json;
        return;
      end if;
      begin
        select distinct t.activity_name, t.activity_type, dbp.process_name
          into v_activity_name, v_activity_type, v_process_name
          from dbpm_ba_process_activity t, dbpm_ba_process dbp
         where t.process_id = dbp.process_id
           and t.process_code = v_process_code
           and t.activity_code = v_activity_code
           and dbp.system_code = v_system_code;
      exception
        when others then
          v_response.fail('活动编号错误，请重新输入');
          x_response := v_response.to_json;
      end;
      v_response.set_value('activityCode', v_activity_code);
      v_response.set_value('activityName', v_activity_name);
      v_response.set_value('activityType', v_activity_type);
      v_response.set_value('processCode', v_process_code);
      v_response.set_value('processName', v_process_name);
      v_response.set_value('dimensionName',
                           func_get_data_value('date_groups', v_group));
      v_response.set_value('dimensionCode', v_group);
      v_group_ls := func_get_date_group(v_group,
                                        v_start_date,
                                        v_end_date,
                                        v_date_format);

      --循环组
      for i in 1 .. v_group_ls.count loop
        v_item      := pl_json;
        v_group_obj := json(v_group_ls.get(i));
        v_item.set_value('dimensionValue', v_group_obj.get_string('name'));
        --如果没有传状态，查询全部状态
        if v_type_ls is null or v_type_ls.count <= 0 then
          v_json.put('name', '最大时间');
          v_json.put('code', 'max');
          v_type_ls.append(v_json.to_json_value);
          v_json.put('name', '平均时间');
          v_json.put('code', 'avg');
          v_type_ls.append(v_json.to_json_value);
        end if;
        --遍历状态
        for j in 1 .. v_type_ls.count loop
          v_json      := json(v_type_ls.get(j));
          v_type      := v_json.get('code').get_string;
          v_type_name := v_json.get('name').get_string;
          begin
            execute immediate 'select round(' || v_type ||
                              '(to_number(to_date(to_char(t.end_time, ''yyyy-mm-dd hh24:mi:ss''),
                             ''yyyy-mm-dd hh24:mi:ss'') -
                     to_date(to_char(t.start_time,
                                     ''yyyy-mm-dd hh24:mi:ss''),
                             ''yyyy-mm-dd hh24:mi:ss''))),2) during_time
  from dbpm_ba_process_instance_act t,dbpm_ba_process dbp
 where t.process_id = dbp.process_id
   and dbp.system_code = :0
   and dbp.process_code = :1
   and t.activity_code = :2
   and t.end_time >= to_date(:3,:4)
   and t.end_time < to_date(:5,:6)
   and t.end_time is not null
   group by system_code,process_code,activity_code'
              into v_during_time
              using v_system_code, v_process_code, v_activity_code, v_group_obj.get_string('startDate'), v_date_format, v_group_obj.get_string('endDate'), v_date_format;
          exception
            when NO_DATA_FOUND then
              v_during_time := 0;
          end;
          v_type_item := pl_json;
          v_type_item.set_value('code', v_type);
          v_type_item.set_value('name', v_type_name);
          v_type_item.set_value('count', nvl(v_during_time, 0));
          v_item.add_list_item('duringTimes', v_type_item);
        end loop;
        v_response.add_list_item('dimensionValues', v_item);
      end loop;
    else
      v_response.fail('非法日期格式，请重新输入');
    end if;
    x_response := v_response.to_json;
    /*exception
    when others then
      v_response.fail('获取数据失败，请稍后再试');
      x_response := v_response.to_json;*/
  end proc_process_act_dur_group;

  /*==================================================
  Procedure/Function Name :
      proc_process_query_acts
  Description:
      This function perform:
      获取流程信息

  Argument:
     p_request      请求json
          {
              "user": "weblogic",
              "data":
                {
                    "queryKey": "",
                    "processCode": "",
                    "systemCode": ""
                }
          }
     x_response     响应json
          {
              "code": "SUCCESS",
              "data":
              {
                  "processCode": "BI_KT",
                  "processName": "流程名称",
                  "activities": [
                  {
                      "activityCode": "file_up",
                      "activityName": "审核文件上传",
                      "activityType": "task"
                  },
                  {
                      "activityCode": "file_up",
                      "activityName": "审核文件上传",
                      "activityType": "task"
                  }]
              }
          }
  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  procedure proc_process_query_acts(p_request IN CLOB, x_response OUT CLOB) is
    v_request       json;
    v_response      pl_json := pl_json;
    v_process_code  dbpm_ba_process.process_code%TYPE;
    v_process_name  dbpm_ba_process.process_name%TYPE;
    v_system_code   dfnd_app.system_code%TYPE;
    v_au_sys_code   dfnd_app.system_code%TYPE;
    v_activity_type varchar2(300);
    v_item          pl_json;
    v_user          varchar2(100);
    v_role          varchar2(100);
    cursor v_param_value_cur(p_user_code varchar2) is
      select dr.role_code,
             dr.role_name,
             drp.data_source_code,
             t.param_value,
             drp.param_name,
             drm.member_code
        from dbpm_role_member_params t,
             dbpm_role_params        drp,
             dbpm_role_members       drm,
             dbpm_roles              dr
       where t.param_id = drp.param_id
         and t.member_id = drm.member_id
         and drp.role_id = dr.role_id
         and drm.role_id = dr.role_id
         and dr.role_code = 'plat_admin'
         and lower(drm.member_code) = p_user_code;
    cursor v_act_all_cur(p_system_code varchar2, p_process_code varchar2) is
      select distinct t.activity_code, t.activity_name, t.activity_type
        from dbpm_ba_process_activity t, dbpm_ba_process dbp
       where t.process_id = dbp.process_id
         and dbp.system_code = p_system_code
         and t.process_code = p_process_code;

    cursor v_act_cur(p_system_code   varchar2,
                     p_process_code  varchar2,
                     p_activity_type varchar2) is
      select distinct t.activity_code, t.activity_name, t.activity_type
        from dbpm_ba_process_activity t, dbpm_ba_process dbp
       where t.process_id = dbp.process_id
         and dbp.system_code = p_system_code
         and t.process_code = p_process_code
         and lower(t.activity_type) = lower(p_activity_type);
  begin
    v_request      := json(p_request, 'OBJECT');
    v_system_code  := v_request.get('systemCode').get_string;
    v_process_code := v_request.get('processCode').get_string;
    v_user         := json(p_request).get('user').get_string;
    if v_system_code is not null and v_process_code is not null then
      --判断角色
      for v_row in v_param_value_cur(v_user) loop
        if v_row.data_source_code = 'admin_type' then
          v_role := v_row.param_value;
        end if;
        if v_row.data_source_code = 'DbpmSysCode' then
          v_au_sys_code := v_row.param_value;
        end if;
      end loop;
      --判断权限
      if (v_role = 'system' and v_system_code <> v_au_sys_code) or
         v_role = 'process' then
        v_response.fail('权限不足！');
        x_response := v_response.to_json;
        return;
      end if;
      select max(t.process_name)
        into v_process_name
        from dbpm_ba_process t
       where t.system_code = v_system_code
         and t.process_code = v_process_code;
      v_response.set_value('processCode', v_process_code);
      v_response.set_value('processName',
                           nvl(v_process_name, v_process_code));
      --如果activityType没传查询所有
      if v_request.get('activityType') is null or v_request.get('activityType')
        .get_string is null then
        for v_act_all_cur_row in v_act_all_cur(v_system_code,
                                               v_process_code) loop
          v_item := pl_json;
          v_item.set_value('activityCode', v_act_all_cur_row.activity_code);
          v_item.set_value('activityName',
                           nvl(v_act_all_cur_row.activity_name,
                               v_act_all_cur_row.activity_code));
          v_item.set_value('activityType', v_act_all_cur_row.activity_type);
          v_response.add_list_item('activities', v_item);
        end loop;
      else
        v_activity_type := v_request.get('activityType').get_string;
        --如果activityType不为空，根据activityType获取
        for v_act_cur_row in v_act_cur(v_system_code,
                                       v_process_code,
                                       v_activity_type) loop
          v_item := pl_json;
          v_item.set_value('activityCode', v_act_cur_row.activity_code);
          v_item.set_value('activityName',
                           nvl(v_act_cur_row.activity_name,
                               v_act_cur_row.activity_code));
          v_item.set_value('activityType', v_activity_type);
          v_response.add_list_item('activities', v_item);
        end loop;
      end if;
    else
      v_response.fail('参数不能为空，请重新输入');
    end if;
    x_response := v_response.to_json;
    /*exception
    when others then
      v_response.fail('获取数据失败，请稍后再试');
      x_response := v_response.to_json;*/
  end proc_process_query_acts;

  /*==================================================
  Procedure/Function Name :
      proc_task_duringtime
  Description:
      This function perform:
      获取单个系统的实例数量

  Argument:
     p_request      请求json
                    {
                        "user": "a0017702",
                        "data":
                          {
                            "systemCode":"DMC",
                            "processCode":"",
                            "startDate":"2017-12-29",
                            "endDate":"2017-12-31",
                            "orderType":"desc",
                            "size":100
                          }
                    }
    p_response      响应json
                    {
                        "code": "SUCCESS",
                        "data":
                        {
                            "processCode": "JYBZ",
                            "processName": "JYBZ",
                            "activities": [
                            {
                                "activityCode":"",
                                "activityName": "审批文件上传",
                                "approver": "09810938",
                                "approverName": "",
                                "avgDuringtime": "201"
                            },
                            {
                                "activityCode":"",
                                "activityName": "审批文件上传",
                                "approver": "09810938",
                                "approverName": "",
                                "avgDuringtime": "201"
                            }]
                        }
                    }

  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  procedure proc_task_duringtime(p_request IN CLOB, x_response OUT CLOB) is
    v_request       json;
    v_response      pl_json := pl_json;
    v_date_format   varchar2(30);
    v_value_code    varchar2(30);
    v_start_date    varchar2(30);
    v_end_date      varchar2(30);
    v_item          pl_json;
    v_user          varchar2(300);
    v_role          varchar2(30);
    v_au_sys_code   varchar2(30);
    v_size          number;
    v_process_code  dbpm_ba_process.process_code%TYPE;
    v_process_name  dbpm_ba_process.process_name%TYPE;
    v_activity_code dbpm_ba_process_activity.activity_code%TYPE;
    v_activity_name dbpm_ba_process_activity.activity_name%TYPE;
    v_system_code   dfnd_app.system_code%TYPE;
    v_approver_name varchar2(300);
    v_approver      varchar2(300);
    v_during_time   number;
    v_order_type    varchar2(30);
    v_approve_cur   refcur;
    cursor v_param_value_cur(p_user_code varchar2) is
      select dr.role_code,
             dr.role_name,
             drp.data_source_code,
             t.param_value,
             drp.param_name,
             drm.member_code
        from dbpm_role_member_params t,
             dbpm_role_params        drp,
             dbpm_role_members       drm,
             dbpm_roles              dr
       where t.param_id = drp.param_id
         and t.member_id = drm.member_id
         and drp.role_id = dr.role_id
         and drm.role_id = dr.role_id
         and dr.role_code = 'plat_admin'
         and lower(drm.member_code) = p_user_code;
  begin
    --获取参数
    v_request       := json(p_request, 'OBJECT');
    v_user          := json(p_request).get('user').get_string;
    v_system_code   := v_request.get('systemCode').get_string;
    v_process_code  := v_request.get('processCode').get_string;
    v_activity_code := v_request.get('activityCode').get_string;
    v_start_date    := v_request.get('startDate').get_string;
    v_end_date      := v_request.get('endDate').get_string;
    v_order_type    := v_request.get('orderType').get_string;
    v_size          := v_request.get('size').get_number;
    --获取日期格式
    if v_request.get('date_format') is null then
      v_value_code := 'default';
    else
      v_value_code := v_request.get('date_format').get_string;
    end if;
    begin
      v_date_format := func_get_data_value('oracle_date_format',
                                           v_value_code);
    exception
      when others then
        v_response.fail('查询日期格式值出错，请稍后再试');
        x_response := v_response.to_json;
        return;
    end;
    if func_check_date(v_start_date, v_end_date, v_date_format) then
      --判断角色
      for v_row in v_param_value_cur(v_user) loop
        if v_row.data_source_code = 'admin_type' then
          v_role := v_row.param_value;
        end if;
        if v_row.data_source_code = 'DbpmSysCode' then
          v_au_sys_code := v_row.param_value;
        end if;
      end loop;
      --判断权限
      if (v_role = 'system' and v_system_code <> v_au_sys_code) or
         v_role = 'process' then
        v_response.fail('权限不足！');
        x_response := v_response.to_json;
        return;
      end if;
      --查询流程数据
      begin
        select x.process_name
          into v_process_name
          from (select nvl(t.process_name, t.process_code) process_name
                  from dbpm_ba_process t
                 where t.process_code = v_process_code
                   and t.system_code = v_system_code
                 order by t.process_name) x
         where rownum = 1;
      exception
        when others then
          v_response.fail('流程编号不存在，请重新输入！');
          x_response := v_response.to_json;
          return;
      end;
      --检查排序类型是否正确
      if v_order_type is null or
         (lower(v_order_type) <> 'desc' and lower(v_order_type) <> 'asc') then
        v_response.fail('排序类型错误，请重新输入！');
        x_response := v_response.to_json;
        return;
      end if;
      v_response.set_value('processCode', v_process_code);
      v_response.set_value('processName',
                           nvl(v_process_name, v_process_code));
      --遍历流程活动
      open v_approve_cur for 'select activity_code,
       activity_name,
       updatedby,
       during_time
from (select t.activity_code,
             t.activity_name,
             t.updatedby,
             round(avg(to_number(to_date(to_char(t.end_time,
                                           ''yyyy-mm-dd hh24:mi:ss''),
                                   ''yyyy-mm-dd hh24:mi:ss'') -
                           to_date(to_char(t.start_time,
                                           ''yyyy-mm-dd hh24:mi:ss''),
                                   ''yyyy-mm-dd hh24:mi:ss''))),
             2) during_time
  from dbpm_ba_process_instance_act t, dbpm_ba_process dbp
 where t.process_id = dbp.process_id
   and t.end_time >= to_date(:0, :1)
   and t.end_time < to_date(:2, :3)
   and t.end_time is not null
   and dbp.process_code = :4
   and dbp.system_code = :5
   and t.activity_code = :6
 group by t.activity_code, t.activity_name, t.updatedby
 order by during_time desc) where rownum <= :7'
        using v_start_date, v_date_format, v_end_date, v_date_format, v_process_code, v_system_code, v_activity_code, v_size;
      loop
        fetch v_approve_cur
          into v_activity_code, v_activity_name, v_approver, v_during_time;
        exit when v_approve_cur%notfound;
        v_item := pl_json;
        v_item.set_value('activityCode', v_activity_code);
        v_item.set_value('activityName',
                         nvl(v_activity_name, v_activity_code));
        v_item.set_value('approver', v_approver);
        select max(t.employee_name)
          into v_approver_name
          from dfnd_employees t
         where lower(t.employee_code) = lower(v_approver)
           and rownum = 1;
        if v_approver_name is null then
          v_approver_name := v_approver;
        end if;
        v_item.set_value('approverName', v_approver_name);
        v_item.set_value('avgDuringtime', v_during_time);
        v_response.add_list_item('activities', v_item);
      end loop;
    else
      v_response.fail('非法日期格式，请重新输入');
    end if;
    x_response := v_response.to_json;
    /*exception
    when others then
      v_response.fail('获取数据失败，请稍后再试');
      x_response := v_response.to_json;*/
  end proc_task_duringtime;

  /*==================================================
  Procedure/Function Name :
      proc_task_user_duringtime
  Description:
      This function perform:
      获取流程任务节点某个用户审批时间最长/最短的TOP10任务

  Argument:
     p_request      请求json
                    {
                        "user": "a0017702",
                        "data":
                            {
                              "systemCode":"DMC",
                              "processCode":"",
                              "activityCode":"",
                              "startDate":"2017-12-29",
                              "endDate":"2017-12-31",
                              "orderType":"desc",
                              "approver":"",
                              "size":100
                            }
                    }
    p_response      响应json
                    {
                        "code": "SUCCESS",
                        "data":
                        {
                            "processCode":"",
                            "processName":"",
                            "activities": [
                            {
                                "activityName": "审批文件上传",
                                "activityType": "task",
                                "approver": "09810938",
                                "approverName": "",
                                "taskId": "",
                                "instanceId": "",
                                "formNo":"",
                                "approveTime":"2017-06-05 16:00:00",
                                "duringTime": "201"
                            },
                            {
                                "activityName": "审批文件上传",
                                "activityType": "task",
                                "approver": "09810938",
                                "approverName": "",
                                "taskId": "",
                                "instanceId": "",
                                "formNo":"",
                                "approveTime":"2017-06-05 16:00:00",
                                "duringTime": "201"
                            }]
                        }
                    }
  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  procedure proc_task_user_duringtime(p_request  IN CLOB,
                                      x_response OUT CLOB) is
    v_request         json;
    v_response        pl_json := pl_json;
    v_date_format     varchar2(30);
    v_value_code      varchar2(30);
    v_start_date      varchar2(30);
    v_end_date        varchar2(30);
    v_item            pl_json;
    v_user            varchar2(300);
    v_role            varchar2(30);
    v_au_sys_code     varchar2(30);
    v_size            number;
    v_process_code    dbpm_ba_process.process_code%TYPE;
    v_process_name    dbpm_ba_process.process_name%TYPE;
    v_activity_code   dbpm_ba_process_activity.activity_code%TYPE;
    v_activity_name   dbpm_ba_process_activity.activity_name%TYPE;
    v_system_code     dfnd_app.system_code%TYPE;
    v_approver_name   varchar2(300);
    v_approver        varchar2(300);
    v_during_time     number;
    v_order_type      varchar2(30);
    v_task_id         varchar2(300);
    v_instance_id     varchar2(300);
    v_process_form_id varchar2(300);
    v_end_time        varchar2(30);
    v_approve_cur     refcur;
    cursor v_param_value_cur(p_user_code varchar2) is
      select dr.role_code,
             dr.role_name,
             drp.data_source_code,
             t.param_value,
             drp.param_name,
             drm.member_code
        from dbpm_role_member_params t,
             dbpm_role_params        drp,
             dbpm_role_members       drm,
             dbpm_roles              dr
       where t.param_id = drp.param_id
         and t.member_id = drm.member_id
         and drp.role_id = dr.role_id
         and drm.role_id = dr.role_id
         and dr.role_code = 'plat_admin'
         and lower(drm.member_code) = p_user_code;
  begin
    --获取参数
    v_request       := json(p_request, 'OBJECT');
    v_user          := json(p_request).get('user').get_string;
    v_system_code   := v_request.get('systemCode').get_string;
    v_process_code  := v_request.get('processCode').get_string;
    v_activity_code := v_request.get('activityCode').get_string;
    v_start_date    := v_request.get('startDate').get_string;
    v_end_date      := v_request.get('endDate').get_string;
    v_order_type    := v_request.get('orderType').get_string;
    v_approver      := v_request.get('approver').get_string;
    v_size          := v_request.get('size').get_number;
    --获取日期格式
    if v_request.get('date_format') is null then
      v_value_code := 'default';
    else
      v_value_code := v_request.get('date_format').get_string;
    end if;
    begin
      v_date_format := func_get_data_value('oracle_date_format',
                                           v_value_code);
    exception
      when others then
        v_response.fail('查询日期格式值出错，请稍后再试');
        x_response := v_response.to_json;
        return;
    end;
    if func_check_date(v_start_date, v_end_date, v_date_format) then
      --判断角色
      for v_row in v_param_value_cur(v_user) loop
        if v_row.data_source_code = 'admin_type' then
          v_role := v_row.param_value;
        end if;
        if v_row.data_source_code = 'DbpmSysCode' then
          v_au_sys_code := v_row.param_value;
        end if;
      end loop;
      --判断权限
      if (v_role = 'system' and v_system_code <> v_au_sys_code) or
         v_role = 'process' then
        v_response.fail('权限不足！');
        x_response := v_response.to_json;
        return;
      end if;
      --查询流程数据
      begin
        select x.process_name
          into v_process_name
          from (select nvl(t.process_name, t.process_code) process_name
                  from dbpm_ba_process t
                 where t.process_code = v_process_code
                   and t.system_code = v_system_code
                 order by t.process_name) x
         where rownum = 1;
      exception
        when others then
          v_response.fail('流程编号不存在，请重新输入！');
          x_response := v_response.to_json;
          return;
      end;
      --检查排序类型是否正确
      if v_order_type is null or
         (lower(v_order_type) <> 'desc' and lower(v_order_type) <> 'asc') then
        v_response.fail('排序类型错误，请重新输入！');
        x_response := v_response.to_json;
        return;
      end if;
      v_response.set_value('processCode', v_process_code);
      v_response.set_value('processName',
                           nvl(v_process_name, v_process_code));
      --遍历流程活动
      open v_approve_cur for 'select activity_code,
       activity_name,
       updatedby,
       task_id,
       instance_id,
       process_form_id,
       end_time,
       during_time
  from (select t.activity_code,
               t.activity_name,
               t.updatedby,
               t.task_id,
               t.instance_id,
               ins.process_form_id,
               to_char(t.end_time,:0) end_time,
               round(to_number(to_date(to_char(t.end_time,
                                               ''yyyy-mm-dd hh24:mi:ss''),
                                       ''yyyy-mm-dd hh24:mi:ss'') -
                               to_date(to_char(t.start_time,
                                               ''yyyy-mm-dd hh24:mi:ss''),
                                       ''yyyy-mm-dd hh24:mi:ss'')),
                     2) during_time
          from dbpm_ba_process_instance_act t,
               dbpm_ba_process              dbp,
               dbpm_ba_process_instance     ins
         where t.instance_id = ins.instance_id
           and t.process_id = dbp.process_id
           and t.end_time >= to_date(:1, :2)
           and t.end_time < to_date(:3, :4)
           and t.end_time is not null
           and dbp.process_code = :5
           and dbp.system_code = :6
           and t.activity_code = :7
           and lower(t.updatedby) = lower(:8)
         order by during_time desc)
 where rownum <= :9'
        using v_date_format, v_start_date, v_date_format, v_end_date, v_date_format, v_process_code, v_system_code, v_activity_code, v_approver, v_size;
      loop
        fetch v_approve_cur
          into v_activity_code,
               v_activity_name,
               v_approver,
               v_task_id,
               v_instance_id,
               v_process_form_id,
               v_end_time,
               v_during_time;
        exit when v_approve_cur%notfound;
        v_item := pl_json;
        v_item.set_value('activityCode', v_activity_code);
        v_item.set_value('activityName',
                         nvl(v_activity_name, v_activity_code));
        v_item.set_value('approver', v_approver);
        select max(t.employee_name)
          into v_approver_name
          from dfnd_employees t
         where lower(t.employee_code) = lower(v_approver)
           and rownum = 1;
        if v_approver_name is null then
          v_approver_name := v_approver;
        end if;
        v_item.set_value('approverName', v_approver_name);
        v_item.set_value('taskId', v_task_id);
        v_item.set_value('instanceId', v_instance_id);
        v_item.set_value('formNo', v_process_form_id);
        v_item.set_value('approveTime', v_end_time);
        v_item.set_value('duringTime', v_during_time);
        v_response.add_list_item('activities', v_item);
      end loop;
    else
      v_response.fail('非法日期格式，请重新输入');
    end if;
    x_response := v_response.to_json;
    /*exception
    when others then
      v_response.fail('获取数据失败，请稍后再试');
      x_response := v_response.to_json;*/
  end proc_task_user_duringtime;

  /*==================================================
  Procedure/Function Name :
      proc_query_data_source_values
  Description:
      This function perform:
      动态查询数据源的值
  Argument:
     p_request： 请求参数
     x_response： 响应结果
  History:
      1.00  2018-02-01  Echo.Zeng  Creation
  ==================================================*/
  PROCEDURE proc_query_data_source_values(p_request  CLOB,
                                          x_response OUT CLOB) IS
    v_api              VARCHAR2(100) := 'proc_query_data_source_values';
    v_request          json;
    v_response         pl_json := pl_json;
    v_data_source_code VARCHAR2(100);
    v_dsc_ls           json_list;
    v_data_value       pl_json;
    cursor v_data_source_cur(p_data_source_code varchar2) is
     select t.value_code,t.value_name,t.status,t.display_seq
      from dbpm_data_source_values t
     where t.data_source_code = p_data_source_code;
    v_symbol          varchar2(300);
  BEGIN
    v_request := json(p_request, 'OBJECT');
    v_dsc_ls := json_list(v_request.get('dataSourceCodes'));
    for i in 1 .. v_dsc_ls.count loop
      v_data_source_code := v_dsc_ls.get(i).get_string;
      if v_data_source_code is not null then
        for v_row in v_data_source_cur(v_data_source_code) loop
          if v_data_source_code = 'warning_rule_op' then
            if v_row.value_code = 'EQ' then
              v_symbol := '=';
            elsif v_row.value_code = 'N_EQ' then
              v_symbol := '!=';
            elsif v_row.value_code = 'GT' then
              v_symbol := '>';
            elsif v_row.value_code = 'GT_EQ' then
              v_symbol := '>=';
            elsif v_row.value_code = 'LT' then
              v_symbol := '<';
            elsif v_row.value_code = 'LT_EQ' then
              v_symbol := '<=';
            elsif v_row.value_code = 'IN' then
              v_symbol := 'IN';
            elsif v_row.value_code = 'N_IN' then
              v_symbol := 'NOT IN';
            end if;
          end if;
          v_data_value := pl_json();
          v_data_value.set_value('valueCode', v_row.value_code);
          v_data_value.set_value('valueName', v_row.value_name);
          v_data_value.set_value('symbol', v_symbol);
          v_data_value.set_value('status', v_row.status);
          v_data_value.set_value('displaySeq', v_row.display_seq);
          v_response.add_list_item(v_data_source_code, v_data_value);
        end loop;
      else
        v_response.fail('数据源编号不能为空！');
      end if;
    end loop;
    x_response := v_response.to_json;
  EXCEPTION
    WHEN OTHERS THEN
      v_response.fail('接口' || v_api || '发生错误,错误原因:' || SQLERRM);
      x_response := v_response.to_json;
  END proc_query_data_source_values;
  /*==================================================
  Procedure/Function Name :
      func_get_data_value
  Description:
      This function perform:
      获取数据字典中的值

  Argument:
     --入参
     p_data_source_code 数据源编号
     p_value_code       值编号
     --出参

  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  function func_get_data_value(p_data_source_code in varchar2,
                               p_value_code       in varchar2)
    return varchar2 is
    v_value_name varchar2(300);
  begin
    select max(v.value_name)
      into v_value_name
      from dcld_data_value_v v
     where v.data_source_code = p_data_source_code
       and v.value_code = p_value_code
       and v.ds_status = 'Y'
       and v.dsv_status = 'Y';
    return v_value_name;
  end func_get_data_value;

  /*==================================================
  Procedure/Function Name :
      func_check_date
  Description:
      This function perform:
      检查日期：
      1、日期格式
      2、结束日期必须大于开始日期
  Argument:
     --入参
     p_start_date   开始日期
     p_end_date     结束日期
     p_date_format  日期格式
     --出参
     boolean 是否正确
  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  function func_check_date(p_start_date  in varchar2,
                           p_end_date    in varchar2,
                           p_date_format in varchar2) return boolean as
    bool    boolean := false;
    v_count number;
  begin
    select count(1)
      into v_count
      from dual t
     where to_date(p_end_date, p_date_format) >=
           to_date(p_start_date, p_date_format);
    if v_count > 0 then
      bool := true;
    end if;
    return bool;
  exception
    when others then
      return bool;
  end func_check_date;
  /*==================================================
  Procedure/Function Name :
      func_get_date_group
  Description:
      This function perform:
      获取日期组


  Argument:
     --入参
     p_group_code       组编号
     --出参
     组format值
  History:
      1.00  2018-01-11    Echo.Zeng
  ==================================================*/
  function func_get_date_group(p_group_code in varchar2,
                               p_start_date in varchar2,
                               p_end_date   in varchar2,
                               p_date_fmt   in varchar2) return json_list is
    v_group_list json_list := json_list();
    v_json_value json := json();
  begin

    if p_group_code is null or p_group_code = 'day' then
      --按天分组
      --首先算出第一组的区间值
      v_json_value.put('startDate',
                       to_char(trunc(to_date(p_start_date, p_date_fmt),
                                     'DD'),
                               p_date_fmt));
      v_json_value.put('endDate',
                       to_char(trunc(to_date(p_start_date, p_date_fmt) + 1,
                                     'DD'),
                               p_date_fmt));
      --区间值显示名称
      v_json_value.put('name',
                       substr(to_char(trunc(to_date(p_start_date,
                                                    p_date_fmt),
                                            'DD'),
                                      p_date_fmt),
                              1,
                              10));
      v_group_list.append(v_json_value.to_json_value);
      --遍历剩下的组
      for i in 1 .. to_number(trunc(to_date(p_end_date, p_date_fmt), 'DD') -
                              trunc(to_date(p_start_date, p_date_fmt), 'DD')) loop
        v_json_value.put('startDate',
                         to_char(trunc(to_date(p_start_date, p_date_fmt) + i,
                                       'DD'),
                                 p_date_fmt));
        v_json_value.put('endDate',
                         to_char(trunc(to_date(p_start_date, p_date_fmt) + i + 1,
                                       'DD'),
                                 p_date_fmt));
        --区间值显示名称
        v_json_value.put('name',
                         substr(to_char(trunc(to_date(p_start_date,
                                                      p_date_fmt) + i,
                                              'DD'),
                                        p_date_fmt),
                                1,
                                10));
        v_group_list.append(v_json_value.to_json_value);
      end loop;
    elsif p_group_code = 'month' then
      --按月分组
      --首先算出第一组的区间值
      v_json_value.put('startDate',
                       to_char(trunc(to_date(p_start_date, p_date_fmt),
                                     'MON'),
                               p_date_fmt));
      v_json_value.put('endDate',
                       to_char(add_months(trunc(to_date(p_start_date,
                                                        p_date_fmt),
                                                'MON'),
                                          1),
                               p_date_fmt));
      --区间值显示名称
      v_json_value.put('name',
                       substr(to_char(trunc(to_date(p_start_date,
                                                    p_date_fmt),
                                            'MON'),
                                      p_date_fmt),
                              1,
                              7));
      v_group_list.append(v_json_value.to_json_value);
      --遍历剩下的组
      for i in 1 .. months_between(trunc(to_date(p_end_date, p_date_fmt),
                                         'MON'),
                                   trunc(to_date(p_start_date, p_date_fmt),
                                         'MON')) loop
        v_json_value.put('startDate',
                         to_char(add_months(trunc(to_date(p_start_date,
                                                          p_date_fmt),
                                                  'MON'),
                                            i),
                                 p_date_fmt));
        v_json_value.put('endDate',
                         to_char(add_months(trunc(to_date(p_start_date,
                                                          p_date_fmt),
                                                  'MON'),
                                            i + 1),
                                 p_date_fmt));
        v_json_value.put('name',
                         substr(to_char(add_months(trunc(to_date(p_start_date,
                                                                 p_date_fmt),
                                                         'MON'),
                                                   i),
                                        p_date_fmt),
                                1,
                                7));
        v_group_list.append(v_json_value.to_json_value);
      end loop;
    elsif p_group_code = 'week' then
      --按周分组
      --首先算出第一组的区间值
      v_json_value.put('startDate',
                       to_char(trunc(to_date(p_start_date, p_date_fmt),
                                     'IW'),
                               p_date_fmt));
      v_json_value.put('endDate',
                       to_char(trunc(to_date(p_start_date, p_date_fmt),
                                     'IW') + 7,
                               p_date_fmt));
      --区间值显示名称
      v_json_value.put('name',
                       substr(to_char(trunc(to_date(p_start_date,
                                                    p_date_fmt),
                                            'IW'),
                                      p_date_fmt),
                              1,
                              10) || '~' || substr(to_char(trunc(to_date(p_start_date,
                                                                         p_date_fmt),
                                                                 'IW') + 7,
                                                           p_date_fmt),
                                                   1,
                                                   10));
      v_group_list.append(v_json_value.to_json_value);
      --遍历剩下的组
      for i in 1 .. to_number(trunc(to_date(p_end_date, p_date_fmt), 'IW') -
                              trunc(to_date(p_start_date, p_date_fmt), 'IW') + 7) / 7 loop
        v_json_value.put('startDate',
                         to_char(trunc(to_date(p_start_date, p_date_fmt),
                                       'IW') + i * 7,
                                 p_date_fmt));
        v_json_value.put('endDate',
                         to_char(trunc(to_date(p_start_date, p_date_fmt),
                                       'IW') + (i + 1) * 7,
                                 p_date_fmt));
        v_json_value.put('name',
                         substr(to_char(trunc(to_date(p_start_date,
                                                      p_date_fmt),
                                              'IW') + i * 7,
                                        p_date_fmt),
                                1,
                                10) || '~' ||
                         substr(to_char(trunc(to_date(p_start_date,
                                                      p_date_fmt),
                                              'IW') + (i + 1) * 7,
                                        p_date_fmt),
                                1,
                                10));
        v_group_list.append(v_json_value.to_json_value);
      end loop;
    elsif p_group_code = 'year' then
      --按年分组
      --首先算出第一组的区间值
      v_json_value.put('startDate',
                       to_char(trunc(to_date(p_start_date, p_date_fmt),
                                     'YYYY'),
                               p_date_fmt));
      v_json_value.put('endDate',
                       to_char(add_months(trunc(to_date(p_start_date,
                                                        p_date_fmt),
                                                'YYYY'),
                                          12),
                               p_date_fmt));
      --区间值显示名称
      v_json_value.put('name',
                       substr(to_char(trunc(to_date(p_start_date,
                                                    p_date_fmt),
                                            'YYYY'),
                                      p_date_fmt),
                              1,
                              4));
      v_group_list.append(v_json_value.to_json_value);
      --遍历剩下的组
      for i in 1 .. months_between(trunc(to_date(p_end_date, p_date_fmt),
                                         'YYYY'),
                                   trunc(to_date(p_start_date, p_date_fmt),
                                         'YYYY')) / 12 loop
        v_json_value.put('startDate',
                         to_char(add_months(trunc(to_date(p_start_date,
                                                          p_date_fmt),
                                                  'YYYY'),
                                            i * 12),
                                 p_date_fmt));
        v_json_value.put('endDate',
                         to_char(add_months(trunc(to_date(p_start_date,
                                                          p_date_fmt),
                                                  'YYYY'),
                                            (i + 1) * 12),
                                 p_date_fmt));
        v_json_value.put('name',
                         substr(to_char(add_months(trunc(to_date(p_start_date,
                                                                 p_date_fmt),
                                                         'YYYY'),
                                                   i * 12),
                                        p_date_fmt),
                                1,
                                4));
        v_group_list.append(v_json_value.to_json_value);
      end loop;
    elsif p_group_code = 'quarter' then
      --按季度分组
      --首先算出第一组的区间值
      v_json_value.put('startDate',
                       to_char(trunc(to_date(p_start_date, p_date_fmt), 'Q'),
                               p_date_fmt));
      v_json_value.put('endDate',
                       to_char(add_months(trunc(to_date(p_start_date,
                                                        p_date_fmt),
                                                'Q'),
                                          3),
                               p_date_fmt));
      --区间值显示名称
      v_json_value.put('name',
                       substr(to_char(trunc(to_date(p_start_date,
                                                    p_date_fmt),
                                            'Q'),
                                      p_date_fmt),
                              1,
                              10) || '~' || substr(to_char(add_months(trunc(to_date(p_start_date,
                                                                                    p_date_fmt),
                                                                            'Q'),
                                                                      3),
                                                           p_date_fmt),
                                                   1,
                                                   10));
      v_group_list.append(v_json_value.to_json_value);
      --遍历剩下的组
      for i in 1 .. months_between(trunc(to_date(p_end_date, p_date_fmt),
                                         'YYYY'),
                                   trunc(to_date(p_start_date, p_date_fmt),
                                         'YYYY')) / 3 loop
        v_json_value.put('startDate',
                         to_char(add_months(trunc(to_date(p_start_date,
                                                          p_date_fmt),
                                                  'Q'),
                                            i * 3),
                                 p_date_fmt));
        v_json_value.put('endDate',
                         to_char(add_months(trunc(to_date(p_start_date,
                                                          p_date_fmt),
                                                  'Q'),
                                            (i + 1) * 3),
                                 p_date_fmt));
        v_json_value.put('name',
                         substr(to_char(add_months(trunc(to_date(p_start_date,
                                                                 p_date_fmt),
                                                         'Q'),
                                                   i * 3),
                                        p_date_fmt),
                                1,
                                10) || '~' ||
                         substr(to_char(add_months(trunc(to_date(p_start_date,
                                                                 p_date_fmt),
                                                         'Q'),
                                                   (i + 1) * 3),
                                        p_date_fmt),
                                1,
                                10));
        v_group_list.append(v_json_value.to_json_value);
      end loop;
    elsif p_group_code = 'hour' then
      --按小时分组
      --首先算出第一组的区间值
      v_json_value.put('startDate',
                       to_char(trunc(to_date(p_start_date, p_date_fmt),
                                     'HH24'),
                               p_date_fmt));
      v_json_value.put('endDate',
                       to_char(trunc(to_date(p_start_date, p_date_fmt),
                                     'HH24') + (1 / 24),
                               p_date_fmt));
      --区间值显示名称
      v_json_value.put('name',
                       to_char(trunc(to_date(p_start_date, p_date_fmt),
                                     'HH24'),
                               p_date_fmt));
      v_group_list.append(v_json_value.to_json_value);
      --遍历剩下的组
      for i in 1 .. (trunc(to_date(p_end_date, p_date_fmt), 'HH24') -
                    trunc(to_date(p_start_date, p_date_fmt), 'HH24')) * 24 loop
        v_json_value.put('startDate',
                         to_char(trunc(to_date(p_start_date, p_date_fmt),
                                       'HH24') + i / 24,
                                 p_date_fmt));
        v_json_value.put('endDate',
                         to_char(trunc(to_date(p_start_date, p_date_fmt),
                                       'HH24') + (i + 1) / 24,
                                 p_date_fmt));
        v_json_value.put('name',
                         to_char(trunc(to_date(p_start_date, p_date_fmt),
                                       'HH24') + i / 24,
                                 p_date_fmt));
        v_group_list.append(v_json_value.to_json_value);
      end loop;
    end if;
    return v_group_list;
  end func_get_date_group;

end DBPA_BA_CORE_PKG;

/

